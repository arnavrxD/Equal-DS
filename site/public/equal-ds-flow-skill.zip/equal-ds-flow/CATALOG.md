# Equal AI Design System: full catalog

> Everything Claude needs to design and build Equal AI screens and flows for web (React) and Android (Jetpack Compose). Generated from the sources by scripts/build-llms.mjs; do not edit by hand.

## Rules and recipe (CLAUDE.md)

This repo is the Equal AI design system for **web (React)** and **Android (Jetpack Compose only)**.
It covers tokens, components, screens, flows and the docs site. Read this file before you design or
build anything here. The catalog of every component, prop, token, asset, icon and flow is in
`site/public/llms-full.txt`, which `npm run llms` regenerates. Search it first; reuse before you add.
The same catalog is an MCP server (tools `search`, `get`, `list`) at https://equal-ds.vercel.app/mcp,
or locally with `npm run mcp`. `npm run llms` also rebuilds its index (`api/_index.json`).

### The rules (these always apply)

The reason behind every rule is in `site/src/data/decisions.ts` (the site’s Rules & decisions page).
When a design and the system disagree, check it first; when a rule changes, update it there too.

**Type and colour**
- **Typography:** DM Sans only, through the 12 type tokens (`<Text variant>` / `EqualTheme.type`).
  Nothing is set in Lora or any other font. Weights: 400, 500, 600 (SemiBold) and 700.
- **Colour:** only tokens. Never put a hex value in a component.
  - **New colour:** add it to `tokens/tokens.json` with `"derived": true` and a `"why"`, give it light
    and dark values, and check text pairs for AA (4.5:1). Decide colours yourself; don't ask for
    sign-off.
- **Dark mode:** every component and screen works in light and dark. In dark, every green is lime
  (#BAFF29): accents use lime itself, green-tinted surfaces are re-hued to lime, and anything on lime
  is `text/on-action` (black), never white.

**Icons and images**
- **Action cards:** the grey body sits on a white card (never a green card), and every CTA row is
  emoji + label (📤 Send, ✏️ Edit, 👍 Confirm, 🗑️ Delete).
- **Icons:** flat icons are Material Symbols (`scripts/build-icons.mjs`, then `npm run icons`). Action
  chips use emoji, sized to the label font size.
- **Images:** the only images are supplied assets in `assets/`. Everything else is code: logos, seals,
  patterns, rings, progress bars, badges. Never crop an image; trimming transparent margins is fine.
- **Premium (monetization) surfaces:** perk icons are *filled* Material Symbols at 16 dp, painted
  with the gold radial gradient `premium-icon/start` → `premium-icon/end` (`<PremiumIcon>` /
  `PremiumIcon`). Light premium cards sit on the `premium-glow` art; dark ones use the coded
  black-gold gradient. Gold CTAs use `gradient/cta-gold`. Most monetization values (price, coupon, copy, entry point) are experiments: keep them as props.
- **Mascots:** the green mascot illustrations are generated to order. When a screen needs a new one,
  ask for it and show a placeholder.

**Android frame and chrome**
- **Frame:** 390 × 800 dp. Extend only vertically (`StagePhone.height` / `ANDROID_FRAME` on web,
  `EqualFrameWidthDp` / `EqualFrameHeightDp` in Compose).
- **Status bar:** Material 3, 52 dp. Text fields have 12 dp corners.
- **Avatars:** free users get the plain bust; paid users (Unlimited) get the gold background and ring
  (`tier: 'free' | 'paid'`). Saved contacts show their initials on the light-blue disc with the person
  badge at the bottom-right (the signifier for a known contact); unknown and business callers use
  category art.
- **The green orb** (nav FAB) opens the assistant sheet (Global MYA, `AssistantSheet`) on any screen.
  Requests become a short task conversation that ends in a result to confirm. Don't draw the system
  keyboard; just lift the input above it.
- **Call Handling** lives under You → Your assistant. Ask for a permission only at the step that
  needs it. Android draws notifications: `CallNotification` only fills the shell (who, what they want,
  Takeover first), and the wallpaper behind it in docs is coded.
- **Dark-mode You tab:** the cream-gold profile header stays light (its content renders with light
  tokens) as a panel with rounded bottom corners; the status bar sits on the gold.

- **Text inputs that can send:** show the mic while empty and the send arrow as soon as there is text.

**Engineering**
- **Stack:** business logic is Kotlin, UI is Compose, and animations are Lottie JSON (`assets/lottie/`,
  `<Lottie>` / `EqualLottie`). Respect reduced motion everywhere.
- **Experiments are props, not forks.** The Android team A/B tests monetization, so price, copy,
  coupon, entry touchpoint and similar knobs are props on the same screen.
- **Paywall experiments** (`MonetizationExperiments.tsx`): touchpoints and payment states are props on
  Home / Chat / Paywall (`planExpired`, `homeNotice`, `official`, `lockedActions`, `paywallSheet`,
  `paymentProcessing`, `PaymentResultScreen`). While a payment is processing, every surface says so
  and the paywall CTA is disabled.

### Where things live

| What | Web | Android |
|---|---|---|
| Tokens (generated) | `web/src/tokens/` | `compose/.../tokens/EqualTokens.kt` |
| Components | `web/src/components/<Name>.tsx` + `.css`, exported from `web/src/index.ts` | `compose/equal-ds/src/main/java/ai/equal/ds/components/` |
| Screens | `web/src/screens/*.tsx` | `compose/.../catalog/*.kt` |
| Assets | `assets/<name>.webp\|svg` + `web/src/foundations/Asset.tsx` | `res/drawable-xxxhdpi/ds_asset_*.webp`, `EqualAssets` |
| Docs page per component | `site/src/registry/components.tsx` | snippets in `compose/equal-ds/src/debug/java/ai/equal/ds/snippets/` |
| Flow pages | `site/src/pages/Flow.tsx` + `site/src/app/nav.ts` + `site/src/pages/Screens.tsx` | snippet group `flow-<id>` |

### Recipe: a new flow from a design (PDF, Figma frames or screenshots)

1. **Read the design fully.** Render PDFs at high resolution (`pdftoppm -r 100`) and crop each region.
   List every screen state, every component and every image.
2. **Map it to the system.** For each element, find the existing component in `llms-full.txt`. Only
   build a new component when nothing fits, or extend one with a prop.
3. **List the assets.** Split them into images to supply (3D art, illustrations, mascots) and things to
   code. Ask the designer for any images that are missing. Until they arrive, `<Asset>` shows a
   checkerboard placeholder.
4. **Add assets.**
   - PNG/WebP: a transparent file at least 2000 px into `assets/source/<name>.png`; add its display size
     to `SIZES` in `scripts/build-assets.py`; run `npm run assets`.
   - Register it in `Asset.tsx` (`assetNames` + `assetUsage`) and in `EqualAssets`.
   - SVG: `assets/<name>.svg` for web, and a VectorDrawable at `res/drawable/ds_asset_<name>.xml` for Android.
5. **Tokens:** add any new colours or gradients to `tokens/tokens.json`, then run `npm run tokens`.
6. **Web components:** add a `.tsx` + `.css` pair using only tokens, export it, and give it a docs entry in
   `site/src/registry/components.tsx`: examples with `code`, props, tokens, and do / don't.
7. **Screens:** add props to the revamped screens, or a new screen in `web/src/screens/`.
8. **Flow page:** add the flow to `Flow.tsx`, with states (`key`, `label`, `render`, `code`, and
   `height` when the screen is taller than 800), plus steps and the source. Add it to `nav.ts` and the
   Screens overview cards.
9. **Android:** mirror every component and screen in Compose. Add a snippet for every docs example and
   flow state: `// snippet: <doc id> / <example title>` or `// snippet: flow-<id> / <state key>`.
10. **Verify** with the commands below, and look at every state in light and dark on the site.

### Commands

```bash
npm run site          # docs site at http://localhost:5190 (tokens + snippets + llms first)
npm run tokens        # tokens.json → web + Compose
npm run icons         # icon manifest → web + Compose
npm run assets        # assets/source → web webp + Compose drawable-xxxhdpi
npm run llms          # regenerate site/public/llms*.txt and the Claude skill zip
npx tsc --noEmit      # web typecheck
node scripts/build-snippets.mjs --check   # every docs example has Compose code
cd compose && JAVA_HOME=/opt/homebrew/opt/openjdk@17 ANDROID_HOME=/opt/homebrew/share/android-commandlinetools ./gradlew :equal-ds:compileDebugKotlin :equal-ds:assembleRelease :equal-ds:lintDebug
```

Done means: typecheck clean, `--check` passes, Gradle BUILD SUCCESSFUL, and lint reports
"0 errors, 0 warnings" in `compose/equal-ds/build/reports/lint-results-debug.txt`.

## Rules & decisions (why each rule exists)

### Principles

- **One token file feeds web and Android.** Why: If a value lives in two places it drifts. tokens.json generates the CSS, the TS and the Kotlin, so a change lands on both platforms at once and nobody hand-copies hex values. (Source: Engineering)
- **Experiments are props on one screen, never forks.** Why: The Android team A/B tests monetization constantly (price, copy, entry point, layout). A forked screen per variant would multiply bugs and fall out of sync; a prop keeps every variant on the same, tested code. (Source: Product: Android runs monetization experiments)
- **Only supplied art is an image; everything else is code.** Why: Coded logos, seals, rings, badges and progress bars stay sharp at any size, follow light and dark automatically and weigh nothing. Images are reserved for 3D art and illustrations nobody can draw in code. (Source: Design direction)
- **Never crop supplied art.** Why: Designers compose the transparent padding on purpose (glow, shadow, breathing room). Cropping changes the art; only fully transparent margins are trimmed when an asset is built. (Source: Design direction)
- **Colours that aren’t in the colour guide are marked “derived”.** Why: The colour guide doesn’t cover every surface the screens use. Marking derived tokens keeps it clear which values came from the guide and which were measured from screens, so design can review them in one place. (Source: Design: colour guide gaps)

### Colour & type

- **Green (lime in dark) only for what you can touch.** Why: If green also decorates, users can’t tell what is tappable. Reserving it for actions and the assistant’s byline makes every green thing a promise that it does something. (Source: Typography v3 colour roles)
- **In dark mode every green is lime (#BAFF29).** Why: Brand green goes muddy on near-black; lime is the brand’s dark-mode accent. Accents (buttons, icons, strokes, the FAB, the WhatsApp glyph) use lime itself, and green-tinted dark surfaces are re-hued to lime at the same darkness. Anything drawn on lime is dark (text/on-action), never white. (Source: Design rule)
- **Every text pair passes WCAG AA (4.5:1).** Why: Many users read the app outdoors on mid-range phones at low brightness. When a mock’s colour falls short (e.g. the saved-contact blue at 4.15:1), the token is nudged until it passes and the reason is written on the token. (Source: Accessibility)
- **Everything is set in DM Sans. Nothing is in Lora.** Why: One family keeps every screen consistent and the app light to ship. Some design files use Lora for display lines; in the product those lines are DM Sans. (Source: Product: “Make everything DM Sans”)
- **Four DM Sans weights: 400, 500, 600 and 700.** Why: Regular is for reading, Medium for labels, SemiBold where the designs use it (plan names such as “Equal AI Unlimited”), Bold for display lines. All four are loaded on web and Android, so nothing is synthesised. (Source: Design files)
- **Text that doesn’t match a type token is a bug.** Why: Twelve tokens cover every role. Ad-hoc sizes creep in one screen at a time until nothing lines up; holding to the tokens keeps rhythm across screens. (Source: Typography v3)
- **Medium is scanned, Regular is read; wrapping text is always Regular.** Why: Weight separates labels from prose. Paragraphs in Medium are tiring to read and flatten the hierarchy. (Source: Typography v3)
- **Emoji are sized to the label they sit in.** Why: Emoji render larger than letters at the same font size, so oversized emoji pull the eye away from the words. Matching the label size keeps chips calm. (Source: Design review: emoji looked too big)

### Android frame & chrome

- **Design at 390 × 800 dp and extend only vertically.** Why: It is the team’s working Android frame. Long screens grow taller rather than wider, so layouts are always checked at real phone width. (Source: Product: team frame)
- **The status bar and every icon follow Material 3.** Why: The app runs inside Android’s system UI. A Material 3 status bar (52 dp) and Material Symbols for all flat icons mean screens sit naturally next to the real system UI and every icon shares one line weight. (Source: Product: Material 3)
- **Text fields have 12 dp corners; search and assistant message fields are fully rounded.** Why: Form fields read as editable boxes. Search and the assistant composer are conversational entry points, so they use the pill shape the app uses for chat input. (Source: Design: text field 12px; assistant fields fully rounded)
- **48 dp touch targets, even when the visual is smaller.** Why: Smaller targets cause mis-taps, especially one-handed. Where a mock draws a 36 dp button, the touch area is still 48 dp. (Source: Accessibility / Material)
- **Business logic in Kotlin, UI in Compose, animations in Lottie.** Why: That is how the Android team builds. Components are stateless Compose; illustrative motion is Lottie JSON played by Lottie, never re-built by hand. (Source: Engineering: Android stack)
- **Respect reduced motion everywhere.** Why: Some users get motion sickness or find animation distracting. Every animation in the system holds still when the phone asks for reduced motion. (Source: Accessibility)

### People & identity

- **Free users get the plain avatar; paid users get the gold background and ring.** Why: Unlimited should feel like a status the user can see on their own face. Keeping free plain makes the upgrade visible without nagging. (Source: Product)
- **Saved contacts show initials on a tinted disc with a person badge.** Why: The badge is the signifier for “someone you know”. The disc colour varies per contact (blue, green, purple, orange, pink, teal) at the same saturation and lightness, so a list isn’t one flat colour, and every pair keeps the initials readable (AA). The same initials always get the same colour. (Source: Design: “AN with a mark”; colour can vary at the same saturation)
- **Unknown and business callers use 3D category art.** Why: The category tells the user at a glance why someone called (delivery, bank, real estate) before reading a word. (Source: Design)
- **The robot is the default “AI Assistant is On” art; the phone-with-sparkles is an experiment.** Why: Design confirmed the robot as final. The phone stays available as a prop so the team can test it. (Source: Product decision)
- **Green mascots are generated to order.** Why: Mascot moments are custom for each screen. When a new one is needed, the system shows a placeholder and asks for the art rather than reusing a mismatched pose. (Source: Design)
- **The logo comes from the official SVG.** Why: A traced logo drifts from the brand. The official vector generates both platforms (npm run logo). (Source: Brand)
- **In the AI layer, saved contacts are addressed by first name, others by full name.** Why: “Replying Amit” reads naturally for a friend, but splitting a business name gives nonsense like “Replying Dr.”. (Source: Engineering (copy))

### Components

- **Action cards: grey body on a white card, never a green card.** Why: A green wrapper made confirmations look like warnings and broke consistency with the rest of the thread. Every action card has the same frame; the content says what happened. (Source: Design review)
- **Every action-card CTA has an emoji (📤 Send, ✏️ Edit, 👍 Confirm, 🗑️ Delete).** Why: Emoji make the action recognisable at a glance and match the chip language used everywhere else in chat. (Source: Design review)
- **All actions in a card have the same weight; Confirm is not a filled button.** Why: Two actions at equal weight let the user choose; a filled Confirm pushes them. The commit goes first, the revise second, both as text rows. (Source: Typography v3 / handoff)
- **Instructions use the note_stack icon with When / Do lines, never a category avatar.** Why: An instruction is a rule the user set, not a caller. The icon and When / Do structure make that obvious. (Source: Design review)
- **Flat icons are Material Symbols (Material 3); actions use emoji.** Why: One icon family keeps line weight consistent. Emoji on actions add warmth and are easier to recognise in a crowded chat. (Source: Design direction)
- **Premium (monetization) perk icons are filled, 16 dp, in the gold radial gradient.** Why: Filled gold marks a paid perk apart from everyday UI icons, which are outlined. (Source: Design spec)

### Monetization

- **Unlimited is ₹249; with EQUAL25 it is ₹149.** Why: Today’s default, confirmed by product; price and coupon are experiment props (price, discountedPrice). The coupon row says “Save Flat ₹100”, and the price drop animates only when the user taps APPLY. (Source: Product decision)
- **The plan value card shows ₹39 with ₹49 struck through.** Why: The value designs show both orders; ₹39 / ₹49 was confirmed. (Source: Product decision)
- **🎊 LIMITED TIME DISCOUNT stays an emoji, not art.** Why: Confirmed by design: it is copy, not an illustration. (Source: Design decision)
- **Lock content, never identity.** Why: Free users still see who called and when; only the content (bubbles, recording, actions) is blurred or crown-locked. Hiding the caller would make the app useless, not tempting. (Source: Product)
- **While a payment is processing, every surface says so and the paywall button is disabled.** Why: UPI confirmations can take minutes. Without this, users who close the pending page pay twice. (Source: Design: If User Closes the payment pending page)
- **The exit offer appears once per session.** Why: Offering the coupon when someone leaves converts; offering it every time trains people to leave first. (Source: System guidance (not yet enforced in code))
- **Show what Unlimited did before asking for a renewal.** Why: A user who sees “20 calls handled” renews for the value they already got, not on a promise. (Source: Design: Monetization value)
- **Keep the existing bottom navigation (Chats, You).** Why: One mock showed a Home tab; product confirmed the navigation stays as it is. (Source: Product decision)

### Assistant & calls

- **The green orb opens the same assistant sheet on every screen.** Why: One consistent entry point means users learn it once. (Source: Design: Global MYA)
- **Inside a chat, the task sheet stops below the chat header.** Why: The user must still see whose chat they are acting in, so a reply never goes to the wrong person. (Source: Design: chat AI layer)
- **Tasks end in a result the user confirms (Edit / Confirm), then the outcome shows where it lives.** Why: The assistant acts on the user’s behalf; confirming first keeps them in control, and showing the result in the chat row closes the loop. (Source: Design: Global MYA)
- **Confirm before actions that are hard to undo (mute, send, save).** Why: The assistant acts for the user. A one-line check (“Are you sure? You’ll not get any call from them…”) prevents the mistake that costs the most. (Source: Design: Mute, Reply on WhatsApp, Save Contact)
- **Every finished action leaves an action card in the chat.** Why: The chat is the record of what the assistant did (Outgoing call, Muted, WhatsApp message, Contact saved), and each card links to where the result lives. (Source: Design: action flows)
- **Hand off to the phone for the dialer, Settings and WhatsApp; never redraw them.** Why: The system owns those screens. The app hands off, then picks up where the user left off (“You stopped between saving this contact. Want to continue?”). (Source: Design: Call Back, Save Contact)
- **Errors say what happened in one line and offer one fix.** Why: Retry for a failed generation, Refresh or Try again when offline, “hold and speak again” for voice. One clear next step beats an error code. (Source: Design: Error states)
- **The contact form has two candidate designs (iOS-revamp parity, WhatsApp parity).** Why: The team hasn’t chosen; both are props on one form so either can ship. (Source: Design: Save Contact)
- **A missed call shows only what we know: the reason (with caller art and 👍/👎), else the name, else “Missed by the assistant”.** Why: Inventing a reason would mislead the call-back decision. The thumbs rate the reason, so they only appear with one. The warm tint says “missed”, not “error”. (Source: Design: missed-call card)
- **Never draw the system keyboard in the app.** Why: Android owns the keyboard. The docs show a stand-in image; the app only lifts its input above the keyboard. (Source: Engineering)
- **Ask for a permission only at the step that needs it, and say why in one line.** Why: Permissions asked up front get denied. Asked in context (“I need your contact list to know who is calling”), they get granted. (Source: Design: Known Calls flow)
- **Notifications: who, what they want, and Takeover first.** Why: A notification is glanced at in a second. Takeover is the action that matters most when the assistant is on a call with someone you know. (Source: Design: Notifications - Known Calls)
- **Silent Mode is titled “Silent Mode” everywhere.** Why: The dark mock said “Call Preferences”; design confirmed “Silent Mode” to match the You-tab row. (Source: Design decision)
- **Auto-rickshaw, paper bag and delivery rider are not caller categories.** Why: They appeared in a design as decoration; product confirmed they shouldn’t become categories. (Source: Product decision)

## Components (62 docs pages)

### Group: Actions

#### Action chips (`action-chips`)

Emoji-led glass chips for the next step after a call: small chips in the chat list, large chips inside a conversation or the AI panel.

- React: `import { SmallActionChip, LargeActionChip, ChipRow } from '@equal/ds';`
- Compose: `SmallActionChip`, `LargeActionChip`
- Tokens: `gradient/chip-small-unread`, `gradient/chip-small-read`, `gradient/chip-large`, `action/stroke/unread`, `stroke/subtle`, `shadow/glass`, `text/action`, `text/secondary`, `text/primary`
- Source: §9 Small Action Chip · §10 Large Action Chip

Do: Lead every action with a Unicode emoji (📞 Call Back, ✏️ Update Address, 🗓️ Add to Calendar); actions use emoji, not Material icons. Use small chips outside chats (the chat list) and large chips inside a conversation or the AI panel. Let ChatListItem pick the small-chip state: unread rows get unread chips, read rows read chips, a selected row outlined chips. Mark the suggested next step unread and the alternative read (👍 Confirm vs ✍️ Edit).

Don't: Don't swap the emoji for a Material icon or drop it on some chips in a row. Don't wrap the chat-list chip row; it scrolls and clips at the right edge. Don't use a chip for a destructive action; that belongs in a confirm sheet.

Example: Small chip states
```tsx
<SmallActionChip emoji="📞" label="Call Back" />
<SmallActionChip emoji="✏️" label="Update Address" />
<SmallActionChip emoji="📞" label="Call Back" state="read" />
<SmallActionChip emoji="📞" label="Call Back" state="outlined" />
<SmallActionChip emoji="🗓️" label="Add to Calendar" state="outlined" chevron={false} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SmallActionChip(label = "Call Back", emoji = "📞", onClick = {})
        SmallActionChip(label = "Update Address", emoji = "✏️", onClick = {})
    }
    SmallActionChip(label = "Call Back", emoji = "📞", onClick = {}, style = SmallActionChipStyle.Read)
    SmallActionChip(label = "Call Back", emoji = "📞", onClick = {}, style = SmallActionChipStyle.Outlined)
    // Compose: no chevron toggle; the trailing chevron is always shown.
    SmallActionChip(label = "Add to Calendar", emoji = "🗓️", onClick = {}, style = SmallActionChipStyle.Outlined)
}
```

Example: Large chips
```tsx
<ChipRow gap={8}>
  <LargeActionChip emoji="📞" label="Takeover" />
  <LargeActionChip emoji="🗓️" label="Ask to reschedule" />
</ChipRow>
<ChipRow gap={8}>
  <LargeActionChip emoji="✍️" label="Edit" state="read" />
  <LargeActionChip emoji="👍" label="Confirm" />
</ChipRow>
```
```kotlin
// Compose: no ChipRow; a Row with spacedBy(8.dp) does the same job.
Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    LargeActionChip(label = "Takeover", emoji = "📞", onClick = {})
    LargeActionChip(label = "Ask to reschedule", emoji = "🗓️", onClick = {})
}
Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    LargeActionChip(label = "Edit", emoji = "✍️", onClick = {}, state = LargeActionChipState.Read)
    LargeActionChip(label = "Confirm", emoji = "👍", onClick = {})
}
```

Example: In a chat row
```tsx
<ChipRow>
  <SmallActionChip emoji="📞" label="Call Back" />
  <SmallActionChip emoji="✏️" label="Update Address" />
  <SmallActionChip emoji="🗓️" label="Add to Calendar" />
</ChipRow>
```
```kotlin
// Compose: no ChipRow; a horizontally scrolling Row (gap 12) clips at the right edge.
Row(
    modifier = Modifier.horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(12.dp),
) {
    SmallActionChip(label = "Call Back", emoji = "📞", onClick = {})
    SmallActionChip(label = "Update Address", emoji = "✏️", onClick = {})
    SmallActionChip(label = "Add to Calendar", emoji = "🗓️", onClick = {})
}
```

#### Button (`button`)

Filled, text and icon buttons: use a filled Button for the one commit action on a surface, a TextButton for revise or secondary actions, and an IconButton for icon-only controls like back, close and call.

- React: `import { Button, TextButton, IconButton } from '@equal/ds';`
- Compose: `EqualButton`, `EqualTextButton`, `EqualIconButton`
- Tokens: `button/primary`, `button/secondary`, `button/danger`, `button/disabled`, `text/on-action`, `text/on-danger`, `text/on-action-disabled`, `text/action`, `text/danger`, `bg/surface`, `shadow/raised`, `shadow/focusRing`
- Source: §19 Buttons

Do: Use exactly one filled Button per surface for the commit action (Save, Delete, Turn off); pair it with a TextButton for revise or cancel. Write labels in sentence case ("Add new Address", "Share Feedback" as shipped) and keep the same verb from control to confirmation: Turn off → "Call learning turned off". Use the danger variant only for destructive commits, with the trash icon (the delete sheet does this for you). Always pass a `label` to IconButton; it is the accessible name and the tooltip.

Don't: Don't put two filled buttons side by side; two actions at equal weight are one action. Don't colour non-actionable text green; text/action is reserved for things you can tap. Don't shrink the touch target: small buttons keep a 48dp hit area even when the visual is 24dp.

Example: Variants
```tsx
<Button>Save</Button>
<Button variant="secondary">Try Voices</Button>
<Button variant="danger" leadingIcon="delete">Delete</Button>
<Button disabled>Save</Button>
```
```kotlin
EqualButton(text = "Save", onClick = {})
EqualButton(text = "Try Voices", onClick = {}, variant = EqualButtonVariant.Secondary)
EqualButton(text = "Delete", onClick = {}, variant = EqualButtonVariant.Danger, leadingIcon = EqualIcons.Delete)
EqualButton(text = "Save", onClick = {}, enabled = false)
```

Example: Sizes
```tsx
<Button size="sm" leadingIcon="add">Apply</Button>
<Button size="md">Save</Button>
<Button size="lg">Save</Button>
<Button shape="rounded">Save</Button>

<Button block size="lg" leadingIcon="add">Add New Instruction</Button>
```
```kotlin
EqualButton(text = "Apply", onClick = {}, size = EqualButtonSize.Sm, leadingIcon = EqualIcons.Add)
EqualButton(text = "Save", onClick = {}, size = EqualButtonSize.Md)
EqualButton(text = "Save", onClick = {}, size = EqualButtonSize.Lg)
// Block = lg metrics at full width
EqualButton(text = "Add New Instruction", onClick = {}, size = EqualButtonSize.Block, leadingIcon = EqualIcons.Add)
```

Example: Text and icon buttons
```tsx
<TextButton>Edit</TextButton>
<TextButton leadingIcon="share">Share</TextButton>
<TextButton trailingIcon="chevron-right">Share Feedback</TextButton>
<TextButton tone="neutral">Cancel</TextButton>
<TextButton tone="danger">Delete address</TextButton>
<TextButton size="small">Clear all</TextButton>

<IconButton icon="arrow-back" label="Back" />
<IconButton icon="delete" label="Delete" variant="danger-ghost" />
<IconButton icon="close" label="Close" variant="neutral" />
<IconButton icon="check" label="Confirm" variant="primary" />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    EqualTextButton(text = "Edit", onClick = {})
    EqualTextButton(text = "Share", onClick = {}, leadingIcon = EqualIcons.Share)
    EqualTextButton(text = "Share Feedback", onClick = {}, trailingIcon = EqualIcons.ChevronRight)
    EqualTextButton(text = "Delete address", onClick = {}, danger = true)
}
Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    EqualIconButton(icon = EqualIcons.Back, contentDescription = "Back", onClick = {})
    EqualIconButton(icon = EqualIcons.Check, contentDescription = "Confirm", onClick = {}, variant = EqualIconButtonVariant.Primary)
}
```

Example: Commit + revise
```tsx
<TextButton tone="neutral">Cancel</TextButton>
<Button>Turn off</Button>
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    EqualTextButton(text = "Cancel", onClick = {})
    EqualButton(text = "Turn off", onClick = {})
}
```

### Group: Assistant

#### Assistant sheet (Global MYA) (`assistant-sheet`)

The sheet the green orb opens on any screen: greeting, quick-action tiles, suggestion chips and a text or voice input. A request turns it into a short task conversation (voice note → Thinking… → result card → Edit / Confirm).

- React: `import { AssistantSheetShell, AssistantGreeting, AssistantActions, AssistantInput, VoiceRecorder, TrySaying, AssistantTaskHeader, AssistantThinking, AssistantReplies, CarouselDots } from '@equal/ds';`
- Compose: `AssistantSheetShell`, `AssistantGreeting`, `AssistantActions`, `AssistantInput`, `VoiceRecorder`, `TrySaying`, `AssistantTaskHeader`, `AssistantThinking`, `AssistantReplies`, `CarouselDots`
- Tokens: `component/sheet/bg`, `gradient/voice-note`, `text/action`, `action/stroke/unread`, `text/danger`, `component/chat/wallpaper-bg`
- Source: Global MYA

Props of `AssistantInput`:
- `mode`: `'text' | 'voice'`. Field + mic, or keyboard toggle + Send voice note.
- `value?`: `string` = ''. Text.
- `focused?`: `boolean`. Green outline (keyboard open).
- `onMic?`: `() => void`. Text → voice.
- `onKeyboard?`: `() => void`. Voice → text.
- `onVoiceNote?`: `() => void`. Tap to record.
- `onVoiceHold?`: `() => void`. Press and hold to record.
- `onSubmit?`: `(text: string) => void`. Send.

Props of `VoiceRecorder`:
- `state`: `'idle' | 'recording' | 'hold' | 'cancel'`. Bar state.
- `seconds?`: `number` = 0. Elapsed.
- `onDelete?`: `() => void`. Discard.
- `onSend?`: `() => void`. Send.

Props of `AssistantGreeting`:
- `name`: `string`. First name, in text/action.
- `greeting?`: `string` = 'Good morning'. Use greetingFor(hour).

Props of `AssistantActions`:
- `items`: `{ label; icon: IconName | 'equal'; onClick? }[]`. Three tiles.

Props of `AssistantSheetShell`:
- `task?`: `boolean`. The taller conversation sheet (wallpaper body).
- `header?`: `ReactNode`. AssistantTaskHeader in task mode.
- `footer?`: `ReactNode`. Input / recorder.
- `onScrim?`: `() => void`. Tap outside closes.

Do: Open it from the green orb on every screen; it is the same sheet everywhere. Title the task by what the assistant is doing, not what the user said. End with a result to confirm (Edit / Confirm), then close and show the outcome where it lives (the chat row).

Don't: Don't draw the keyboard; it's the system's. Only lift the input above it. Don't keep the tiles while typing; the keyboard needs the room.

Example: Greeting & quick actions
```tsx
<AssistantSheetShell footer={<AssistantInput mode="text" onMic={toVoice} onSubmit={send} />} onScrim={close}>
  <AssistantGreeting name="Keshav" />
  <AssistantActions items={quickActions} />
  <ChipRow><LargeActionChip emoji="🗓️" label="Reply Amit on WhatsApp" /> …</ChipRow>
</AssistantSheetShell>
```
```kotlin
EqualTheme {
    AssistantSheetShell(
        onScrim = { /* close */ },
        footer = { AssistantInput(mode = AssistantInputMode.Text, onMic = { /* to voice */ }, onSubmit = { /* send */ }) },
    ) {
        AssistantGreeting(name = "Keshav")
        AssistantActions(
            items = listOf(
                AssistantAction("Talk to Equal"), // null icon: the Equal mark
                AssistantAction("Talk to Equal", EqualIcons.AutoFix),
                AssistantAction("Make a call", EqualIcons.CallFilled),
            ),
        )
        AssistantChips {
            LargeActionChip(label = "Reply Amit on WhatsApp", emoji = "\uD83D\uDDD3\uFE0F", onClick = {})
            LargeActionChip(label = "Set reminder", emoji = "\uD83D\uDD14", onClick = {})
        }
    }
}
```

Example: Input: text and voice
```tsx
<AssistantInput mode="text" value={text} onChange={setText} onMic={() => setMode('voice')} onSubmit={send} />
<AssistantInput mode="voice" onKeyboard={() => setMode('text')} onVoiceNote={record} onVoiceHold={holdToRecord} />
```
```kotlin
EqualTheme {
    var mode by remember { mutableStateOf(AssistantInputMode.Text) }
    var text by remember { mutableStateOf("") }
    AssistantInput(
        mode = mode,
        value = text,
        onValueChange = { text = it },
        onMic = { mode = AssistantInputMode.Voice },
        onKeyboard = { mode = AssistantInputMode.Text },
        onSubmit = { /* send it */ },
        onVoiceNote = { /* record */ },
        onVoiceHold = { /* hold to record */ },
        modifier = Modifier.imePadding(), // lift above the system keyboard
    )
}
```

Example: Recorder states
```tsx
<VoiceRecorder state="idle" onDelete={discard} onSend={send} />
<VoiceRecorder state="recording" seconds={elapsed} onDelete={discard} onSend={send} />
<VoiceRecorder state="hold" />    // press and hold: release to send, slide left to cancel
<VoiceRecorder state="cancel" />  // slid left: release to cancel
```
```kotlin
EqualTheme {
    Column(Modifier.background(EqualTheme.colors.sheetBg).padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        VoiceRecorder(state = RecorderState.Idle, onDelete = {}, onSend = {})
        VoiceRecorder(state = RecorderState.Recording, seconds = 4, onDelete = {}, onSend = {})
        VoiceRecorder(state = RecorderState.Hold) // press and hold: release to send, slide left to cancel
        VoiceRecorder(state = RecorderState.Cancel) // slid left: release to cancel
    }
}
```

Example: Task conversation
```tsx
<AssistantTaskHeader title="Setting up a reminder for appointment at Dr. Mehta’s" onClose={close} />
<AssistantThinking />
<AssistantReplies onEdit={edit} onConfirm={confirm} />
```
```kotlin
EqualTheme {
    Column(Modifier.background(EqualTheme.colors.chatWallpaperBg)) {
        AssistantTaskHeader(title = "Setting up a reminder for appointment at Dr. Mehta\u2019s", onClose = { /* close */ })
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            AssistantThinking()
            AssistantReplies(onEdit = { /* edit */ }, onConfirm = { /* confirm */ })
        }
    }
}
```

Example: Carousel dots
```tsx
<CarouselDots count={3} active={0} />
```
```kotlin
EqualTheme {
    CarouselDots(count = 3, active = 0)
}
```

Example: Reply card
```tsx
<AssistantReplyCard time="03:21" actions={[{ label: 'Edit', emoji: '✏️', onClick: edit }, { label: 'Send', emoji: '📤', onClick: send }]}>
  {draft}
</AssistantReplyCard>
```
```kotlin
EqualTheme {
    Column(Modifier.background(EqualTheme.colors.chatWallpaperBg).padding(16.dp)) {
        AssistantReplyCard(
            text = "Sure! Here\u2019s a draft for Amit:\n\nHi Amit! Count me in for Sunday 8 PM. See you there \uD83D\uDC4D",
            time = "03:21",
            actions = listOf(
                ReplyAction(label = "Edit", emoji = "\u270F\uFE0F", onClick = { /* edit */ }),
                ReplyAction(label = "Send", emoji = "\uD83D\uDCE4", onClick = { /* send */ }),
            ),
        )
    }
}
```

Example: Chat task sheet
```tsx
<ChatScreen chat={amit} />               // tap Reply on WhatsApp or send a message
<ChatTaskSheet contact="Amit" request={text} onClose={close} onSend={openWhatsApp} />
```
```kotlin
EqualTheme {
    // From a chat's AI layer (Reply on WhatsApp, or a sent message): stops below the chat header
    ChatTaskSheet(
        contact = "Amit",
        request = "Reply on whatsapp",
        onClose = { /* close */ },
        onSend = { /* open WhatsApp */ },
    )
}
```

#### Chat actions (`chat-actions`)

What the AI layer uses to carry out a task in a chat and to fail well: the assistant’s turn, Hold to speak, the edit-in-place bubble, the new contact form (two parity options), the permission dialog and the offline sheet and screen.

- React: `import { AiTurn, HoldToSpeakBar, EditBubble, NewContactForm, PermissionDialog, OfflineSheet, OfflineScreen } from '@equal/ds';`
- Compose: `AiTurn`, `HoldToSpeakBar`, `EditBubble`, `NewContactForm`, `PermissionDialog`, `OfflineSheet`, `OfflineScreen`, `DialerStandIn`
- Tokens: `button/primary`, `bg/surface`, `gradient/offline-screen`, `action/stroke/unread`
- Source: Flows/Call Back · Mute · Reply On WhatsApp · Save Contact · Error states

Props of `NewContactForm`:
- `value`: `{ first; last?; phone; email?; sync? }`. Pre-filled from the call.
- `variant?`: `'grouped' | 'outlined'` = 'grouped'. iOS-revamp parity or exact WhatsApp parity.
- `onSave?`: `() => void`. Save.

Props of `EditBubble`:
- `value`: `string`. The draft.
- `onChange?`: `(v: string) => void`. Typing.
- `onDone?`: `() => void`. Green check.

Props of `AiTurn`:
- `children`: `ReactNode`. What the assistant says.
- `actions?`: `{ label; emoji; onClick? }[]`. Action rows, emoji first.

Do: Confirm before anything the user can’t easily undo (mute, send, save). Leave the result in the chat as an action card, so the chat is the record of what the assistant did. On failure, say what happened in one line and offer the one action that fixes it.

Don't: Don't draw the dialer, Settings or WhatsApp; they belong to the phone. Hand off and show the result when the user comes back. Don't lose the user’s place: after Settings, offer to continue where they stopped.

Example: Assistant turn
```tsx
<AiTurn actions={[{ label: 'Mute', emoji: '🔕', onClick: mute }]}>Are you sure? …</AiTurn>
```
```kotlin
EqualTheme {
    AiTurn(
        text = "Are you sure? You’ll not get any call from them even if it’s important",
        actions = listOf(ReplyAction(label = "Mute", emoji = "🔕", onClick = { /* mute */ })),
    )
}
```

Example: Hold to speak
```tsx
<HoldToSpeakBar onHold={record} onKeyboard={showKeyboard} />
```
```kotlin
EqualTheme {
    HoldToSpeakBar(onHold = { /* record */ }, onKeyboard = { /* show keyboard */ })
}
```

Example: Edit bubble
```tsx
<EditBubble value={draft} onChange={setDraft} onDone={save} autoFocus />
```
```kotlin
EqualTheme {
    var draft by remember { mutableStateOf("Hi Amit! Count me in for Sunday 8 PM. See you there 👍") }
    // Over the chat dimmed with EditDimColor; lift above the keyboard with imePadding()
    Box(Modifier.background(EditDimColor)) {
        EditBubble(value = draft, onValueChange = { draft = it }, onDone = { /* save */ }, autoFocus = true)
    }
}
```

Example: New contact: iOS parity
```tsx
<NewContactForm variant="grouped" value={contact} onClose={close} onSave={save} />
```
```kotlin
EqualTheme {
    NewContactForm(
        value = NewContactValue(first = "Rahul (Electrician)", phone = "+91 98717 46113"),
        variant = NewContactVariant.Grouped,
        onClose = { /* close */ },
        onSave = { /* save */ },
    )
}
```

Example: New contact: WhatsApp parity
```tsx
<NewContactForm variant="outlined" value={contact} onSave={save} onSync={setSync} />
```
```kotlin
EqualTheme {
    var sync by remember { mutableStateOf(true) }
    NewContactForm(
        value = NewContactValue(first = "Rahul (Electrician)", phone = "+91 98717 46113", sync = sync),
        variant = NewContactVariant.Outlined,
        onSave = { /* save */ },
        onSync = { sync = it },
    )
}
```

Example: Offline
```tsx
<OfflineSheet onRefresh={refresh} />   // over a chat
<OfflineScreen onRetry={retry} />    // nothing to show yet
```
```kotlin
EqualTheme {
    OfflineSheet(onRefresh = { /* refresh */ })   // over a chat
    OfflineScreen(onRetry = { /* retry */ })      // nothing to show yet
}
```

### Group: Cards

#### Action card (`action-card`)

A card for something the assistant did or proposes (a WhatsApp reply, an appointment, a saved rule), with stacked actions underneath.

- React: `import { ActionCard, ActionCardBody, instructionLines } from '@equal/ds';`
- Compose: `ActionCard`
- Tokens: `bg/surface`, `bg/primary`, `stroke/subtle`, `text/primary`, `text/secondary`, `text/tertiary`, `text/action`, `button/primary`
- Source: §14 Action Card

Do: Put the positive action first (Confirm, Send), then the revise (Edit). Both are text rows. Name the source in the title ("WhatsApp · Amit Nanda") so the user knows where the action goes. Lead every action with its emoji (📤 Send, ✏️ Edit, 👍 Confirm, 🗑️ Delete).

Don't: Don't use a filled button inside an action card, not even for Confirm. Don't use a 3D category avatar for an instruction; use the note_stack icon with When / Do lines. Don't put the card on a green card; the grey body always sits on a white card. Don't use flat icons in action labels; the rows are emoji + text.

Example: WhatsApp reply
```tsx
<ActionCard source="whatsapp" title="WhatsApp · Amit Nanda"
  quote="“Count me in for Sunday 8 PM 👍”" time="03:21"
  actions={[{ label: 'Send', emoji: '📤' }, { label: 'Edit reply', emoji: '✏️' }]} />
```
```kotlin
// The coded WhatsApp logo is the default when no category or icon is set
ActionCard(
    title = "WhatsApp · Amit Nanda",
    quote = "“Count me in for Sunday 8 PM 👍”",
    timestamp = "03:21",
    actions = listOf(
        ActionCardAction("Send", emoji = "📤", onClick = {}),
        ActionCardAction("Edit reply", emoji = "✏️", onClick = {}),
    ),
)
```

Example: Appointment: Confirm + Edit
```tsx
<ActionCard category="others" title="Dr. Mehta's Clinic Appointment"
  details={[
    { text: 'Tomorrow, 9:00 AM' },
    { text: 'Bring previous medical reports', tone: 'tertiary' },
  ]}
  time="03:21"
  actions={[{ label: 'Confirm', emoji: '👍' }, { label: 'Edit', emoji: '✏️' }]} />
```
```kotlin
ActionCard(
    category = EqualCategory.Others,
    title = "Dr. Mehta's Clinic Appointment",
    lines = listOf(
        ActionCardLine("Tomorrow, 9:00 AM"),
        ActionCardLine("Bring previous medical reports", ActionCardTone.Tertiary),
    ),
    timestamp = "03:21",
    actions = listOf(
        ActionCardAction("Confirm", emoji = "👍", onClick = {}),
        ActionCardAction("Edit", emoji = "✏️", onClick = {}),
    ),
)
```

Example: Instruction saved
```tsx
<ActionCard icon="instructions" title="Instruction saved"
  details={instructionLines('Delivery agents call', 'Ask them to leave parcels with security')}
  time="03:21" actions={[{ label: 'Edit rule', emoji: '✏️' }]} />
```
```kotlin
ActionCard(
    icon = EqualIcons.Instructions,
    title = "Instruction saved",
    lines = instructionLines("Delivery agents call", "Ask them to leave parcels with security"),
    timestamp = "03:21",
    actions = listOf(ActionCardAction("Edit rule", emoji = "✏️", onClick = {})),
)
```

Example: Instruction (body only)
```tsx
<ActionCardBody icon="instructions" title="Instructions"
  details={instructionLines('Bank calls come', 'Tell callers I’ll call back after 6 PM')}
  time="03:21" />
```
```kotlin
ActionCardBody(
    icon = EqualIcons.Instructions,
    title = "Instructions",
    lines = instructionLines("Bank calls come", "Tell callers I’ll call back after 6 PM"),
    timestamp = "03:21",
)
```

#### Assistant toggle (`assistant-toggle`)

The card at the top of Chats and the You tab that turns the AI assistant on or off, with the mascot dimming when it is off.

- React: `import { AssistantToggle } from '@equal/ds';`
- Compose: `AssistantToggleCard`
- Tokens: `gradient/assistant-toggle`, `bg/surface`, `stroke/subtle`, `text/primary`, `text/secondary`, `button/primary`, `button/disabled`
- Source: §3 Assistant Availability Toggle

Do: Put it directly under the top bar on Chats (HomeHeader does this) and first under YOUR ASSISTANT on the You tab. Let the default copy explain the state: on manages unknown calls, off lets them ring normally.

Don't: Don't crop or replace the mascot; it dims itself when off. Don't add a Save button; the change applies immediately.

Example: Interactive
```tsx
const [on, setOn] = useState(true);

<AssistantToggle on={on} onChange={setOn} />
```
```kotlin
var on by remember { mutableStateOf(true) }
AssistantToggleCard(checked = on, onCheckedChange = { on = it })
```

Example: On and off
```tsx
<AssistantToggle on />
<AssistantToggle on={false} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    AssistantToggleCard(checked = true, onCheckedChange = {})
    AssistantToggleCard(checked = false, onCheckedChange = {})
}
```

#### Feedback card (`feedback-card`)

The post-call card that asks the user to rate the call from one to five stars and share feedback.

- React: `import { FeedbackCard } from '@equal/ds';`
- Compose: `FeedbackCard`
- Tokens: `bg/surface`, `rating/star-filled`, `rating/star-empty`, `text/placeholder`, `stroke/subtle`, `text/action`
- Source: §13 Feedback Card

Do: Show it once, right after the call summary, indented to line up with the summary bubble. Keep the question short and about the call itself.

Don't: Don't add a text field to the card; Share Feedback opens the next step. Don't use emoji or images for the stars; they are coded.

Example: Interactive
```tsx
const [rating, setRating] = useState(0);

<FeedbackCard rating={rating} onRate={setRating} onShare={(r) => submit(r)} />
```
```kotlin
var rating by remember { mutableIntStateOf(0) }
FeedbackCard(
    question = "How would you rate the call?",
    rating = rating,
    onRatingChange = { rating = it },
    // Compose: the share callback takes no argument; read `rating` from state
    onShareFeedbackClick = {},
)
```

Example: Rated
```tsx
<FeedbackCard rating={4} />
```
```kotlin
// Compose: always controlled, so the question and rating callback are required
FeedbackCard(
    question = "How would you rate the call?",
    rating = 4,
    onRatingChange = {},
    onShareFeedbackClick = {},
)
```

#### Meet Your Assistant card (`meet-assistant-card`)

Introduces the voice assistant with its persona avatar and a “Call me” pill. Compact on Chats once the assistant is back; banner as a standalone promo.

- React: `import { MeetAssistantCard } from '@equal/ds';`
- Compose: `MeetAssistantCard`
- Tokens: `gradient/meet-assistant`, `gradient/call-me`, `text/primary`, `text/action`, `text/secondary`, `text/on-action`, `text/placeholder`
- Source: Flows: Temporarily Unavailable

Do: Use the compact layout in the Chats promo slot, the same slot as What’s New. Keep “Call me” as the only action.

Don't: Don’t show it together with a What’s New card. Don’t crop or recolour the avatar-assistant art; the orb badge is part of the file.

Example: Compact (Chats)
```tsx
<MeetAssistantCard onCall={startAssistantCall} onDismiss={dismiss} />
```
```kotlin
MeetAssistantCard(onCallClick = {}, onDismiss = {})
```

Example: Banner
```tsx
<MeetAssistantCard layout="banner" onCall={startAssistantCall} onDismiss={dismiss} />
```
```kotlin
MeetAssistantCard(layout = MeetAssistantLayout.Banner, onCallClick = {}, onDismiss = {})
```

#### System status card (`system-status-card`)

Takes the assistant toggle’s place on Chats while Equal AI is down: a SYSTEM STATUS pill, the sleeping robot, and a “Notify me when ready” pill that turns into a confirmation.

- React: `import { SystemStatusCard } from '@equal/ds';`
- Compose: `SystemStatusCard`
- Tokens: `gradient/status-card`, `component/status-card/pill-bg`, `component/status-card/button`, `component/status-card/button-text`, `text/primary`, `text/secondary`, `text/action`
- Source: Flows: Temporarily Unavailable

Do: Put it where the assistant toggle sits (HomeHeader `status`), so the outage reads as the assistant’s state. Hide promo cards (What’s New, Meet Your Assistant) while the card is showing.

Don't: Don’t show it for a single failed call; it means the whole service is down. Don’t keep the Notify pill tappable after the user has subscribed.

Example: Unavailable
```tsx
<SystemStatusCard onNotify={subscribeToRecovery} />
```
```kotlin
SystemStatusCard(state = SystemStatusState.Unavailable, onNotifyClick = {})
```

Example: Notify requested
```tsx
<SystemStatusCard state="notified" />
```
```kotlin
// The confirmation is not tappable, so onNotifyClick is never called in this state
SystemStatusCard(state = SystemStatusState.Notified, onNotifyClick = {})
```

Example: In the Chats header
```tsx
<HomeHeader assistantOn={on} status={down ? <SystemStatusCard state={notify} onNotify={subscribe} /> : undefined} />
```
```kotlin
var on by remember { mutableStateOf(true) }
var notify by remember { mutableStateOf(SystemStatusState.Unavailable) }
val down = true
HomeHeader(
    assistantOn = on,
    onAssistantChange = { on = it },
    status = if (down) {
        { SystemStatusCard(state = notify, onNotifyClick = { notify = SystemStatusState.Notified }) }
    } else {
        null
    },
)
```

#### What's New card (`whats-new-card`)

A dismissible announcement card with the NEW FEATURE badge, a heading, body copy and one CTA. Built in three layers: a flat fill, a blurred circle in the bottom-right corner, and the illustration on top of the circle.

- React: `import { WhatsNewCard } from '@equal/ds';`
- Compose: `WhatsNewCard`
- Tokens: `whats-new/bg`, `whats-new/glow`, `badge/new-feature-stroke`, `text/action`, `text/secondary`, `text/placeholder`, `button/primary`
- Source: §22 What's New Card

Do: Keep the body to about two lines and one CTA that goes straight to the feature. Always offer onDismiss on the Chats list so the card can go away.

Don't: Don't stack more than one What's New card at a time. Don't add a second button; the card has a single commit.

Example: Default
```tsx
<WhatsNewCard width="100%" heading="Language Preference"
  body="Set your preferred language and choose how your assistant sounds"
  ctaLabel="Try Voices" ctaIcon="translate" onCta={openVoices} onDismiss={dismiss} />
```
```kotlin
WhatsNewCard(
    title = "Language Preference",
    body = "Set your preferred language and choose how your assistant sounds",
    buttonLabel = "Try Voices",
    buttonIcon = EqualIcons.Translate,
    onButtonClick = {},
    onCloseClick = {},
)
```

Example: Custom badge and icon, not dismissible
```tsx
<WhatsNewCard width="100%" badge="Just added" heading="Instructions"
  body="Tell your assistant how to handle deliveries, sales calls and more."
  ctaLabel="Add instruction" ctaIcon="add" />
```
```kotlin
WhatsNewCard(
    badgeText = "Just added",
    title = "Instructions",
    body = "Tell your assistant how to handle deliveries, sales calls and more.",
    buttonLabel = "Add instruction",
    buttonIcon = EqualIcons.Add,
    onButtonClick = {},
    onCloseClick = null, // null hides the close (X)
)
```

### Group: Chat

#### AI panel (`ai-panel`)

The assistant's bottom panel inside a conversation: a suggestion from the orb, large action chips and a composer; AiSuggestion is the avatar-plus-prompt line on its own.

- React: `import { AiChatPanel, AiSuggestion } from '@equal/ds';`
- Compose: `AiChatPanel`, `AiSuggestion`
- Tokens: `bg/surface`, `text/secondary`, `text/primary`, `gradient/chip-large`, `action/stroke/unread`
- Source: §12b AI Chat — Within other conversation · §16 AI Suggestion

Do: Phrase the prompt as a question the user can answer with one chip ("Want me to send Amit a quick reply on WhatsApp?"). Offer at most two or three emoji chips, the most likely one first. Hide the composer (composer={false}) when only a quick decision makes sense, like during a live call.

Don't: Don't put a filled Button in the panel; the actions are large chips. Don't write the prompt in green; the assistant's words are text/secondary here.

Example: After a call
```tsx
<AiChatPanel
  prompt="Want me to send Amit a quick reply on WhatsApp?"
  actions={[
    { label: 'Reply on WhatsApp', emoji: '💬' },
    { label: 'Add to Calendar', emoji: '🗓️' },
  ]}
  composer={{ onSend: send }} />
```
```kotlin
var draft by remember { mutableStateOf("") }

AiChatPanel(
    prompt = "Want me to send Amit a quick reply on WhatsApp?",
    actions = listOf(
        ActionChipData("Reply on WhatsApp", "💬"),
        ActionChipData("Add to Calendar", "🗓️"),
    ),
    onActionClick = {},
    composerValue = draft,
    onComposerValueChange = { draft = it },
    onSend = {},
)
```

Example: During a live call, no composer
```tsx
<AiChatPanel
  prompt="Arnav is at the gate with a parcel. Want to take over?"
  actions={[
    { label: 'Takeover', emoji: '📞' },
    { label: 'Ask to reschedule', emoji: '🗓️' },
  ]}
  composer={false} />
```
```kotlin
var draft by remember { mutableStateOf("") }

// Compose: AiChatPanel always shows the composer; there is no composer = false.
AiChatPanel(
    prompt = "Arnav is at the gate with a parcel. Want to take over?",
    actions = listOf(
        ActionChipData("Takeover", "📞"),
        ActionChipData("Ask to reschedule", "🗓️"),
    ),
    onActionClick = {},
    composerValue = draft,
    onComposerValueChange = { draft = it },
    onSend = {},
)
```

Example: AI suggestion
```tsx
<AiSuggestion>Want me to send Amit a quick reply on WhatsApp?</AiSuggestion>
<AiSuggestion tone="secondary">I can also add Sunday dinner to your calendar.</AiSuggestion>
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    AiSuggestion("Want me to send Amit a quick reply on WhatsApp?")
    // Compose: no `tone`; AiSuggestion is always text/primary.
    AiSuggestion("I can also add Sunday dinner to your calendar.")
}
```

#### Call status (`call-status`)

Centred thread markers: the day divider, call start/end events, and a notice when the thread switches to the assistant.

- React: `import { DayDivider, ThreadEvent, ThreadNotice } from '@equal/ds';`
- Compose: `DayDivider`, `ThreadEvent`, `ThreadNotice`
- Tokens: `bg/surface`, `stroke/subtle`, `text/primary`, `text/secondary`, `notice/bg`
- Source: §21 Call Status Indicators

Props of `DayDivider`:
- `label`: `string`. "Today", "12 July".

Props of `ThreadEvent`:
- `label`: `string`. "Call Started 03:31", "Call Ended 03:31".

Props of `ThreadNotice`:
- `children`: `ReactNode`. Notice text (captionWrap, centred, max width 240).

Do: Bracket every call with Call Started / Call Ended events. Use a ThreadNotice when the conversation changes hands ("You are now talking to your AI assistant").

Don't: Don't use a ThreadNotice for ordinary messages; it is for system state changes only. Don't style these as bubbles; they are centred pills without avatars.

Example: All indicators
```tsx
<MessageList>
  <DayDivider label="Today" />
  <ThreadEvent label="Call Started 03:31" />
  <ThreadEvent label="Call Ended 03:31" />
  <ThreadNotice>Call has ended. You are now talking to your AI assistant.</ThreadNotice>
</MessageList>
```
```kotlin
Column(
    Modifier.fillMaxWidth(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(12.dp),
) {
    DayDivider("Today")
    ThreadEvent("Call Started 03:31")
    ThreadEvent("Call Ended 03:31")
    ThreadNotice("Call has ended. You are now talking to your AI assistant.")
}
```

Example: In a thread
```tsx
<ChatWallpaper>
  <MessageList>
    <DayDivider label="12 July" />
    <ThreadEvent label="Call Started 18:02" />
    <ChatBubble kind="outgoing" sender="Equal AI" time="18:02">Hi, who is this?</ChatBubble>
    …
    <ThreadEvent label="Call Ended 18:04" />
    <ThreadNotice>Call has ended. You are now talking to your AI assistant.</ThreadNotice>
  </MessageList>
</ChatWallpaper>
```
```kotlin
ChatWallpaper {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        DayDivider("12 July")
        ThreadEvent("Call Started 18:02")
        ChatBubble(type = ChatBubbleType.Outgoing, sender = "Equal AI", timestamp = "18:02", message = "Hi, who is this?")
        ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.NA, sender = "Amit Nanda",
            timestamp = "18:02", message = "It's Amit. Dinner at mine this Sunday, 8 PM?")
        ThreadEvent("Call Ended 18:04")
        ThreadNotice("Call has ended. You are now talking to your AI assistant.")
    }
}
```

#### Call summary (`call-summary`)

The post-call card in a thread: a recording player with a coded waveform and speed pill, the assistant's summary, and an optional share footer or "Instruction Applied" tag.

- React: `import { CallSummary, VoicePlayer } from '@equal/ds';`
- Compose: `CallSummaryBubble`, `VoiceNotePlayer`
- Tokens: `bg/surface`, `voice/player-bg`, `stroke/subtle`, `waveform/bar`, `waveform/bar-played`, `playback/pill-bg`, `text/on-dark`, `text/tertiary`, `text/primary`, `text/action`
- Source: §11 Chat Bubbles · Voice note + Call Summary bubble

Do: Write the summary as the outcome for the user ("Amit invited you to dinner… confirm by tonight"), not a transcript. Tag the card 🪄 "Instruction Applied" when one of the user's instructions handled the call. Keep the same `seed` for a recording so its waveform is stable.

Don't: Don't use an image for the waveform; it is coded. Don't show the player for calls without a recording; use `noRecording`.

Example: With recording and share
```tsx
<CallSummary
  summary="Amit invited you to dinner this Sunday, 8 PM at his place. He asked you to confirm by tonight."
  time="03:21" onShare={share} />
```
```kotlin
var playing by remember { mutableStateOf(false) }
var speed by remember { mutableStateOf(PlaybackSpeed.X1) }

CallSummaryBubble(
    summary = "Amit invited you to dinner this Sunday, 8 PM at his place. He asked you to confirm by tonight.",
    timestamp = "03:21",
    voiceNote = {
        // Compose: the player is controlled; drive progress/elapsed from your media player.
        VoiceNotePlayer(isPlaying = playing, onPlayPauseClick = { playing = !playing },
            progress = 0f, elapsed = "0:00", total = "2:37",
            speed = speed, onSpeedChange = { speed = it })
    },
    onShareClick = {},
)
```

Example: Instruction applied
```tsx
<CallSummary
  summary="Priya from Dr. Mehta's clinic confirmed your appointment for tomorrow at 10 AM. Bring your previous reports."
  time="03:32" tag={{ emoji: '🪄', label: 'Instruction Applied' }} />
```
```kotlin
CallSummaryBubble(
    summary = "Priya from Dr. Mehta's clinic confirmed your appointment for tomorrow at 10 AM. Bring your previous reports.",
    timestamp = "03:32",
    tag = CallSummaryTag(label = "Instruction Applied", emoji = "🪄"),
    modifier = Modifier.width(264.dp),
)
```

Example: Summary only
```tsx
<CallSummary noRecording
  summary="Vijay from NoBroker called with an offer on a 2BHK flat in Sector 12. You said you were not interested and ended the call."
  time="03:21" />
```
```kotlin
// No voiceNote slot = no recording player.
CallSummaryBubble(
    summary = "Vijay from NoBroker called with an offer on a 2BHK flat in Sector 12. You said you were not interested and ended the call.",
    timestamp = "03:21",
)
```

Example: Voice player
```tsx
<VoicePlayer duration={94} seed={7} />
```
```kotlin
var playing by remember { mutableStateOf(false) }
var speed by remember { mutableStateOf(PlaybackSpeed.X1) }

// Compose: no `seed`; pass `samples` for a recording-specific waveform (defaults are fixed).
VoiceNotePlayer(
    isPlaying = playing,
    onPlayPauseClick = { playing = !playing },
    progress = 0f,
    elapsed = "0:00",
    total = "1:34",
    speed = speed,
    onSpeedChange = { speed = it },
)
```

#### Chat bubble (`chat-bubble`)

Message bubbles for a call thread: outgoing (Equal AI or you on the call), incoming (the caller) and assistant (Equal AI talking to you), stacked with MessageList.

- React: `import { ChatBubble, MessageList } from '@equal/ds';`
- Compose: `ChatBubble`
- Tokens: `chat-bubble/user-bg`, `chat-bubble/user-title`, `chat-bubble/other-bg`, `chat-bubble/contact-title`, `bg/surface`, `text/action`, `text/primary`, `text/tertiary`
- Source: §11 Chat Bubbles

Do: Use `outgoing` with sender "Equal AI" when the assistant speaks for the user on a call, and "You" after a takeover. Use `assistant` only when Equal AI is talking to the user, not to the caller. Set first={false} on consecutive bubbles from the same sender.

Don't: Don't mix up outgoing and assistant; the green byline means Equal AI is addressing you. Don't put custom cards inside a padded bubble; use `bare`.

Example: A call thread
```tsx
<MessageList>
  <ChatBubble kind="outgoing" sender="Equal AI" time="03:21">Hi, who is this?</ChatBubble>
  <ChatBubble kind="incoming" sender="Dr Mehta Clinic" time="03:21">
    This is Priya from Dr. Mehta's clinic. Your appointment is confirmed for tomorrow.
  </ChatBubble>
  <ChatBubble kind="outgoing" sender="You" time="03:21">Yes, I'll be there at 10 AM</ChatBubble>
  <ChatBubble kind="assistant" sender="Equal AI" time="03:21">
    Hey Keshav! Here is the summary of your call
  </ChatBubble>
</MessageList>
```
```kotlin
// Compose: no MessageList; a Column with 12dp spacing gives the between-group rhythm.
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    ChatBubble(type = ChatBubbleType.Outgoing, sender = "Equal AI", timestamp = "03:21", message = "Hi, who is this?")
    ChatBubble(type = ChatBubbleType.Incoming, sender = "Dr Mehta Clinic", timestamp = "03:21",
        message = "This is Priya from Dr. Mehta's clinic. Your appointment is confirmed for tomorrow.")
    ChatBubble(type = ChatBubbleType.Outgoing, sender = "You", timestamp = "03:21", message = "Yes, I'll be there at 10 AM")
    ChatBubble(type = ChatBubbleType.Incoming, sender = "Dr Mehta Clinic", timestamp = "03:21",
        message = "Great. Please bring your previous reports too.")
    ChatBubble(type = ChatBubbleType.Assistant, sender = "Equal AI", timestamp = "03:21",
        message = "Hey Keshav! Here is the summary of your call")
}
```

Example: Tails and grouping
```tsx
<ChatBubble kind="incoming" category="real-estate" sender="Vijay · NoBroker" time="03:21" tail>
  I have an offer on a 2BHK flat in Sector 12.
</ChatBubble>
<ChatBubble kind="incoming" category="real-estate" first={false} time="03:21">
  Are you free for a site visit this weekend?
</ChatBubble>
<ChatBubble kind="outgoing" sender="Equal AI" time="03:22" tail>
  Thanks, but Keshav is not interested right now.
</ChatBubble>
```
```kotlin
Column {
    ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.RealEstate,
        sender = "Vijay · NoBroker", timestamp = "03:21", tail = true,
        message = "I have an offer on a 2BHK flat in Sector 12.")
    // Follow-up in the same group: 4dp gap, no avatar, no sender line.
    ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.RealEstate,
        isFirstInGroup = false, timestamp = "03:21", modifier = Modifier.padding(top = 4.dp),
        message = "Are you free for a site visit this weekend?")
    ChatBubble(type = ChatBubbleType.Outgoing, sender = "Equal AI", timestamp = "03:22", tail = true,
        modifier = Modifier.padding(top = 12.dp), message = "Thanks, but Keshav is not interested right now.")
}
```

Example: Bare content
```tsx
<ChatBubble kind="assistant" bare>
  <CallSummary noRecording summary="Delivery agent will arrive between 4 and 5 PM." time="03:21" />
</ChatBubble>
```
```kotlin
// Compose: ChatBubble has no `bare` mode; lay the AI avatar beside the card yourself.
Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    AiAvatar(size = AiAvatarSize.Small)
    CallSummaryBubble(
        summary = "Delivery agent will arrive between 4 and 5 PM.",
        timestamp = "03:21",
        modifier = Modifier.width(240.dp),
    )
}
```

#### Chat list item (`chat-list-item`)

A row in the Chats list with avatar, name, date, preview, unread count and the small action chips; states come from `unread` and `selected`.

- React: `import { ChatListItem } from '@equal/ds';`
- Compose: `ChatListItem`
- Tokens: `bg/surface`, `action-card/highlight`, `text/primary`, `text/secondary`, `text/action`, `text/tertiary`, `button/primary`, `text/on-action`
- Source: §6 Chat List Item

Do: Give unknown callers their category art and saved contacts their initials. Offer the next step as chips on the row (📞 Call Back, 🗓️ Add to Calendar) so it is one tap from the list. Use long-press to enter selection mode.

Don't: Don't set chip states yourself; the row derives them from unread and selected. Don't let the preview wrap; it is one line with an ellipsis.

Example: Unread and read
```tsx
<ChatListItem name="Arnav Raj" preview="You have a visitor" date="Yesterday"
  unread={5} avatar={{ category: 'na' }}
  actions={[
    { label: 'Call Back', emoji: '📞' },
    { label: 'Update Address', emoji: '✏️' },
    { label: 'Add to Calendar', emoji: '🗓️' },
  ]} />
<ChatListItem name="Amit Nanda" preview="Count me in for Sunday 8 PM 👍" date="12 July"
  avatar={{ initials: 'AN' }} actions={[{ label: 'Call Back', emoji: '📞' }]} />
```
```kotlin
ChatListItem(
    name = "Arnav Raj",
    preview = "You have a visitor",
    date = "Yesterday",
    state = ChatListItemState.Unread,
    unreadCount = 5,
    category = EqualCategory.NA,
    chips = listOf(
        ActionChipData("Call Back", "📞"),
        ActionChipData("Update Address", "✏️"),
        ActionChipData("Add to Calendar", "🗓️"),
    ),
)
ChatListItem(
    name = "Amit Nanda",
    preview = "Count me in for Sunday 8 PM 👍",
    date = "12 July",
    initials = "AN",
    chips = listOf(ActionChipData("Call Back", "📞")),
)
```

Example: Long-press to select
```tsx
<ChatListItem name="Dr Mehta Clinic" preview="Appointment confirmed for tomorrow, 10 AM"
  date="03:21" unread={2} avatar={{ category: 'others' }}
  actions={[{ label: 'Add to Calendar', emoji: '🗓️' }, { label: 'Call Back', emoji: '📞' }]}
  selected={selected} onLongPress={() => setSelected(true)} />
```
```kotlin
var selected by remember { mutableStateOf(false) }

ChatListItem(
    name = "Dr Mehta Clinic",
    preview = "Appointment confirmed for tomorrow, 10 AM",
    date = "03:21",
    state = if (selected) ChatListItemState.Selected else ChatListItemState.Unread,
    unreadCount = 2,
    category = EqualCategory.Others,
    chips = listOf(ActionChipData("Add to Calendar", "🗓️"), ActionChipData("Call Back", "📞")),
    onLongClick = { selected = true },
    onClick = { selected = false },
)
```

Example: The list
```tsx
{chats.map((c) => (
  <ChatListItem key={c.id} name={c.name} preview={c.preview} date={c.date}
    unread={c.unread} actions={c.actions}
    avatar={c.initials ? { initials: c.initials } : { category: c.category }} />
))}
```
```kotlin
val callBack = listOf(ActionChipData("Call Back", "📞"))
Column {
    ChatListItem(name = "Amit Nanda", preview = "Count me in for Sunday 8 PM 👍", date = "12 July",
        initials = "AN", chips = callBack)
    ChatListItem(name = "Vijay · NoBroker", preview = "Offer on a 2BHK flat in Sector 12", date = "10 July",
        category = EqualCategory.RealEstate, chips = callBack)
    ChatListItem(name = "Swiggy Delivery", preview = "Your order is at the gate", date = "09 July",
        category = EqualCategory.Delivery, chips = listOf(ActionChipData("Update Address", "✏️")))
    ChatListItem(name = "HDFC Bank", preview = "Pre-approved loan offer. You said not interested", date = "08 July",
        category = EqualCategory.Financial, chips = callBack)
}
```

#### Chat wallpaper (`chat-wallpaper`)

The doodle pattern behind chat threads and the instruction setup chat, tinted by token so one tile serves light and dark.

- React: `import { ChatWallpaper } from '@equal/ds';`
- Compose: `ChatWallpaper`
- Tokens: `chat/wallpaper-bg`, `chat/wallpaper-pattern`
- Source: Flows · Chat wallpaper

Do: Use it behind chat threads and the "Setting up instruction" chat only. Give it minHeight: 100% so the pattern fills short threads.

Don't: Don't put the wallpaper behind lists or settings screens. Don't tint the pattern yourself; it reads chat/wallpaper-pattern in both themes.

Example: Behind a thread
```tsx
<ChatWallpaper style={{ minHeight: '100%' }}>
  <MessageList>
    <DayDivider label="Today" />
    <ChatBubble kind="outgoing" sender="Equal AI" time="03:21">Hi, who is this?</ChatBubble>
    …
  </MessageList>
</ChatWallpaper>
```
```kotlin
ChatWallpaper(Modifier.fillMaxSize()) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        DayDivider("Today")
        ChatBubble(type = ChatBubbleType.Outgoing, sender = "Equal AI", timestamp = "03:21", message = "Hi, who is this?")
        ChatBubble(type = ChatBubbleType.Incoming, sender = "Dr Mehta Clinic", timestamp = "03:21",
            message = "This is Priya from Dr. Mehta's clinic. Your appointment is confirmed for tomorrow.")
    }
}
```

#### Missed call card (`missed-call`)

The thread card for a call the assistant couldn’t pick up. One component, three cases: we know why the caller usually calls, we know only their name, or we know nothing. Every case ends in Call back.

- React: `import { MissedCallCard } from '@equal/ds';`
- Compose: `MissedCallCard`
- Tokens: `bg/surface`, `missed-call/bg`, `missed-call/stroke`, `missed-call/icon-bg`, `missed-call/icon`, `text/primary`, `text/secondary`, `text/tertiary`, `text/action`, `stroke/subtle`

Do: Pick the case from what we know: reason + art, then name only, then unknown. Never invent a reason. Show thumbs only with a reason, since they rate the reason. Call back opens the same Call Back task as everywhere else (Flows → Call Back).

Don't: Don’t colour the whole card red; the warm tint says “missed”, not “error”. Don’t show caller art without a reason; the disc keeps the three cases distinct.

Example: With a reason
```tsx
<MissedCallCard
  caller="Kuldeep Solanki" category="real-estate"
  reason={<>Promote <b>L&amp;T Realty residential</b> projects.</>}
  time="03:21" onCallBack={callBack}
  feedback={feedback} onFeedback={setFeedback} />
```
```kotlin
EqualTheme {
    var feedback by remember { mutableStateOf<CallFeedback?>(null) }
    MissedCallCard(
        caller = "Kuldeep Solanki",
        category = EqualCategory.RealEstate,
        reason = buildAnnotatedString {
            append("Promote ")
            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("L&T Realty residential") }
            append(" projects.")
        },
        time = "03:21",
        onCallBack = { /* call back */ },
        feedback = feedback,
        onFeedback = { feedback = it },
    )
}
```

Example: Caller unknown
```tsx
<MissedCallCard time="3:31 PM" onCallBack={callBack} />
```
```kotlin
EqualTheme {
    MissedCallCard(time = "3:31 PM", onCallBack = { /* call back */ })
}
```

Example: Name only
```tsx
<MissedCallCard caller="Valluri" time="3:31 PM" onCallBack={callBack} />
```
```kotlin
EqualTheme {
    MissedCallCard(caller = "Valluri", time = "3:31 PM", onCallBack = { /* call back */ })
}
```

### Group: Display

#### Avatars (`avatars`)

Every face in the app: caller category art or initials for contacts, the Equal orb for the assistant, the ringed 3D profile avatar for the user, and the robot mascot.

- React: `import { ContactAvatar, CategoryAvatar, AiAvatar, EqualOrb, ProfileAvatar, Mascot } from '@equal/ds';`
- Compose: `ContactAvatar`, `CategoryAvatar`, `InitialsAvatar`, `AiAvatar`, `EqualLogoOrb`, `ProfileAvatar`, `EqualMascot`
- Tokens: `action-card/highlight`, `text/action`, `button/primary`, `text/on-action`, `bg/surface`
- Source: Icons, emoji, categories, logo · §12 AI Assistant Avatar

Do: Default unknown callers to `na` and incoming bubbles to `others` (the red telephone). Size ProfileAvatar by width only; its height follows so the head can rise above the ring. Use AiAvatar at 24 / 36 / 48 only.

Don't: Never crop category art or the profile avatar; the circle and ring are part of the image. Don't draw your own green circle for the assistant; the orb swaps light (#00B140) and dark (lime) files by theme. Don't use initials for business callers; they get their category art.

Example: Profile avatar: free vs paid
```tsx
<ProfileAvatar variant="male" size={70} tier="free" />
<ProfileAvatar variant="male" size={70} tier="paid" />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
    ProfileAvatar(variant = ProfileAvatarVariant.Male, width = 70.dp, tier = PlanTier.Free)
    ProfileAvatar(variant = ProfileAvatarVariant.Male, width = 70.dp, tier = PlanTier.Paid)
}
```

Example: Caller categories
```tsx
<CategoryAvatar category="na" />
<CategoryAvatar category="delivery" />
<CategoryAvatar category="real-estate" size={48} />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
    CategoryAvatar(category = EqualCategory.NA, size = 48.dp)
    CategoryAvatar(category = EqualCategory.Delivery, size = 48.dp)
    CategoryAvatar(category = EqualCategory.RealEstate, size = 48.dp)
}
```

Example: Contact avatar
```tsx
<ContactAvatar />
<ContactAvatar category="others" />
<ContactAvatar initials="AN" />
<ContactAvatar initials="AN" selected />
<ContactAvatar category="career" size={36} />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
    ContactAvatar(size = 48.dp)
    ContactAvatar(size = 48.dp, category = EqualCategory.Others)
    ContactAvatar(size = 48.dp, initials = "AN")
    ContactAvatar(size = 48.dp, initials = "AN", selected = true)
    ContactAvatar(size = 36.dp, category = EqualCategory.Career)
}
```

Example: Saved-contact colours
```tsx
<ContactAvatar initials="AN" />              // tone picked from the initials
<ContactAvatar initials="AR" tone="green" />  // blue · green · purple · orange · pink · teal
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
    // The tone is picked from the initials by default; pass tone to choose.
    listOf("AN", "AR", "KS", "PR", "VJ", "MS").zip(ContactTone.entries).forEach { (initials, tone) ->
        InitialsAvatar(initials = initials, size = 48.dp, tone = tone)
    }
}
```

Example: Assistant, user and mascot
```tsx
<AiAvatar size={24} />
<AiAvatar size={36} />
<AiAvatar size={48} />
<EqualOrb size={58} />
<ProfileAvatar size={70} />
<ProfileAvatar variant="female" size={70} />
<Mascot size={40} />
<Mascot size={40} dimmed />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.Bottom) {
    AiAvatar(size = AiAvatarSize.Small)
    AiAvatar(size = AiAvatarSize.Medium)
    AiAvatar(size = AiAvatarSize.Large)
    EqualLogoOrb(size = 58.dp)
    ProfileAvatar(variant = ProfileAvatarVariant.Male, width = 70.dp)
    ProfileAvatar(variant = ProfileAvatarVariant.Female, width = 70.dp)
    EqualMascot(size = 40.dp)
    EqualMascot(size = 40.dp, dimmed = true)
}
```

#### Badges (`badges`)

Small uppercase markers: NEW on settings rows, unread counts, the NEW FEATURE pill on announcements, and the gold UNLIMITED plan marker.

- React: `import { NewBadge, CountBadge, FeatureBadge, PlanBadge } from '@equal/ds';`
- Compose: `NewBadge`, `CountBadge`, `FeatureBadge`, `PlanBadge`
- Tokens: `button/primary`, `text/on-action`, `bg/surface`, `badge/new-feature-stroke`, `text/secondary`, `gradient/gold`, `text/on-dark`
- Source: §20 Badge

Do: Keep badge text to one or two words; badges never wrap. Pass normal-case strings; the components uppercase badge text in the string (rule 5). Use CountBadge for unread messages only; it hides itself at zero.

Don't: Don't use NewBadge for counts or statuses; it means "new" and nothing else. Don't recolour PlanBadge; the gold gradient marks the plan everywhere (top bar, profile).

Example: All badges
```tsx
<NewBadge />
<NewBadge tone="soft" />
<CountBadge count={5} />
<CountBadge count={12} />
<CountBadge count={140} />   {/* renders 99+ */}
<FeatureBadge />
<PlanBadge />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
    NewBadge()
    // Compose: no tone = "soft"; NewBadge has the solid fill only.
    CountBadge(count = 5)
    CountBadge(count = 12)
    CountBadge(count = 140) // renders 99+
    FeatureBadge()
    PlanBadge()
}
```

Example: In context
```tsx
<TopBar />                                  {/* PlanBadge */}
<SettingsRow icon="instructions" label="Instructions" isNew
  description="Tell assistant how you'd like it to help" />   {/* NewBadge */}
<ChatListItem name="Arnav Raj" preview="You have a visitor"
  date="Yesterday" unread={5} />             {/* CountBadge */}
```
```kotlin
Column {
    TopBar() // PlanBadge
    RowGroup(inset = 0.dp) {
        SettingsRow(
            label = "Instructions",
            description = "Tell assistant how you'd like it to help",
            leadingIcon = EqualIcons.Instructions,
            showNewBadge = true, // NewBadge
        )
    }
    ChatListItem(
        name = "Arnav Raj",
        preview = "You have a visitor",
        date = "Yesterday",
        state = ChatListItemState.Unread,
        unreadCount = 5, // CountBadge
    )
}
```

#### Lottie animation (`lottie`)

Plays illustrative animations shipped as Lottie JSON: mascot moments, celebrations, typing. The same file plays on web and Android.

- React: `import { Lottie } from '@equal/ds';`
- Compose: `EqualLottie`
- Tokens: `text/action`
- Source: Motion · Animations

Do: Use Lottie for illustrative motion; keep micro-interactions (press, toggles, sheets) in code on the motion tokens. Export from After Effects with Bodymovin, shapes only (no images or text layers), 60 fps, under ~100 KB. Tint single-colour animations with `text/action` so they follow the theme.

Don't: Don't rebuild an animation by hand in code when a Lottie file exists. Don't autoplay looping animations behind text people are reading.

Example: Typing dots
```tsx
// assets/lottie/typing-dots.json
<Lottie name="typing-dots" width={120} height={40} tint="var(--eq-text-action)" label="Equal AI is typing" />
```
```kotlin
// res/raw/lottie_typing_dots.json (copied from assets/lottie/ by `npm run assets`)
EqualLottie(
    rawRes = R.raw.lottie_typing_dots,
    width = 120.dp,
    height = 40.dp,
    tint = EqualTheme.colors.textAction,
    contentDescription = "Equal AI is typing",
)
```

Example: Original colours, play once
```tsx
<Lottie name="typing-dots" width={120} height={40} loop={false} />
```
```kotlin
EqualLottie(rawRes = R.raw.lottie_typing_dots, width = 120.dp, height = 40.dp, iterations = 1)
```

### Group: Flows

#### Address (`address`)

Saved address cards with an Edit / Delete overflow, and the add/edit form (label chips, address lines, city, pincode, guiding direction, Save).

- React: `import { AddressCard, AddressForm, formatAddress } from '@equal/ds';`
- Compose: `AddressCard`, `AddressForm`
- Tokens: `bg/surface`, `text/primary`, `text/secondary`, `text/tertiary`, `text/danger`, `chip/selected-bg`, `button/primary`
- Source: Flows · Addresses

Do: Use formatAddress so every card reads "line1, line2, City- pincode". Open the form in a titled BottomSheet ("Edit Address" / "Add Address"). Route Delete address through the trash confirm sheet.

Don't: Don't show Edit as a separate button; it lives in the ⋮ menu. Don't accept a pincode that isn't six digits; the form blocks Save.

Example: Saved addresses
```tsx
{addresses.map((a) => (
  <AddressCard key={a.id} label={a.label} address={formatAddress(a)}
    onEdit={() => edit(a)} onDelete={() => confirmDelete(a)} />
))}
```
```kotlin
var addresses by remember { mutableStateOf(SampleAddresses) }
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    addresses.forEach { a ->
        AddressCard(
            label = a.label,
            address = formatAddress(a),
            onEdit = {},
            onDelete = { addresses = addresses - a },
        )
    }
}
```

Example: Long address
```tsx
<AddressCard label="Work"
  address="Flat 4B, Block C, Skyline Towers, Phase 2, HITECH city, MG Road, Opposite City Center Mall, Banjara Hills, Hyderabad- 500034"
  onEdit={edit} />
```
```kotlin
AddressCard(
    label = "Work",
    address = "Flat 4B, Block C, Skyline Towers, Phase 2, HITECH city, MG Road, Opposite City Center Mall, Banjara Hills, Hyderabad- 500034",
    onEdit = {},
)
```

Example: Edit address form
```tsx
<AddressForm
  initial={{ label: 'Home', line1: 'House no. 4, Tony Street', line2: 'Financial District', city: 'Hyderabad', pincode: '500032' }}
  onSave={(address) => save(address)} />
```
```kotlin
AddressForm(
    // Compose: SavedAddress needs an id (web takes a Partial)
    initial = SavedAddress(
        id = "a1",
        label = "Home",
        line1 = "House no. 4, Tony Street",
        line2 = "Financial District",
        city = "Hyderabad",
        pincode = "500032",
    ),
    onSave = {},
)
```

#### Call Handling (`call-handling`)

Pieces of the Call Handling setup and the known-call notification: radio choice cards, contact pickers with an A–Z index, the setup takeover, permission sheets, the done wash, the Android ongoing-call notification and the ongoing-call strip.

- React: `import { CallQuestion, ChoiceCard, InfoNote, ContactPick, ContactCheckRow, AlphabetIndex, SetupPrompt, SetupDone, PermissionSheet, CallNotification, OngoingCallBar } from '@equal/ds';`
- Compose: `CallQuestion`, `ChoiceCard`, `SuggestedTag`, `InfoNote`, `ContactPick`, `ContactCheckRow`, `AlphabetIndex`, `SetupPrompt`, `SetupDone`, `PermissionSheet`, `CallNotification`, `OngoingCallBar`
- Tokens: `choice/selected-bg`, `gradient/choice-stroke`, `info-note/bg`, `initials-disc/bg`, `gradient/setup-done`, `gradient/setup-prompt`, `ongoing-bar/bg`, `ongoing-bar/text`
- Source: Known Calls (new users) · Known-call notifications

Props of `ChoiceCard`:
- `icon`: `IconName`. Leading icon.
- `title`: `string`. Option.
- `description`: `string`. What it means.
- `selected?`: `boolean`. Green outline + tint.
- `suggested?`: `boolean`. ⭐ Suggested tag.
- `disabled?`: `boolean`. Dimmed (e.g. no permission).
- `onSelect?`: `() => void`. Choose.

Props of `CallNotification`:
- `name`: `string`. Caller.
- `state`: `'answering' | 'summary' | 'expanded' | 'connecting'`. Stage of the call.
- `category?`: `Category` = 'home-services'. Avatar art.
- `elapsed?`: `string` = '00:06'. Timer.
- `summary?`: `string`. What the caller wants.
- `replies?`: `string[]`. Quick replies (expanded).

Props of `PermissionSheet`:
- `art`: `AssetName`. 3D art.
- `title`: `string`. Ask.
- `body`: `ReactNode`. Why.
- `cta`: `string`. Action.
- `secondary?`: `string`. Underlined text action (e.g. Skip, answer everyone).
- `onClose?`: `() => void`. Floating close.

Do: Ask for a permission only at the step that needs it, and say why in one line. Keep the notification to who, what they want and one tap to act; Takeover always comes first.

Don't: Don't style the notification beyond Android's shell; the system draws it. Don't make the user pick contacts before they've chosen All calls.

Example: Choice cards
```tsx
<div role="radiogroup">
  <ChoiceCard icon="globe" title="All calls, except a few" description="I answer everyone. You pick who I skip." selected={mode === 'all'} onSelect={() => setMode('all')} />
  <ChoiceCard icon="call" title="Only unknown numbers" description="I answer numbers that are not saved in your phone." selected={mode === 'unknown'} onSelect={() => setMode('unknown')} />
</div>
<InfoNote title="Contact access needed" body="Without it, the assistant can’t handle all calls." link="Give contacts permission" onLink={askContacts} />
```
```kotlin
var mode by remember { mutableStateOf(CallMode.All) }
Column(Modifier.selectableGroup(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
    ChoiceCard(
        icon = EqualIcons.Globe,
        title = "All calls, except a few",
        description = "I answer everyone. You pick who I skip.",
        selected = mode == CallMode.All,
        onSelect = { mode = CallMode.All },
    )
    ChoiceCard(
        icon = EqualIcons.Call,
        title = "Only unknown numbers",
        description = "I answer numbers that are not saved in your phone.",
        selected = mode == CallMode.Unknown,
        onSelect = { mode = CallMode.Unknown },
    )
    InfoNote(
        title = "Contact access needed",
        body = "Without it, the assistant can’t handle all calls.",
        link = "Give contacts permission",
        onLink = { /* ask for READ_CONTACTS */ },
    )
}
```

Example: Contact pickers
```tsx
<ContactPick initials="SU" name="Mom" onClick={add} />
<ContactPick initials="VC" name="Vijay Cousin" mark="remove" onClick={remove} />
<ContactCheckRow initials="AR" name="Arnav Raj" phone="+91 8986461540" checked={picked} onToggle={toggle} />
<AlphabetIndex onPick={jumpTo} />
```
```kotlin
var picked by remember { mutableStateOf(true) }
Column {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ContactPick(initials = "SU", name = "Mom", onClick = { /* add */ })
        ContactPick(initials = "VC", name = "Vijay Cousin", onClick = { /* remove */ }, mark = ContactPickMark.Remove)
    }
    Box(Modifier.fillMaxWidth()) {
        ContactCheckRow(initials = "AR", name = "Arnav Raj", phone = "+91 8986461540", checked = picked, onCheckedChange = { picked = it })
        AlphabetIndex(Modifier.align(Alignment.CenterEnd).padding(end = 2.dp), onPick = { /* jump to letter */ })
    }
}
```

Example: Permission sheet
```tsx
<PermissionSheet art="permission-contacts" title="Allow contacts permission" body="I need your contact list to know who is calling." cta="Allow" onAllow={requestContacts} onClose={close} />
```
```kotlin
// Overlay: fills the screen (scrim + sheet); pass inline = true to draw only the sheet
PermissionSheet(
    art = EqualAssets.PermissionContacts,
    title = "Allow contacts permission",
    body = "I need your contact list to know who is calling.",
    cta = "Allow",
    onAllow = { /* request READ_CONTACTS */ },
    onClose = { /* hide the sheet */ },
)
```

Example: Call notification
```tsx
<CallNotification name="Mom" state="answering" />
<CallNotification name="Mom" state="expanded" summary={liveSummary} replies={['Takeover', 'I’ll bring them all', 'I’ll call back to get more']} onReply={reply} onAnswer={answer} />
<CallNotification name="Mom" state="connecting" />
```
```kotlin
// Design reference + in-app preview. On device, build the same content into an ongoing
// NotificationCompat (CATEGORY_CALL, custom RemoteViews); the system draws the shell.
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    CallNotification(name = "Mom", state = CallNotificationState.Answering)
    CallNotification(
        name = "Mom",
        state = CallNotificationState.Expanded,
        category = EqualCategory.HomeServices,
        summary = SampleCallSummary,
        replies = listOf("Takeover", "I’ll bring them all", "I’ll call back to get more"),
        onReply = { /* say it (it == "Takeover": pick up) */ },
        onAnswer = { /* pick up */ },
    )
    CallNotification(name = "Mom", state = CallNotificationState.Connecting)
}
```

Example: Ongoing call bar
```tsx
<OngoingCallBar elapsed="02:34" />
```
```kotlin
OngoingCallBar(elapsed = "02:34")
```

#### Gender selector (`gender-selector`)

The two-card Male / Female picker in Personal Details; the choice sets the profile avatar across the app.

- React: `import { GenderSelector } from '@equal/ds';`
- Compose: `GenderSelector`
- Tokens: `bg/surface`, `button/primary`, `gradient/gender-selected`, `text/primary`
- Source: Flows · Profile

Do: Update the profile avatar (hero and bottom nav) as soon as the user picks. Place it under a GENDER overline, below the Name field.

Don't: Don't crop the bust art; if it is missing the card falls back to the ringed avatar. Don't add a third card or a text input here.

Example: Free vs paid
```tsx
<GenderSelector value={gender} onChange={setGender} tier="free" />
<GenderSelector value={gender} onChange={setGender} tier="paid" />
```
```kotlin
var gender by remember { mutableStateOf(Gender.Male) }
Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    GenderSelector(value = gender, onValueChange = { gender = it }, tier = PlanTier.Free)
    GenderSelector(value = gender, onValueChange = { gender = it }, tier = PlanTier.Paid)
}
```

Example: Interactive
```tsx
const [gender, setGender] = useState<Gender>('male');

<GenderSelector value={gender} onChange={setGender} />
<ProfileAvatar variant={gender} size={56} />
```
```kotlin
var gender by remember { mutableStateOf(Gender.Male) }
GenderSelector(value = gender, onValueChange = { gender = it })
ProfileAvatar(
    variant = if (gender == Gender.Male) ProfileAvatarVariant.Male else ProfileAvatarVariant.Female,
    width = 56.dp,
)
```

Example: In Personal Details
```tsx
<AppBar title="Personal Details" onBack={goBack} />
<TextField label="Name" value={name} onChange={setName}
  helper="Your AI will call you 'Keshav'" />
<SectionHeader inset={0}>Gender</SectionHeader>
<GenderSelector value={gender} onChange={setGender} />
```
```kotlin
var name by remember { mutableStateOf("Keshav") }
var gender by remember { mutableStateOf(Gender.Female) }
EqualAppBar(title = "Personal Details", onBackClick = {})
EqualTextField(
    value = name,
    onValueChange = { name = it },
    label = "Name",
    helper = AnnotatedString("Your AI will call you '$name'"),
)
SectionHeader(title = "Gender", inset = 0.dp)
GenderSelector(value = gender, onValueChange = { gender = it })
```

#### Instruction cards (`instruction-cards`)

The pieces of the Instructions flow: recommended and preset cards on the hub, preset and active instruction cards with When / Do rows, and the preview shown in the setup chat.

- React: `import { RecommendedCard, SuggestionsComingCard, PresetCard, PresetInstructionCard, InstructionCard, WhenDoRow, InstructionPreview } from '@equal/ds';`
- Compose: `RecommendedCard`, `SuggestionsComingCard`, `PresetCard`, `PresetInstructionCard`, `InstructionCard`, `WhenDoRow`, `InstructionPreview`
- Tokens: `bg/surface`, `chip/when-bg`, `chip/do-bg`, `preset/tint-red`, `preset/tint-green`, `preset/tint-orange`, `gradient/suggestion-card`, `text/primary`, `text/secondary`, `text/tertiary`, `text/action`, `button/primary`
- Source: Flows · Instructions · Instruction Card

Do: Write When as the situation and Do as the assistant's behaviour, in plain first person ("say I am not interested"). Use sentence-case When / Do on presets and uppercase WHEN / DO on active instructions (`upper`). Confirm with 👍 Confirm (unread) next to ✍️ Edit (read) under the preview. Show SuggestionsComingCard once every recommendation is applied.

Don't: Don't delete an instruction straight from the ⋮ menu; confirm first. Don't use Material icons on preset or recommended cards; they lead with emoji. Don't put two filled buttons on a preset instruction; Apply is the only commit.

Example: Recommended for you
```tsx
<RecommendedCard emoji="🚫" title="Decline sales & spam"
  description="Politely declines sales and insurance calls." onAdd={add} />
<RecommendedCard emoji="💬" title="Take a message"
  description="Takes their name, number and message." onAdd={add} />

{allApplied && <SuggestionsComingCard />}
```
```kotlin
var added by remember { mutableStateOf(setOf<String>()) }
if (added.size < 2) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        if ("decline" !in added) {
            RecommendedCard(
                emoji = "🚫",
                title = "Decline sales & spam",
                description = "Politely declines sales and insurance calls.",
                onAdd = { added = added + "decline" },
            )
        }
        if ("message" !in added) {
            RecommendedCard(
                emoji = "💬",
                title = "Take a message",
                description = "Takes their name, number and message.",
                onAdd = { added = added + "message" },
            )
        }
    }
} else {
    SuggestionsComingCard()
}
```

Example: Browse presets
```tsx
<PresetCard emoji="🛡️" tint="red" title="Screen & Protect"
  description="Decline spam, hold the line on loan and payments call, close wrong call" onClick={open} />
<PresetCard emoji="📞" tint="green" title="Handle everyday calls"
  description="Take message, guide deliveries, relay to family, start in your language" onClick={open} />
<PresetCard emoji="💼" tint="orange" title="Run my business"
  description="Capture enquiries, orders, bookings, job, and supplier calls" onClick={open} />
```
```kotlin
PresetCard(
    emoji = "🛡️", tint = PresetTint.Red, title = "Screen & Protect",
    description = "Decline spam, hold the line on loan and payments call, close wrong call", onClick = {},
)
PresetCard(
    emoji = "📞", tint = PresetTint.Green, title = "Handle everyday calls",
    description = "Take message, guide deliveries, relay to family, start in your language", onClick = {},
)
PresetCard(
    emoji = "💼", tint = PresetTint.Orange, title = "Run my business",
    description = "Capture enquiries, orders, bookings, job, and supplier calls", onClick = {},
)
```

Example: Preset instructions
```tsx
<PresetInstructionCard instruction={instructionLibrary.declineSales}
  applied={applied} onApply={apply} />
```
```kotlin
var applied by remember { mutableStateOf(false) }
PresetInstructionCard(
    instruction = InstructionLibrary.declineSales,
    applied = applied,
    onApply = { applied = true },
)
```

Example: Active instructions
```tsx
<InstructionCard instruction={{
  id: 'decline-sales',
  title: 'Decline sales, promo spam calls',
  source: { emoji: '✨', label: 'Recommended for you' },
  when: 'The caller is selling loan, insurance, credit card, product, or another unsolicited offer',
  do: 'Politely say I am not interested and end the conversation without discussing the offer',
}} onEdit={edit} onDelete={confirmDelete} />
```
```kotlin
InstructionCard(
    instruction = Instruction(
        id = "decline-sales",
        title = "Decline sales, promo spam calls",
        source = InstructionSource(emoji = "✨", label = "Recommended for you"),
        whenText = "The caller is selling loan, insurance, credit card, product, or another unsolicited offer",
        doText = "Politely say I am not interested and end the conversation without discussing the offer",
    ),
    onEdit = {},
    onDelete = {},
)
```

Example: Preview in the setup chat
```tsx
<InstructionPreview title="Decline sales calls"
  when="Caller is selling a loan, insurance or product"
  action="Politely decline and end the conversation"
  time="03:21" confirmed={confirmed} />
```
```kotlin
var confirmed by remember { mutableStateOf(false) }
InstructionPreview(
    title = "Decline sales calls",
    whenText = AnnotatedString("Caller is selling a loan, insurance or product"),
    action = AnnotatedString("Politely decline and end the conversation"),
    time = "03:21",
    confirmed = confirmed,
)
```

### Group: Inputs

#### Checkbox (`checkbox`)

A coded checkbox with an optional label, used for multi-select such as "Select All" in chat-list selection mode.

- React: `import { Checkbox } from '@equal/ds';`
- Compose: `EqualCheckbox`
- Tokens: `button/primary`, `text/secondary`, `text/primary`
- Source: §5 Chat Header · Selection mode

Do: Use for multi-select lists; the whole label is the tap target. Use bodyLarge labels in headers ("Select All") and body1 in dense lists.

Don't: Don't use a checkbox for an instant on/off setting; that is a Switch. Don't replace the coded box with an image; checkboxes are coded, never images.

Example: Interactive
```tsx
const [all, setAll] = useState(false);

<Checkbox checked={all} onChange={setAll} label="Select All" />
<Checkbox checked={a} onChange={setA} label="Loan Offers" labelVariant="body1" />
```
```kotlin
var all by remember { mutableStateOf(false) }
var loanOffers by remember { mutableStateOf(false) }

// Compose: no label / labelVariant params; put an EqualText beside the box.
Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
    EqualCheckbox(checked = all, onCheckedChange = { all = it })
    EqualText(text = "Select All", style = EqualTheme.type.bodyLarge, color = EqualTheme.colors.textPrimary)
}
Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
    EqualCheckbox(checked = loanOffers, onCheckedChange = { loanOffers = it })
    EqualText(text = "Loan Offers", style = EqualTheme.type.body1, color = EqualTheme.colors.textPrimary)
}
```

Example: Sizes and bare
```tsx
<Checkbox checked size={18} />
<Checkbox checked={false} size={18} />
<Checkbox checked />
<Checkbox checked={false} />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
    EqualCheckbox(checked = true, onCheckedChange = {}, size = 18.dp)
    EqualCheckbox(checked = false, onCheckedChange = {}, size = 18.dp)
    // Compose: default size is 18.dp (web defaults to 22), so pass 22.dp explicitly.
    EqualCheckbox(checked = true, onCheckedChange = {}, size = 22.dp)
    EqualCheckbox(checked = false, onCheckedChange = {}, size = 22.dp)
}
```

Example: In the selection header
```tsx
<SelectionHeader count={selected.length} allSelected={all}
  onSelectAll={(v) => setSelected(v ? ids : [])} />
```
```kotlin
val ids = listOf("arnav", "amit", "priya")
var selected by remember { mutableStateOf(setOf<String>()) }

SelectionChatHeader(
    selectedCount = selected.size,
    allSelected = selected.size == ids.size,
    onSelectAllChange = { all -> selected = if (all) ids.toSet() else emptySet() },
    onBackClick = {},
    onMarkReadClick = {},
    onDeleteClick = {},
)
```

#### Composer (`composer`)

The message input bar with a send button that stays disabled until there is text, used at the bottom of a chat and in the AI panel.

- React: `import { Composer } from '@equal/ds';`
- Compose: `VoiceInputBar`
- Tokens: `bg/surface`, `stroke/subtle`, `action/stroke/unread`, `shadow/focusRing`, `gradient/send-disabled`, `gradient/fab`, `shadow/fab`, `text/tertiary`, `text/primary`
- Source: §15 Voice Input Bar (Composer)

Do: Pin the composer to the bottom of the chat or AI panel. Leave send disabled on empty input; the component does this for you.

Don't: Don't add attachment or emoji buttons inside the bar; the spec is input + send only. Don't change the send glyph; it is the coded send icon rotated −35°.

Example: Interactive
```tsx
<Composer onSend={(text) => setSent((s) => [...s, text])} />
```
```kotlin
val sent = remember { mutableStateListOf<String>() }
var text by remember { mutableStateOf("") }

// Compose: always controlled; clear the value yourself after send.
VoiceInputBar(
    value = text,
    onValueChange = { text = it },
    onSend = {
        sent += text.trim()
        text = ""
    },
)
```

Example: States
```tsx
<Composer />
<Composer forceFocus />
<Composer value="Sure, I'll be there!" onChange={setText} />
```
```kotlin
var text by remember { mutableStateOf("Sure, I'll be there!") }

Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    VoiceInputBar(value = "", onValueChange = {}, onSend = {})
    // Compose: no forceFocus; the focused look appears when the field has focus.
    VoiceInputBar(value = text, onValueChange = { text = it }, onSend = {})
}
```

#### Search (`search`)

The search screen’s pieces: the outlined search bar with back inside, section labels with Clear all, recent searches as avatar tiles, message hits with the match in bold, loading dots and the three illustration states.

- React: `import { SearchBar, SearchSection, RecentSearches, MessageResult, LoadingDots, SearchState } from '@equal/ds';`
- Compose: `SearchBar`, `SearchSection`, `RecentSearches`, `MessageResult`, `LoadingDots`, `SearchState`
- Tokens: `button/primary`, `bg/surface`, `text/tertiary`, `text/primary`
- Source: Search

Props of `SearchBar`:
- `value`: `string`. Query.
- `onChange?`: `(v: string) => void`. Typing.
- `onBack?`: `() => void`. Back arrow inside the bar.
- `placeholder?`: `string` = 'Search for names'. Hint.

Props of `MessageResult`:
- `name`: `string`. Who.
- `time`: `string`. When.
- `text`: `string`. The message line.
- `query`: `string`. Bolded wherever it appears.

Props of `SearchState`:
- `art`: `AssetName`. Illustration.
- `title`: `string`. Headline.
- `body`: `string`. One line of help.
- `size?`: `number` = 160. Art size.

Do: Show chats first and messages after; chats come back fastest. Bold the match in message hits so people see why each one showed up.

Don't: Don't show a spinner for the whole screen; load each section in place with the dots. Don't reuse the no-results art for errors; offline has its own.

Example: Search bar
```tsx
<SearchBar value={q} onChange={setQ} onBack={goBack} autoFocus />
```
```kotlin
var q by remember { mutableStateOf("") }
SearchBar(value = q, onValueChange = { q = it }, onBack = {}, autoFocus = true)
```

Example: Recent searches
```tsx
<SearchSection title="Recent searches" onClear={clearRecent} />
<RecentSearches items={recent} onPick={setQ} />
```
```kotlin
var q by remember { mutableStateOf("") }
var recent by remember {
    mutableStateOf(
        listOf(
            RecentSearch("Amit Nanda", EqualCategory.Career),
            RecentSearch("Shankar", EqualCategory.Ride),
            RecentSearch("DSR Builder", EqualCategory.Financial),
        ),
    )
}
Column {
    SearchBar(value = q, onValueChange = { q = it })
    SearchSection(title = "Recent searches", onClear = { recent = emptyList() })
    RecentSearches(items = recent, onPick = { q = it })
}
```

Example: Message results
```tsx
<MessageResult name="Santosh Anna" time="3:02 PM" text={line} query={q} onClick={openMessage} />
```
```kotlin
val q = "Sa"
Column {
    SearchSection(title = "Messages")
    MessageResult(name = "Santosh Anna", time = "3:02 PM", text = "Caller said that they’ll call you in the evening", query = q, onClick = {})
    EqualDivider()
    MessageResult(name = "Amit Nanda", time = "3:02 PM", text = "Same address, near Gachibowli", query = q, onClick = {})
}
```

Example: States
```tsx
<SearchState art="illustration-search" title="Search across your calls" body="…" />
<SearchState art="illustration-no-internet" title="No internet connection" body="…" />
<SearchState art="illustration-no-results" title="No results found" body="…" />
<LoadingDots />
```
```kotlin
Column {
    // Compose: SearchState takes an EqualAssets illustration and a size in dp
    SearchStateView(art = EqualAssets.IllustrationSearch, size = 170.dp, title = "Search across your calls", body = "Look for names, phone numbers, categories, keywords")
    SearchStateView(art = EqualAssets.IllustrationNoInternet, size = 130.dp, title = "No internet connection", body = "We could not connect to a stable internet. Check your connection and try again.")
    SearchStateView(art = EqualAssets.IllustrationNoResults, size = 150.dp, title = "No results found", body = "Couldn’t find anything matching. Try a different name, number, category or keyword")
    LoadingDots()
}
```

#### Search field (`search-field`)

A pill search input with a leading search icon and a clear button, used to filter chats.

- React: `import { SearchField } from '@equal/ds';`
- Compose: `SearchField`
- Tokens: `bg/surface`, `text/tertiary`, `text/primary`, `text/placeholder`
- Source: Surfaces from the Typography screen inventory · Search Field

Do: Say what is being searched in the placeholder ("Search chats"). Show an EmptyState with the query in it when nothing matches.

Don't: Don't add a separate search button; results filter as you type. Don't use it as a general form field; use TextField.

Example: Empty
```tsx
const [q, setQ] = useState('');

<SearchField value={q} onChange={setQ} />
```
```kotlin
var q by remember { mutableStateOf("") }

// Compose: the default placeholder is "Search", so pass "Search chats".
SearchField(value = q, onValueChange = { q = it }, placeholder = "Search chats")
```

Example: With a query
```tsx
<SearchField value="Amit" onChange={setQ} />
```
```kotlin
var q by remember { mutableStateOf("Amit") }

// Compose: no built-in clear (X) button; clear by setting the value to "".
SearchField(value = q, onValueChange = { q = it }, placeholder = "Search chats")
```

Example: Filtering the chat list
```tsx
<SearchField value={q} onChange={setQ} />
{results.length === 0
  ? <EmptyState title="No chats found" body={`Nothing matches "\${q}". Try a name or number.`} />
  : results.map((c) => <ChatListItem key={c.id} {...c} />)}
```
```kotlin
val chats = listOf("Arnav Raj", "Amit Kumar", "Priya Nair")
var q by remember { mutableStateOf("") }
val results = chats.filter { it.contains(q, ignoreCase = true) }

SearchField(value = q, onValueChange = { q = it }, placeholder = "Search chats")
if (results.isEmpty()) {
    EmptyState(title = "No chats found", body = "Nothing matches \"$q\". Try a name or number.")
} else {
    results.forEach { name ->
        ChatListItem(name = name, preview = "You have a visitor", date = "Yesterday")
    }
}
```

#### Segmented chips (`segmented-chips`)

A single-select row of pill chips for a short, fixed set of options, like the Home / Work / Other address label.

- React: `import { SegmentedChips } from '@equal/ds';`
- Compose: `SegmentedChips`
- Tokens: `chip/selected-bg`, `chip/selected-text`, `stroke/medium`, `text/secondary`
- Source: Surfaces from the Typography screen inventory · Segmented Label Chips

Do: Use for two to four short options where exactly one is always selected. Declare options `as const` so value and onChange are typed to the union.

Don't: Don't use it for multi-select; use checkboxes. Don't use it for long labels that would wrap; the chips wrap as a row, not the text.

Example: Address label
```tsx
const LABELS = ['Home', 'Work', 'Other'] as const;
const [label, setLabel] = useState<(typeof LABELS)[number]>('Home');

<SegmentedChips options={LABELS} value={label} onChange={setLabel} />
```
```kotlin
val labels = listOf("Home", "Work", "Other")
var selected by remember { mutableStateOf(0) }

SegmentedChips(options = labels, selectedIndex = selected, onSelectedIndexChange = { selected = it })
```

Example: Any string union
```tsx
const SPEEDS = ['Slow', 'Normal', 'Fast'] as const;

<SegmentedChips options={SPEEDS} value={v} onChange={setV} />
```
```kotlin
val speeds = listOf("Slow", "Normal", "Fast")
var selected by remember { mutableStateOf(1) }

// Compose: options are a List<String> addressed by index, not a typed union.
SegmentedChips(options = speeds, selectedIndex = selected, onSelectedIndexChange = { selected = it })
```

#### Switch (`switch`)

A controlled on/off toggle (40 × 24 track) for settings that take effect immediately, such as the assistant or promotional-call muting.

- React: `import { Switch } from '@equal/ds';`
- Compose: `EqualSwitch`
- Tokens: `button/primary`, `button/disabled`, `brand/white`, `shadow/raised`
- Source: §3 Assistant Availability Toggle · Switch

Do: Use a Switch when the change applies instantly (Mute Promotional Calls, Get updates on WhatsApp). Put the visible label in the row beside it and pass the same text as `label`. Confirm with a sheet when turning something off has consequences, as WhatsApp Updates does ("Turn off WhatsApp updates?").

Don't: Don't use a Switch for a choice that needs a Save button; use Checkbox or SegmentedChips. Don't recolour the track; on is button/primary and off is button/disabled in both themes.

Example: Interactive
```tsx
const [on, setOn] = useState(true);

<Switch checked={on} onChange={setOn} label="AI Assistant" />
```
```kotlin
var on by remember { mutableStateOf(true) }

// Compose: no label param; set the accessible label with semantics.
EqualSwitch(
    checked = on,
    onCheckedChange = { on = it },
    modifier = Modifier.semantics { contentDescription = "AI Assistant" },
)
```

Example: States
```tsx
<Switch checked label="On" />
<Switch checked={false} label="Off" />
<Switch checked disabled label="On, disabled" />
<Switch checked={false} disabled label="Off, disabled" />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
    EqualSwitch(checked = true, onCheckedChange = {})
    EqualSwitch(checked = false, onCheckedChange = {})
    EqualSwitch(checked = true, onCheckedChange = {}, enabled = false)
    EqualSwitch(checked = false, onCheckedChange = {}, enabled = false)
}
```

Example: In context
```tsx
<RowGroup>
  <ToggleRow label="Mute Promotional Calls" wrap
    description="Equal AI Assistant can identify Promotional Calls and automatically mute them"
    checked={mute} onChange={setMute} />
</RowGroup>
```
```kotlin
var mute by remember { mutableStateOf(true) }

RowGroup {
    ToggleRow(
        label = "Mute Promotional Calls",
        description = "Equal AI Assistant can identify Promotional Calls and automatically mute them",
        descriptionWraps = true,
        checked = mute,
        onCheckedChange = { mute = it },
    )
}
```

#### Text field (`text-field`)

A borderless white form field with an uppercase overline label, bodyLarge value, helper and error text, used in the Personal Details and Address forms.

- React: `import { TextField } from '@equal/ds';`
- Compose: `EqualTextField`
- Tokens: `bg/surface`, `stroke/medium`, `action/stroke/unread`, `shadow/focusRing`, `text/primary`, `text/placeholder`, `text/tertiary`, `text/secondary`, `text/danger`
- Source: Surfaces from the Typography screen inventory · Text Field

Do: Write the overline label in the string's natural case; the component uppercases it (rule 5). Use `pill` for single short values (Name) and `rounded` for address lines. Add `className="eq-tnum"` on numeric fields; postal codes use tabular figures (rule 6).

Don't: Don't add a border in light mode; fields are borderless white on bg/primary. Don't put instructions in the placeholder that the user needs after typing; use `helper`. Don't show both helper and error; the error replaces the helper.

Example: Name
```tsx
const [name, setName] = useState('Keshav');

<TextField label="Name" value={name} onChange={setName}
  placeholder="Your name" helper="Your AI will call you 'Keshav'" />
```
```kotlin
var name by remember { mutableStateOf("Keshav") }

EqualTextField(
    value = name,
    onValueChange = { name = it },
    label = "Name",
    placeholder = "Your name",
    helper = AnnotatedString("Your AI will call you 'Keshav'"),
)
```

Example: Optional label
```tsx
<TextField label="Guiding direction" optional value={v} onChange={setV}
  placeholder="e.g. Near City Center Mall" />
```
```kotlin
var direction by remember { mutableStateOf("") }

EqualTextField(
    value = direction,
    onValueChange = { direction = it },
    label = "Guiding direction",
    optional = true,
    placeholder = "e.g. Near City Center Mall",
)
```

Example: Multiline and grouped
```tsx
<TextField aria-label="Address line 1" placeholder="Flat, house no., building"
  value={l1} onChange={setL1} multiline />
<TextField aria-label="Address line 2" placeholder="Street, area, landmark"
  value={l2} onChange={setL2} multiline />
```
```kotlin
var line1 by remember { mutableStateOf("") }
var line2 by remember { mutableStateOf("") }

// Fields that share one ADDRESS label omit `label` and pass contentDescription instead.
EqualTextField(
    value = line1,
    onValueChange = { line1 = it },
    contentDescription = "Address line 1",
    placeholder = "Flat, house no., building",
    multiline = true,
)
EqualTextField(
    value = line2,
    onValueChange = { line2 = it },
    contentDescription = "Address line 2",
    placeholder = "Street, area, landmark",
    multiline = true,
)
```

Example: Error
```tsx
<TextField aria-label="Pincode" placeholder="Pincode" value={pin}
  onChange={(v) => setPin(v.replace(/\D/g, '').slice(0, 6))}
  inputMode="numeric" className="eq-tnum" align="center"
  error={/^\d{6}$/.test(pin) ? undefined : 'Enter a 6-digit pincode'} />
```
```kotlin
var pin by remember { mutableStateOf("") }

EqualTextField(
    value = pin,
    onValueChange = { pin = it.filter(Char::isDigit).take(6) },
    contentDescription = "Pincode",
    placeholder = "Pincode",
    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
    tabular = true,
    align = TextFieldAlign.Center,
    error = if (pin.length == 6) null else "Enter a 6-digit pincode",
)
```

### Group: Lists & rows

#### Call history (`call-history`)

The Contact Info call-history card (radius 16; outlined in dark) and its rows: direction icon, call type, meta line and time.

- React: `import { CallHistoryList, CallHistoryRow } from '@equal/ds';`
- Compose: `CallHistoryList`, `CallHistoryRow`
- Tokens: `bg/surface`, `stroke/subtle`, `stroke/medium`, `text/primary`, `text/secondary`, `text/tertiary`, `text/danger`
- Source: Contact Info · Call history

Do: Separate date and duration in `meta` with " • " ("Today • 30 Sec."). Group rows in a CallHistoryList under a `SectionHeader size="label"` CALL HISTORY header (inset 22).

Don't: Don't colour the "Missed Call" label red; only the icon uses text/danger. Don't pass your own label; the direction sets it.

Example: Directions
```tsx
<SectionHeader size="label" inset={22}>Call history</SectionHeader>
<CallHistoryList>
  <CallHistoryRow direction="incoming" meta="Today • 30 Sec." time="02:30 PM" />
  <CallHistoryRow direction="missed" meta="Yesterday" time="11:04 AM" />
  <CallHistoryRow direction="outgoing" meta="12 July • 2 Min." time="06:15 PM" />
</CallHistoryList>
```
```kotlin
SectionHeader(title = "Call history", size = SectionHeaderSize.Label, inset = 22.dp)
CallHistoryList {
    CallHistoryRow(CallDirection.Incoming, meta = "Today • 30 Sec.", time = "02:30 PM")
    CallHistoryRow(CallDirection.Missed, meta = "Yesterday", time = "11:04 AM")
    CallHistoryRow(CallDirection.Outgoing, meta = "12 July • 2 Min.", time = "06:15 PM")
}
```

Example: With trailing
```tsx
<CallHistoryRow direction="incoming" meta="Today • 2 Min." time="03:21 PM"
  trailing={<IconButton icon="play" label="Play recording" size={32} iconSize={20} />} />
```
```kotlin
CallHistoryList {
    // Compose: no custom trailing slot; onCallClick adds the only trailing button (call back, not play)
    CallHistoryRow(CallDirection.Incoming, meta = "Today • 2 Min.", time = "03:21 PM", onCallClick = {})
}
```

#### Empty state (`empty-state`)

A centred illustration, title, body and optional action for empty lists and no-results, plus IllustrationHeader for the art at the top of settings detail screens.

- React: `import { EmptyState, IllustrationHeader } from '@equal/ds';`
- Compose: `EmptyState`, `IllustrationHeader`
- Tokens: `text/primary`, `text/tertiary`, `button/primary`
- Source: Surfaces from the Typography screen inventory · Empty / Error State

Do: Say what the feature does for the user in the title ("Never explain your address again"). Put the query back in no-results copy and suggest what to try.

Don't: Don't crop or recolour the 3D illustrations. Don't show an action when the list fills from elsewhere; if the add button is pinned below, leave it off.

Example: Addresses empty
```tsx
<EmptyState illustration="illustration-addresses-empty"
  title="Never explain your address again"
  body="Save frequently used addresses, and your assistant will use them to handle delivery, pickup calls, etc. more naturally."
  actionLabel="Add new Address" onAction={addAddress} />
```
```kotlin
EmptyState(
    title = "Never explain your address again",
    body = "Save frequently used addresses, and your assistant will use them to handle delivery, pickup calls, etc. more naturally.",
    // Compose: the illustration is a slot, not an asset name
    illustration = { EqualAssetImage(EqualAssets.IllustrationAddressesEmpty, 96.dp) },
    actionLabel = "Add new Address",
    onActionClick = {},
)
```

Example: No results
```tsx
<EmptyState title="No chats found" body={`Nothing matches "\${q}". Try a name or number.`} />
```
```kotlin
val query = "Priya"
EmptyState(title = "No chats found", body = "Nothing matches \"$query\". Try a name or number.")
```

Example: Illustration header
```tsx
<IllustrationHeader asset="illustration-silent-mode" />
<RowGroup>
  <ToggleRow label="Mute Promotional Calls" … />
</RowGroup>
```
```kotlin
IllustrationHeader(asset = EqualAssets.IllustrationSilentMode)
RowGroup {
    ToggleRow(
        label = "Mute Promotional Calls",
        description = "Equal AI Assistant can identify Promotional Calls and automatically mute them",
        descriptionWraps = true,
        checked = true,
        onCheckedChange = {},
    )
}
```

#### Settings row (`settings-row`)

The dense settings row (icon, subheading label, caption description, chevron or switch), grouped into rounded cards with RowGroup.

- React: `import { SettingsRow, ToggleRow, RowGroup } from '@equal/ds';`
- Compose: `SettingsRow`, `ToggleRow`, `RowGroup`
- Tokens: `bg/surface`, `stroke/subtle`, `text/primary`, `text/tertiary`, `text/placeholder`, `button/primary`
- Source: You tab · Settings row

Do: Group related rows under a SectionHeader with matching inset. Use `wrap` for descriptions longer than one line so they switch to Regular (rule 3). Use ToggleRow for instant settings and a chevron row for anything that opens a screen.

Don't: Don't mix a chevron and a switch on one row. Don't truncate a description that matters; set `wrap`.

Example: You tab group
```tsx
<SectionHeader>Your assistant</SectionHeader>
<RowGroup>
  <SettingsRow icon="instructions" label="Instructions" isNew
    description="Tell assistant how you'd like it to help" onClick={open} />
  <SettingsRow icon="health-check" label="Assistant Health Check"
    description="Check Real-Time Assistant Connectivity" onClick={open} />
  …
</RowGroup>
```
```kotlin
SectionHeader(title = "Your assistant")
RowGroup {
    SettingsRow(
        label = "Instructions",
        description = "Tell assistant how you'd like it to help",
        leadingIcon = EqualIcons.Instructions,
        showNewBadge = true,
        onClick = {},
    )
    SettingsRow(label = "Assistant Health Check", description = "Check Real-Time Assistant Connectivity", leadingIcon = EqualIcons.HealthCheck, onClick = {})
    SettingsRow(label = "Silent Mode", description = "Mute promotional calls", leadingIcon = EqualIcons.SilentMode, onClick = {})
    SettingsRow(label = "Voice & Language", description = "How your assistant sounds", leadingIcon = EqualIcons.VoiceLanguage, onClick = {})
}
```

Example: Toggle rows
```tsx
<RowGroup>
  <ToggleRow label="Mute Promotional Calls" wrap
    description="Equal AI Assistant can identify Promotional Calls and automatically mute them"
    checked={mute} onChange={setMute} />
</RowGroup>
```
```kotlin
var mute by remember { mutableStateOf(true) }
RowGroup {
    ToggleRow(
        label = "Mute Promotional Calls",
        description = "Equal AI Assistant can identify Promotional Calls and automatically mute them",
        descriptionWraps = true,
        checked = mute,
        onCheckedChange = { mute = it },
    )
}
```

Example: Trailing variants
```tsx
<SettingsRow label="Active Instructions" description="3 Active" onClick={open} />
<SettingsRow label="Muted Contacts" trailing={<span>4</span>} onClick={open} />
<SettingsRow label="Version" description="2.4.0" trailing="none" />
```
```kotlin
RowGroup {
    SettingsRow(label = "Active Instructions", description = "3 Active", onClick = {})
    SettingsRow(label = "Muted Contacts", onClick = {}, trailing = {
        EqualText(text = "4", style = EqualTheme.type.body1, color = EqualTheme.colors.textTertiary)
    })
    SettingsRow(label = "Version", description = "2.4.0", trailing = null) // null = no chevron
}
```

### Group: Monetization

#### Cancellation (`cancel-sheet`)

Three steps to cancel: tell us why (Proceed stays disabled until there is text), confirm, and the request submitted with access kept until the end date.

- React: `import { CancelSheet } from '@equal/ds';`
- Compose: `CancelSheet`
- Tokens: `gradient/status-neutral`, `button/primary`, `stroke/subtle`
- Source: Monetization Flow · cancellation

Props of `CancelSheet`:
- `step`: `'feedback' | 'confirm' | 'submitted'`. Step.
- `accessUntil?`: `string` = '15 June 2026'. Access end date.
- `reason / onReasonChange?`: `string / (v) => void`. Feedback text (controlled or not).
- `onProceed / onKeep / onConfirm / onRedirect?`: `() => void`. Step actions.

Do: Say how long access lasts at every step.

Don't: Don't make Proceed tappable before the user writes a reason.

Example: Feedback
```tsx
<CancelSheet step="feedback" reason={reason} onReasonChange={setReason} onProceed={next} />
```
```kotlin
var reason by remember { mutableStateOf("") }
CancelSheet(step = CancelStep.Feedback, reason = reason, onReasonChange = { reason = it },
    onProceed = { /* next step */ }, inline = true)
```

Example: Feedback filled
```tsx
<CancelSheet step="feedback" reason="Felt it too expensive…" onReasonChange={setReason} onProceed={next} />
```
```kotlin
var reason by remember { mutableStateOf("Felt it too expensive, I hope it would be under my budget") }
CancelSheet(step = CancelStep.Feedback, reason = reason, onReasonChange = { reason = it },
    onProceed = { /* next step */ }, inline = true)
```

Example: Are you really sure?
```tsx
<CancelSheet step="confirm" accessUntil="15 June 2026" onKeep={close} onConfirm={cancel} />
```
```kotlin
CancelSheet(step = CancelStep.Confirm, accessUntil = "15 June 2026", onKeep = { /* close */ },
    onConfirm = { /* cancel subscription */ }, inline = true)
```

Example: Request submitted
```tsx
<CancelSheet step="submitted" accessUntil="15 June 2026" onRedirect={goHome} />
```
```kotlin
CancelSheet(step = CancelStep.Submitted, accessUntil = "15 June 2026", onRedirect = { /* go home */ }, inline = true)
```

#### Coupon ticket (`coupon-ticket`)

A notched ticket with the coupon code, what it saves, APPLY / APPLIED and the big discount line.

- React: `import { CouponTicket } from '@equal/ds';`
- Compose: `CouponTicket`
- Tokens: `gradient/coupon`, `paywall/card-stroke`, `paywall/divider`, `text/gold`, `gradient/gold-text`
- Source: Monetization Flow · EQUAL25

Props of `CouponTicket`:
- `code`: `string`. Coupon code.
- `description`: `ReactNode`. What it saves.
- `discount`: `string`. Big gold line, e.g. "25% OFF".
- `applied?`: `boolean`. Shows APPLIED; the price above drops.
- `onApply?`: `() => void`. APPLY tap.

Do: Drop the price in PriceTag when the coupon applies (₹249 → ₹149).

Don't: Don't show more than one coupon at a time.

Example: Available
```tsx
<CouponTicket code="EQUAL25" description="Save Flat ₹100 with this Code" discount="25% OFF" onApply={apply} />
```
```kotlin
CouponTicket(code = "EQUAL25", description = "Save Flat ₹100 with this Code", discount = "25% OFF", onApply = {})
```

Example: Applied
```tsx
<CouponTicket code="EQUAL25" description="Save Flat ₹100 with this Code" discount="25% OFF" applied />
```
```kotlin
CouponTicket(code = "EQUAL25", description = "Save Flat ₹100 with this Code", discount = "25% OFF", applied = true)
```

#### Discount badge & price drop (`discount-badge`)

The green 25% OFF seal with its label, and the price drop it rides on: APPLY strikes the old price, the new price lands beside the list price with Saved ₹100, then the badge pops.

- React: `import { DiscountBadge, PriceTag } from '@equal/ds';`
- Compose: `DiscountBadge`, `PriceTag`
- Tokens: `text/brand`, `gradient/gold-text`
- Source: Monetization local components

Props of `DiscountBadge`:
- `label?`: `string` = 'Discounted!!'. Green label.
- `off?`: `string` = '25%'. Seal text.
- `animate?`: `boolean`. Pop in.

Props of `PriceTag`:
- `price`: `number`. Price now.
- `was?`: `number`. Struck list price; adds /Monthly and Saved ₹.
- `badge?`: `string`. A DiscountBadge under the price.
- `animate?`: `boolean`. Run the strike → land → pop sequence (still under reduced motion).

Do: Animate only when the user caused the change (APPLY).

Don't: Don't animate a price that was already discounted when the page opened.

Example: Badges
```tsx
<DiscountBadge />
<DiscountBadge label="Special Coupon Applied!" />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
    DiscountBadge()
    DiscountBadge(label = "Special Coupon Applied!")
}
```

Example: Price drop
```tsx
<PriceTag price={149} was={249} badge="Special Coupon Applied!" animate={justApplied} />
```
```kotlin
var replay by remember { mutableIntStateOf(0) }
Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
    // Strike the old price → land the new one with "Saved ₹100" → pop the badge
    key(replay) {
        PriceTag(price = "149", was = 249, badge = "Special Coupon Applied!", animate = true)
    }
    EqualButton(text = "Replay", onClick = { replay++ }, variant = EqualButtonVariant.Secondary, size = EqualButtonSize.Sm)
}
```

#### FAQ (`faq`)

The FREQUENTLY ASKED QUESTIONS accordion on the paywall and the subscription page, and the hairline section label it sits under.

- React: `import { FaqList, DividerLabel } from '@equal/ds';`
- Compose: `FaqList`, `DividerLabel`
- Tokens: `bg/surface`, `stroke/subtle`, `paywall/divider`, `text/secondary`
- Source: Monetization Flow · FAQ

Props of `FaqList`:
- `items`: `{ q: string; a: ReactNode }[]`. Questions.
- `title?`: `string | null` = 'Frequently asked questions'. Label above.
- `defaultOpen?`: `number[]` = []. Expanded rows.

Do: Answer cancellation and refunds plainly.

Don't: Don't put the FAQ above the CTA.

Example: Accordion
```tsx
<FaqList items={faq} defaultOpen={[3]} />
```
```kotlin
val faq = listOf(
    FaqItem("What do I get with Equal Unlimited?", "Unlimited call screenings, full recordings, summaries, and zero daily cap."),
    FaqItem("Will Equal screen all types of calls?", "Yes! Delivery, ride pickups, spam, loan calls, Equal handles them all."),
    FaqItem("Can I cancel my Equal Unlimited plan later?", "Yes, cancel anytime. Your Unlimited access stays active until the end of your billing period."),
    FaqItem("Will I get a refund if I’m not happy with Equal Unlimited?", "We don’t offer refunds, but you can write to our support team and we’ll do our best to help."),
)
FaqList(items = faq, defaultOpen = listOf(3))
```

Example: Section label
```tsx
<DividerLabel>Why people choose</DividerLabel>
```
```kotlin
DividerLabel(text = "Why people choose")
```

#### Feature list (`feature-list`)

What You Get on the plan page: one card per Unlimited feature with its 3D gold icon (24/7 Unlimited Call Screening, Unlimited Recordings, Unlimited Summaries).

- React: `import { FeatureList, unlimitedFeatures } from '@equal/ds';`
- Compose: `FeatureList`
- Tokens: `stroke/subtle`, `bg/surface`
- Source: Monetization value · Manage Plan

Props of `FeatureList`:
- `items?`: `{ art: AssetName; label: string }[]` = unlimitedFeatures. Features, top to bottom; art is a 3D feature-* asset.

Do: Keep labels to one line. Use the 3D feature-* art; add a new asset for a new feature.

Don't: Don't swap in flat Material icons here. Don't list more than five; the page already has FAQ and proof.

Example: What You Get
```tsx
<DividerLabel>What You Get</DividerLabel>
<FeatureList items={unlimitedFeatures} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    DividerLabel(text = "What You Get")
    FeatureList(items = UnlimitedFeatures)
}
```

#### Help Center sheet (`help-center-sheet`)

Opened from Support on the paywall (or Contact Support after a pending payment): call or mail the team.

- React: `import { HelpCenterSheet } from '@equal/ds';`
- Compose: `HelpCenterSheet`
- Tokens: `bg/surface`, `stroke/subtle`, `action-card/highlight`, `text/action`
- Source: Monetization Flow · Help Center

Props of `HelpCenterSheet`:
- `phone / email?`: `string` = +91 9876 543210 / hello@equal.in. Contact rows.
- `onCall / onMail?`: `() => void`. Row taps.

Do: Keep it to the two contact routes.

Don't: Don't send people to a web page from here.

Example: Default
```tsx
<HelpCenterSheet phone="+91 9876 543210" email="hello@equal.in" onCall={call} onMail={mail} />
```
```kotlin
HelpCenterSheet(phone = "+91 9876 543210", email = "hello@equal.in", onCall = {}, onMail = {}, inline = true)
```

#### Locked content (`locked-content`)

How free users see what Unlimited unlocks: blurred previews with the crown-lock badge, the Unlock All Details card, and the Unlock Audio pill. Each is a paywall touchpoint.

- React: `import { Locked, LockBadge, UnlockDetailsCard, UnlockAudioPill, ChatListItem, ChatBubble, CallSummary } from '@equal/ds';`
- Compose: `LockedContent`, `LockBadge`, `UnlockDetailsCard`, `UnlockAudioPill`
- Tokens: `locked/badge-bg`, `gradient/status-gold`, `button/primary`
- Source: Monetization Flow · touchpoints

Props of `Locked`:
- `children`: `ReactNode`. Real content, blurred.
- `badge?`: `boolean` = true. Crown-lock badge.
- `inline?`: `boolean`. One line (chat-list previews).

Props of `UnlockDetailsCard`:
- `title / body / cta?`: `string` = Unlock All Details…. Copy.
- `onUnlock?`: `() => void`. Opens the paywall.

Props of `ChatListItem · ChatBubble · CallSummary`:
- `locked?`: `boolean · boolean · 'audio' | 'all'`. Locked state on the existing components.
- `onUnlock?`: `() => void`. CallSummary: Unlock Audio tap.

Do: Blur the real content so the user sees there is something there. Route every locked tap to the paywall with its touchpoint.

Don't: Don't lock the caller's name or the time; only the content. Don't show the crown-lock to paid users.

Example: Locked chat rows
```tsx
<ChatListItem name="Vijay CA" preview="Your KYC is pending" date="1 May"
  avatar={{ category: 'financial' }} locked onClick={openPaywall} />
```
```kotlin
Column {
    ChatListItem(name = "Amit Nanda", preview = "Amit is done with onboarding.", date = "Yesterday",
        category = EqualCategory.Career)
    ChatListItem(name = "Vijay CA", preview = "Your KYC is pending", date = "1 May",
        category = EqualCategory.Financial, locked = true, onClick = { /* open paywall */ })
    ChatListItem(name = "Vijay OLA", preview = "On the gate, need approval.", date = "1 Jul",
        category = EqualCategory.Ride, locked = true, onClick = { /* open paywall */ })
}
```

Example: Locked bubbles and audio
```tsx
<ChatBubble kind="incoming" locked>…</ChatBubble>
<CallSummary summary="…" locked="audio" onUnlock={openPaywall} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    ChatBubble(type = ChatBubbleType.Outgoing, timestamp = "03:21", message = "Hello, who is this?", locked = true)
    ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.RealEstate, timestamp = "03:21",
        message = "We have a 2BHK in Sector 12 with good offer", locked = true)
    CallSummaryBubble(
        summary = "Hey Keshav! Here is the summary of your call.",
        timestamp = "03:22",
        locked = CallSummaryLock.Audio,
        onUnlock = { /* open paywall */ },
        voiceNote = {
            VoiceNotePlayer(isPlaying = false, onPlayPauseClick = {}, progress = 0f, elapsed = "0:00",
                total = "2:37", speed = PlaybackSpeed.X1, onSpeedChange = {})
        },
    )
}
```

Example: Unlock All Details
```tsx
<UnlockDetailsCard onUnlock={openPaywall} />
```
```kotlin
UnlockDetailsCard(onUnlock = { /* open paywall */ })
```

Example: Badge and wrapper
```tsx
<LockBadge />
<Locked><Text variant="body1">…</Text></Locked>
<UnlockAudioPill onClick={openPaywall} />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
    LockBadge()
    LockedContent {
        EqualText(text = "Hey this is vijay calling from magicbrick", style = EqualTheme.type.body1,
            color = EqualTheme.colors.textPrimary)
    }
    UnlockAudioPill(onClick = { /* open paywall */ })
}
```

#### Payment status (`payment-status`)

The result sheets after the user pays: Waiting for Confirmation, Payment Confirmed, Pending, Failed and Congratulations. All share the ring StatusCard.

- React: `import { PaymentStatusSheet, StatusCard, StatusSheet, RedirectNote } from '@equal/ds';`
- Compose: `PaymentStatusSheet`, `StatusCard`, `StatusSheet`, `RedirectNote`
- Tokens: `gradient/status-neutral`, `gradient/status-success`, `gradient/status-warning`, `gradient/status-danger`, `gradient/status-gold`, `scrim`
- Source: Monetization Flow · payment results

Props of `PaymentStatusSheet`:
- `status`: `'waiting' | 'confirmed' | 'pending' | 'failed' | 'welcome'`. Result.
- `cardLast4?`: `string` = '2652'. In the refund line.
- `onRetry / onContactSupport / onRedirect?`: `() => void`. Actions.
- `waitingArt?`: `'status-waiting' | 'status-waiting-cash'` = 'status-waiting'. Experiment: coin or cash art.
- `mode?`: `'overlay' | 'inline'` = 'overlay'. Inline for docs.

Props of `StatusCard`:
- `tone`: `'neutral' | 'success' | 'warning' | 'danger' | 'gold'`. Tint.
- `art`: `AssetName`. 3D art (100dp).
- `strong`: `string`. Bold line 28/32.
- `light?`: `string`. Regular line 22/26.
- `strongFirst?`: `boolean` = true. Order of the lines.

Do: Say what happens to the money on pending and failed. Auto-redirect after success, with the countdown visible.

Don't: Don't add a close button; each result has one next step.

Example: Waiting for Confirmation (Compose)
```kotlin
PaymentStatusSheet(status = PaymentStatus.Waiting, inline = true)
```

Example: Payment Confirmed (Compose)
```kotlin
PaymentStatusSheet(status = PaymentStatus.Confirmed, onRedirect = { /* go home */ }, inline = true)
```

Example: Payment Pending (Compose)
```kotlin
PaymentStatusSheet(status = PaymentStatus.Pending, onContactSupport = { /* open HelpCenterSheet */ }, inline = true)
```

Example: Payment Failed (Compose)
```kotlin
PaymentStatusSheet(status = PaymentStatus.Failed, onRetry = { /* retry payment */ }, inline = true)
```

Example: Congratulations (Compose)
```kotlin
PaymentStatusSheet(status = PaymentStatus.Welcome, onRedirect = { /* go home */ }, inline = true)
```

#### Paywall (`paywall`)

The Equal Unlimited paywall: gold hero with the 3D crown, the price, a preview of what is locked (it changes with the touchpoint), and the sticky gold CTA.

- React: `import { PaywallHero, PriceTag, LockedPreviewCard, PaywallFooter, AnimatedCrown } from '@equal/ds';`
- Compose: `PaywallHero`, `PriceTag`, `LockedPreviewCard`, `PaywallFooter`, `AnimatedCrown`
- Tokens: `gradient/paywall-hero`, `gradient/gold-text`, `gradient/cta-gold`, `text/gold`, `paywall/card-bg`, `paywall/card-stroke`, `paywall/divider`
- Source: Monetization Flow · Unlock Equal Unlimited

Props of `PaywallHero`:
- `title?`: `string` = 'Unlock Equal'. Regular first line.
- `titleStrong?`: `string` = 'Unlimited'. Bold display line.
- `subtitle?`: `ReactNode` = Unlock Summaries…. Experiment: copy variant.
- `onBack / onSupport?`: `() => void`. Header actions; Support opens the Help Center sheet.
- `children?`: `ReactNode`. Price, preview, coupon.

Props of `PriceTag`:
- `price`: `number | string`. Shown price (drops when the coupon applies).
- `label?`: `string | null` = 'Limited time discount'. Gold caps label with 🎊.
- `currency?`: `string` = '₹'. Prefix.

Props of `PaywallFooter`:
- `cta?`: `string` = 'Unlock Unlimited'. Gold block button.
- `note?`: `string | null` = 'Cancel Anytime. Automatically renews'. Caption under it.
- `onClick?`: `() => void`. Starts payment.
- `variant?`: `'gold' | 'gold-outline' | 'primary'` = 'gold'. gold-outline for Cancel Subscription on the plan page.
- `disabled?`: `boolean`. While a payment is processing.
- `flat?`: `boolean`. No surface or shadow, inside the sheet paywall.
- `above?`: `ReactNode`. Above the button, e.g. the processing toast.

Do: Pick the preview from the touchpoint the user came from. Keep one gold CTA; it is the only commit on the page.

Don't: Don't use a serif for the display lines; the system is DM Sans only. Don't hide the auto-renew note.

Example: Hero with price and preview
```tsx
<PaywallHero onBack={back} onSupport={openHelp}>
  <PriceTag price={249} />
  <LockedPreviewCard>…what's locked…</LockedPreviewCard>
</PaywallHero>
```
```kotlin
PaywallHero(onBack = {}, onSupport = { /* open HelpCenterSheet */ }) {
    PriceTag(price = "249")
    LockedPreviewCard {
        Column {
            ChatListItem(name = "HDFC RM", preview = "Loan pre-approval request", date = "1:00 PM",
                category = EqualCategory.GateAlert)
            EqualDivider()
            ChatListItem(name = "Vijay NoBroker", preview = "About miniature painting", date = "Yesterday",
                category = EqualCategory.RealEstate, locked = true)
        }
    }
}
```

Example: Preview by touchpoint
```tsx
<PaywallPreview touchpoint="chat-list" />
<PaywallPreview touchpoint="chat" />
<PaywallPreview touchpoint="audio" />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    // Chat list
    LockedPreviewCard {
        ChatListItem(name = "Vijay NoBroker", preview = "About miniature painting", date = "Yesterday",
            category = EqualCategory.RealEstate, locked = true)
    }
    // Chat
    LockedPreviewCard {
        Column(Modifier.padding(horizontal = 4.dp, vertical = 12.dp)) {
            ChatBubble(type = ChatBubbleType.Outgoing, timestamp = "03:21", message = "Hello, who is this?")
            ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.RealEstate,
                timestamp = "03:21", message = "Vijay from no broker", modifier = Modifier.padding(top = 12.dp))
            ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.RealEstate,
                isFirstInGroup = false, timestamp = "03:21", locked = true, modifier = Modifier.padding(top = 4.dp),
                message = "Hey this is vijay calling from magicbrick a property advisor")
        }
    }
    // Audio
    LockedPreviewCard {
        CallSummaryBubble(
            summary = "Hey Keshav! Here is the summary of your call.",
            timestamp = "03:21",
            locked = CallSummaryLock.Audio,
            onUnlock = { /* open paywall */ },
            voiceNote = {
                VoiceNotePlayer(isPlaying = false, onPlayPauseClick = {}, progress = 0f, elapsed = "0:00",
                    total = "2:37", speed = PlaybackSpeed.X1, onSpeedChange = {})
            },
            modifier = Modifier.padding(4.dp),
        )
    }
}
```

Example: Animated crown
```tsx
<AnimatedCrown size={64} />
<AnimatedCrown size={64} animated={false} />
```
```kotlin
// Turntable sway (4.8s loop); static when animations are off. Stands in for the crown video.
AnimatedCrown(size = 64.dp)
```

Example: Sticky footer
```tsx
<PaywallFooter cta="Unlock Unlimited" note="Cancel Anytime. Automatically renews" onClick={buy} />
```
```kotlin
PaywallFooter(
    onClick = { /* start payment */ },
    cta = "Unlock Unlimited",
    note = "Cancel Anytime. Automatically renews",
)
```

#### Paywall experiments (`monetization-experiments`)

The pieces the Android team A/B tests around the paywall: full-screen payment results, the processing strip, the sheet paywall with its coupon row, Help Center and exit offer, the offer strip, home notice and usage cards, Equal AI’s own notice, crown-locked actions and recordings.

- React: `import { PaymentResult, ProcessingStrip, PaywallSheet, CouponRow, HelpFaqSheet, ExitOfferDialog, OfferStrip, HomeNoticeCard, UsageCapCard, AssistantNoticeCard, SummaryActions, LockedRecording } from '@equal/ds';`
- Compose: `PaymentResult`, `ProcessingStrip`, `PaywallSheet`, `CouponRow`, `HelpFaqSheet`, `ExitOfferDialog`, `OfferStrip`, `HomeNoticeCard`, `UsageCapCard`, `AssistantNoticeCard`, `SummaryActions`, `LockedRecording`
- Tokens: `gradient/result-success`, `gradient/result-pending`, `gradient/result-failed`, `result/ring`, `processing/bg`, `processing/ring`, `offer-strip/bg`, `plan-badge/expired-bg`
- Source: All Payment States · Payment Pending · Home / Conversation Screen (light & dark) · Plan Expired & Usage Cap touchpoints · Recordings + Transcripts Locked · Actions on Home Page

Props of `PaymentResult`:
- `status`: `'success' | 'pending' | 'failed'`. Which page.
- `activeTill?`: `string` = '10th Sept 2026'. Success date.
- `pendingAction?`: `'refresh' | 'support'` = 'refresh'. Pending CTA.
- `header?`: `ReactNode`. Status bar on the wash.

Props of `PaywallSheet`:
- `price?`: `number` = 249. List price.
- `discountedPrice?`: `number` = 149. With EQUAL25.
- `applied?`: `boolean`. Coupon applied.
- `processing?`: `boolean`. Toast + disabled CTA.
- `cta?`: `string` = 'Unlock Equal AI Unlimited'. CTA copy (experiment).
- `mode?`: `'overlay' | 'inline'` = 'overlay'. Docs: inline.

Props of `ExitOfferDialog`:
- `dismissLabel?`: `string` = 'Not Now'. Leave in chats.
- `claimLabel?`: `string` = 'Claim 25% Off'. Keep 25% Off in chats.

Props of `ProcessingStrip`:
- `variant?`: `'strip' | 'card' | 'toast'` = 'strip'. Where it sits.

Do: Pass experiments as props on the same screen (Home, Chat, Paywall); never fork a screen per variant. While a payment is processing, show it everywhere it matters and disable the paywall CTA.

Don't: Don't show the exit offer more than once per session. Don't lock the caller's name, the time or the summary label; only content and actions.

Example: Payment results
```tsx
<PaymentResult status="success" activeTill="10th Sept 2026" />
<PaymentResult status="pending" onClose={close} onRefresh={refresh} />   // pendingAction="support" → Contact Support
<PaymentResult status="failed" onBack={back} onRetry={retry} onContactSupport={support} />
```
```kotlin
Row(Modifier.height(440.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
    PaymentResult(status = PaymentResultStatus.Success, activeTill = "10th Sept 2026", modifier = Modifier.weight(1f))
    // pendingAction = PendingAction.Support → Contact Support
    PaymentResult(status = PaymentResultStatus.Pending, onClose = {}, onRefresh = {}, modifier = Modifier.weight(1f))
    PaymentResult(status = PaymentResultStatus.Failed, onBack = {}, onRetry = {}, onContactSupport = {}, modifier = Modifier.weight(1f))
}
```

Example: Payment processing
```tsx
<ProcessingStrip />                 // under a chat header
<ProcessingStrip variant="card" />  // under the home toggle
<ProcessingStrip variant="toast" /> // above the disabled paywall CTA
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    ProcessingStrip() // under a chat header
    ProcessingStrip(variant = ProcessingStripVariant.Card) // under the home toggle
    ProcessingStrip(variant = ProcessingStripVariant.Toast, modifier = Modifier.padding(horizontal = 12.dp)) // above the disabled paywall CTA
}
```

Example: Sheet paywall
```tsx
<PaywallSheet applied={applied} onApply={apply} onSupport={openHelp} onScrim={askToLeave} onUnlock={pay} />
```
```kotlin
var applied by remember { mutableStateOf(false) }
// Over a screen: draw it last in a full-size Box (onScrim → the exit offer). Docs: inline = true.
PaywallSheet(
    applied = applied,
    onApply = { applied = true },
    onSupport = { /* HelpFaqSheet */ },
    onScrim = { /* ExitOfferDialog */ },
    onUnlock = { /* pay */ },
    inline = true,
)
```

Example: Exit offer and offer strip
```tsx
<ExitOfferDialog onDismiss={leave} onClaim={claim} />          // chat: dismissLabel="Leave" claimLabel="Keep 25% Off"
<OfferStrip onClick={reopenWithCoupon} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    // In a chat: dismissLabel = "Leave", claimLabel = "Keep 25% Off"
    ExitOfferDialog(onDismiss = {}, onClaim = {}, inline = true, modifier = Modifier.padding(horizontal = 16.dp))
    OfferStrip(onClick = { /* reopen the sheet with EQUAL25 applied */ })
}
```

Example: Home cards
```tsx
<HomeNoticeCard lead="👑" title="Your Plan Expired" subtitle="Renew to get Unlimited access back" cta="Renew Now" onCta={renew} />
<UsageCapCard left={7} limit={30} resets="Mon" onUpgrade={openPaywall} />
```
```kotlin
Column {
    HomeNoticeCard(
        lead = { EmojiGlyph(emoji = "👑", size = 14.dp) },
        title = "Your Plan Expired",
        subtitle = "Renew to get Unlimited access back",
        cta = "Renew Now",
        onCta = { /* renew */ },
    )
    UsageCapCard(left = 7, limit = 30, resets = "Mon", onUpgrade = { /* open the paywall */ })
}
```

Example: Equal AI notice
```tsx
<AssistantNoticeCard title="Your Plan Expired" body="Renew to unlock unlimited recordings, …" cta="Renew Equal AI Unlimited" onCta={openPaywall} />
```
```kotlin
AssistantNoticeCard(
    title = "Your Plan Expired",
    body = "Renew to unlock unlimited recordings, call summaries, transcripts, and unlimited call screening.",
    cta = "Renew Equal AI Unlimited",
    onCta = { /* open the paywall */ },
)
```

Example: Locked recording and actions
```tsx
<LockedRecording onUnlock={openPaywall} />
<SummaryActions locked actions={[{ label: 'Call Back', icon: 'call-filled' }, { label: 'Add to Calendar', icon: 'calendar' }]} onLocked={openPaywall} />
<SmallActionChip label="Call Back" emoji="📞" locked />   // ChatListItem lockedActions
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    LockedRecording(onUnlock = { /* open the paywall */ })
    SummaryActions(
        actions = listOf(SummaryAction("Call Back", EqualIcons.CallFilled), SummaryAction("Add to Calendar", EqualIcons.CalendarMonth)),
        locked = true,
        onLocked = { /* open the paywall */ },
    )
    // ChatListItem(lockedActions = true) draws its chips like this
    SmallActionChip(label = "Call Back", emoji = "📞", onClick = {}, locked = true)
}
```

#### Plan banner (`plan-banner`)

The amber "Reactivate your current Plan…" strip for lapsed plans, under the plan card in Settings or at the top of a chat; plus the plan card link label (Manage plan / Restore Plan / Reactivate plan).

- React: `import { PlanBanner, PlanCard } from '@equal/ds';`
- Compose: `PlanBanner`
- Tokens: `plan-banner/bg`, `plan-banner/text`
- Source: Monetization Flow · lapsed plan

Props of `PlanBanner`:
- `children`: `ReactNode`. Message.
- `attached?`: `boolean`. Hangs under the plan card.
- `onClick?`: `() => void`. Makes the strip tappable.

Do: Use it only when the plan has lapsed or autopay is off.

Don't: Don't use red; it is a nudge, not an error.

Example: Under the plan card
```tsx
<PlanCard onManage={reactivate} actionLabel="Reactivate plan" />
<PlanBanner attached>Reactivate your current Plan to use Equal Unlimited</PlanBanner>
```
```kotlin
Column {
    PlanCard(onManageClick = { /* reactivate */ }, manageLabel = "Reactivate plan")
    PlanBanner(text = "Reactivate your current Plan to use Equal Unlimited", attached = true)
}
```

Example: At the top of a chat
```tsx
<PlanBanner onClick={reactivate}>Reactivate your current Plan to keep using Equal Unlimited</PlanBanner>
```
```kotlin
PlanBanner(text = "Reactivate your current Plan to keep using Equal Unlimited", onClick = { /* reactivate */ })
```

#### Plan expiry banner (`plan-expiry-banner`)

The strip under the home header as a plan runs out: amber while days remain, red on the last day and after it ends, always with Renew Now.

- React: `import { PlanExpiryBanner } from '@equal/ds';`
- Compose: `PlanExpiryBanner`
- Tokens: `expiry-banner/warning-bg`, `expiry-banner/warning-text`, `expiry-banner/danger-bg`, `expiry-banner/danger-text`
- Source: Monetization value · Home Screen

Props of `PlanExpiryBanner`:
- `expiry`: `{ state: 'expiring', days } | { state: 'today' } | { state: 'expired', date }`. Where the plan stands; picks the tone and copy.
- `onRenew?`: `() => void`. Renew Now.

Do: Show it full width directly under the home header. Use amber while days remain, red from the last day.

Don't: Don't show it while the plan is comfortably active. Don't stack it with the Reactivate plan banner.

Example: States
```tsx
<PlanExpiryBanner expiry={{ state: 'expiring', days: 2 }} onRenew={renew} />
<PlanExpiryBanner expiry={{ state: 'today' }} onRenew={renew} />
<PlanExpiryBanner expiry={{ state: 'expired', date: '30th July' }} onRenew={renew} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    PlanExpiryBanner(expiry = PlanExpiry.Expiring(days = 2), onRenew = { /* open PaywallScreen */ })
    PlanExpiryBanner(expiry = PlanExpiry.Today, onRenew = { /* open PaywallScreen */ })
    PlanExpiryBanner(expiry = PlanExpiry.Expired(date = "30th July"), onRenew = { /* open PaywallScreen */ })
}
```

#### Social proof (`social-proof`)

The subscription page proof block: a big gold stat, the rating pill and a testimonial carousel.

- React: `import { StatBlock, RatingPill, TestimonialCarousel } from '@equal/ds';`
- Compose: `StatBlock`, `RatingPill`, `TestimonialCarousel`
- Tokens: `gradient/gold-text`, `text/gold`, `paywall/card-stroke`
- Source: Monetization Flow · Why people choose

Props of `StatBlock`:
- `value`: `string`. "400k+".
- `label`: `string`. Under it.

Props of `RatingPill`:
- `rating`: `number`. 4.5
- `outOf?`: `number` = 5. Scale.

Props of `TestimonialCarousel`:
- `items`: `{ quote; name; avatar? }[]`. Cards (240 wide), with page dots.

Do: Use real numbers and real reviews only.

Don't: Don't invent testimonials for production.

Example: Stat and rating
```tsx
<StatBlock value="400k+" label="People never miss a call" />
<RatingPill rating={4.5} />
```
```kotlin
Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
    StatBlock(value = "400k+", label = "People never miss a call")
    RatingPill(rating = 4.5f)
}
```

Example: Testimonials
```tsx
<TestimonialCarousel items={[{ quote, name, avatar: <ProfileAvatar variant="female" size={36} /> }, …]} />
```
```kotlin
val avatar = @Composable { asset: EqualAssets -> EqualAssetImage(asset, size = 36.dp, modifier = Modifier.clip(CircleShape)) }
TestimonialCarousel(
    items = listOf(
        Testimonial(
            quote = "As a freelancer, client calls and spam used to mix together. Now I get proper summaries.",
            name = "keerthana",
            avatar = { avatar(EqualAssets.AvatarTestimonial1) },
        ),
        Testimonial(
            quote = "It is a very useful app for screening the unknown calls. This is a must download.",
            name = "Arnav Raj",
            avatar = { avatar(EqualAssets.AvatarTestimonial2) },
        ),
        Testimonial(
            quote = "My parents get loan and insurance calls all day. Equal answers them, and I just read the summary.",
            name = "Riya Kapoor",
            avatar = { avatar(EqualAssets.AvatarTestimonial3) },
        ),
    ),
)
```

#### Value card & sheet (`value-card`)

What Unlimited saved you: calls handled, the perks, the expiry chip and the current plan. Inside the sheet that rises after a call near the end of a plan, and on the plan page (circuit pattern, no perks). For free users the QuotaCard counts the week’s calls instead.

- React: `import { ValueCard, QuotaCard, ValueSheet, ExpiryChip, PremiumIcon } from '@equal/ds';`
- Compose: `ValueCard`, `QuotaCard`, `ValueSheet`, `ExpiryChip`, `PremiumIcon`
- Tokens: `premium-icon/start`, `premium-icon/end`, `gradient/value-card`, `value-card/stroke`, `value-card/perks-bg`, `value-card/ring`, `expiry-chip/warning-bg`, `expiry-chip/danger-bg`, `expiry-chip/active-bg`
- Source: Monetization value · Value Bottom Sheet Once Called

Props of `ValueCard`:
- `calls`: `number`. Calls the assistant handled.
- `expiry`: `PlanExpiry`. active (until) · expiring (days) · today · expired (date).
- `title?`: `string | null` = 'What Unlimited saved you'. In-card heading; null on the plan page.
- `perks?`: `ValuePerk[] | null` = defaultValuePerks. The three rows; null hides them.
- `price?`: `number` = 39. Current price.
- `was?`: `number` = 49. Struck list price.
- `pattern?`: `'rings' | 'circuit'` = circuit when perks is null. Rings (sheet) or the gold circuit lines (plan page).

Props of `PremiumIcon`:
- `name`: `IconName`. A filled Material Symbol (the -fill icons, timer, person, call-log).
- `size?`: `number` = 16. dp.

Props of `QuotaCard`:
- `quota`: `{ used: number; limit: number; resetsInDays: number }`. This week; used ≥ limit shows Limit Reached.
- `perks?`: `ValuePerk[] | null` = quotaPerks. What Unlimited adds.
- `price?`: `number` = 149. Price.
- `was?`: `number` = 249. Struck list price.

Props of `ValueSheet`:
- `expiry?`: `PlanExpiry`. Paid plan state.
- `quota?`: `Quota`. Free plan: show the QuotaCard (CTA Get Equal AI Unlimited).
- `calls?`: `number` = 20. Calls handled.
- `variant?`: `'card' | 'flush'` = 'card'. Inset card or the card as the sheet (experiment).
- `cta?`: `string` = 'Renew your Equal AI'. Gold CTA.
- `onRenew?`: `() => void`. CTA.
- `onClose?`: `() => void`. The floating close and the scrim.

Do: Show the sheet once, after the assistant handles a call in the last days of a plan. Lead with the number; the user should see what they get before the ask. Perk icons are filled Material Symbols at 16 dp in the premium gold gradient (PremiumIcon), never outlined or flat-tinted. Light cards sit on the premium-glow art; dark cards use the coded black-gold gradient.

Don't: Don't show the sheet on every call or app open. Don't use it for users who never subscribed; they get the paywall.

Example: Sheet
```tsx
<ValueSheet expiry={{ state: 'expiring', days: 3 }} onRenew={renew} onClose={close} />
```
```kotlin
// Overlay: fills the screen (scrim + sheet); pass inline = true to draw only the panel
ValueSheet(
    expiry = PlanExpiry.Expiring(days = 3),
    onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
    onClose = { /* hide the sheet */ },
)
```

Example: Flush sheet (experiment)
```tsx
<ValueSheet variant="flush" expiry={{ state: 'today' }} onRenew={renew} onClose={close} />
```
```kotlin
ValueSheet(
    expiry = PlanExpiry.Today,
    variant = ValueSheetVariant.Flush,
    onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
    onClose = { /* hide the sheet */ },
)
```

Example: On the plan page
```tsx
<DividerLabel>What Unlimited Saved You</DividerLabel>
<ValueCard calls={20} title={null} perks={null} expiry={{ state: 'expired', date: '30th July' }} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    DividerLabel(text = "What Unlimited Saved You")
    ValueCard(calls = 20, title = null, perks = null, expiry = PlanExpiry.Expired(date = "30th July"))
}
```

Example: Quota: calls left
```tsx
<QuotaCard quota={{ used: 24, limit: 30, resetsInDays: 4 }} />
```
```kotlin
// Free plan: "6 out of 30 Calls Left" with the gold progress bar
QuotaCard(quota = Quota(used = 24, limit = 30, resetsInDays = 4))
```

Example: Quota: limit reached
```tsx
<QuotaCard quota={{ used: 30, limit: 30, resetsInDays: 2 }} />
// in the sheet: <ValueSheet quota={{ used: 30, limit: 30, resetsInDays: 2 }} onRenew={openPaywall} onClose={close} />
```
```kotlin
QuotaCard(quota = Quota(used = 30, limit = 30, resetsInDays = 2))
// in the sheet: ValueSheet(quota = Quota(used = 30, limit = 30, resetsInDays = 2), onRenew = openPaywall, onClose = close)
```

Example: Expiry chips
```tsx
<ExpiryChip tone="active">25th Jun ’26</ExpiryChip>
<ExpiryChip tone="warning">03 Days</ExpiryChip>
<ExpiryChip tone="danger">Today</ExpiryChip>
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
    ExpiryChip(text = "25th Jun ’26", tone = ExpiryTone.Active)
    ExpiryChip(text = "03 Days", tone = ExpiryTone.Warning)
    ExpiryChip(text = "Today", tone = ExpiryTone.Danger)
}
```

### Group: Navigation

#### App bar (`app-bar`)

The standard screen header with back, a subheading title and trailing actions, plus the uppercase section header that labels groups of rows.

- React: `import { AppBar, SectionHeader } from '@equal/ds';`
- Compose: `EqualAppBar`, `SectionHeader`
- Tokens: `bg/primary`, `bg/surface`, `shadow/header`, `text/primary`, `text/tertiary`
- Source: Surfaces from the Typography screen inventory · App Bar, Section Header

Do: Centre the title in flow screens (Personal Details, Your Addresses, Contact Info). Keep SectionHeader side inset equal to the RowGroup inset below it (20 on the You tab).

Don't: Don't write section headers in capitals in source; pass normal text and let the component uppercase it. Don't put a filled Button in the app bar; trailing actions are icon or text buttons.

Example: Centred (flows)
```tsx
<AppBar title="Personal Details" onBack={goBack} />
```
```kotlin
EqualAppBar(title = "Personal Details", onBackClick = {})
```

Example: Start-aligned, elevated, with trailing
```tsx
<AppBar title="Active Instructions" align="start" surface="surface" elevated
  onBack={goBack} trailing={<TextButton leadingIcon="add">Add</TextButton>} />
```
```kotlin
EqualAppBar(
    title = "Active Instructions",
    onBackClick = {},
    align = AppBarAlign.Start,
    background = EqualTheme.colors.bgSurface,
    elevated = true,
) {
    EqualTextButton(text = "Add", onClick = {}, leadingIcon = EqualIcons.Add)
}
```

Example: Section headers
```tsx
<SectionHeader>Your assistant</SectionHeader>
<SectionHeader qualifier="(Optional)">Guiding direction</SectionHeader>
<SectionHeader action={<TextButton size="small">Clear all</TextButton>}>
  Recommended for you
</SectionHeader>
```
```kotlin
// Pass normal text; SectionHeader uppercases it.
SectionHeader(title = "Your assistant")
// Compose: no `qualifier` slot; it is appended to the title (and uppercased with it).
SectionHeader(title = "Guiding direction (Optional)")
SectionHeader(title = "Recommended for you", actionLabel = "Clear all", onActionClick = {})
```

#### Bottom nav (`bottom-nav`)

The floating two-tab pill (Chats, You) with an unread count, beside the Equal orb FAB that opens the assistant.

- React: `import { BottomNav, Fab } from '@equal/ds';`
- Compose: `BottomNavBar`, `EqualFab`
- Tokens: `bg/surface`, `shadow/nav`, `nav/selected-bg`, `text/action`, `text/tertiary`, `text/secondary`, `button/primary`, `text/on-action`
- Source: §4 Tab Bar (Bottom Navigation)

Do: Float the nav over content and leave ~104dp bottom padding so the last row is reachable. Pass the user's gender as `avatar` so the You tab matches the profile avatar.

Don't: Don't add a third tab; the pill is Chats and You. Don't replace the FAB orb with an icon; the orb carries its own glow.

Example: Interactive
```tsx
const [tab, setTab] = useState<NavTab>('chats');

<BottomNav active={tab} onChange={setTab} unread={7} />
```
```kotlin
var tab by remember { mutableStateOf(EqualTab.Chats) }

BottomNavBar(
    selectedTab = tab,
    onTabSelected = { tab = it },
    onFabClick = {},
    chatsBadgeCount = 7,
)
```

Example: You active, female avatar, no FAB
```tsx
<BottomNav active="you" avatar="female" showFab={false} />
```
```kotlin
// Compose: BottomNavBar always draws the FAB; there is no showFab = false.
BottomNavBar(
    selectedTab = EqualTab.You,
    onTabSelected = {},
    onFabClick = {},
    avatar = ProfileAvatarVariant.Female,
)
```

Example: FAB on its own
```tsx
<Fab onClick={openAssistant} />
```
```kotlin
EqualFab(onClick = {})
```

#### Chat header (`chat-header`)

Headers for the chat surfaces: the in-conversation header (with the Takeover pill on a live call), the chat-list selection header, and the home header with the assistant toggle.

- React: `import { ChatHeader, TakeoverPill, SelectionHeader, HomeHeader } from '@equal/ds';`
- Compose: `ChatHeader`, `TakeoverPill`, `SelectionChatHeader`, `HomeHeader`
- Tokens: `bg/surface`, `bg/primary`, `shadow/header`, `gradient/takeover`, `action/stroke/unread`, `shadow/glass`, `text/action`, `text/primary`, `text/tertiary`, `button/danger`
- Source: §5 Chat Header (In-Conversation)

Do: Show the phone number as the subtitle normally and a status line ("You have a visitor") during a live call. During a live call show only the Takeover pill; the call and more buttons go away. Route selection-mode Delete through the delete confirm sheet.

Don't: Don't show Takeover alongside the call button; that is two actions for the same intent. Don't truncate the phone number with custom styles; it is tabular and one line.

Example: Default
```tsx
<ChatHeader name="Amit Nanda" subtitle="+91 98717 46113"
  avatar={{ initials: 'AN' }} onBack={goBack} onCall={call} onMore={openInfo} />
```
```kotlin
ChatHeader(
    name = "Amit Nanda",
    subtitle = "+91 98717 46113",
    initials = "AN",
    onBackClick = {},
    onCallClick = {},
    onMoreClick = {},
)
```

Example: Live call
```tsx
<ChatHeader name="Arnav Raj" subtitle="You have a visitor" live
  onBack={goBack} onTakeover={takeover} />
```
```kotlin
ChatHeader(
    name = "Arnav Raj",
    subtitle = "You have a visitor",
    subtitleIsPhone = false,
    variant = ChatHeaderVariant.LiveCall,
    onBackClick = {},
    onTakeoverClick = {},
)
```

Example: Selection mode
```tsx
<SelectionHeader count={1} allSelected={false}
  onSelectAll={selectAll} onBack={exit} onMarkRead={markRead} onDelete={confirmDelete} />
```
```kotlin
var allSelected by remember { mutableStateOf(false) }

SelectionChatHeader(
    selectedCount = if (allSelected) 3 else 1,
    allSelected = allSelected,
    onSelectAllChange = { allSelected = it },
    onBackClick = {},
    onMarkReadClick = {},
    onDeleteClick = {},
)
```

Example: Home
```tsx
const [on, setOn] = useState(true);

<HomeHeader assistantOn={on} onAssistantChange={setOn} />
```
```kotlin
var on by remember { mutableStateOf(true) }

HomeHeader(assistantOn = on, onAssistantChange = { on = it })
```

Example: Takeover pill
```tsx
<TakeoverPill onClick={takeover} />
```
```kotlin
TakeoverPill(onClick = {})
```

#### Status bar (`status-bar`)

The Material 3 Android status bar (52dp: Roboto time; wifi, triangle signal and an upright battery) for mocks, flows and screen demos.

- React: `import { StatusBar } from '@equal/ds';`
- Compose: `StatusBar`
- Tokens: `bg/primary`, `text/primary`
- Source: §1 Status Bar

Do: Use it only in mocks and flow demos; the app draws edge-to-edge and pads with `WindowInsets.statusBars`. Match `background` to the surface beneath (bg/surface under white headers).

Don't: Don't add carrier names or extra icons; the Material 3 bar is time + wifi + signal + battery.

Example: Default
```tsx
<StatusBar />
```
```kotlin
StatusBar()
```

Example: On a white header
```tsx
<StatusBar time="9:41" background="var(--eq-bg-surface)" />
<AppBar title="Contact Info" surface="surface" onBack={goBack} />
```
```kotlin
Column {
    StatusBar(time = "9:41", background = EqualTheme.colors.bgSurface)
    EqualAppBar(title = "Contact Info", onBackClick = {}, background = EqualTheme.colors.bgSurface)
}
```

#### Top bar (`top-bar`)

The Chats home bar: the vector Equal AI logo with the plan marker, plus the logo and mark on their own.

- React: `import { TopBar, EqualLogo, EqualMark } from '@equal/ds';`
- Compose: `TopBar`, `EqualLogo`, `EqualMark`
- Tokens: `text/action`, `gradient/gold`, `text/on-dark`
- Source: §2 Top Bar (Logo + Availability Status)

Do: Use the vector logo in text/action so it is #00B140 in light and lime in dark. Keep the logo 20dp high in the top bar.

Don't: Don't use a raster logo; the logo is coded as vector paths. Don't stretch or recolour the lockup outside text/action.

Example: Default
```tsx
<TopBar />
```
```kotlin
TopBar()
```

Example: Without a plan, with a trailing action
```tsx
<TopBar plan={null} trailing={<IconButton icon="search" label="Search chats" />} />
```
```kotlin
TopBar(planLabel = null) {
    EqualIconButton(icon = EqualIcons.Search, contentDescription = "Search chats", onClick = {})
}
```

Example: Logo and mark
```tsx
<EqualLogo height={20} />
<EqualLogo height={20} variant="wordmark" />
<EqualMark width={23} />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
    EqualLogo(height = 20.dp)
    EqualLogo(height = 20.dp, variant = EqualLogoVariant.WORDMARK)
    EqualMark(width = 23.dp, color = EqualTheme.colors.textAction)
}
```

### Group: Overlays

#### Bottom sheet (`bottom-sheet`)

Sheets that rise over the current screen: the standard sheet with a floating close or title row, the centred confirm content for destructive actions, and the full-height sheet for the instruction setup chat.

- React: `import { BottomSheet, ConfirmSheetContent, FullSheet } from '@equal/ds';`
- Compose: `EqualBottomSheet`, `ConfirmSheetContent`, `FullSheet`
- Tokens: `scrim`, `sheet/bg`, `bg/surface`, `shadow/raised`, `text/secondary`, `text/primary`, `button/danger`, `text/on-danger`, `chat/wallpaper-bg`
- Source: §17 Bottom Sheet

Do: Name the thing being deleted in the title and put its number in `subject` ("Delete chat with Amit Nanda", "(+91 9871746113)"). State the consequence in the body ("This action cannot be undone."). Render overlays inside a positioned container such as PhoneFrame; use mode="inline" in docs.

Don't: Don't put a Cancel button next to the confirm; the close button and scrim are the revise path. Don't use a sheet for a quick yes/no that needs no context; use a Dialog. Don't show both a title row and the floating close.

Example: Delete confirm (inline)
```tsx
<BottomSheet open mode="inline">
  <ConfirmSheetContent
    title={<>Delete chat with<br />Amit Nanda</>}
    subject="(+91 9871746113)"
    body="All past conversations will be deleted. This action cannot be undone."
    confirmLabel="Delete"
    destructive />
</BottomSheet>
```
```kotlin
// Compose: no inline mode; the sheet always draws over its parent with the scrim
EqualBottomSheet(visible = true, onDismissRequest = {}) {
    ConfirmSheetContent(
        title = "Delete chat with\nAmit Nanda",
        phone = "(+91 9871746113)",
        body = "All past conversations will be deleted. This action cannot be undone.",
        confirmLabel = "Delete",
        destructive = true,
        onConfirm = {},
    )
}
```

Example: Titled sheet (inline)
```tsx
<BottomSheet open mode="inline" title="Turn off WhatsApp updates?">
  <IllustrationHeader asset="illustration-whatsapp" size={120} />
  …
  <Button block size="lg">Turn off updates</Button>
</BottomSheet>
```
```kotlin
// Compose: no inline mode; the sheet always draws over its parent with the scrim
EqualBottomSheet(visible = true, onDismissRequest = {}, title = "Turn off WhatsApp updates?") {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IllustrationHeader(asset = EqualAssets.IllustrationWhatsapp, size = 120.dp)
        EqualText(
            text = "You'll stop getting call alerts and account updates on WhatsApp.",
            style = EqualTheme.type.body1,
            color = EqualTheme.colors.textSecondary,
            textAlign = TextAlign.Center,
        )
        EqualButton(text = "Turn off updates", onClick = {}, size = EqualButtonSize.Block, modifier = Modifier.padding(top = 16.dp))
    }
}
```

Example: Overlay in a phone
```tsx
<PhoneFrame height={560}>
  <Button variant="danger" leadingIcon="delete" onClick={() => setOpen(true)}>Delete chat</Button>
  <BottomSheet open={open} onClose={() => setOpen(false)}>
    <ConfirmSheetContent title={<>Delete chat with<br />Amit Nanda</>}
      subject="(+91 9871746113)" confirmLabel="Delete" destructive
      onConfirm={deleteChat} />
  </BottomSheet>
</PhoneFrame>
```
```kotlin
var open by remember { mutableStateOf(false) }
Box(Modifier.fillMaxSize()) {
    EqualButton(text = "Delete chat", onClick = { open = true }, variant = EqualButtonVariant.Danger, leadingIcon = EqualIcons.Delete)
    EqualBottomSheet(visible = open, onDismissRequest = { open = false }) {
        ConfirmSheetContent(
            title = "Delete chat with\nAmit Nanda",
            phone = "(+91 9871746113)",
            // Compose: body is required
            body = "All past conversations will be deleted. This action cannot be undone.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = { open = false },
        )
    }
}
```

Example: Full sheet
```tsx
<FullSheet open={open} onClose={() => setOpen(false)} title="Setting up instruction"
  footer={
    <ChipRow gap={8}>
      <LargeActionChip emoji="✍️" label="Edit" state="read" />
      <LargeActionChip emoji="👍" label="Confirm" onClick={confirm} />
    </ChipRow>
  }>
  <MessageList>…</MessageList>
</FullSheet>
```
```kotlin
var open by remember { mutableStateOf(false) }
FullSheet(
    visible = open,
    onDismissRequest = { open = false },
    title = "Setting up instruction",
    footer = {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LargeActionChip(label = "Edit", emoji = "✍️", onClick = {}, state = LargeActionChipState.Read)
            LargeActionChip(label = "Confirm", emoji = "👍", onClick = { open = false })
        }
    },
) {
    // Compose: no MessageList; stack bubbles in a Column
    Column(Modifier.padding(horizontal = 12.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ChatBubble(message = "Take a message & Callback request", timestamp = "03:21", type = ChatBubbleType.Outgoing, sender = "You")
        ChatBubble(message = "Got it! Here's your instruction:", timestamp = "03:21", type = ChatBubbleType.Assistant, sender = "Equal AI")
    }
}
```

#### Context menu (`context-menu`)

The long-press menu of icon + label items, and OverflowMenu, the ⋮ button that opens one anchored to a card.

- React: `import { ContextMenu, OverflowMenu } from '@equal/ds';`
- Compose: `ContextMenu`, `ContextMenuPopup`, `OverflowMenu`
- Tokens: `bg/surface`, `shadow/card`, `stroke/subtle`, `text/primary`, `text/tertiary`, `text/danger`
- Source: §18 Context Menu (Long-press)

Do: Put the destructive item last and mark it `danger`. Name the object in destructive labels ("Delete instruction", "Delete address").

Don't: Don't put more than four or five items in a menu. Don't delete straight from the menu; open the confirm sheet.

Example: Chat long-press
```tsx
<ContextMenu items={[
  { label: 'Mark as read', icon: 'done-all' },
  { label: 'Call back', icon: 'call' },
  { label: 'Delete chat', icon: 'delete', danger: true },
]} />
```
```kotlin
ContextMenu(
    items = listOf(
        ContextMenuItem("Mark as read", EqualIcons.DoneAll, onClick = {}),
        ContextMenuItem("Call back", EqualIcons.Call, onClick = {}),
        ContextMenuItem("Delete chat", EqualIcons.Delete, onClick = {}, destructive = true),
    ),
)
```

Example: Overflow menu
```tsx
<OverflowMenu items={[
  { label: 'Edit', icon: 'edit', onSelect: edit },
  { label: 'Delete instruction', icon: 'delete', danger: true, onSelect: confirmDelete },
]} />
```
```kotlin
OverflowMenu(
    items = listOf(
        ContextMenuItem("Edit", EqualIcons.Edit, onClick = {}),
        ContextMenuItem("Delete instruction", EqualIcons.Delete, onClick = {}, destructive = true),
    ),
)
```

#### Dialog (`dialog`)

A centred decision dialog with a text cancel and one filled commit, plus the inverse-surface Snackbar that confirms an action afterwards.

- React: `import { Dialog, Snackbar } from '@equal/ds';`
- Compose: `EqualDialog`, `EqualDialogContent`, `EqualSnackbar`
- Tokens: `bg/surface`, `shadow/nav`, `scrim`, `text/primary`, `text/secondary`, `text/tertiary`, `button/primary`, `button/danger`, `button/secondary`
- Source: Surfaces from the Typography screen inventory · Dialog, Snackbar/Toast

Do: Commit is filled and cancel is a text action, right-aligned (rule 4). Reuse the verb from the control: Turn off → "Turn off" button → "Call learning turned off" snackbar. Offer Undo on the snackbar for reversible deletes.

Don't: Don't write "OK" / "Yes" as the commit; name the action. Don't stack a snackbar on an open dialog.

Example: Inline
```tsx
<Dialog open mode="inline" title="Turn off Call Learning?" subject="Call learning"
  body="Your assistant will stop learning from new calls. What it already knows stays until you clear it."
  confirmLabel="Turn off" />
```
```kotlin
// EqualDialogContent is the dialog surface without the window, for inline use
EqualDialogContent(
    title = "Turn off Call Learning?",
    subject = "Call learning",
    body = "Your assistant will stop learning from new calls. What it already knows stays until you clear it.",
    confirmLabel = "Turn off",
    onConfirm = {},
    onDismiss = {},
)
```

Example: Destructive
```tsx
<Dialog open mode="inline" destructive title="Delete address?" subject="Work"
  body="Your assistant will no longer share this address with delivery partners."
  confirmLabel="Delete" />
```
```kotlin
EqualDialogContent(
    title = "Delete address?",
    subject = "Work",
    body = "Your assistant will no longer share this address with delivery partners.",
    confirmLabel = "Delete",
    destructive = true,
    onConfirm = {},
    onDismiss = {},
)
```

Example: Overlay + snackbar
```tsx
<Dialog open={open} title="Turn off Call Learning?" confirmLabel="Turn off"
  onCancel={() => setOpen(false)}
  onConfirm={() => { setOpen(false); setToast('Call learning turned off'); }} />

{toast && <Snackbar message={toast} actionLabel="Undo" onAction={undo} />}
```
```kotlin
var open by remember { mutableStateOf(false) }
var toast by remember { mutableStateOf<String?>(null) }
EqualButton(text = "Turn off Call Learning", onClick = { toast = null; open = true })
if (open) {
    EqualDialog(
        onDismissRequest = { open = false },
        title = "Turn off Call Learning?",
        subject = "Call learning",
        body = "Your assistant will stop learning from new calls. What it already knows stays until you clear it.",
        confirmLabel = "Turn off",
        onConfirm = { open = false; toast = "Call learning turned off" },
    )
}
toast?.let { EqualSnackbar(message = it, actionLabel = "Undo", onActionClick = { toast = null }) }
```

Example: Snackbars
```tsx
<Snackbar message="Contact saved" />
<Snackbar message="Chat deleted" actionLabel="Undo" onAction={undo} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    EqualSnackbar(message = "Contact saved")
    EqualSnackbar(message = "Chat deleted", actionLabel = "Undo", onActionClick = {})
}
```

#### System notification (`system-notification`)

The Android heads-up notification Equal AI posts, drawn over the status bar in mocks and flows (e.g. “Equal AI Assistant is back on”).

- React: `import { SystemNotification } from '@equal/ds';`
- Compose: `SystemNotificationPreview`
- Tokens: `component/notification/bg`, `text/primary`, `text/secondary`, `text/placeholder`
- Source: Flows: Temporarily Unavailable

Do: Keep the title under about 32 characters, so it fits on one line on a 360dp phone.

Don't: Don’t use it as an in-app toast; it stands for the OS notification.

Example: Back on
```tsx
<SystemNotification title="Equal AI Assistant is back on"
  body="Equal AI is now handling all your unknown calls." />
```
```kotlin
// On a device, post a NotificationCompat instead; this preview is for mocks and flows
SystemNotificationPreview(
    title = "Equal AI Assistant is back on",
    body = "Equal AI is now handling all your unknown calls.",
)
```

### Group: You tab

#### AI summary card (`ai-summary-card`)

The "Your AI Summary" card, prose the assistant wrote about the user, with empty, loading and ready states.

- React: `import { AiSummaryCard } from '@equal/ds';`
- Compose: `AiSummaryCard`
- Tokens: `gradient/ai-summary`, `skeleton`, `text/primary`, `text/secondary`, `text/tertiary`
- Source: You tab · AI Summary card

Do: Write the summary in the assistant's voice, second person, short sentences. Use the loading state while the summary refreshes rather than hiding the card.

Don't: Don't show a stale summary with a spinner; use `status="loading"`. Don't use bullet lists; the summary is prose.

Example: Ready
```tsx
<AiSummaryCard summary="Your family calls you a lot. They always say it's urgent. They almost never say why." />
```
```kotlin
// Compose: status isn't inferred from summary; pass Ready explicitly
AiSummaryCard(
    status = AiSummaryStatus.Ready,
    summary = "Your family calls you a lot. They always say it's urgent. They almost never say why.",
)
```

Example: Empty
```tsx
<AiSummaryCard />
```
```kotlin
AiSummaryCard()
```

Example: Loading
```tsx
<AiSummaryCard status="loading" lastUpdated="8:06 AM" />
```
```kotlin
AiSummaryCard(status = AiSummaryStatus.Loading, lastUpdated = "8:06 AM")
```

#### Contact info header (`contact-info-header`)

The top of the Contact Info screen: a 96dp avatar, name, phone and a row of action tiles (Call, Mute, Save, Share).

- React: `import { ContactInfoHeader } from '@equal/ds';`
- Compose: `ContactInfoHeader`
- Tokens: `bg/surface`, `stroke/subtle`, `text/action`, `text/primary`, `text/secondary`
- Source: Contact Info (Contact Info)

Do: Use the four tiles Call · Mute · Save · Share, with Material Symbols icons in text/action. Flip the Mute tile label to Unmute when the contact is muted.

Don't: Don't add more than four tiles; they share one row. Don't use emoji on the tiles; these are icon tiles, not action chips.

Example: Saved contact
```tsx
<ContactInfoHeader name="Amit Nanda" phone="+91 98717 46113" avatar={{ initials: 'AN' }}
  actions={[
    { icon: 'call', label: 'Call' },
    { icon: 'silent-mode', label: 'Mute' },
    { icon: 'person-add', label: 'Save' },
    { icon: 'share', label: 'Share' },
  ]} />
```
```kotlin
ContactInfoHeader(
    name = "Amit Nanda",
    phone = "+91 98717 46113",
    initials = "AN",
    actions = listOf(
        ContactInfoAction("Call", EqualIcons.Call, onClick = {}),
        ContactInfoAction("Mute", EqualIcons.SilentMode, onClick = {}),
        ContactInfoAction("Save", EqualIcons.PersonAdd, onClick = {}),
        ContactInfoAction("Share", EqualIcons.Share, onClick = {}),
    ),
)
```

Example: Unknown caller, with history
```tsx
<ContactInfoHeader name="Arnav Raj" phone="+91 98717 46113"
  avatar={{ category: 'career' }} actions={actions} />
<SectionHeader size="label" inset={22}>Call history</SectionHeader>
<CallHistoryList>
  <CallHistoryRow direction="incoming" meta="Today • 30 Sec." time="02:30 PM" />
  <CallHistoryRow direction="missed" meta="Yesterday" time="11:04 AM" />
</CallHistoryList>
```
```kotlin
ContactInfoHeader(
    name = "Arnav Raj",
    phone = "+91 98717 46113",
    category = EqualCategory.Career,
    // Call · Mute · Save · Share
    actions = defaultContactInfoActions(onCall = {}, onMute = {}, onSave = {}, onShare = {}),
)
SectionHeader(title = "Call history")
RowGroup {
    CallHistoryRow(direction = CallDirection.Incoming, meta = "Today • 30 Sec.", time = "02:30 PM")
    CallHistoryRow(direction = CallDirection.Missed, meta = "Yesterday", time = "11:04 AM")
}
```

#### Invite card (`invite-card`)

The mint "Invite a Friend" pill at the bottom of the You tab, with the high-five art rising above it and a share button.

- React: `import { InviteCard } from '@equal/ds';`
- Compose: `InviteCard`
- Tokens: `invite/bg`, `invite/stroke`, `bg/surface`, `text/primary`, `text/secondary`
- Source: You tab · Invite card

Do: Leave ~29dp of space above the card for the art to rise into. Keep it the last item on the You tab, above the bottom nav.

Don't: Don't rotate the art again; the tilt is baked into the file. Don't crop the high-five illustration to fit the card.

Example: Default
```tsx
<InviteCard onShare={shareInvite} />
```
```kotlin
InviteCard(onShare = {})
```

Example: Custom copy
```tsx
<InviteCard title="Give a month free" subtitle="Share Equal AI with family" onShare={shareInvite} />
```
```kotlin
InviteCard(title = "Give a month free", subtitle = "Share Equal AI with family", onShare = {})
```

#### Plan card (`plan-card`)

The dark card showing the user's current plan (Equal AI UNLIMITED, ₹149/Monthly), with a Manage plan action and an expired state.

- React: `import { PlanCard } from '@equal/ds';`
- Compose: `PlanCard`
- Tokens: `plan-card/bg`, `plan-card/pill-stroke`, `plan-card/pattern`, `text/on-dark`, `text/on-dark-secondary`, `text/accent-gold`, `text/danger`
- Source: You tab · Plan card

Do: Show the price with the period ("₹149/Monthly"); it renders in tabular figures. Use the expired state with Manage plan so renewing is one tap.

Don't: Don't replace the coded gold pattern with an image. Don't place the plan card on a white surface; it belongs in the gold hero.

Example: Current and expired
```tsx
<PlanCard onManage={managePlan} />
<PlanCard status="expired" onManage={managePlan} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    PlanCard(onManageClick = {})
    // Compose: status="expired" is a Boolean flag
    PlanCard(expired = true, onManageClick = {})
}
```

Example: Custom tier
```tsx
<PlanCard tier="LITE" price="₹49/Monthly" />
```
```kotlin
PlanCard(tier = "LITE", price = "₹49/Monthly")
```

#### Profile hero (`profile-hero`)

The gold header at the top of the You tab (avatar, name, plan marker, edit, phone) that hosts the plan card, plus the compact ProfileHeader.

- React: `import { ProfileHero, ProfileHeader } from '@equal/ds';`
- Compose: `ProfileHero`, `ProfileHeader`
- Tokens: `gradient/profile-hero`, `gradient/gold`, `text/primary`, `text/secondary`
- Source: You tab · Profile hero

Do: Put the PlanCard inside the hero as children so it sits on the gold. Drive `avatar` from the gender chosen in Personal Details.

Don't: Don't add more actions to the hero row; edit is the only one. Don't format the phone number without tabular figures.

Example: You tab hero with plan card
```tsx
<ProfileHero name="Keshav" phone="+91 98789 56749" onEdit={editProfile}>
  <PlanCard onManage={managePlan} />
</ProfileHero>
```
```kotlin
ProfileHero(name = "Keshav", phone = "+91 98789 56749", onEdit = {}) {
    PlanCard(onManageClick = {})
}
```

Example: Female avatar, no plan
```tsx
<ProfileHero name="Priya Sharma" phone="+91 99100 22114" avatar="female" plan={null} onEdit={editProfile} />
```
```kotlin
ProfileHero(
    name = "Priya Sharma",
    phone = "+91 99100 22114",
    avatar = ProfileAvatarVariant.Female,
    plan = null,
    onEdit = {},
)
```

Example: Compact header
```tsx
<ProfileHeader name="Keshav" phone="+91 98789 56749" />
```
```kotlin
ProfileHeader(name = "Keshav", phone = "+91 98789 56749")
```

## Core screens (the revamped app: start every flow from these)

- `home` Chats: `<HomeScreen />`
  ```kotlin
  EqualTheme {
      HomeScreenSample()
  }
  ```
- `live` Chat, live call: `<ChatScreen live />`
  ```kotlin
  EqualTheme {
      // Compose: ChatScreenSample renders the live-call thread; the after-call variant is a web-only sample
      ChatScreenSample()
  }
  ```
- `after` Chat, after the call: `<ChatScreen chat={sampleChats[1]} />`
  ```kotlin
  EqualTheme {
      // Compose: same sample as the live call; compose the after-call thread from ChatHeader + MessageList
      ChatScreenSample()
  }
  ```
- `you` You, summary ready: `<YouScreen summary="ready" />`
  ```kotlin
  EqualTheme {
      YouScreenSample(summary = AiSummaryStatus.Ready)
  }
  ```
- `you-loading` You, summary loading: `<YouScreen summary="loading" />`
  ```kotlin
  EqualTheme {
      YouScreenSample(summary = AiSummaryStatus.Loading)
  }
  ```
- `you-empty` You, summary empty: `<YouScreen summary="empty" avatar="female" />`
  ```kotlin
  EqualTheme {
      YouScreenSample(summary = AiSummaryStatus.Empty, avatar = ProfileAvatarVariant.Female)
  }
  ```
- `contact` Contact info: `<ContactInfoScreen />`
  ```kotlin
  EqualTheme {
      ContactInfoScreen(name = "Amit Nanda", phone = "+91 9871746113", onBack = {})
  }
  ```
- `search` Search: `<SearchScreen />`
  ```kotlin
  EqualTheme {
      SearchScreen(onBack = {}, onOpenChat = {})
  }
  ```

## Flows (18)

### Monetization (`/flows/monetization`)

Equal Unlimited: the free-plan touchpoints that open the paywall, the paywall itself, payment results, managing and cancelling the plan, and lapsed plans. The Android team experiments here, so every screen takes the experiment knobs (price, coupon, copy, entry touchpoint) as props.

Source: Monetization Flow

1. Touchpoints (where the paywall opens from): locked rows in the chat list (blurred preview, crown-lock), a locked conversation (Unlock All Details), locked audio (Unlock Audio), Manage plan on the You tab’s plan card, and the Reactivate banners on a lapsed plan. They sit on the revamped screens as props: HomeScreen lockedFrom, ChatScreen lock (details · audio · lapsed) and YouScreen plan (active · restore · reactivate). Pass the entry as touchpoint so the paywall previews what the user was trying to see.
2. Paywall: gold hero with the crown, “Unlock Equal Unlimited”, the price under LIMITED TIME DISCOUNT, the preview card, the EQUAL25 coupon (APPLY → APPLIED drops ₹249 to ₹149), FAQ, and the sticky gold Unlock Unlimited with “Cancel Anytime. Automatically renews”.
3. Payment: Waiting for Confirmation (auto) → Payment Confirmed (redirect in 5s) → Congratulations (redirect to home). Pending offers Contact Support; Failed offers Retry Payment; both say the refund comes within 24 hours. Support opens the Help Center sheet.
4. After: the home header shows UNLIMITED and avatars turn gold. The You tab’s plan card has Manage plan → the subscription page (plan end date, 400k+, rating, testimonials, FAQ).
5. Cancel: tell us why (Proceed disabled until there is text) → are you really sure (Cancel / Confirm) → request submitted (redirect in 3s). Access stays until the end date; the page then offers Re-Subscribe.
6. Lapsed: the You tab shows Restore Plan or Reactivate plan with the amber banner; chats show “Reactivate your current Plan to keep using Equal Unlimited”.
7. Experiments (props, not forks): price / discountedPrice (₹249, ₹149), coupon (none · available · applied), subtitle (“Unlock Summaries…” · “Get Unlimited Summaries…”), touchpoint (chat-list · chat · audio), waitingArt (coin · cash), HomeScreen lockedFrom (how many free chats).

States:
- `home-free` Home, free plan (locked chats): `<HomeScreen tier="free" lockedFrom={4} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Free plan: rows from index 4 on are locked; tapping one opens the paywall
      HomeScreenSample(
          tier = PlanTier.Free,
          lockedFrom = 4,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onLockedChat = { /* open PaywallScreen(touchpoint = PaywallTouchpoint.ChatList) */ },
      )
  }
  ```
- `chat-locked` Chat: Unlock All Details: `<ChatScreen lock="details" />`
  ```kotlin
  EqualTheme {
      // Free plan: bubbles blurred, recording locked, Unlock All Details instead of the AI panel
      ChatScreenSample(lock = ChatLock.Details, onUnlock = { /* open PaywallScreen(touchpoint = PaywallTouchpoint.Chat) */ })
  }
  ```
- `chat-audio` Chat: Unlock Audio: `<ChatScreen lock="audio" />`
  ```kotlin
  EqualTheme {
      // Free plan: only the call summary recording is locked (Unlock Audio)
      ChatScreenSample(lock = ChatLock.Audio, onUnlock = { /* open PaywallScreen(touchpoint = PaywallTouchpoint.Audio) */ })
  }
  ```
- `paywall` Paywall (Try it: apply, unlock): `<PaywallScreen touchpoint="chat-list" />`
  ```kotlin
  EqualTheme {
      // Live: APPLY drops ₹249 to ₹149; Unlock → Waiting → Confirmed → Welcome
      PaywallScreen(touchpoint = PaywallTouchpoint.ChatList)
  }
  ```
- `paywall-chat` Paywall from a chat: `<PaywallScreen touchpoint="chat" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.Chat)
  }
  ```
- `paywall-audio` Paywall from audio, coupon applied: `<PaywallScreen touchpoint="audio" coupon="applied" subtitle="get" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.Audio, coupon = PaywallCoupon.Applied, subtitle = PaywallSubtitle.Get)
  }
  ```
- `waiting` Waiting for Confirmation: `<PaywallScreen overlay="waiting" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Waiting)
  }
  ```
- `confirmed` Payment Confirmed: `<PaywallScreen overlay="confirmed" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Confirmed)
  }
  ```
- `pending` Payment Pending: `<PaywallScreen overlay="pending" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Pending)
  }
  ```
- `failed` Payment Failed: `<PaywallScreen overlay="failed" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Failed)
  }
  ```
- `help` Help Center: `<PaywallScreen overlay="help" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Help)
  }
  ```
- `welcome` Congratulations: `<PaywallScreen overlay="welcome" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Welcome)
  }
  ```
- `home-paid` Home, paid: `<HomeScreen promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Paid (the default tier): nothing locked
      HomeScreenSample(promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) })
  }
  ```
- `settings` You: Manage plan: `<YouScreen plan="active" />`
  ```kotlin
  EqualTheme {
      YouScreenSample(plan = YouPlan.Active, onManagePlan = { /* open SubscriptionScreen() */ })
  }
  ```
- `subscription` Subscription (Try it: cancel): `<SubscriptionScreen />`
  ```kotlin
  EqualTheme {
      // Live: Cancel Subscription → feedback → confirm → submitted → cancelled (Re-Subscribe)
      SubscriptionScreen()
  }
  ```
- `cancel-feedback` Cancel: tell us why: `<SubscriptionScreen cancelStep="feedback" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(cancelStep = CancelStep.Feedback)
  }
  ```
- `cancel-filled` Cancel: reason written: `<SubscriptionScreen cancelStep="feedback" reason="Felt it too expensive, I hope it would be under my budget" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(cancelStep = CancelStep.Feedback, reason = "Felt it too expensive, I hope it would be under my budget")
  }
  ```
- `cancel-confirm` Cancel: are you sure?: `<SubscriptionScreen cancelStep="confirm" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(cancelStep = CancelStep.Confirm)
  }
  ```
- `cancel-submitted` Cancel: request submitted: `<SubscriptionScreen cancelStep="submitted" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(cancelStep = CancelStep.Submitted)
  }
  ```
- `cancelled` Cancelled: Re-Subscribe: `<SubscriptionScreen state="cancelled" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(state = SubscriptionState.Cancelled)
  }
  ```
- `settings-restore` You: Restore Plan: `<YouScreen tier="free" plan="restore" />`
  ```kotlin
  EqualTheme {
      // Plan ended: free tier, Restore Plan
      YouScreenSample(tier = PlanTier.Free, plan = YouPlan.Restore, onManagePlan = { /* open PaywallScreen() */ })
  }
  ```
- `settings-reactivate` You: Reactivate plan: `<YouScreen plan="reactivate" />`
  ```kotlin
  EqualTheme {
      // Autopay off: Reactivate plan + the attached banner under the plan card
      YouScreenSample(plan = YouPlan.Reactivate, onManagePlan = { /* open SubscriptionScreen() */ })
  }
  ```
- `chat-lapsed` Chat: plan lapsed: `<ChatScreen lock="lapsed" />`
  ```kotlin
  EqualTheme {
      // Plan lapsed: readable, Reactivate banner under the header
      ChatScreenSample(lock = ChatLock.Lapsed, onUnlock = { /* open SubscriptionScreen() */ })
  }
  ```

### Temporarily unavailable (`/flows/system-status`)

What Chats shows while Equal AI is down, and how it tells you it’s back. Switch to Try it and tap “Notify me when ready” to run the whole flow.

Source: Temporarily Unavailable

1. Unavailable: the System status card takes the assistant toggle’s place, with the sleeping robot and an amber “Notify me when ready”. The promo card is hidden while the system is down.
2. Notify requested: the pill becomes a green “✓ You’ll be notified soon”. Nothing else on the screen changes.
3. Back on: a heads-up notification (“Equal AI Assistant is back on”) drops in, the toggle returns as “AI Assistant is On”, and Meet Your Assistant with “Call me” sits above Conversations.

States:
- `down` Unavailable: `<SystemStatusFlow stage="unavailable" />`
  ```kotlin
  EqualTheme {
      SystemStatusFlowSample(stage = SystemStatusStage.Unavailable)
  }
  ```
- `notified` Notify requested: `<SystemStatusFlow stage="notified" />`
  ```kotlin
  EqualTheme {
      SystemStatusFlowSample(stage = SystemStatusStage.Notified)
  }
  ```
- `back` Back on: `<SystemStatusFlow stage="back-on" />`
  ```kotlin
  EqualTheme {
      SystemStatusFlowSample(stage = SystemStatusStage.BackOn)
  }
  ```
- `live` Live flow (Try it): `<SystemStatusFlow />`
  ```kotlin
  EqualTheme {
      // No stage: tap Notify, and the system recovers after recoverAfterMillis
      SystemStatusFlowSample(recoverAfterMillis = 2500)
  }
  ```

### Profile flow (`/flows/profile`)

Personal Details, Silent Mode and WhatsApp Updates: the nested screens behind the You tab.

Source: Nested Profile Screen

1. Personal Details: the name field uses the pill shape; the helper line reads “Your AI will call you ‘Keshav’” with the first name bolded. Choosing a gender card swaps the profile avatar across the app.
2. Silent Mode: the master toggle mutes promotional calls; the five category toggles dim and lock while it’s off. Muted Contacts opens the list of people you’ve muted.
3. WhatsApp Updates: turning the toggle off never happens silently. It opens a confirm sheet with the WhatsApp illustration and a primary “Turn off updates”.

States:
- `personal` Personal Details: `<PersonalDetailsScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      PersonalDetailsScreen(onBack = {}, onChange = { name, gender -> })
  }
  ```
- `silent` Silent Mode: `<SilentModeScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      SilentModeScreen(onBack = {})
  }
  ```
- `wa` WhatsApp Updates: `<WhatsAppUpdatesScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      WhatsAppUpdatesScreen(onBack = {})
  }
  ```
- `wa-sheet` Turn-off confirm: `<WhatsAppUpdatesScreen onBack={goBack} showSheet />`
  ```kotlin
  EqualTheme {
      WhatsAppUpdatesScreen(onBack = {}, showSheet = true)
  }
  ```

### Addresses flow (`/flows/addresses`)

Empty state, the saved list with an overflow menu, the Edit Address sheet and the delete confirm.

Source: Addresses

1. Empty: the illustration, “Never explain your address again”, and a pinned “Add new Address”.
2. List: each card shows its label and address, with ⋮ → Edit / Delete address.
3. Edit / Add: a titled sheet with LABEL* chips (the selected chip is dark), two address lines, City + Pincode (6 digits, checked), an optional guiding direction and Save.
4. Delete: a confirm sheet with the trash illustration and a destructive Delete.

States:
- `empty` Empty: `<AddressesScreen onBack={goBack} initial={[]} />`
  ```kotlin
  EqualTheme {
      AddressesScreen(onBack = {}, initial = emptyList())
  }
  ```
- `list` Saved addresses: `<AddressesScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      AddressesScreen(onBack = {}, initial = SampleAddresses)
  }
  ```
- `edit` Edit Address sheet: `<AddressesScreen onBack={goBack} openEdit={sampleAddresses[3].id} />`
  ```kotlin
  EqualTheme {
      AddressesScreen(onBack = {}, openEdit = SampleAddresses[3].id)
  }
  ```
- `delete` Delete confirm: `<AddressesScreen onBack={goBack} confirmDelete={sampleAddresses[0].id} />`
  ```kotlin
  EqualTheme {
      AddressesScreen(onBack = {}, confirmDelete = SampleAddresses[0].id)
  }
  ```

### Instructions flow (`/flows/instructions`)

The hub, presets, the “Setting up instruction” chat and Active Instructions. Switch to Try it and apply an instruction end to end.

Source: Instructions

1. Hub: horizontal recommended cards (or “New suggestions coming…” once they’re all applied), an Active Instructions row, three presets and a pinned “Add New Instruction”.
2. Preset: the description plus instruction cards with When / Do rows and + Apply, which turns into Applied.
3. Setup chat, no input: You → Equal AI “Got it! Here’s your instruction:” → preview → ✍️ Edit / 👍 Confirm. Confirm adds ✅ and saves.
4. Setup chat, input needed: Equal AI asks each follow-up (the landmark, then the wait time); the answers are bolded in the preview → ✏️ Change something else / 👌 That’s all.
5. Active: cards with a source chip, WHEN / DO, and ⋮ Edit / Delete instruction; plus an empty state.

States:
- `hub` Hub: `<InstructionsFlow initialActive={[]} />`
  ```kotlin
  EqualTheme {
      InstructionsFlow(onBack = {}, initialActive = emptyList())
  }
  ```
- `preset` Preset: Screen & Protect: `<InstructionsFlow initialActive={[]} initialView={{ preset: 'screen' }} />`
  ```kotlin
  EqualTheme {
      InstructionsFlow(initialActive = emptyList(), initialView = InstructionsView.PresetDetail("screen"))
  }
  ```
- `setup` Setup chat, no input: `<InstructionSetupDemo which="decline" />`
  ```kotlin
  EqualTheme {
      InstructionSetupDemo(which = SetupDemo.Decline)
  }
  ```
- `setup-input` Setup chat, input needed: `<InstructionSetupDemo which="delivery" />`
  ```kotlin
  EqualTheme {
      InstructionSetupDemo(which = SetupDemo.Delivery)
  }
  ```
- `active` Active instructions: `<InstructionsFlow initialView="active" />`
  ```kotlin
  EqualTheme {
      InstructionsFlow(initialView = InstructionsView.Active)
  }
  ```
- `active-empty` Active, empty: `<InstructionsFlow initialActive={[]} initialView="active" />`
  ```kotlin
  EqualTheme {
      InstructionsFlow(initialActive = emptyList(), initialView = InstructionsView.Active)
  }
  ```
- `no-recs` No recommendations: `<InstructionsFlow noRecommendations />`
  ```kotlin
  EqualTheme {
      InstructionsFlow(noRecommendations = true)
  }
  ```

### Plan value & renewal (`/flows/plan-renewal`)

Before a plan ends, show what it did for the user, then make renewing one tap. Home carries the expiry strip, a call near the end brings up the What Unlimited saved you sheet, and Manage plan leads to the renewal page and the paywall.

Source: Monetization value, Monetization local components

1. Expiry strip under the home header: amber “Your Plan Expires in 2 Days”, red “Expires Today” and “Expired on 30th July”, each with Renew Now. Pass planExpiry to HomeScreen; nothing shows while the plan is comfortably active.
2. Value sheet once called: after the assistant handles a call near the end of the plan, the What Unlimited saved you sheet rises over home: calls handled, three perks, the expiry chip (03 Days amber, Today / 30th July red) and the current plan, with Renew your Equal AI. Close floats above the sheet. valueSheet="flush" is the experiment where the card is the sheet. In dark mode the card turns black with a gold glow.
3. Free plan quota: the same sheet for free users counts the week’s calls. Under the limit it reads “6 out of 30 Calls Left” with a gold progress bar; at the limit, “Limit Reached · 30 out of 30 (100%)”. Both show when the quota resets and Subscribe to Equal AI Unlimited at ₹149, with Get Equal AI Unlimited opening the paywall. Pass quotaSheet to HomeScreen.
4. Plan card: active shows Current Plan; expired shows the red Plan Expired pill and a plain avatar. Manage plan opens the plan page either way.
5. Plan page: Equal AI Unlimited hero, What Unlimited Saved You (calls, plan active until or expired on, price), What You Get, social proof and FAQ. The plan action is pinned: Cancel Subscription (gold outline) while active, Renew your Equal AI once expired, which opens the paywall with Get Equal AI Unlimited.
6. Motion (local components): APPLY strikes the old price, lands the new one with the list price and “Saved ₹100”, and pops the Special Coupon Applied! badge. The gold CTA has a sheen sweep. The waiting sheet steps through Connecting To Razorpay → Waiting for Confirmation → Verifying Transaction, then Payment Confirmed with the ray burst behind the seal. Everything holds still under reduced motion.

States:
- `home-expiring` Home: expires in 2 days: `<HomeScreen planExpiry={{ state: 'expiring', days: 2 }} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Amber strip under the header; Renew Now opens the paywall
      HomeScreenSample(
          planExpiry = PlanExpiry.Expiring(days = 2),
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `home-today` Home: expires today: `<HomeScreen planExpiry={{ state: 'today' }} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(
          planExpiry = PlanExpiry.Today,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `home-expired` Home: expired: `<HomeScreen tier="free" planExpiry={{ state: 'expired', date: '30th July' }} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(
          tier = PlanTier.Free,
          planExpiry = PlanExpiry.Expired(date = "30th July"),
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `value-sheet` Value sheet (Try it: close): `<HomeScreen planExpiry={{ state: 'expiring', days: 3 }} valueSheet promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // After a call near the end of the plan: What Unlimited saved you; close or the scrim hides it
      HomeScreenSample(
          planExpiry = PlanExpiry.Expiring(days = 3),
          valueSheet = ValueSheetVariant.Card,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `value-sheet-flush` Value sheet, flush (experiment): `<HomeScreen planExpiry={{ state: 'expiring', days: 3 }} valueSheet="flush" promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Experiment: the value card is the sheet
      HomeScreenSample(
          planExpiry = PlanExpiry.Expiring(days = 3),
          valueSheet = ValueSheetVariant.Flush,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `value-sheet-today` Value sheet: expires today: `<HomeScreen planExpiry={{ state: 'today' }} valueSheet promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(
          planExpiry = PlanExpiry.Today,
          valueSheet = ValueSheetVariant.Card,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `value-sheet-expired` Value sheet: expired: `<HomeScreen tier="free" planExpiry={{ state: 'expired', date: '30th July' }} valueSheet promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(
          tier = PlanTier.Free,
          planExpiry = PlanExpiry.Expired(date = "30th July"),
          valueSheet = ValueSheetVariant.Card,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `quota-left` Free: 6 of 30 calls left: `<HomeScreen tier="free" quotaSheet={{ used: 24, limit: 30, resetsInDays: 4 }} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Free plan: 6 out of 30 Calls Left; Get Equal AI Unlimited opens the paywall
      HomeScreenSample(
          tier = PlanTier.Free,
          quotaSheet = Quota(used = 24, limit = 30, resetsInDays = 4),
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `quota-limit` Free: limit reached: `<HomeScreen tier="free" lockedFrom={4} quotaSheet={{ used: 30, limit: 30, resetsInDays: 2 }} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Limit Reached · 30 out of 30 (100%); rows from the 5th on are locked
      HomeScreenSample(
          tier = PlanTier.Free,
          lockedFrom = 4,
          quotaSheet = Quota(used = 30, limit = 30, resetsInDays = 2),
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `you-active` You: plan active: `<YouScreen plan="active" />`
  ```kotlin
  EqualTheme {
      YouScreenSample(plan = YouPlan.Active, onManagePlan = { /* open SubscriptionScreen() */ })
  }
  ```
- `manage-active` Manage plan: active: `<SubscriptionScreen />`
  ```kotlin
  EqualTheme {
      // Value card (plan active until), What You Get, proof, FAQ; Cancel Subscription pinned
      SubscriptionScreen()
  }
  ```
- `you-expired` You: plan expired: `<YouScreen tier="free" plan="expired" />`
  ```kotlin
  EqualTheme {
      // Red "Plan Expired" pill, plain avatar; Manage plan opens the renewal page
      YouScreenSample(
          tier = PlanTier.Free,
          plan = YouPlan.Expired,
          onManagePlan = { /* open SubscriptionScreen(state = SubscriptionState.Expired) */ },
      )
  }
  ```
- `manage-expired` Manage plan: expired (Renew): `<SubscriptionScreen state="expired" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(
          state = SubscriptionState.Expired,
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `renew-paywall` Renew: paywall (Try it: apply): `<PaywallScreen touchpoint="chat-list" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      // APPLY strikes ₹249, lands ₹149 with "Saved ₹100" and pops Special Coupon Applied!
      PaywallScreen(touchpoint = PaywallTouchpoint.ChatList, cta = "Get Equal AI Unlimited")
  }
  ```
- `progress` Payment progress steps: `<PaywallScreen overlay="waiting" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      // Connecting To Razorpay → Waiting for Confirmation → Verifying Transaction (every 1.4s)
      PaywallScreen(overlay = PaywallOverlay.Waiting, cta = "Get Equal AI Unlimited")
  }
  ```
- `confirmed` Payment Confirmed: `<PaywallScreen overlay="confirmed" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      // Payment Confirmed with the ray burst behind the seal
      PaywallScreen(overlay = PaywallOverlay.Confirmed, cta = "Get Equal AI Unlimited")
  }
  ```

### Global MYA (`/flows/global-mya`)

Tap the green orb anywhere and your assistant answers in a sheet: a greeting, quick actions and suggestions, then a request typed or spoken. The request turns into a short task conversation that ends with the result to confirm.

Source: Global MYA

1. Open: the green orb (the nav FAB) opens the sheet over whatever screen you’re on: orb, “Good morning, Keshav” (name in green), “What can I help you with today?”, three quick-action tiles, suggestion chips, and a message field with the mic.
2. Type: focusing the field hides the tiles and lifts the input above the keyboard (green outline). Enter sends.
3. Speak: the mic swaps the field for Send voice note with a keyboard toggle. Tap it to record: “Try saying …”, then delete, the timer with a live waveform, and send. Or press and hold: “Release to send, slide left to cancel”, and sliding left turns the waveform red (“Release to cancel”).
4. Task: once sent, the sheet grows into a conversation titled with what the assistant is doing (“Setting up a reminder…”), with close. Your voice note (player + transcript) → Thinking… → the result card (here a WhatsApp reminder) with Edit / Confirm.
5. Inside a chat: the chat’s own AI layer (“Want me to send Amit a quick reply on WhatsApp?”) works the same way. Tapping a chip or sending a message raises the task sheet, which stops below the chat header so you can still see whose chat it is. “Replying Amit on WhatsApp” shows the drafted reply with ✏️ Edit / 📤 Send and the 📤 Send · ✏️ Edit draft · 🖋️ Custom chips. Confirming shows “Opening WhatsApp…” and greys the chips out.
6. Done: Confirm ticks the card, the sheet closes, and the chat it acted on now reads “Reminder added”. Saved contacts carry the person badge on their initials.

States:
- `home` Home (Try it: tap the orb): `<HomeScreen chats={chats} promo="meet-assistant-carousel" />`
  ```kotlin
  EqualTheme {
      // Home: tap the green orb (nav FAB) to open the live sheet
      HomeScreenSample(chats = MyaSampleChats, promo = { MeetAssistantCarousel(onDismiss = {}) })
  }
  ```
- `greeting` Greeting & quick actions: `<HomeScreen chats={chats} assistantResult={{ chatId: 'c3', preview: 'Reminder added' }} />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(chats = MyaSampleChats, promo = { MeetAssistantCarousel(onDismiss = {}) }, assistant = MyaStage.Greeting)
  }
  ```
- `chat-ai` In a chat: the AI layer (Try it): `<ChatScreen chat={amit} />`
  ```kotlin
  EqualTheme {
      // Tap Reply on WhatsApp (or send a message) to open the task sheet
      ChatScreenSample(name = "Amit Nanda", initials = "AN", category = EqualCategory.NA, subtitle = "+91 98717 46113")
  }
  ```
- `chat-task` In a chat: Replying Amit on WhatsApp: `<ChatScreen chat={amit} aiTask="draft" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(name = "Amit Nanda", initials = "AN", category = EqualCategory.NA, subtitle = "+91 98717 46113", aiTask = ChatTaskStage.Draft)
  }
  ```
- `chat-sending` In a chat: Opening WhatsApp: `<ChatScreen chat={amit} aiTask="sending" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(name = "Amit Nanda", initials = "AN", category = EqualCategory.NA, subtitle = "+91 98717 46113", aiTask = ChatTaskStage.Sending)
  }
  ```

### Monetization touchpoints (`/flows/monetization-touchpoints`)

Where a free user meets Equal Unlimited. Each touchpoint is an experiment option the Android team A/B tests, built as props on the same Home, Chat and Paywall screens.

Source: Plan Expired Touchpoint · Usage Cap Touchpoint (options 1 & 2) · Touchpoint: Actions on Home Page · Recordings + Transcripts Locked (with / without actions) · Component 25

1. Plan expired, option 1: the red PLAN EXPIRED badge, and Equal AI’s own verified chat on top (“Your Plan Expired…”, 👑 Renew Now). Its message is a voice note plus Renew Equal AI Unlimited, which opens the paywall previewing a locked summary.
2. Plan expired, option 2: no chat, a card under the header instead (👑 Your Plan Expired · Renew Now).
3. Usage cap: the assistant switches Off at the weekly limit. Option 1 is again an Equal AI message (“Weekly call limit reached…”). Option 2 is a meter card: “7 Calls left this week · Resets Mon | Unlimited on premium” with Get Unlimited.
4. Actions locked: action chips turn gold with the crown-lock. Tapping one opens the paywall (here the sheet) with “Unlock Unlimited Actions…” and the locked row as its preview.
5. Recordings locked: bubbles blur, the recording washes gold under the crown-lock, and Unlock All Details sits at the bottom. With actions, Call Back / Add to Calendar stay visible under the summary and show locked in the paywall preview.
6. Toggle art (Component 25): the phone-with-sparkles is an experiment on the toggle; the robot stays the default.

States:
- `expired-home` Plan expired 1: Equal AI chat: `<HomeScreen tier="free" planExpired official="plan-expired" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, planExpired = true, official = OfficialNotice.PlanExpired)
  }
  ```
- `expired-chat` Plan expired 1: the message: `<ChatScreen official="plan-expired" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(official = OfficialNotice.PlanExpired)
  }
  ```
- `expired-paywall` Plan expired 1: paywall: `<PaywallScreen touchpoint="recordings" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.Recordings, cta = "Get Equal AI Unlimited")
  }
  ```
- `expired-card` Plan expired 2: home card: `<HomeScreen tier="free" planExpired homeNotice="plan-expired" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, planExpired = true, homeNotice = HomeNotice.PlanExpired)
  }
  ```
- `cap-chat-home` Usage cap 1: Equal AI chat: `<HomeScreen tier="free" assistantOff official="usage-cap" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, assistantOff = true, official = OfficialNotice.UsageCap)
  }
  ```
- `cap-chat` Usage cap 1: the message: `<ChatScreen official="usage-cap" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(official = OfficialNotice.UsageCap)
  }
  ```
- `cap-card` Usage cap 2: calls left: `<HomeScreen tier="free" assistantOff homeNotice={{ callsLeft: 7, limit: 30 }} />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, assistantOff = true, homeNotice = HomeNotice.UsageCap(callsLeft = 7, limit = 30))
  }
  ```
- `actions-home` Actions locked: home (Try it): `<HomeScreen tier="free" lockedActions paywallSheet promo="meet-assistant-carousel" />`
  ```kotlin
  EqualTheme {
      // Try it: a locked chip opens the sheet paywall
      HomeScreenSample(tier = PlanTier.Free, lockedActions = true, paywallSheet = true, promo = { MeetAssistantCarousel() })
  }
  ```
- `actions-paywall` Actions locked: paywall: `<PaywallScreen touchpoint="actions" subtitle="actions" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.Actions, subtitle = PaywallSubtitle.Actions, cta = "Get Equal AI Unlimited")
  }
  ```
- `recordings` Recordings locked (without actions): `<ChatScreen chat={sampleChats[1]} lock="details" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(lock = ChatLock.Details)
  }
  ```
- `recordings-actions` Recordings locked (with actions): `<ChatScreen chat={sampleChats[1]} lock="details" summaryActions />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(lock = ChatLock.Details, summaryActions = true)
  }
  ```
- `recordings-paywall` Recordings locked: paywall: `<PaywallScreen touchpoint="recordings-actions" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.RecordingsActions, cta = "Get Equal AI Unlimited")
  }
  ```
- `phone-toggle` Toggle art: phone (Component 25): `<HomeScreen assistantArt="phone" promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(assistantArt = AssistantToggleArt.Phone, promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) })
  }
  ```

### Sheet paywall & payment (`/flows/paywall-sheet`)

The experiment that opens the paywall as a sheet over the screen the user was on, offers EQUAL25 when they try to leave, and shows full-screen payment results. If the user closes a pending payment, every surface says it is processing and the paywall locks.

Source: Light / Dark Mode: Home Screen · Conversation Screen · All Payment States · Payment Pending: Home Screen · If User Closes the payment pending page · Dark Mode_Monetization

1. Sheet: a compact gold card (crown, Equal AI Unlimited, “Trusted by 10 Lakh+ Indians”, ₹249, EQUAL25 · APPLY) with Unlock Equal AI Unlimited. Support opens the Help Center FAQ sheet, and back returns.
2. Exit offer: tapping outside asks Leave Without Unlocking? “Claim 25% off with EQUAL25 first, go Unlimited for ₹149/month.” On home the buttons read Not Now / Claim 25% Off; in a chat, Leave / Keep 25% Off. Claim reopens the sheet at ₹149 with APPLIED. Not Now closes it and leaves the Go unlimited for ₹149 with EQUAL25 · Claim Now strip on home.
3. Results are full screens on a tinted wash with rings. Congratulations, You’re Unlimited, shows Plan active till. Payment Pending has × and Refresh Status, or Contact Support. Payment Failed has ‹ and suggests another UPI app, with Retry payment and Contact Support.
4. Closed while pending: a “Payment processing · We’ll update your order once it’s confirmed.” strip under the chat header and as a card under the home toggle. On the paywall it’s a toast above a disabled Unlock Unlimited, so nobody pays twice.
5. Dark mode: everything follows the theme switch (black and gold paywall, deep green / brown / red result washes, lime buttons).

States:
- `sheet` Sheet paywall (Try it): `<HomeScreen tier="free" paywallSheet="sheet" />`
  ```kotlin
  EqualTheme {
      // Try it: Support → Help Center, tap outside → exit offer, Claim → EQUAL25 applied
      HomeScreenSample(tier = PlanTier.Free, paywallSheetStage = PaywallSheetStage.Sheet)
  }
  ```
- `help` Help Center sheet: `<HomeScreen tier="free" paywallSheet="help" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, paywallSheetStage = PaywallSheetStage.Help)
  }
  ```
- `exit` Leave Without Unlocking?: `<HomeScreen tier="free" paywallSheet="exit" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, paywallSheetStage = PaywallSheetStage.Exit)
  }
  ```
- `offer` Declined: offer strip: `<HomeScreen tier="free" offerStrip promo="meet-assistant-carousel" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, offerStrip = true, promo = { MeetAssistantCarousel() })
  }
  ```
- `claimed` Claimed: EQUAL25 applied: `<HomeScreen tier="free" paywallSheet="claimed" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, paywallSheetStage = PaywallSheetStage.Claimed)
  }
  ```
- `chat-sheet` From a chat: sheet: `<ChatScreen chat={sampleChats[1]} lock="details" summaryActions paywallSheet="sheet" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(lock = ChatLock.Details, summaryActions = true, paywallSheetStage = PaywallSheetStage.Sheet)
  }
  ```
- `chat-exit` From a chat: Leave / Keep 25% Off: `<ChatScreen chat={sampleChats[1]} lock="details" summaryActions paywallSheet="exit" />`
  ```kotlin
  EqualTheme {
      // In a chat the exit offer reads Leave / Keep 25% Off
      ChatScreenSample(lock = ChatLock.Details, summaryActions = true, paywallSheetStage = PaywallSheetStage.Exit)
  }
  ```
- `success` Congratulations: `<PaymentResultScreen status="success" />`
  ```kotlin
  EqualTheme {
      PaymentResultScreen(status = PaymentResultStatus.Success)
  }
  ```
- `pending` Payment Pending (Try it: Refresh): `<PaymentResultScreen status="pending" />`
  ```kotlin
  EqualTheme {
      // Try it: Refresh Status → Congratulations
      PaymentResultScreen(status = PaymentResultStatus.Pending)
  }
  ```
- `failed` Payment Failed (Try it: Retry): `<PaymentResultScreen status="failed" />`
  ```kotlin
  EqualTheme {
      // Try it: Retry payment → Payment Pending
      PaymentResultScreen(status = PaymentResultStatus.Failed)
  }
  ```
- `pending-support` Pending: Contact Support: `<PaymentResultScreen status="pending" pendingAction="support" />`
  ```kotlin
  EqualTheme {
      PaymentResultScreen(status = PaymentResultStatus.Pending, pendingAction = PendingAction.Support)
  }
  ```
- `processing-chat` Closed pending: chat strip: `<ChatScreen chat={sampleChats[1]} lock="details" summaryActions paymentProcessing />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(lock = ChatLock.Details, summaryActions = true, paymentProcessing = true)
  }
  ```
- `processing-paywall` Closed pending: paywall locked: `<PaywallScreen touchpoint="recordings-actions" processing />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.RecordingsActions, processing = true)
  }
  ```
- `processing-home` Closed pending: home card: `<HomeScreen paymentProcessing promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(paymentProcessing = true, promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) })
  }
  ```

### Call Handling (`/flows/call-handling`)

You → Your assistant → Call Handling: which calls the assistant answers and who always rings you. New users are invited into it from home: two questions, one minute. The wording is an experiment, so the question screen takes a copy prop.

Source: Known Calls (new users)

1. Where it lives: You → Your assistant → Call Handling (“Choose which calls I answer”). New users see the “Talk With Your Assistant” home, then the dark Set up your calls takeover: “Two questions. One minute.”
2. Question 1: “Which calls should I answer? You decide. I follow.” Two radio cards: All calls, except a few and Only unknown numbers. The copy experiment (copy="whose") asks “Whose calls should I answer?”, tags All calls as ⭐ Suggested, and says what each option means for your contacts.
3. All calls: needs the contacts permission (sheet: “I need your contact list to know who is calling.”) and offers call history so frequent callers sort first. Then Anyone you want to answer yourself?: search, suggested people, all contacts with checkboxes and an A–Z index; the button counts the picks. Ends on Perfect! naming who will always ring you.
4. Only unknown numbers: ends on All Sorted! (“Your contacts will ring you, like always.”). Without the permission, All calls is dimmed and a blue note offers Give contacts permission ›.
5. Later: if the user stops halfway, home shows Finish your setup? with Finish or Skip, answer everyone. Always ring me edits the list; with no saved contacts, Direct Calls explains why it’s empty. The hero art on the contact screens is also a Lottie (call-handling-contacts).

States:
- `home-new` Home, new user: `<CallHandlingScreen />`
  ```kotlin
  EqualTheme {
      // No chats yet: the search field hides and the hero promo fills the home
      HomeScreenSample(
          chats = emptyList(),
          promo = { MeetAssistantHero() },
          assistantDescription = "Equal is managing your calls!",
      )
  }
  ```
- `exclude` Exclude contacts: `<CallHandlingScreen step="exclude" picked={[]} />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(step = CallHandlingStep.Exclude, picked = emptyList())
  }
  ```
- `exclude-picked` Exclude contacts: 2 picked: `<CallHandlingScreen step="exclude" />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(step = CallHandlingStep.Exclude)
  }
  ```
- `perfect` Perfect!: `<CallHandlingScreen step="perfect" />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(step = CallHandlingStep.Perfect)
  }
  ```
- `unknown` Only unknown numbers: `<CallHandlingScreen mode="unknown" />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(mode = CallMode.Unknown)
  }
  ```
- `whose` Copy experiment: whose calls: `<CallHandlingScreen copy="whose" mode="unknown" />`
  ```kotlin
  EqualTheme {
      // Copy experiment
      CallHandlingScreen(copy = CallHandlingCopy.Whose, mode = CallMode.Unknown)
  }
  ```
- `sorted` All Sorted!: `<CallHandlingScreen step="sorted" mode="unknown" />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(step = CallHandlingStep.Sorted, mode = CallMode.Unknown)
  }
  ```
- `no-permission` No contacts permission: `<CallHandlingScreen copy="whose" mode="unknown" contactsAllowed={false} />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(copy = CallHandlingCopy.Whose, mode = CallMode.Unknown, contactsAllowed = false)
  }
  ```
- `perm-contacts` Allow contacts: `<CallHandlingScreen copy="whose" step="perm-contacts" contactsAllowed={false} />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(copy = CallHandlingCopy.Whose, step = CallHandlingStep.PermContacts, contactsAllowed = false)
  }
  ```
- `perm-history` Allow call history: `<CallHandlingScreen copy="whose" step="perm-history" />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(copy = CallHandlingCopy.Whose, step = CallHandlingStep.PermHistory)
  }
  ```
- `finish` Finish your setup?: `<AlwaysRingScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(
          chats = emptyList(),
          promo = { MeetAssistantHero() },
          assistantDescription = "Equal is managing your calls!",
          callSetup = CallSetupOverlay.Finish,
          onCallSetup = { /* open CallHandlingScreen(step = CallHandlingStep.Exclude) */ },
          onSkipCallSetup = { /* answer everyone */ },
      )
  }
  ```
- `no-contacts` Direct Calls: no contacts: `<DirectCallsEmptyScreen onBack={goBack} onDone={goBack} />`
  ```kotlin
  EqualTheme {
      DirectCallsEmptyScreen(onBack = { /* pop */ }, onDone = { /* pop */ })
  }
  ```
- `you` You: Call Handling row: `<YouScreen onOpen={(page) => page === "call-handling" && open("call-handling")} />`
  ```kotlin
  EqualTheme {
      YouScreenSample(onOpenCallHandling = { /* open CallHandlingScreen() */ })
  }
  ```

### Known-call notifications (`/flows/known-calls`)

When the assistant answers someone you know, Android shows an ongoing notification that tells you who it is and what they want, with quick replies, and hands the call to you when it needs you. Opening it shows the live chat.

Source: Known-call notifications

1. Answering: “Equal AI • Ongoing” with a live timer; the caller (their avatar) and “Your Equal AI is answering your call.”, with the Equal app badge.
2. Summary: the line updates to what the caller wants as the call goes on.
3. Expanded: two lines, a call button to pick up, and quick replies: Takeover first, then suggested answers the assistant can say for you.
4. Hand-off: when it needs you, the replies give way to “This needs your attention, connecting this call to you”.
5. Open: the chat shows the call live under a black Ongoing call - 02:34 strip with Takeover in the header and the assistant’s follow-up below. Android draws the notification shell; the system wallpaper here is a coded stand-in.

States:
- `answering` Answering: `<CallNotification name="Mom" state="answering" />`
  ```kotlin
  EqualTheme {
      CallNotification(name = "Mom", state = CallNotificationState.Answering)
  }
  ```
- `summary` What they want: `<CallNotification name="Mom" state="summary" summary={liveSummary} />`
  ```kotlin
  EqualTheme {
      CallNotification(name = "Mom", state = CallNotificationState.Summary, summary = SampleCallSummary)
  }
  ```
- `expanded` Expanded: quick replies: `<CallNotification name="Mom" state="expanded" replies={["Takeover", "I’ll bring them all", "I’ll call back to get more"]} onReply={reply} onAnswer={answer} />`
  ```kotlin
  EqualTheme {
      CallNotification(
          name = "Mom",
          state = CallNotificationState.Expanded,
          replies = listOf("Takeover", "I’ll bring them all", "I’ll call back to get more"),
          onReply = { /* say it (it == "Takeover": pick up) */ },
          onAnswer = { /* pick up */ },
      )
  }
  ```
- `connecting` Needs you: connecting: `<CallNotification name="Mom" state="connecting" />`
  ```kotlin
  EqualTheme {
      // Docs: on the coded wallpaper. On device the system draws the shade.
      KnownCallNotificationScreen(state = CallNotificationState.Connecting)
  }
  ```
- `chat` Live chat: `<ChatScreen chat={mom} live ongoing="02:34" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(
          name = "Mom",
          category = EqualCategory.HomeServices,
          live = true,
          ongoing = "02:34",
          onTakeover = { /* pick up */ },
      )
  }
  ```

### Search (`/flows/search`)

Search from home: names, numbers, categories and keywords across calls. Results arrive in two passes, chats first and messages after, so something useful shows while the slower search finishes.

Source: Search

1. Open: tapping “Search for names” on home opens search with the keyboard up. The bar is a green-outlined pill with back inside it.
2. Before typing: recent searches show as avatar tiles with Clear all. With none, the robot and “Search across your calls · Look for names, phone numbers, categories, keywords”.
3. Typing: green dots under CHATS, then matching chats (with their action chips). Messages load next under MESSAGES, each hit showing who, when, and the line with the match in bold.
4. Nothing found: the thinking robot, “No results found”, and a nudge to try another name, number, category or keyword.
5. Offline: the struck-through wifi, “No internet connection”. The same art works anywhere the network is needed.

States:
- `empty` Empty: `<SearchScreen keyboard state="empty" />`
  ```kotlin
  EqualTheme {
      // keyboard = true draws the system keyboard stand-in (docs only)
      SearchScreen(state = SearchState.Empty, keyboard = true)
  }
  ```
- `offline` No internet: `<SearchScreen keyboard state="offline" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.Offline, keyboard = true)
  }
  ```
- `recent` Recent searches (Try it: type): `<SearchScreen keyboard />`
  ```kotlin
  EqualTheme {
      // Live: type to run loading → chats → messages
      SearchScreen(keyboard = true)
  }
  ```
- `no-results` No results: `<SearchScreen keyboard state="no-results" query="Xyz" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.NoResults, query = "Xyz", keyboard = true)
  }
  ```
- `loading` Loading: `<SearchScreen keyboard state="loading" query="S" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.Loading, query = "S", keyboard = true)
  }
  ```
- `results` Results: chats: `<SearchScreen keyboard state="results" query="S" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.Results, query = "S", keyboard = true)
  }
  ```
- `messages-loading` Results: messages loading: `<SearchScreen keyboard state="messages-loading" query="S" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.MessagesLoading, query = "S", keyboard = true)
  }
  ```
- `messages` Results: messages included: `<SearchScreen keyboard state="messages" query="Sa" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.Messages, query = "Sa", keyboard = true)
  }
  ```

### Call Back (`/flows/call-back`)

The AI layer calls someone back for you: it suggests what to ask, hands off to the phone’s dialer, and leaves an Outgoing call card in the chat.

Source: Call Back

1. Prompt: “Want me to give a quick call back to the clinic?” with 📞 Call Back, 🗓️ Add to Calendar and 🔔 Set reminder chips.
2. Task sheet: “Calling Dr. Mehta’s Clinic” (stops below the chat header). The assistant lists what to ask (reports, location, charges, insurance) with 📞 Call Back.
3. Hand-off: the phone’s own dialer places the call; the system draws it, so the docs show a coded stand-in.
4. Result: an Outgoing call card (“You called back Dr. Mehta’s Clinic · Bring previous medical reports”) with 📞 Call back.
5. From a missed call: when the assistant couldn’t pick up, the thread shows a missed-call card instead of a summary. With a reason: the caller’s art with a missed badge, “LIKELY CALLS FOR …” and 👍/👎. With only a name: “Valluri Called”. With nothing: “Missed by the assistant”. Its Call back opens the same task.

States:
- `live` Chat (Try it: tap Call Back): `<ChatActionScreen action="call-back" />`
  ```kotlin
  EqualTheme {
      // Runs live from the chat: tap the chip, then follow the task sheet
      ChatActionScreen(action = ChatAction.CallBack, onBack = { /* pop */ })
  }
  ```
- `ask` Calling: what to ask: `<ChatActionScreen action="call-back" step="ask" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.CallBack, step = "ask", onBack = { /* pop */ })
  }
  ```
- `dialer` Dialer (system, stand-in): `<ChatActionScreen action="call-back" step="dialer" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.CallBack, step = "dialer", onBack = { /* pop */ })
  }
  ```
- `done` Back in the chat: `<ChatActionScreen action="call-back" step="done" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.CallBack, step = "done", onBack = { /* pop */ })
  }
  ```
- `missed-reason` Missed call: with reason (Try it): `<ChatActionScreen action="call-back" missed="reason" />`
  ```kotlin
  EqualTheme {
      // The card's Call back opens the ask step
      ChatActionScreen(action = ChatAction.CallBack, missed = MissedCase.Reason, onBack = { /* pop */ })
  }
  ```
- `missed-name` Missed call: name only: `<ChatActionScreen action="call-back" missed="name" />`
  ```kotlin
  EqualTheme {
      // The card's Call back opens the ask step
      ChatActionScreen(action = ChatAction.CallBack, missed = MissedCase.Name, onBack = { /* pop */ })
  }
  ```
- `missed-unknown` Missed call: caller unknown: `<ChatActionScreen action="call-back" missed="unknown" />`
  ```kotlin
  EqualTheme {
      // The card's Call back opens the ask step
      ChatActionScreen(action = ChatAction.CallBack, missed = MissedCase.Unknown, onBack = { /* pop */ })
  }
  ```

### Mute (`/flows/mute`)

Muting a caller from the chat: the assistant double-checks, because muting means missing their calls even when they matter.

Source: Mute

1. Ask: 🔕 Mute from the AI layer opens “Muting Amit Nanda”.
2. Confirm: “Are you sure? You’ll not get any call from them even if it’s important” with 🔕 Mute.
3. Result: “This caller has been muted” and a card “+91-81720 33604 muted · Calls from this caller will be muted” with 📋 Open muted caller list.

States:
- `live` Chat (Try it: tap Mute): `<ChatActionScreen action="mute" />`
  ```kotlin
  EqualTheme {
      // Runs live from the chat: tap the chip, then follow the task sheet
      ChatActionScreen(action = ChatAction.Mute, onBack = { /* pop */ })
  }
  ```
- `confirm` Are you sure?: `<ChatActionScreen action="mute" step="confirm" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.Mute, step = "confirm", onBack = { /* pop */ })
  }
  ```
- `done` Muted: `<ChatActionScreen action="mute" step="done" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.Mute, step = "done", onBack = { /* pop */ })
  }
  ```

### Reply on WhatsApp (`/flows/reply-whatsapp`)

The assistant drafts a WhatsApp reply from the call. The user sends it as is or edits it in place, WhatsApp opens with the message entered, and the chat keeps a record.

Source: Reply On WhatsApp

1. Draft: “Replying Amit on WhatsApp”: You “Reply on whatsapp”, then the draft with ✏️ Edit / 📤 Send.
2. Edit: “Edit Message” dims the chat and floats the draft above the keyboard. The bubble grows with the text (about 11 lines, then scrolls); the green check saves.
3. Send: “send as is” → Opening WhatsApp…, chips grey out; WhatsApp opens with the message entered.
4. Confirmation: “Wrote a draft for Amit” and a WhatsApp card with the message and 👀 View message.

States:
- `live` Chat (Try it): `<ChatActionScreen action="reply-whatsapp" />`
  ```kotlin
  EqualTheme {
      // Runs live from the chat: tap the chip, then follow the task sheet
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, onBack = { /* pop */ })
  }
  ```
- `draft` Draft: `<ChatActionScreen action="reply-whatsapp" step="draft" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, step = "draft", onBack = { /* pop */ })
  }
  ```
- `sending` Opening WhatsApp: `<ChatActionScreen action="reply-whatsapp" step="sending" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, step = "sending", onBack = { /* pop */ })
  }
  ```
- `edit` Edit message: `<ChatActionScreen action="reply-whatsapp" step="edit" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, step = "edit", onBack = { /* pop */ })
  }
  ```
- `edit-long` Edit: long message: `<ChatActionScreen action="reply-whatsapp" step="edit-long" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, step = "edit-long", onBack = { /* pop */ })
  }
  ```
- `done` Confirmation: `<ChatActionScreen action="reply-whatsapp" step="done" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, step = "done", onBack = { /* pop */ })
  }
  ```

### Save Contact (`/flows/save-contact`)

Saving an unknown caller as a contact from the chat, including editing the details, the contact form, and every path through the contacts permission.

Source: Save Contact

1. Prompt: “This number isn’t saved. Add Rahul to your contacts?” with 👤 Save contact.
2. Review: “Saving contact”: the pre-filled card (Rahul (Electrician), number) with ✏️ Edit / 💾 Save and “Looks right? Tap Save to add them.”
3. Edit: by voice (“What should I change?”, Hold to speak) or in the contact form. Two forms are on the table: iOS-revamp parity (grouped rows) and exact WhatsApp parity (outlined fields, Sync contact to phone).
4. No permission: a centred dialog “Allow contacts permission · Open Settings”. Back from Settings, the chat offers ▶️ Continue saving. If granted, the pre-filled card returns with ✏️ Edit / 👍 Confirm; if not, a “Contact Permission Required” card with ⚙️ Open Settings.
5. Saved: “Saved! Rahul is in your contacts now.” with 👤 View contact.

States:
- `live` Chat (Try it): `<ChatActionScreen action="save-contact" />`
  ```kotlin
  EqualTheme {
      // Runs live from the chat: tap the chip, then follow the task sheet
      ChatActionScreen(action = ChatAction.SaveContact, onBack = { /* pop */ })
  }
  ```
- `review` Review: Edit / Save: `<ChatActionScreen action="save-contact" step="review" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "review", onBack = { /* pop */ })
  }
  ```
- `saved` Saved: `<ChatActionScreen action="save-contact" step="saved" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "saved", onBack = { /* pop */ })
  }
  ```
- `edit-ask` Edit: what should I change?: `<ChatActionScreen action="save-contact" step="edit-ask" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "edit-ask", onBack = { /* pop */ })
  }
  ```
- `form` Contact form (iOS parity): `<ChatActionScreen action="save-contact" step="form" keyboard />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "form", keyboard = true, onBack = { /* pop */ })
  }
  ```
- `form-outlined` Contact form (WhatsApp parity): `<ChatActionScreen action="save-contact" step="form-outlined" keyboard />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "form-outlined", keyboard = true, onBack = { /* pop */ })
  }
  ```
- `no-permission` No permission: allow: `<ChatActionScreen action="save-contact" step="no-permission" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "no-permission", onBack = { /* pop */ })
  }
  ```
- `resume` Back from Settings: `<ChatActionScreen action="save-contact" step="resume" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "resume", onBack = { /* pop */ })
  }
  ```
- `granted` Permission granted: `<ChatActionScreen action="save-contact" step="granted" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "granted", onBack = { /* pop */ })
  }
  ```
- `denied` Still no permission: `<ChatActionScreen action="save-contact" step="denied" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "denied", onBack = { /* pop */ })
  }
  ```

### Error states (`/flows/error-states`)

How the AI layer fails: say what happened in one line and offer the one action that fixes it.

Source: Error states

1. Generation failure: “Sorry, I couldn’t do that just now. Please try again.” with 🔄 Retry, inside the task.
2. Offline in a task: “It looks like you’re offline. Try again once you’re back online.” with 🔄 Retry.
3. Voice input failure: the AI layer asks again: “Sorry, I didn’t catch that. Could you hold and speak again?”
4. Offline sheet: over the chat, the struck wifi, “No internet connection” and Refresh. Full screen: the same with Try again, when there is nothing to show yet.

States:
- `generation` Generation failure: `<ChatErrorScreen state="generation" onRetry={retry} />`
  ```kotlin
  EqualTheme {
      ChatErrorScreen(state = ErrorState.Generation, onRetry = { /* retry */ })
  }
  ```
- `offline-reply` No internet (in a task): `<ChatErrorScreen state="offline-reply" onRetry={retry} />`
  ```kotlin
  EqualTheme {
      ChatErrorScreen(state = ErrorState.OfflineReply, onRetry = { /* retry */ })
  }
  ```
- `voice` Voice input failure: `<ChatErrorScreen state="voice" />`
  ```kotlin
  EqualTheme {
      ChatErrorScreen(state = ErrorState.Voice)
  }
  ```
- `offline-sheet` No internet (sheet): `<ChatErrorScreen state="offline-sheet" onRetry={refresh} />`
  ```kotlin
  EqualTheme {
      ChatErrorScreen(state = ErrorState.OfflineSheet, onRetry = { /* refresh */ })
  }
  ```
- `offline-screen` No internet (full screen): `<ChatErrorScreen state="offline-screen" onRetry={retry} />`
  ```kotlin
  EqualTheme {
      ChatErrorScreen(state = ErrorState.OfflineScreen, onRetry = { /* retry */ })
  }
  ```

### Contact info (`/flows/contact-info`)

The caller’s page: category avatar, name and number, four action tiles and the call history.

Source: Contact Info

1. Header: a 96dp category avatar (or initials for saved contacts), the headline name and a tabular phone number.
2. Actions: Call, Mute (toggles to Unmute), Save and Share as 72dp tiles with the icon in text/action.
3. Call history: phone_callback, phone_missed (red icon, label not red) and phone_forwarded rows inside a card.

States:
- `contact` Contact Info: `<ContactInfoScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      ContactInfoScreen(name = "Amit Nanda", phone = "+91 9871746113", onBack = {})
  }
  ```

## Tokens

Alias colours (CSS `var(--eq-<name without component/>)`, TS `color.*`, Compose `EqualTheme.colors.*`):

- `bg/primary`  light {neutrals.grey14} · dark #141414
- `bg/surface`  light {brand.white} · dark {neutrals.grey02}
- `bg/nav-bottom`  light #F7F7F7 · dark {neutrals.grey02}
- `bg/overlay`  light #9F9F9F · dark #B5B5B5
- `text/primary`  light {neutrals.grey01} · dark {neutrals.grey14}
- `text/placeholder`  light {neutrals.grey10} · dark {neutrals.grey07}
- `text/secondary`  light {neutrals.grey05} · dark {neutrals.grey11}
- `text/action-disabled`  light {neutrals.grey12} · dark {neutrals.grey04}
- `text/action`  light {brand.green} · dark {brand.lime}
- `text/on-action`  light {brand.white} · dark {brand.black}
- `text/on-action-disabled`  light {neutrals.grey08} · dark {neutrals.grey08}
- `button/primary`  light {brand.green} · dark {brand.lime}
- `button/secondary`  light {brand.lime} · dark {brand.green}
- `button/danger`  light {red.red08} · dark {red.red12}
- `button/disabled`  light {neutrals.grey13} · dark {neutrals.grey04}
- `stroke/subtle`  light #E9E9E9 · dark #2E2E2E
- `stroke/medium`  light #E1E1E1 · dark #3A3A3A
- `stroke/dark`  light #A7A7A7 · dark #4A4A4A
- `action/stroke/unread`  light #9DDDB4 · dark #4B5A2A
- `action/fill/unread`  light #F0F6E5 · dark #2F3423
- `action/bottom-color`  light #EBEBEB · dark #191919
- `component/chat-bubble/user-bg`  light #E8FFED · dark #272C1E
- `component/chat-bubble/user-title`  light #006223 · dark {brand.lime}
- `component/action-card/highlight`  light #DCFFE4 · dark #2F3423
- `text/tertiary`  light #6E6E6E · dark {neutrals.grey09} · derived
- `text/danger`  light {red.red08} · dark {red.red12} · derived
- `text/on-danger`  light {brand.white} · dark {brand.black} · derived
- `text/on-dark`  light {brand.white} · dark {brand.white} · derived
- `text/on-dark-secondary`  light {neutrals.grey10} · dark {neutrals.grey10} · derived
- `text/accent-gold`  light #D9A928 · dark #E6B93C · derived
- `text/brand`  light {brand.green} · dark {brand.lime} · derived
- `component/chat-bubble/contact-title`  light #9A5B00 · dark #FFB74D · derived
- `component/chat-bubble/other-bg`  light {brand.white} · dark {neutrals.grey02} · derived
- `component/plan-card/bg`  light #2B2B2B · dark #2B2B2B · derived
- `component/plan-card/pill-stroke`  light #C9A55A · dark #C9A55A · derived
- `component/rating/star-filled`  light #FFC700 · dark #FFC700 · derived
- `component/rating/star-empty`  light #CFCFCF · dark {neutrals.grey04} · derived
- `component/nav/selected-bg`  light #F1FAF3 · dark #272C1E · derived
- `component/playback/pill-bg`  light {neutrals.grey05} · dark {neutrals.grey04} · derived
- `component/waveform/bar`  light #8A8A8A · dark #808080 · derived
- `component/waveform/bar-played`  light {neutrals.grey05} · dark {neutrals.grey11} · derived
- `component/notice/bg`  light #F6FDEB · dark #272C1E · derived
- `component/chip/when-bg`  light #F1F1F1 · dark {neutrals.grey03} · derived
- `component/sheet/bg`  light #F9F9F9 · dark #292929 · derived
- `component/scrim`  light rgba(0,0,0,0.20) · dark rgba(0,0,0,0.55) · derived
- `component/badge/new-feature-stroke`  light #E6E6E6 · dark #3A3A3A · derived
- `component/plan-card/pattern`  light #C9A55A · dark #C9A55A · derived
- `component/invite/bg`  light #F0FBF2 · dark #272C1E · derived
- `component/invite/stroke`  light #D5F0DB · dark #3D442E · derived
- `component/skeleton`  light #FFFFFF · dark #353A2A · derived
- `component/chip/do-bg`  light #EEF8EF · dark #272C1E · derived
- `component/chip/selected-bg`  light #333333 · dark #F7F7F7 · derived
- `component/chip/selected-text`  light #FFFFFF · dark #111111 · derived
- `component/preset/tint-red`  light #FDECEC · dark #3A2222 · derived
- `component/preset/tint-green`  light #E6F7EA · dark #272C1E · derived
- `component/preset/tint-orange`  light #FDF1DE · dark #3A3020 · derived
- `component/icon-button/bg`  light #F2F2F2 · dark #333333 · derived
- `component/chat/wallpaper-bg`  light #F2F2F2 · dark #141414 · derived
- `component/voice/player-bg`  light #F2F2F2 · dark #2E2E2E · derived
- `component/voice/player-bg-sent`  light #E1F7E6 · dark #333926 · derived
- `component/chat/wallpaper-pattern`  light rgba(115,115,115,0.08) · dark rgba(115,115,115,0.08)
- `component/status-card/pill-bg`  light #FFFFFF · dark #2E2E2E · derived
- `component/status-card/button`  light #FAAF39 · dark #F2A22C · derived
- `component/status-card/button-text`  light #3D2600 · dark #1A1A1A · derived
- `component/notification/bg`  light #FFFFFF · dark #2A2A2A · derived
- `component/brand/whatsapp`  light #25D366 · dark {brand.lime} · derived
- `text/gold`  light #8C5817 · dark #E8BD62 · derived
- `component/paywall/card-bg`  light #FFFDF7 · dark #221F19 · derived
- `component/paywall/card-stroke`  light #EFE2C6 · dark #3A3326 · derived
- `component/paywall/divider`  light #E9D9B5 · dark #4A4233 · derived
- `component/plan-banner/bg`  light #FFF0CC · dark #33291A · derived
- `component/plan-banner/text`  light #82500F · dark #F0C878 · derived
- `component/locked/badge-bg`  light #FFF6DE · dark #3A3020 · derived
- `component/expiry-banner/warning-bg`  light #FFEFD3 · dark #33291A · derived
- `component/expiry-banner/warning-text`  light #7A4300 · dark #F0C878 · derived
- `component/expiry-banner/danger-bg`  light #FDE4E4 · dark #3A2224 · derived
- `component/expiry-banner/danger-text`  light #7D0F0F · dark #FFA3A3 · derived
- `component/whats-new/bg`  light #EAFBE6 · dark #272C1E · derived
- `component/whats-new/glow`  light #C9F7A0 · dark #4F5E2F · derived
- `component/missed-call/bg`  light #FFF9F7 · dark #2A2120 · derived
- `component/missed-call/stroke`  light #F5EDEA · dark #3A2E2C · derived
- `component/missed-call/icon-bg`  light #FBE9E5 · dark #45302C · derived
- `component/missed-call/icon`  light #D4380D · dark #FF8A6B · derived
- `component/expiry-chip/warning-bg`  light #FFF0C9 · dark #FFB64A · derived
- `component/expiry-chip/warning-text`  light #7A4A00 · dark #2A1A00 · derived
- `component/expiry-chip/danger-bg`  light #FFE1E1 · dark #5A2328 · derived
- `component/expiry-chip/danger-text`  light #B3141B · dark #FFB3B3 · derived
- `component/expiry-chip/active-bg`  light #FFF0C9 · dark #3A3020 · derived
- `component/value-card/stroke`  light #F0E1BD · dark #4A3C1C · derived
- `component/value-card/perks-bg`  light #FFFFFF · dark #1F1B14 · derived
- `component/value-card/ring`  light rgba(214,165,70,0.22) · dark rgba(232,189,98,0.35) · derived
- `component/plan-card/expired-pill`  light #D0302F · dark #D0302F · derived
- `component/sunburst/ray`  light rgba(255,255,255,0.6) · dark rgba(232,189,98,0.12) · derived
- `component/premium-icon/start`  light #D1A85C · dark #E2BE77 · derived
- `component/premium-icon/end`  light #A0621F · dark #B97C3A · derived
- `component/contact-avatar/blue-bg`  light #D5EFFC · dark #233843 · derived
- `component/contact-avatar/blue-text`  light #296D8E · dark #7DC4E8 · derived
- `component/contact-avatar/green-bg`  light #D5FCE2 · dark #394323 · derived
- `component/contact-avatar/green-text`  light #247B41 · dark {brand.lime} · derived
- `component/contact-avatar/purple-bg`  light #E5D5FC · dark #302343 · derived
- `component/contact-avatar/purple-text`  light #5D2E9E · dark #AA7DE8 · derived
- `component/contact-avatar/orange-bg`  light #FCE8D5 · dark #433323 · derived
- `component/contact-avatar/orange-text`  light #8E5C29 · dark #E8B27D · derived
- `component/contact-avatar/pink-bg`  light #FCD5E5 · dark #432330 · derived
- `component/contact-avatar/pink-text`  light #9E2E5D · dark #E87DAA · derived
- `component/contact-avatar/teal-bg`  light #D5FCF8 · dark #234341 · derived
- `component/contact-avatar/teal-text`  light #227770 · dark #7DE8DF · derived
- `component/contact-avatar/badge-bg`  light #FFFFFF · dark #222222 · derived
- `component/contact-avatar/badge-icon`  light #141414 · dark #F2F2F2 · derived
- `component/processing/bg`  light #FFEFCF · dark #3A2C1A · derived
- `component/processing/ring`  light #8C5817 · dark #E8BD62 · derived
- `component/plan-badge/expired-bg`  light #D0302F · dark #D0302F · derived
- `component/offer-strip/bg`  light #FFF3D6 · dark #33291A · derived
- `component/offer-strip/text`  light #5C3A0A · dark #F0C878 · derived
- `component/result/ring`  light rgba(255,255,255,0.55) · dark rgba(255,255,255,0.07) · derived
- `component/profile-hero/status-bg`  light {brand.white} · dark #F8E4A2 · derived
- `component/profile-hero/status-text`  light {neutrals.grey01} · dark {neutrals.grey01} · derived
- `component/info-note/bg`  light #E9F1FA · dark #1C2633 · derived
- `component/info-note/text`  light #1A1A1A · dark #E3ECF6 · derived
- `component/choice/selected-bg`  light #F3FAEA · dark #272C1E · derived
- `component/ongoing-bar/bg`  light #262626 · dark #1A1A1A · derived
- `component/ongoing-bar/text`  light #BAFF29 · dark #BAFF29 · derived
- `component/initials-disc/bg`  light #FFFFFF · dark #262626 · derived
- `component/paywall/hero-top`  light #FCE290 · dark #4A3C1C · derived

Gradients (CSS `var(--eq-gradient-<name>)`, Compose `EqualTheme.gradients.*`):

- `gradient/fab`  light 180deg: #86E63B 0%, #00B140 100% · dark 180deg: #C9FF5C 0%, #BAFF29 100%
- `gradient/send-disabled`  light 180deg: #E4F6E5 0%, #C8EAD3 100% · dark 180deg: #353A2A 0%, #272C1E 100%
- `gradient/assistant-toggle`  light 90deg: #D3F4DA 0%, #F7FDEB 55%, #DBF5DF 100% · dark 90deg: #272C1E 0%, #2F3423 55%, #272C1E 100%
- `gradient/gold`  light 90deg: #D8A857 0%, #A2702C 100% · dark 90deg: #D8A857 0%, #A2702C 100%
- `gradient/whats-new`  light 120deg: #E6FEE8 0%, #EEFFE8 55%, #F4FFE9 100% · dark 135deg: #272C1E 0%, #2F3423 100%
- `gradient/chip-large`  light 180deg: #F3F9E8 0%, #EEFAD8 100% · dark 180deg: #2F3423 0%, #272C1E 100%
- `gradient/chip-small-unread`  light 180deg: #F7FBEF 0%, #EAF7D6 100% · dark 180deg: #2F3423 0%, #272C1E 100%
- `gradient/chip-small-read`  light 180deg: #FFFFFF 0%, #F2F2F2 100% · dark 180deg: #333333 0%, #2A2A2A 100%
- `gradient/takeover`  light 180deg: #FFFFFF 0%, #EAF8EE 100% · dark 180deg: #2F3423 0%, #272C1E 100%
- `gradient/profile-hero`  light 180deg: #F8E4A2 0%, #FAEDC4 45%, #F7F7F7 100% · dark 180deg: #F8E4A2 0%, #FAEDC4 55%, #FDF8EC 100%
- `gradient/ai-summary`  light 135deg: #FFFFFF 0%, #F6FDEB 40%, #FFFFFF 70%, #E6F7EA 100% · dark 135deg: #222222 0%, #2F3423 45%, #222222 75%, #272C1E 100%
- `gradient/gender-selected`  light 135deg: #F4FBEC 0%, #EAF7DE 100% · dark 135deg: #2B3021 0%, #252A1C 100%
- `gradient/suggestion-card`  light 120deg: #FFFFFF 0%, #F2FBEA 60%, #E9F8EC 100% · dark 120deg: #242424 0%, #2F3423 100%
- `gradient/status-card`  light 120deg: #FEEBC8 0%, #FDF2DB 45%, #FBF9F4 100% · dark 120deg: #3A2E1A 0%, #2A2622 60%, #242424 100%
- `gradient/meet-assistant`  light 120deg: #E6F7EB 0%, #EDF9F1 55%, #F3FCEF 100% · dark 120deg: #272C1E 0%, #2F3423 100%
- `gradient/call-me`  light 90deg: #55CC6D 0%, #00B140 60% · dark 90deg: #C9FF5C 0%, #BAFF29 60%
- `gradient/when-chip`  light 90deg: #EEEAFF 0%, rgba(238,234,255,0) 100% · dark 90deg: #2B2740 0%, rgba(43,39,64,0) 100%
- `gradient/do-chip`  light 90deg: #E2F8EA 0%, rgba(226,248,234,0) 100% · dark 90deg: #2C331E 0%, rgba(44,51,30,0) 100%
- `gradient/paywall-hero`  light 180deg: #FCE290 0%, #FAEFCF 38%, #FFFFFF 62% · dark 180deg: #4A3C1C 0%, #2A241A 38%, #141414 62%
- `gradient/gold-text`  light 180deg: #B57E32 0%, #7C4C10 100% · dark 180deg: #F6D48A 0%, #D9A44A 100%
- `gradient/cta-gold`  light 90deg: #8A5516 0%, #9E6A27 55%, #B88A45 100% · dark 90deg: #8A5516 0%, #9E6A27 55%, #B88A45 100%
- `gradient/coupon`  light 135deg: #FFFCF5 0%, #FFF4DE 100% · dark 135deg: #2A251C 0%, #221F19 100%
- `gradient/status-neutral`  light 180deg: #E6E6E6 0%, #F7F7F7 45%, #FFFFFF 100% · dark 180deg: #3A3A3A 0%, #262626 60%, #222222 100%
- `gradient/status-success`  light 180deg: #B8F2C5 0%, #EEFCF1 55%, #FFFFFF 100% · dark 180deg: #313A1E 0%, #2B3020 55%, #222222 100%
- `gradient/status-warning`  light 180deg: #FFD6AD 0%, #FFF2E5 55%, #FFFFFF 100% · dark 180deg: #43301C 0%, #2E2620 55%, #222222 100%
- `gradient/status-danger`  light 180deg: #FFC4CB 0%, #FFEEF0 55%, #FFFFFF 100% · dark 180deg: #46232A 0%, #2E2224 55%, #222222 100%
- `gradient/status-gold`  light 180deg: #FCE290 0%, #FFF7DF 55%, #FFFFFF 100% · dark 180deg: #4A3C1C 0%, #2A241A 55%, #222222 100%
- `gradient/value-card`  light 180deg: #FCE7A8 0%, #FFF6DC 42%, #FFFFFF 100% · dark 180deg: #4A3410 0%, #1E170C 48%, #0E0E0E 100%
- `gradient/voice-note`  light 90deg: #00B140 0%, #7FD93A 100% · dark 90deg: #C9FF5C 0%, #BAFF29 100%
- `gradient/choice-stroke`  light 90deg: #00B140 0%, #A6E36A 100% · dark 90deg: #C9FF5C 0%, #BAFF29 100%
- `gradient/setup-done`  light 180deg: #E5F5F4 0%, #F3F8EC 50%, #EAF6CC 100% · dark 180deg: #13201F 0%, #161D17 50%, #222814 100%
- `gradient/setup-prompt`  light 180deg: rgba(0,0,0,0.35) 0%, rgba(0,0,0,0.7) 55%, #000000 100% · dark 180deg: rgba(0,0,0,0.5) 0%, rgba(0,0,0,0.8) 55%, #000000 100%
- `gradient/result-success`  light 180deg: #A8F5B4 0%, #DDFBE2 45%, #FFFFFF 78% · dark 180deg: #2C3A0E 0%, #1C240B 45%, #0A0A0A 78%
- `gradient/result-pending`  light 180deg: #FFB98A 0%, #FFE3CF 45%, #FFFFFF 78% · dark 180deg: #3A2410 0%, #22160C 45%, #0A0A0A 78%
- `gradient/result-failed`  light 180deg: #FFC9CD 0%, #FFE9EB 45%, #FFFFFF 78% · dark 180deg: #4A0E10 0%, #2A0A0B 45%, #0A0A0A 78%
- `gradient/offline-screen`  light 180deg: #FFFFFF 0%, #F7FBF5 55%, #E6F6E4 100% · dark 180deg: #141414 0%, #151A15 55%, #212618 100%

Typography (DM Sans; `<Text variant>`, `.eq-t-<name>`, `EqualTheme.type.<name>`):

- `headline`  24/32 weight 500
- `title`  20/28 weight 500
- `subheading`  16/24 weight 500
- `bodyLarge`  16/24 weight 400
- `body2`  14/22 weight 500
- `body1`  14/22 weight 400
- `body1Italic`  14/22 weight 400
- `button`  14/20 weight 500
- `buttonSmall`  12/16 weight 500
- `caption`  12/16 weight 500
- `captionWrap`  12/18 weight 400
- `micro`  12/16 weight 500
- `overline`  11/16 weight 500
- `badge`  10/12 weight 500
- `badgeCount`  10/12 weight 500

Spacing: 0 · 2 · 4 · 6 · 8 · 10 · 12 · 16 · 20 · 24 · 32 · 40 · 48

Radius: xs 4 · sm 8 · md 12 · lg 16 · xl 20 · 2xl 24 · 3xl 32 · full 999

Size: touchTarget 48 · statusBar 52 · appBar 64 · icon {"xs":16,"sm":20,"md":24} · avatar {"xs":24,"sm":28,"md":36,"lg":48} · frame {"width":390,"height":800}

## Image assets

Web `<Asset name="…" size={dp} />`, Compose `EqualAssetImage(EqualAssets.<PascalName>, size)`. "needed" means only a placeholder ships today; ask the designer for it.

- `mascot-robot`: Robot mascot — AI Assistant card on Chats (40dp, via <Mascot>)
- `avatar-male`: Profile avatar (male): You tab header + bottom-nav "You"
- `avatar-female`: Profile avatar (female): You tab header + bottom-nav "You"
- `illustration-high-five`: Invite a Friend card: 113 × 112, flush left, 29dp above the card (tilt baked into the file)
- `illustration-trash`: Delete confirm sheet (72dp)
- `logo-orb-light`: Equal orb, light mode (#00B140): AI avatar, FAB
- `logo-orb-dark`: Equal orb, dark mode (lime): AI avatar, FAB
- `illustration-silent-mode`: Silent Mode header (3D bell + phone, 160dp)
- `illustration-whatsapp`: WhatsApp Updates header + turn-off sheet (3D WhatsApp phone, 160 / 120dp)
- `illustration-addresses-empty`: Addresses empty state (robot on a map, 200dp)
- `illustration-instructions-empty`: Active Instructions empty state (robot on a book, 200dp)
- `illustration-suggestions`: "New suggestions coming…" card (robot with call bubbles, 120dp)
- `avatar-male-bust`: Gender card, male (bust without the ring). Falls back to avatar-male
- `avatar-female-bust`: Gender card, female (bust without the ring). Falls back to avatar-female
- `mascot-sleeping`: System status card: sleeping robot with its warm glow (104dp)
- `avatar-assistant`: Meet Your Assistant card: the assistant persona with the orb badge (84 × 94 compact, 96 × 108 banner)
- `crown-gold`: Monetization: 3D gold crown (supplied still; animated in code by AnimatedCrown until the rotating video is exported), paywall hero (64dp), Unlock All Details (56dp), Congratulations (100dp)
- `premium-glow`: Premium glow: the cream-gold radial with soft light rings behind premium cards (value sheet, quota card). Light theme; dark uses the coded black-gold gradient
- `assistant-phone`: Experiment (Component 25): 3D phone with sparkles on the AI Assistant toggle instead of the robot (36dp). The robot stays the default
- `illustration-search`: Search empty state: the robot with a magnifier and sparkles; "Search across your calls" (200dp)
- `illustration-no-internet`: No-internet state: 3D wifi with a red strike; "No internet connection" (140dp). Reusable on any screen that needs the network
- `illustration-no-results`: No-results state: the robot thinking with a question mark; "No results found" (160dp)
- `system-keyboard`: Stand-in for the Android keyboard (Gboard) in docs and previews only; never ship it in the app (390 × 300)
- `call-handling-all`: Call Handling: you with Mom (favourite) and an Unknown caller; "Which calls should I answer?" hero (280dp)
- `call-handling-exclude`: Call Handling: you with Mom and Didi (favourites); "Anyone you want to answer yourself?" hero (280dp). Animated version: lottie call-handling-contacts
- `call-handling-done`: Call Handling: the robot on a call between Mom and Unknown; Perfect! / All Sorted! (300dp)
- `call-setup`: Call Handling: the robot between a ringing call and an unknown call; "Set up your calls" (240dp)
- `permission-contacts`: Permission sheet: 3D orange contact book; "Allow contacts permission" (100dp)
- `permission-call-history`: Permission sheet: the robot with a call-history phone; "Allow call history" (100dp)
- `illustration-no-contacts`: Empty state: 3D address book; "No contacts saved" (140dp)
- `value-card-pattern`: Plan page value card: gold circuit-line pattern across the top (SVG, 329 × 192)
- `feature-call-screening`: Plan page What You Get: 3D gold phone with sparkle, 24/7 Unlimited Call Screening (28dp)
- `feature-recordings`: Plan page What You Get: 3D gold phone with sound bars, Unlimited Recordings (28dp)
- `feature-summaries`: Plan page What You Get: 3D gold summary card with phone, Unlimited Summaries (28dp)
- `crown-lock`: Monetization: Premium Lock (SVG), the gold crown with a padlock on locked rows, bubbles and the audio scrubber (16–20dp)
- `coupon-seal`: 3D gold % seal; Monetization: gold % seal on the coupon ticket (28dp)
- `status-waiting`: Monetization: 3D rupee coin, Waiting for Confirmation (100dp)
- `status-waiting-cash`: Monetization: 3D cash stack, Waiting for Confirmation variant (100dp)
- `status-confirmed`: Monetization: green check seal, Payment Confirmed (100dp)
- `status-pending`: Monetization: orange ! seal, Payment Pending (100dp)
- `status-failed`: Monetization: red ✕ seal, Payment Failed (100dp)
- `emoji-sad`: Monetization: 3D sad face, cancellation feedback / Are you sure (100dp)
- `thumbs-up`: Monetization: 3D thumbs up, Your Request is Submitted (100dp)
- `star-gold`: Monetization: 3D star in the “Rated 4.5/5” pill (20dp)
- `avatar-testimonial-1`: Subscription page: testimonial avatar (36dp)
- `avatar-testimonial-2`: Subscription page: testimonial avatar (36dp)
- `avatar-testimonial-3`: Subscription page: testimonial avatar (36dp)

## Icons (Material Symbols, Outlined 400; `-fill` = filled)

Web `<Icon name="…" />`, Compose `EqualIcon(EqualIcons.<PascalName>)`.

`arrow-back` (arrow_back) · `call` (call) · `call-filled` (call-fill) · `more-vert` (more_vert) · `send` (send-fill) · `check` (check) · `done-all` (done_all) · `close` (close) · `delete` (delete) · `star` (star-fill) · `star-outline` (star) · `share` (share) · `chevron-right` (chevron_right) · `chevron-down` (keyboard_arrow_down) · `checkbox-blank` (check_box_outline_blank) · `checkbox-checked` (check_box-fill) · `play` (play_arrow-fill) · `pause` (pause-fill) · `chat` (chat_bubble-fill) · `chat-outline` (chat_bubble) · `search` (search) · `edit` (edit) · `edit-profile` (border_color) · `add` (add) · `mic` (mic) · `mute` (volume_off) · `person-add` (person_add) · `calendar` (calendar_month) · `place` (location_on) · `call-received` (call_received) · `call-made` (call_made) · `call-missed` (call_missed) · `phone-incoming` (phone_callback) · `phone-missed` (phone_missed) · `phone-outgoing` (phone_forwarded) · `info` (info) · `settings` (settings) · `home` (home) · `work` (work) · `bolt` (bolt) · `instructions` (note_stack) · `health-check` (health_metrics) · `silent-mode` (notifications_off) · `voice-language` (mic) · `address-pin` (pin_drop) · `account-data` (shield) · `help-center` (question_exchange) · `whatsapp` (brand:siWhatsapp) · `menu` (menu) · `arrow-forward` (arrow_forward) · `content-copy` (content_copy) · `light-mode` (light_mode) · `dark-mode` (dark_mode) · `contrast` (contrast) · `touch` (touch_app) · `notify-me` (notifications_active) · `translate` (translate_indic) · `call-sparkle` (custom:call-sparkle) · `help-circle` (help-fill) · `lock` (lock-fill) · `mail` (mail-fill) · `info-fill` (info-fill) · `signal` (signal_cellular_4_bar-fill) · `wifi` (wifi-fill) · `battery` (battery_full-fill) · `timer` (timer-fill) · `person` (person-fill) · `call-log` (call_log-fill) · `call-sparkle-fill` (custom:call-sparkle-fill) · `auto-fix` (wand_stars-fill) · `keyboard` (keyboard) · `mic-fill` (mic-fill) · `navigation` (navigation-fill) · `slide-left` (keyboard_double_arrow_left) · `globe` (public-fill) · `verified` (verified-fill) · `refresh` (refresh) · `graphic-eq` (graphic_eq) · `phone-missed-fill` (phone_missed-fill) · `thumb-up` (thumb_up) · `thumb-down` (thumb_down) · `thumb-up-fill` (thumb_up-fill) · `thumb-down-fill` (thumb_down-fill)
