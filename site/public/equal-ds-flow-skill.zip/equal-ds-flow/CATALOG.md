# Equal AI Design System: full catalog

> Everything Claude needs to design and build Equal AI screens and flows for web (React) and Android (Jetpack Compose). Generated from the sources by scripts/build-llms.mjs; do not edit by hand.

## Rules and recipe (CLAUDE.md)

This repo is the Equal AI design system for **web (React)** and **Android (Jetpack Compose only)**.
It covers tokens, components, screens, flows and the docs site. Read this file before you design or
build anything here. The catalog of every component, prop, token, asset, icon and flow is in
`site/public/llms-full.txt`, which `npm run llms` regenerates. Search it first; reuse before you add.
The same catalog is an MCP server (tools `search`, `get`, `list`) at https://equal-ds.vercel.app/mcp,
or locally with `npm run mcp`. `npm run llms` also rebuilds its index (`api/_index.json`).

### The rules (these always apply)

The reason behind every rule is in `site/src/data/decisions.ts` (the site’s Rules & decisions page).
When a design and the system disagree, check it first; when a rule changes, update it there too.

**Type and colour**
- **Typography:** DM Sans only, through the 12 type tokens (`<Text variant>` / `EqualTheme.type`).
  Nothing is set in Lora or any other font. Weights: 400, 500, 600 (SemiBold) and 700.
- **Colour:** only tokens. Never put a hex value in a component. Colours follow the Figma library’s
  “Colours” set: text black 80 / 60 / 40 / 20 % (primary, secondary, placeholder, disabled), strokes
  black 5 / 8 / 32 %, page `#FAFAFA`. A colour at x % is written as the colour-guide colour plus
  opacity: `"{brand.green} @ 36%"`. One-off greys snap to the text colours; readable text stays ≥ 4.5:1
  (40 % is for placeholders only). Every token needs a `why` that states its purpose.
  - **New colour:** add it to `tokens/tokens.json` with `"derived": true` and a `"why"`, give it light
    and dark values, and check text pairs for AA (4.5:1). Decide colours yourself; don't ask for
    sign-off.
- **Dark mode:** every component and screen works in light and dark. In dark, every green is lime
  (#BAFF29): accents use lime itself, green-tinted surfaces are re-hued to lime, and anything on lime
  is `text/on-action` (black), never white.

**Structure**
- **Atoms first:** every visible leaf is an atom (`Text`, `Icon`, `Emoji`, `Asset`, `Button`…), never
  raw markup with a typography class. Molecules combine atoms; organisms combine molecules. Set a new
  component's level in `site/src/registry/levels.ts` so Trace can show it.
- **Radii:** whole numbers only (2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 50, 54, 80, 100, full).

**Icons and images**
- **Action cards:** the grey body sits on a white card (never a green card), and every CTA row is
  emoji + label (📤 Send, ✏️ Edit, 👍 Confirm, 🗑️ Delete).
- **Icons:** flat icons are Material Symbols (`scripts/build-icons.mjs`, then `npm run icons`). Action
  chips use emoji, sized to the label font size.
- **Images:** the only images are supplied assets in `assets/`. Everything else is code: logos, seals,
  patterns, rings, progress bars, badges. Never crop an image; trimming transparent margins is fine.
- **Premium (monetization) surfaces:** perk icons are *filled* Material Symbols at 16 dp, painted
  with the gold radial gradient `premium-icon/start` → `premium-icon/end` (`<PremiumIcon>` /
  `PremiumIcon`). Light premium cards sit on the `premium-glow` art; dark ones use the coded
  black-gold gradient. Gold CTAs use `gradient/cta-gold`. Most monetization values (price, coupon, copy, entry point) are experiments: keep them as props.
- **Mascots:** the green mascot illustrations are generated to order. When a screen needs a new one,
  ask for it and show a placeholder.

**Android frame and chrome**
- **Frame:** 390 × 800 dp. Extend only vertically (`StagePhone.height` / `ANDROID_FRAME` on web,
  `EqualFrameWidthDp` / `EqualFrameHeightDp` in Compose).
- **Status bar:** Material 3, 52 dp. Text fields have 12 dp corners.
- **Avatars:** free users get the plain bust; paid users (Unlimited) get the gold background and ring
  (`tier: 'free' | 'paid'`). Saved contacts show their initials on the light-blue disc with the person
  badge at the bottom-right (the signifier for a known contact); unknown and business callers use
  category art.
- **The green orb** (nav FAB) opens the assistant sheet (Global MYA, `AssistantSheet`) on any screen.
  Requests become a short task conversation that ends in a result to confirm. Don't draw the system
  keyboard; just lift the input above it.
- **Call Handling** lives under You → Your assistant. Ask for a permission only at the step that
  needs it. Android draws notifications: `CallNotification` only fills the shell (who, what they want,
  Takeover first), and the wallpaper behind it in docs is coded.
- **Dark-mode You tab:** the cream-gold profile header stays light (its content renders with light
  tokens) as a panel with rounded bottom corners; the status bar sits on the gold.

- **Text inputs that can send:** show the mic while empty and the send arrow as soon as there is text.

**Engineering**
- **Stack:** business logic is Kotlin, UI is Compose, and animations are Lottie JSON (`assets/lottie/`,
  `<Lottie>` / `EqualLottie`). Respect reduced motion everywhere.
- **Experiments are props, not forks.** The Android team A/B tests monetization, so price, copy,
  coupon, entry touchpoint and similar knobs are props on the same screen.
- **Paywall experiments** (`MonetizationExperiments.tsx`): touchpoints and payment states are props on
  Home / Chat / Paywall (`planExpired`, `homeNotice`, `official`, `lockedActions`, `paywallSheet`,
  `paymentProcessing`, `PaymentResultScreen`). While a payment is processing, every surface says so
  and the paywall CTA is disabled.

### Where things live

| What | Web | Android |
|---|---|---|
| Tokens (generated) | `web/src/tokens/` | `compose/.../tokens/EqualTokens.kt` |
| Components | `web/src/components/<Name>.tsx` + `.css`, exported from `web/src/index.ts` | `compose/equal-ds/src/main/java/ai/equal/ds/components/` |
| Screens | `web/src/screens/*.tsx` | `compose/.../catalog/*.kt` |
| Assets | `assets/<name>.webp\|svg` + `web/src/foundations/Asset.tsx` | `res/drawable-xxxhdpi/ds_asset_*.webp`, `EqualAssets` |
| Docs page per component | `site/src/registry/components.tsx` | snippets in `compose/equal-ds/src/debug/java/ai/equal/ds/snippets/` |
| Flow pages | `site/src/pages/Flow.tsx` + `site/src/app/nav.ts` + `site/src/pages/Screens.tsx` | snippet group `flow-<id>` |

### Recipe: a new flow from a design (PDF, Figma frames or screenshots)

1. **Read the design fully.** Render PDFs at high resolution (`pdftoppm -r 100`) and crop each region.
   List every screen state, every component and every image.
2. **Map it to the system.** For each element, find the existing component in `llms-full.txt`. Only
   build a new component when nothing fits, or extend one with a prop.
3. **List the assets.** Split them into images to supply (3D art, illustrations, mascots) and things to
   code. Ask the designer for any images that are missing. Until they arrive, `<Asset>` shows a
   checkerboard placeholder.
4. **Add assets.**
   - PNG/WebP: a transparent file at least 2000 px into `assets/source/<name>.png`; add its display size
     to `SIZES` in `scripts/build-assets.py`; run `npm run assets`.
   - Register it in `Asset.tsx` (`assetNames` + `assetUsage`) and in `EqualAssets`.
   - SVG: `assets/<name>.svg` for web, and a VectorDrawable at `res/drawable/ds_asset_<name>.xml` for Android.
5. **Tokens:** add any new colours or gradients to `tokens/tokens.json`, then run `npm run tokens`.
6. **Web components:** add a `.tsx` + `.css` pair using only tokens, export it, and give it a docs entry in
   `site/src/registry/components.tsx`: examples with `code`, props, tokens, and do / don't. Add its
   anatomy (parts in reading order) and accessibility (Role, Name, Keyboard, Touch target, Contrast,
   State, Motion, for web and Android, plus known gaps) to `site/src/registry/a11y.json`.
7. **Screens:** add props to the revamped screens, or a new screen in `web/src/screens/`.
8. **Flow page:** add the flow to `Flow.tsx`, with states (`key`, `label`, `render`, `code`, and
   `height` when the screen is taller than 800), plus steps and the source. Add it to `nav.ts` and the
   Screens overview cards.
9. **Android:** mirror every component and screen in Compose. Add a snippet for every docs example and
   flow state: `// snippet: <doc id> / <example title>` or `// snippet: flow-<id> / <state key>`.
10. **Verify** with the commands below, and look at every state in light and dark on the site.

### Commands

```bash
npm run site          # docs site at http://localhost:5190 (tokens + snippets + llms first)
npm run tokens        # tokens.json → web + Compose
npm run icons         # icon manifest → web + Compose
npm run assets        # assets/source → web webp + Compose drawable-xxxhdpi
npm run llms          # regenerate site/public/llms*.txt and the Claude skill zip
npx tsc --noEmit      # web typecheck
node scripts/build-snippets.mjs --check   # every docs example has Compose code
cd compose && JAVA_HOME=/opt/homebrew/opt/openjdk@17 ANDROID_HOME=/opt/homebrew/share/android-commandlinetools ./gradlew :equal-ds:compileDebugKotlin :equal-ds:assembleRelease :equal-ds:lintDebug
```

Done means: typecheck clean, `--check` passes, Gradle BUILD SUCCESSFUL, and lint reports
"0 errors, 0 warnings" in `compose/equal-ds/build/reports/lint-results-debug.txt`.

## Rules & decisions (why each rule exists)

### Principles

- **One token file feeds web and Android.** Why: If a value lives in two places it drifts. tokens.json generates the CSS, the TS and the Kotlin, so a change lands on both platforms at once and nobody hand-copies hex values. (Source: Engineering)
- **Experiments are props on one screen, never forks.** Why: The Android team A/B tests monetization constantly (price, copy, entry point, layout). A forked screen per variant would multiply bugs and fall out of sync; a prop keeps every variant on the same, tested code. (Source: Product: Android runs monetization experiments)
- **Only supplied art is an image; everything else is code.** Why: Coded logos, seals, rings, badges and progress bars stay sharp at any size, follow light and dark automatically and weigh nothing. Images are reserved for 3D art and illustrations nobody can draw in code. (Source: Design direction)
- **Never crop supplied art.** Why: Designers compose the transparent padding on purpose (glow, shadow, breathing room). Cropping changes the art; only fully transparent margins are trimmed when an asset is built. (Source: Design direction)
- **Colours that aren’t in the colour guide are marked “derived”.** Why: The colour guide doesn’t cover every surface the screens use. Marking derived tokens keeps it clear which values came from the guide and which were measured from screens, so design can review them in one place. (Source: Design: colour guide gaps)

### Colour & type

- **Colours come from the Figma library’s “Colours” set: text is black at 80 / 60 / 40 / 20%.** Why: The app file binds its colours to a shared library with two sets of the same names; the newer “Colours” set (alpha black and white) is the one the revamped screens use. Primary text is black 80%, secondary 60%, placeholder 40%, disabled 20%; strokes are black 5 / 8 / 32%; the page is #FAFAFA and the dark surface #1F1F1F. (Source: Figma: 📱 EQAI Android · library “Colours”)
- **A colour at x% is the colour-guide colour at 100% with x% opacity.** Why: Figma paints the same brand and neutral colours at different opacities (green at 36% for unread strokes, lime at 8% for unread fills). Writing them as “{brand.green} @ 36%” keeps one source colour per hue, so a brand change flows to every tint. (Source: Product owner)
- **One-off greys snap to the text colours; readable text never drops below 4.5:1.** Why: Figma has about 20 hand-picked greys (#3C3C3C names, #858484 previews, #9F9F9F dates…). Snapping them to primary / secondary keeps new screens to four text colours. Black 40% is 2.85:1 on white, so it is only for placeholders and disabled text; dates and captions use secondary (60%, 5.7:1). Figma colours that fail AA for text are darkened in the same hue and the reason is written on the token. (Source: Product owner + accessibility)
- **Every colour token says what it is for and is used somewhere.** Why: Tokens that no Figma screen or component uses were deleted in the rebuild. The Colour page lists each token’s purpose and the components that use it, so an unused or duplicate colour is visible at once. (Source: Figma rebuild)
- **Green (lime in dark) only for what you can touch.** Why: If green also decorates, users can’t tell what is tappable. Reserving it for actions and the assistant’s byline makes every green thing a promise that it does something. (Source: Typography v3 colour roles)
- **In dark mode every green is lime (#BAFF29).** Why: Brand green goes muddy on near-black; lime is the brand’s dark-mode accent. Accents (buttons, icons, strokes, the FAB, the WhatsApp glyph) use lime itself, and green-tinted dark surfaces are re-hued to lime at the same darkness. Anything drawn on lime is dark (text/on-action), never white. (Source: Design rule)
- **Every text pair passes WCAG AA (4.5:1).** Why: Many users read the app outdoors on mid-range phones at low brightness. When a mock’s colour falls short (e.g. the saved-contact blue at 4.15:1), the token is nudged until it passes and the reason is written on the token. (Source: Accessibility)
- **Everything is set in DM Sans. Nothing is in Lora.** Why: One family keeps every screen consistent and the app light to ship. Some design files use Lora for display lines; in the product those lines are DM Sans. (Source: Product: “Make everything DM Sans”)
- **Four DM Sans weights: 400, 500, 600 and 700.** Why: Regular is for reading, Medium for labels, SemiBold where the designs use it (plan names such as “Equal AI Unlimited”), Bold for display lines. All four are loaded on web and Android, so nothing is synthesised. (Source: Design files)
- **Text that doesn’t match a type token is a bug.** Why: Twelve tokens cover every role. Ad-hoc sizes creep in one screen at a time until nothing lines up; holding to the tokens keeps rhythm across screens. (Source: Typography v3)
- **Medium is scanned, Regular is read; wrapping text is always Regular.** Why: Weight separates labels from prose. Paragraphs in Medium are tiring to read and flatten the hierarchy. (Source: Typography v3)
- **Emoji are sized to the label they sit in.** Why: Emoji render larger than letters at the same font size, so oversized emoji pull the eye away from the words. Matching the label size keeps chips calm. (Source: Design review: emoji looked too big)

### Android frame & chrome

- **Design at 390 × 800 dp and extend only vertically.** Why: It is the team’s working Android frame. Long screens grow taller rather than wider, so layouts are always checked at real phone width. (Source: Product: team frame)
- **The status bar and every icon follow Material 3.** Why: The app runs inside Android’s system UI. A Material 3 status bar (52 dp) and Material Symbols for all flat icons mean screens sit naturally next to the real system UI and every icon shares one line weight. (Source: Product: Material 3)
- **Text fields have 12 dp corners; search and assistant message fields are fully rounded.** Why: Form fields read as editable boxes. Search and the assistant composer are conversational entry points, so they use the pill shape the app uses for chat input. (Source: Design: text field 12px; assistant fields fully rounded)
- **48 dp touch targets, even when the visual is smaller.** Why: Smaller targets cause mis-taps, especially one-handed. Where a mock draws a 36 dp button, the touch area is still 48 dp. (Source: Accessibility / Material)
- **Business logic in Kotlin, UI in Compose, animations in Lottie.** Why: That is how the Android team builds. Components are stateless Compose; illustrative motion is Lottie JSON played by Lottie, never re-built by hand. (Source: Engineering: Android stack)
- **Respect reduced motion everywhere.** Why: Some users get motion sickness or find animation distracting. Every animation in the system holds still when the phone asks for reduced motion. (Source: Accessibility)

### People & identity

- **Free users get the plain avatar; paid users get the gold background and ring.** Why: Unlimited should feel like a status the user can see on their own face. Keeping free plain makes the upgrade visible without nagging. (Source: Product)
- **Saved contacts show initials on a tinted disc with a person badge.** Why: The badge is the signifier for “someone you know”. The disc colour varies per contact (blue, green, purple, orange, pink, teal) at the same saturation and lightness, so a list isn’t one flat colour, and every pair keeps the initials readable (AA). The same initials always get the same colour. (Source: Design: “AN with a mark”; colour can vary at the same saturation)
- **Unknown and business callers use 3D category art.** Why: The category tells the user at a glance why someone called (delivery, bank, real estate) before reading a word. (Source: Design)
- **The robot is the default “AI Assistant is On” art; the phone-with-sparkles is an experiment.** Why: Design confirmed the robot as final. The phone stays available as a prop so the team can test it. (Source: Product decision)
- **Green mascots are generated to order.** Why: Mascot moments are custom for each screen. When a new one is needed, the system shows a placeholder and asks for the art rather than reusing a mismatched pose. (Source: Design)
- **The logo comes from the official SVG.** Why: A traced logo drifts from the brand. The official vector generates both platforms (npm run logo). (Source: Brand)
- **In the AI layer, saved contacts are addressed by first name, others by full name.** Why: “Replying Amit” reads naturally for a friend, but splitting a business name gives nonsense like “Replying Dr.”. (Source: Engineering (copy))

### Components

- **Build from atoms: atoms → molecules → organisms → screens.** Why: Every visible leaf (text, icon, emoji, image, coded art) is rendered by an atom (Text, Icon, Emoji, Asset, Button…). Molecules combine atoms for one job (a chip, a row), organisms are whole sections (a chat row, a paywall). Trace walks this chain, so a designer can point at any pixel and find the atom, then step up with ↑ to the molecule and section. (Source: Product owner)
- **Corner radii are whole numbers from one scale.** Why: The Figma scale is 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 50, 54, 80, 100 and full. Decimal radii in Figma (5.76, 1.33, 10.27…) come from scaled component instances or circles; use the whole number the master component uses, and “full” for circles and pills. (Source: Figma audit)
- **Action cards: grey body on a white card, never a green card.** Why: A green wrapper made confirmations look like warnings and broke consistency with the rest of the thread. Every action card has the same frame; the content says what happened. (Source: Design review)
- **Every action-card CTA has an emoji (📤 Send, ✏️ Edit, 👍 Confirm, 🗑️ Delete).** Why: Emoji make the action recognisable at a glance and match the chip language used everywhere else in chat. (Source: Design review)
- **All actions in a card have the same weight; Confirm is not a filled button.** Why: Two actions at equal weight let the user choose; a filled Confirm pushes them. The commit goes first, the revise second, both as text rows. (Source: Typography v3 / handoff)
- **Instructions use the note_stack icon with When / Do lines, never a category avatar.** Why: An instruction is a rule the user set, not a caller. The icon and When / Do structure make that obvious. (Source: Design review)
- **Flat icons are Material Symbols (Material 3); actions use emoji.** Why: One icon family keeps line weight consistent. Emoji on actions add warmth and are easier to recognise in a crowded chat. (Source: Design direction)
- **Premium (monetization) perk icons are filled, 16 dp, in the gold radial gradient.** Why: Filled gold marks a paid perk apart from everyday UI icons, which are outlined. (Source: Design spec)

### Monetization

- **Unlimited is ₹249; with EQUAL25 it is ₹149.** Why: Today’s default, confirmed by product; price and coupon are experiment props (price, discountedPrice). The coupon row says “Save Flat ₹100”, and the price drop animates only when the user taps APPLY. (Source: Product decision)
- **The plan value card shows ₹39 with ₹49 struck through.** Why: The value designs show both orders; ₹39 / ₹49 was confirmed. (Source: Product decision)
- **🎊 LIMITED TIME DISCOUNT stays an emoji, not art.** Why: Confirmed by design: it is copy, not an illustration. (Source: Design decision)
- **Lock content, never identity.** Why: Free users still see who called and when; only the content (bubbles, recording, actions) is blurred or crown-locked. Hiding the caller would make the app useless, not tempting. (Source: Product)
- **While a payment is processing, every surface says so and the paywall button is disabled.** Why: UPI confirmations can take minutes. Without this, users who close the pending page pay twice. (Source: Design: If User Closes the payment pending page)
- **The exit offer appears once per session.** Why: Offering the coupon when someone leaves converts; offering it every time trains people to leave first. (Source: System guidance (not yet enforced in code))
- **Show what Unlimited did before asking for a renewal.** Why: A user who sees “20 calls handled” renews for the value they already got, not on a promise. (Source: Design: Monetization value)
- **Keep the existing bottom navigation (Chats, You).** Why: One mock showed a Home tab; product confirmed the navigation stays as it is. (Source: Product decision)

### Assistant & calls

- **The green orb opens the same assistant sheet on every screen.** Why: One consistent entry point means users learn it once. (Source: Design: Global MYA)
- **Inside a chat, the task sheet stops below the chat header.** Why: The user must still see whose chat they are acting in, so a reply never goes to the wrong person. (Source: Design: chat AI layer)
- **Tasks end in a result the user confirms (Edit / Confirm), then the outcome shows where it lives.** Why: The assistant acts on the user’s behalf; confirming first keeps them in control, and showing the result in the chat row closes the loop. (Source: Design: Global MYA)
- **Confirm before actions that are hard to undo (mute, send, save).** Why: The assistant acts for the user. A one-line check (“Are you sure? You’ll not get any call from them…”) prevents the mistake that costs the most. (Source: Design: Mute, Reply on WhatsApp, Save Contact)
- **Every finished action leaves an action card in the chat.** Why: The chat is the record of what the assistant did (Outgoing call, Muted, WhatsApp message, Contact saved), and each card links to where the result lives. (Source: Design: action flows)
- **Hand off to the phone for the dialer, Settings and WhatsApp; never redraw them.** Why: The system owns those screens. The app hands off, then picks up where the user left off (“You stopped between saving this contact. Want to continue?”). (Source: Design: Call Back, Save Contact)
- **Errors say what happened in one line and offer one fix.** Why: Retry for a failed generation, Refresh or Try again when offline, “hold and speak again” for voice. One clear next step beats an error code. (Source: Design: Error states)
- **The contact form has two candidate designs (iOS-revamp parity, WhatsApp parity).** Why: The team hasn’t chosen; both are props on one form so either can ship. (Source: Design: Save Contact)
- **A missed call shows only what we know: the reason (with caller art and 👍/👎), else the name, else “Missed by the assistant”.** Why: Inventing a reason would mislead the call-back decision. The thumbs rate the reason, so they only appear with one. The warm tint says “missed”, not “error”. (Source: Design: missed-call card)
- **Never draw the system keyboard in the app.** Why: Android owns the keyboard. The docs show a stand-in image; the app only lifts its input above the keyboard. (Source: Engineering)
- **Ask for a permission only at the step that needs it, and say why in one line.** Why: Permissions asked up front get denied. Asked in context (“I need your contact list to know who is calling”), they get granted. (Source: Design: Known Calls flow)
- **Notifications: who, what they want, and Takeover first.** Why: A notification is glanced at in a second. Takeover is the action that matters most when the assistant is on a call with someone you know. (Source: Design: Notifications - Known Calls)
- **Silent Mode is titled “Silent Mode” everywhere.** Why: The dark mock said “Call Preferences”; design confirmed “Silent Mode” to match the You-tab row. (Source: Design decision)
- **Auto-rickshaw, paper bag and delivery rider are not caller categories.** Why: They appeared in a design as decoration; product confirmed they shouldn’t become categories. (Source: Product decision)

## Components (62 docs pages)

### Group: Actions

#### Action chips (`action-chips`)

Emoji-led glass chips for the next step after a call: small chips in the chat list, large chips inside a conversation or the AI panel.

- React: `import { SmallActionChip, LargeActionChip, ChipRow } from '@equal/ds';`
- Compose: `SmallActionChip`, `LargeActionChip`
- Tokens: `gradient/chip-small-unread`, `gradient/chip-small-read`, `gradient/chip-large`, `action/stroke/unread`, `stroke/subtle`, `shadow/glass`, `text/action`, `text/secondary`, `text/primary`
- Source: §9 Small Action Chip · §10 Large Action Chip

Do: Lead every action with a Unicode emoji (📞 Call Back, ✏️ Update Address, 🗓️ Add to Calendar); actions use emoji, not Material icons. Use small chips outside chats (the chat list) and large chips inside a conversation or the AI panel. Let ChatListItem pick the small-chip state: unread rows get unread chips, read rows read chips, a selected row outlined chips. Mark the suggested next step unread and the alternative read (👍 Confirm vs ✍️ Edit).

Don't: Don't swap the emoji for a Material icon or drop it on some chips in a row. Don't wrap the chat-list chip row; it scrolls and clips at the right edge. Don't use a chip for a destructive action; that belongs in a confirm sheet.

Anatomy:
1. Container: Glass pill that holds the action and takes the tap. (Small 30 high, padding 8/10 · Large 40 high, padding 10/12 · radius full · 1dp border action/stroke/unread (unread) or stroke/subtle (read) · shadow/glass)
2. Emoji: Unicode emoji that leads every action (📞 Call back). (Small 12 · Large 14 · gap 6 · platform emoji font)
3. Label: Sentence-case action name, one line. (Small buttonSmall 12/500 · Large button 14/500 · unread text/action, read/outlined text/secondary, large text/primary)
4. Chevron: Trailing arrow on small chips that signals it opens something. (chevron-right 14 · tint follows the label · gap 4 (Compose) · optional on web)
5. Small chip: locked: Free-plan variant where a crown-lock replaces the emoji and tapping opens the paywall. (crown-lock 14 · alt / contentDescription 'Locked' · label text/gold)
6. ChipRow: Horizontal scroller that holds a row of chips and clips at the right edge. (gap 12 default · padding 2 top / 4 bottom · .eq-hscroll, scrollbar hidden)

Accessibility:
- Role. Web: Native <button>; the emoji and chevron are aria-hidden. Android: clickable(role = Role.Button) on the Row.
- Name. Web: The visible label; a locked chip reads 'Locked' (crown-lock alt) followed by the label. Android: Merged text of the chip. EmojiGlyph is a plain BasicText, so TalkBack also reads the emoji name before the label; locked adds 'Locked'.
- Keyboard. Web: Tab to each chip, Enter or Space to activate; ChipRow scrolls horizontally as focus moves. Android: TalkBack: swipe through chips in order, double-tap to activate; the row scrolls to the focused chip.
- Touch target. Web: SmallActionChip uses .eq-touch for a 48px hit area around the 30px pill; LargeActionChip is 40px with no expansion. Android: minimumInteractiveComponentSize() on both, so the 30dp and 40dp pills get a 48dp target.
- Contrast. Web: Unread label text/action #00B140 on the chip-small-unread gradient is about 2.6:1 in light; read text/secondary (6.7:1) and large text/primary pass. Dark: lime on #2F3423 is 10.7:1. Android: Same tokens as web; the 1dp action/stroke/unread border (#9DDDB4) is decorative, the label carries the meaning.
- State. Web: unread / read / outlined are visual emphasis only (colour and fill), with no ARIA state; the row's unread count and selection carry the real state. Android: Same: style is not exposed in semantics. LargeActionChip enabled = false sets disabled semantics and draws at 45%.
- Motion. Web: Press scale 0.97 over 120ms via .eq-pressable; zeroed under prefers-reduced-motion. Android: eqPressFeedback scale tween follows the system animator scale.

Known accessibility gaps:
- ActionChip.tsx: LargeActionChip is 40px high and has no eq-touch, so its web hit area is below 48px.
- ActionChips.kt: EmojiGlyph is not hidden from semantics, so TalkBack reads the emoji name before the label (web hides it with aria-hidden).
- ActionChip.css / ActionChips.kt: unread label text/action #00B140 on the chip-small-unread gradient is about 2.6:1 in light mode, below 4.5:1.
- ActionChip.css: LargeActionChip has no disabled styling on web, while Compose dims to 45% when enabled = false.

Example: Small chip states
```tsx
<SmallActionChip emoji="📞" label="Call Back" />
<SmallActionChip emoji="✏️" label="Update Address" />
<SmallActionChip emoji="📞" label="Call Back" state="read" />
<SmallActionChip emoji="📞" label="Call Back" state="outlined" />
<SmallActionChip emoji="🗓️" label="Add to Calendar" state="outlined" chevron={false} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SmallActionChip(label = "Call Back", emoji = "📞", onClick = {})
        SmallActionChip(label = "Update Address", emoji = "✏️", onClick = {})
    }
    SmallActionChip(label = "Call Back", emoji = "📞", onClick = {}, style = SmallActionChipStyle.Read)
    SmallActionChip(label = "Call Back", emoji = "📞", onClick = {}, style = SmallActionChipStyle.Outlined)
    // Compose: no chevron toggle; the trailing chevron is always shown.
    SmallActionChip(label = "Add to Calendar", emoji = "🗓️", onClick = {}, style = SmallActionChipStyle.Outlined)
}
```

Example: Large chips
```tsx
<ChipRow gap={8}>
  <LargeActionChip emoji="📞" label="Takeover" />
  <LargeActionChip emoji="🗓️" label="Ask to reschedule" />
</ChipRow>
<ChipRow gap={8}>
  <LargeActionChip emoji="✍️" label="Edit" state="read" />
  <LargeActionChip emoji="👍" label="Confirm" />
</ChipRow>
```
```kotlin
// Compose: no ChipRow; a Row with spacedBy(8.dp) does the same job.
Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    LargeActionChip(label = "Takeover", emoji = "📞", onClick = {})
    LargeActionChip(label = "Ask to reschedule", emoji = "🗓️", onClick = {})
}
Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    LargeActionChip(label = "Edit", emoji = "✍️", onClick = {}, state = LargeActionChipState.Read)
    LargeActionChip(label = "Confirm", emoji = "👍", onClick = {})
}
```

Example: In a chat row
```tsx
<ChipRow>
  <SmallActionChip emoji="📞" label="Call Back" />
  <SmallActionChip emoji="✏️" label="Update Address" />
  <SmallActionChip emoji="🗓️" label="Add to Calendar" />
</ChipRow>
```
```kotlin
// Compose: no ChipRow; a horizontally scrolling Row (gap 12) clips at the right edge.
Row(
    modifier = Modifier.horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(12.dp),
) {
    SmallActionChip(label = "Call Back", emoji = "📞", onClick = {})
    SmallActionChip(label = "Update Address", emoji = "✏️", onClick = {})
    SmallActionChip(label = "Add to Calendar", emoji = "🗓️", onClick = {})
}
```

#### Button (`button`)

Filled, text and icon buttons: use a filled Button for the one commit action on a surface, a TextButton for revise or secondary actions, and an IconButton for icon-only controls like back, close and call.

- React: `import { Button, TextButton, IconButton } from '@equal/ds';`
- Compose: `EqualButton`, `EqualTextButton`, `EqualIconButton`
- Tokens: `button/primary`, `button/secondary`, `button/danger`, `button/disabled`, `text/on-action`, `text/on-danger`, `text/on-action-disabled`, `text/action`, `text/danger`, `bg/surface`, `shadow/raised`, `glass-button/default`, `shadow/focusRing`
- Source: §19 Buttons

Do: Use exactly one filled Button per surface for the commit action (Save, Delete, Turn off); pair it with a TextButton for revise or cancel. Write labels in sentence case ("Add new Address", "Share Feedback" as shipped) and keep the same verb from control to confirmation: Turn off → "Call learning turned off". Use the danger variant only for destructive commits, with the trash icon (the delete sheet does this for you). Always pass a `label` to IconButton; it is the accessible name and the tooltip.

Don't: Don't put two filled buttons side by side; two actions at equal weight are one action. Don't colour non-actionable text green; text/action is reserved for things you can tap. Don't shrink the touch target: small buttons keep a 48dp hit area even when the visual is 24dp.

Anatomy:
1. Container: The pill (or 8dp rounded) surface that holds the content and takes the press. (sm 24 · md 36 · lg 45 high · radius full (rounded: radius/sm 8) · fill button/primary, button/secondary, button/danger, gradient/cta-gold or transparent + 1.5 border · disabled button/disabled)
2. Leading icon: Optional icon before the label that reinforces the action. (Web 18 (sm 14) · Compose 16 · gap 6 · tint follows the label colour · decorative)
3. Label: The verb that names the action, sentence case, one line. (button 14/500 (sm buttonSmall 12/500) · text/on-action, text/primary (secondary), text/on-danger · padding h14 / h20 / h24)
4. Trailing icon: Optional icon after the label, usually a chevron for forward navigation. (Same size and tint as the leading icon · gap 6)
5. TextButton: label: Unfilled text action used for the revise or secondary action. (button token · text/action, text/danger or text/secondary · Compose 36 high, padding h8 · disabled text/action-disabled)
6. IconButton: circle + icon: Icon-only circular button for close, confirm and toolbar actions. (ghost 40 / icon 24 · neutral 44 bg/surface + shadow/raised, icon text/secondary · primary 42 button/primary, icon text/on-action / icon 22)

Accessibility:
- Role. Web: Native <button type='button'> for Button, TextButton and IconButton. Android: clickable(role = Role.Button) on the Row/Box; icons inside have contentDescription = null.
- Name. Web: Button and TextButton take their name from the visible label; IconButton requires `label`, set as aria-label and title. Android: Name comes from the text; EqualIconButton takes a required contentDescription parameter (pass a verb such as 'Close').
- Keyboard. Web: Tab to focus, Enter or Space to activate; disabled buttons leave the tab order. Focus shows the shadow/focusRing via .eq-reset-btn:focus-visible. Android: TalkBack: swipe to focus, double-tap to activate; a hardware-keyboard focus draws eqFocusRing on EqualButton.
- Touch target. Web: Only size sm and TextButton/IconButton get .eq-touch (a 48px ::after hit area); md (36) and lg (45) Buttons have no expansion and stay under 48px high. Android: minimumInteractiveComponentSize() on all three, so sm 24, md 36, lg 45 and the 42/44 icon circles all get a 48dp target.
- Contrast. Web: White on button/primary #00B140 is 2.85:1 in light, below 4.5:1; danger (6.2:1), secondary text/primary on lime and dark mode black on lime #BAFF29 (17.4:1) pass. Gold label on gradient/cta-gold falls to 3.1:1 at its light end. Android: Same tokens and ratios as web; TextButton text/action #00B140 on white is 2.85:1 in light, lime on #222222 is 13.2:1 in dark.
- State. Web: Disabled uses the native disabled attribute (exposed to assistive tech) and swaps to button/disabled with text/on-action-disabled; IconButton drops to 40% opacity. Android: enabled = false on clickable marks the node disabled; the fill changes to button/disabled, so state is not only the label colour.
- Motion. Web: Press scales to 0.97 over 120ms and background fades 200ms; base.css zeroes transition and animation durations under prefers-reduced-motion. Android: eqPressFeedback animates scale over motion.fast and follows the system animator scale; the Gold sheen and glow are skipped when rememberReduceMotion() is true.

Known accessibility gaps:
- Button.tsx: only size 'sm' gets the eq-touch class, so md (36px) and lg (45px) Buttons have a hit area under 48px on web.
- Button.css / Buttons.kt: white label on button/primary #00B140 is 2.85:1 in light mode, below 4.5:1 for 14sp button text.
- Button.css / Buttons.kt: Gold variant white label on gradient/cta-gold drops to 3.1:1 at the #B88A45 end.
- Button.css / Buttons.kt: TextButton tone 'action' (#00B140 on white) is 2.85:1 in light mode.
- base.css / EqualEffects.kt: shadow/focusRing is a 3px ring of green at 12% alpha, far below 3:1 against the background, so keyboard focus is hard to see.

Example: Variants
```tsx
<Button>Save</Button>
<Button variant="secondary">Try Voices</Button>
<Button variant="danger" leadingIcon="delete">Delete</Button>
<Button disabled>Save</Button>
```
```kotlin
EqualButton(text = "Save", onClick = {})
EqualButton(text = "Try Voices", onClick = {}, variant = EqualButtonVariant.Secondary)
EqualButton(text = "Delete", onClick = {}, variant = EqualButtonVariant.Danger, leadingIcon = EqualIcons.Delete)
EqualButton(text = "Save", onClick = {}, enabled = false)
```

Example: Sizes
```tsx
<Button size="sm" leadingIcon="add">Apply</Button>
<Button size="md">Save</Button>
<Button size="lg">Save</Button>
<Button shape="rounded">Save</Button>

<Button block size="lg" leadingIcon="add">Add New Instruction</Button>
```
```kotlin
EqualButton(text = "Apply", onClick = {}, size = EqualButtonSize.Sm, leadingIcon = EqualIcons.Add)
EqualButton(text = "Save", onClick = {}, size = EqualButtonSize.Md)
EqualButton(text = "Save", onClick = {}, size = EqualButtonSize.Lg)
// Block = lg metrics at full width
EqualButton(text = "Add New Instruction", onClick = {}, size = EqualButtonSize.Block, leadingIcon = EqualIcons.Add)
```

Example: Text and icon buttons
```tsx
<TextButton>Edit</TextButton>
<TextButton leadingIcon="share">Share</TextButton>
<TextButton trailingIcon="chevron-right">Share Feedback</TextButton>
<TextButton tone="neutral">Cancel</TextButton>
<TextButton tone="danger">Delete address</TextButton>
<TextButton size="small">Clear all</TextButton>

<IconButton icon="arrow-back" label="Back" />
<IconButton icon="delete" label="Delete" variant="danger-ghost" />
<IconButton icon="close" label="Close" variant="neutral" />
<IconButton icon="check" label="Confirm" variant="primary" />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    EqualTextButton(text = "Edit", onClick = {})
    EqualTextButton(text = "Share", onClick = {}, leadingIcon = EqualIcons.Share)
    EqualTextButton(text = "Share Feedback", onClick = {}, trailingIcon = EqualIcons.ChevronRight)
    EqualTextButton(text = "Delete address", onClick = {}, danger = true)
}
Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    EqualIconButton(icon = EqualIcons.Back, contentDescription = "Back", onClick = {})
    EqualIconButton(icon = EqualIcons.Check, contentDescription = "Confirm", onClick = {}, variant = EqualIconButtonVariant.Primary)
}
```

Example: Commit + revise
```tsx
<TextButton tone="neutral">Cancel</TextButton>
<Button>Turn off</Button>
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    EqualTextButton(text = "Cancel", onClick = {})
    EqualButton(text = "Turn off", onClick = {})
}
```

### Group: Assistant

#### Assistant sheet (Global MYA) (`assistant-sheet`)

The sheet the green orb opens on any screen: greeting, quick-action tiles, suggestion chips and a text or voice input. A request turns it into a short task conversation (voice note → Thinking… → result card → Edit / Confirm).

- React: `import { AssistantSheetShell, AssistantGreeting, AssistantActions, AssistantInput, VoiceRecorder, TrySaying, AssistantTaskHeader, AssistantThinking, AssistantReplies, CarouselDots } from '@equal/ds';`
- Compose: `AssistantSheetShell`, `AssistantGreeting`, `AssistantActions`, `AssistantInput`, `VoiceRecorder`, `TrySaying`, `AssistantTaskHeader`, `AssistantThinking`, `AssistantReplies`, `CarouselDots`
- Tokens: `component/sheet/bg`, `gradient/voice-note`, `text/action`, `action/stroke/unread`, `text/danger`, `component/chat/wallpaper-bg`
- Source: Global MYA

Props of `AssistantInput`:
- `mode`: `'text' | 'voice'`. Field + mic, or keyboard toggle + Send voice note.
- `value?`: `string` = ''. Text.
- `focused?`: `boolean`. Green outline (keyboard open).
- `onMic?`: `() => void`. Text → voice.
- `onKeyboard?`: `() => void`. Voice → text.
- `onVoiceNote?`: `() => void`. Tap to record.
- `onVoiceHold?`: `() => void`. Press and hold to record.
- `onSubmit?`: `(text: string) => void`. Send.

Props of `VoiceRecorder`:
- `state`: `'idle' | 'recording' | 'hold' | 'cancel'`. Bar state.
- `seconds?`: `number` = 0. Elapsed.
- `onDelete?`: `() => void`. Discard.
- `onSend?`: `() => void`. Send.

Props of `AssistantGreeting`:
- `name`: `string`. First name, in text/action.
- `greeting?`: `string` = 'Good morning'. Use greetingFor(hour).

Props of `AssistantActions`:
- `items`: `{ label; icon: IconName | 'equal'; onClick? }[]`. Three tiles.

Props of `AssistantSheetShell`:
- `task?`: `boolean`. The taller conversation sheet (wallpaper body).
- `header?`: `ReactNode`. AssistantTaskHeader in task mode.
- `footer?`: `ReactNode`. Input / recorder.
- `onScrim?`: `() => void`. Tap outside closes.

Do: Open it from the green orb on every screen; it is the same sheet everywhere. Title the task by what the assistant is doing, not what the user said. End with a result to confirm (Edit / Confirm), then close and show the outcome where it lives (the chat row).

Don't: Don't draw the keyboard; it's the system's. Only lift the input above it. Don't keep the tiles while typing; the keyboard needs the room.

Anatomy:
1. Sheet: AssistantSheetShell: the panel the green orb opens over a dimmed screen. (sheet/bg · radius 32 top · shadow 0 -8 30 black 12% · task: 82% height, chat/wallpaper-bg body · inChat: stops 112 below the top · footer padding 12/16/20)
2. AssistantGreeting: Orb, greeting with the user's name and the prompt. (56 orb · headline Bold, name in text/action · prompt body1 text/secondary · padding 24/24/0 · gap 2)
3. AssistantActions: Three quick-action tiles. (equal tiles, gap 10 · min 92 high · radius 16 · bg/surface raised · icon 30 text/action (or Equal mark) · label body2)
4. AssistantInput: Text field with mic/send, or the voice row. (text: 48 pill, bg/surface, 1dp stroke/subtle (focus 1.5dp button/primary), bodyLarge + 52 circle gradient/voice-note · voice: 48 keyboard circle + 52 'Send voice note' pill)
5. VoiceRecorder: Recording bar with delete, timer, waveform and send. (48 delete text/danger · 48 pill, 1.5dp action/stroke/unread, m:ss + 22 bars text/action (cancel text/danger) · 52 send · hold/cancel hint caption text/secondary)
6. AssistantTaskHeader: Header once a request becomes a task. (32 orb · title subheading Regular · neutral close · bg/surface raised)
7. AssistantThinking: The assistant working. (28 orb · 'Thinking…' subheading italic text/secondary · dots pulse 1.2s, staggered 0.2s)
8. AssistantReplies + CarouselDots: Edit / Confirm pills under a result, and page dots. (48 pills, gap 12 · Edit bg/surface + stroke/subtle · Confirm gradient/chip-large + action/stroke/unread · dots 7 (active 11) stroke/medium / action/stroke/unread)

Accessibility:
- Role. Web: Panel is role=dialog 'Your assistant' (aria-modal in overlay); greeting is h2; tiles, mic, send and replies are buttons; the field is in a form; recorder pill is role=timer; Thinking is role=status; CarouselDots is role=tablist with no tabs. Android: Panel sets paneTitle 'Your assistant'; tiles, circles and pills are clickable(Role.Button); the voice pill is combinedClickable; Thinking merges with liveRegion Polite; dots are cleared to one description.
- Name. Web: Field 'Message your assistant'; buttons 'Voice note', 'Send', 'Type instead', 'Delete recording', 'Send voice note', 'Close'. The orb is role=img 'Equal AI' wherever it appears. Android: Same labels via contentDescription / onClickLabel; long-press label 'Hold to record'; greeting reads '{greeting}, {name}'; orbs have no description; dots 'Card 1 of 3'.
- Keyboard. Web: Tab through tiles, field (Enter submits), mic/send. Hold-to-record is pointer-only, but a plain Enter still records. No Escape to close and no focus trap; only the scrim click closes. Android: TalkBack: double-tap to activate; double-tap and hold triggers Hold to record; the IME Send key submits. System Back is not handled.
- Touch target. Web: Mic/send 52, round buttons 48, replies 48, tiles 92+, task close 40 with eq-touch (48). Android: Voice circles use minimumInteractiveComponentSize; round buttons and pills are 48dp; close is EqualIconButton (48).
- Contrast. Web: Light: white icons and label on gradient/voice-note fall to 1.8:1 at the lime end; name, tile icons and reply-card actions in text/action are 2.6–2.9:1; placeholder #AAAAAA is 2.3:1. Dark: black on lime 17:1+. TrySaying text/tertiary is 4.8:1 on sheet/bg. Android: Same tokens and ratios as web.
- State. Web: Recording is shown with a timer and text ('Release to send, slide left to cancel', 'Release to cancel'), plus a red waveform on cancel; the hint is not a live region. Focus shows the green outline. Android: Same text; the hold/cancel hint is a polite live region and the timer reads 'Recording 0:04'.
- Motion. Web: Sheet slides up, waveform ticks every 120ms, Thinking dots pulse. Under prefers-reduced-motion the bars stop and the dots and slide are removed. Android: rememberReduceMotion stops the bars and dots and shows the sheet without the slide.

Known accessibility gaps:
- CarouselDots in Assistant.tsx uses role=tablist with no tab children; use role=img with its label or a plain text 'Card 1 of 3'.
- AssistantSheetShell in Assistant.tsx has no Escape handling or focus trap; only the scrim click closes it.
- VoiceRecorder hold/cancel hint in Assistant.tsx is not a live region (Assistant.kt marks it polite).
- Hold-to-record (onVoiceHold) in Assistant.tsx is pointer-only, with no keyboard way to press and hold.
- White icons and 'Send voice note' on gradient/voice-note fall to 1.8:1 at the lime end in light theme (Assistant.tsx/.kt).
- text/action greeting name, tile icons and reply-card actions are 2.6–2.9:1 on light surfaces; placeholder text/placeholder is 2.3:1.
- EqualOrb (Avatar.tsx) is role=img 'Equal AI' in AssistantGreeting, AssistantTaskHeader and AssistantThinking, adding repeated speech; Assistant.kt treats it as decorative.

Example: Greeting & quick actions
```tsx
<AssistantSheetShell footer={<AssistantInput mode="text" onMic={toVoice} onSubmit={send} />} onScrim={close}>
  <AssistantGreeting name="Keshav" />
  <AssistantActions items={quickActions} />
  <ChipRow><LargeActionChip emoji="🗓️" label="Reply Amit on WhatsApp" /> …</ChipRow>
</AssistantSheetShell>
```
```kotlin
EqualTheme {
    AssistantSheetShell(
        onScrim = { /* close */ },
        footer = { AssistantInput(mode = AssistantInputMode.Text, onMic = { /* to voice */ }, onSubmit = { /* send */ }) },
    ) {
        AssistantGreeting(name = "Keshav")
        AssistantActions(
            items = listOf(
                AssistantAction("Talk to Equal"), // null icon: the Equal mark
                AssistantAction("Talk to Equal", EqualIcons.AutoFix),
                AssistantAction("Make a call", EqualIcons.CallFilled),
            ),
        )
        AssistantChips {
            LargeActionChip(label = "Reply Amit on WhatsApp", emoji = "\uD83D\uDDD3\uFE0F", onClick = {})
            LargeActionChip(label = "Set reminder", emoji = "\uD83D\uDD14", onClick = {})
        }
    }
}
```

Example: Input: text and voice
```tsx
<AssistantInput mode="text" value={text} onChange={setText} onMic={() => setMode('voice')} onSubmit={send} />
<AssistantInput mode="voice" onKeyboard={() => setMode('text')} onVoiceNote={record} onVoiceHold={holdToRecord} />
```
```kotlin
EqualTheme {
    var mode by remember { mutableStateOf(AssistantInputMode.Text) }
    var text by remember { mutableStateOf("") }
    AssistantInput(
        mode = mode,
        value = text,
        onValueChange = { text = it },
        onMic = { mode = AssistantInputMode.Voice },
        onKeyboard = { mode = AssistantInputMode.Text },
        onSubmit = { /* send it */ },
        onVoiceNote = { /* record */ },
        onVoiceHold = { /* hold to record */ },
        modifier = Modifier.imePadding(), // lift above the system keyboard
    )
}
```

Example: Recorder states
```tsx
<VoiceRecorder state="idle" onDelete={discard} onSend={send} />
<VoiceRecorder state="recording" seconds={elapsed} onDelete={discard} onSend={send} />
<VoiceRecorder state="hold" />    // press and hold: release to send, slide left to cancel
<VoiceRecorder state="cancel" />  // slid left: release to cancel
```
```kotlin
EqualTheme {
    Column(Modifier.background(EqualTheme.colors.bgPrimary).padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        VoiceRecorder(state = RecorderState.Idle, onDelete = {}, onSend = {})
        VoiceRecorder(state = RecorderState.Recording, seconds = 4, onDelete = {}, onSend = {})
        VoiceRecorder(state = RecorderState.Hold) // press and hold: release to send, slide left to cancel
        VoiceRecorder(state = RecorderState.Cancel) // slid left: release to cancel
    }
}
```

Example: Task conversation
```tsx
<AssistantTaskHeader title="Setting up a reminder for appointment at Dr. Mehta’s" onClose={close} />
<AssistantThinking />
<AssistantReplies onEdit={edit} onConfirm={confirm} />
```
```kotlin
EqualTheme {
    Column(Modifier.background(EqualTheme.colors.chatWallpaperBg)) {
        AssistantTaskHeader(title = "Setting up a reminder for appointment at Dr. Mehta\u2019s", onClose = { /* close */ })
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            AssistantThinking()
            AssistantReplies(onEdit = { /* edit */ }, onConfirm = { /* confirm */ })
        }
    }
}
```

Example: Carousel dots
```tsx
<CarouselDots count={3} active={0} />
```
```kotlin
EqualTheme {
    CarouselDots(count = 3, active = 0)
}
```

Example: Reply card
```tsx
<AssistantReplyCard time="03:21" actions={[{ label: 'Edit', emoji: '✏️', onClick: edit }, { label: 'Send', emoji: '📤', onClick: send }]}>
  {draft}
</AssistantReplyCard>
```
```kotlin
EqualTheme {
    Column(Modifier.background(EqualTheme.colors.chatWallpaperBg).padding(16.dp)) {
        AssistantReplyCard(
            text = "Sure! Here\u2019s a draft for Amit:\n\nHi Amit! Count me in for Sunday 8 PM. See you there \uD83D\uDC4D",
            time = "03:21",
            actions = listOf(
                ReplyAction(label = "Edit", emoji = "\u270F\uFE0F", onClick = { /* edit */ }),
                ReplyAction(label = "Send", emoji = "\uD83D\uDCE4", onClick = { /* send */ }),
            ),
        )
    }
}
```

Example: Chat task sheet
```tsx
<ChatScreen chat={amit} />               // tap Reply on WhatsApp or send a message
<ChatTaskSheet contact="Amit" request={text} onClose={close} onSend={openWhatsApp} />
```
```kotlin
EqualTheme {
    // From a chat's AI layer (Reply on WhatsApp, or a sent message): stops below the chat header
    ChatTaskSheet(
        contact = "Amit",
        request = "Reply on whatsapp",
        onClose = { /* close */ },
        onSend = { /* open WhatsApp */ },
    )
}
```

#### Chat actions (`chat-actions`)

What the AI layer uses to carry out a task in a chat and to fail well: the assistant’s turn, Hold to speak, the edit-in-place bubble, the new contact form (two parity options), the permission dialog and the offline sheet and screen.

- React: `import { AiTurn, HoldToSpeakBar, EditBubble, NewContactForm, PermissionDialog, OfflineSheet, OfflineScreen } from '@equal/ds';`
- Compose: `AiTurn`, `HoldToSpeakBar`, `EditBubble`, `NewContactForm`, `PermissionDialog`, `OfflineSheet`, `OfflineScreen`, `DialerStandIn`
- Tokens: `button/primary`, `bg/surface`, `gradient/offline-screen`, `action/stroke/unread`
- Source: Flows/Call Back · Mute · Reply On WhatsApp · Save Contact · Error states

Props of `NewContactForm`:
- `value`: `{ first; last?; phone; email?; sync? }`. Pre-filled from the call.
- `variant?`: `'grouped' | 'outlined'` = 'grouped'. iOS-revamp parity or exact WhatsApp parity.
- `onSave?`: `() => void`. Save.

Props of `EditBubble`:
- `value`: `string`. The draft.
- `onChange?`: `(v: string) => void`. Typing.
- `onDone?`: `() => void`. Green check.

Props of `AiTurn`:
- `children`: `ReactNode`. What the assistant says.
- `actions?`: `{ label; emoji; onClick? }[]`. Action rows, emoji first.

Do: Confirm before anything the user can’t easily undo (mute, send, save). Leave the result in the chat as an action card, so the chat is the record of what the assistant did. On failure, say what happened in one line and offer the one action that fixes it.

Don't: Don't draw the dialer, Settings or WhatsApp; they belong to the phone. Hand off and show the result when the user comes back. Don't lose the user’s place: after Settings, offer to continue where they stopped.

Anatomy:
1. AiTurn: The assistant's turn: orb and reply card. (28 orb · gap 8 · AssistantReplyCard 280 wide, radius 16, bg/surface · sender body2 text/action · body1 · time micro · 48 emoji + label rows in text/action)
2. HoldToSpeakBar: Voice-first input with a keyboard toggle. (52 pill bg/surface, 1dp action/stroke/unread · mic 20 + button label · 48 keyboard circle)
3. EditBubble: Edit a draft in place above the keyboard. (textarea radius 20, padding 12/16, bodyLarge, grows to 300 · 48 green Done circle with check 24)
4. NewContactForm: New contact form in two parity variants. (header: close, 'New contact' title Medium, sm Save · grouped: radius 16 groups on sheet/bg · outlined: 48 fields, radius 8, 1dp stroke/dark (focus button/primary), floating label · Sync switch)
5. PermissionDialog: Centred permission ask over a dimmed chat. (black 45% scrim · card radius 24, padding 24/16/16 · 36 close (48 touch) · 84 art · title Medium · body1 text/secondary · block lg CTA)
6. OfflineSheet / OfflineScreen: No-internet sheet over a chat, and the full screen. (sheet radius 28 top bg/surface, 64 art, Refresh · screen gradient/offline-screen, 120 art, Try again pinned at the bottom)
7. DialerStandIn: Coded stand-in for the phone's dialer in docs. (dark #1F2125 surface · 40 number · 60 keys · 128 × 56 red end button)

Accessibility:
- Role. Web: Buttons for Hold to speak, Type instead, Done, Save, Close and action rows; EditBubble is a textarea; outlined fields are inputs inside <label>; Sync is a switch; PermissionDialog is role=dialog; OfflineSheet is role=alertdialog; DialerStandIn is a div with aria-label (ignored without a role). Android: Role.Button on actions; BasicTextField fields with contentDescription; PermissionDialog and OfflineSheet set paneTitle; DialerStandIn has contentDescription 'Calling …'.
- Name. Web: 'Edit message', 'Done', 'Type instead', 'Close', 'Sync contact to phone'; outlined fields named by their label text; grouped values are plain text, not fields. Android: Same strings; outlined field labels are cleared and repeated as the field's contentDescription.
- Keyboard. Web: Tab through fields and buttons; Hold to speak works with Enter/Space as a tap. PermissionDialog doesn't trap focus or close on Escape; OfflineSheet has no close by design. Android: TalkBack: double-tap Hold to speak; edit fields with the IME. System Back is not handled by the overlays.
- Touch target. Web: Done and keyboard circle 48; dialog close 36 with eq-touch (48); Save sm 24 with eq-touch (48); lg buttons 45 px with no extension. Android: Done and keyboard 48dp; SmallCloseButton has a 48dp box; EqualButton 48dp minimum.
- Contrast. Web: Done check and Save/Refresh/Try again labels are white on green, 2.85:1 in light; reply-card actions text/action on white 2.85:1. Body text/secondary 7.5:1. Dark is lime with black content. Android: Same tokens and ratios as web.
- State. Web: Switch exposes checked; focused fields get the green border (not the only cue, the caret shows). Offline is said in text. Android: Switch toggleable state; focus border as on web.
- Motion. Web: PermissionDialog pops in (couponSpring) and OfflineSheet slides up; both stop under prefers-reduced-motion. Android: Both start visible under rememberReduceMotion.

Known accessibility gaps:
- PermissionDialog in ChatActions.tsx is role=dialog with no focus move, trap or Escape handling.
- DialerStandIn in ChatActions.tsx puts aria-label on a div with no role, so it isn't announced.
- EditBubble Done (white check on button/primary) and primary Save/Refresh/Try again buttons are 2.85:1 in light theme.
- Button lg (Refresh, Try again, Save, permission CTA) is 45 px tall on web with no touch extension.

Example: Assistant turn
```tsx
<AiTurn actions={[{ label: 'Mute', emoji: '🔕', onClick: mute }]}>Are you sure? …</AiTurn>
```
```kotlin
EqualTheme {
    AiTurn(
        text = "Are you sure? You’ll not get any call from them even if it’s important",
        actions = listOf(ReplyAction(label = "Mute", emoji = "🔕", onClick = { /* mute */ })),
    )
}
```

Example: Hold to speak
```tsx
<HoldToSpeakBar onHold={record} onKeyboard={showKeyboard} />
```
```kotlin
EqualTheme {
    HoldToSpeakBar(onHold = { /* record */ }, onKeyboard = { /* show keyboard */ })
}
```

Example: Edit bubble
```tsx
<EditBubble value={draft} onChange={setDraft} onDone={save} autoFocus />
```
```kotlin
EqualTheme {
    var draft by remember { mutableStateOf("Hi Amit! Count me in for Sunday 8 PM. See you there 👍") }
    // Over the chat dimmed with EditDimColor; lift above the keyboard with imePadding()
    Box(Modifier.background(EditDimColor)) {
        EditBubble(value = draft, onValueChange = { draft = it }, onDone = { /* save */ }, autoFocus = true)
    }
}
```

Example: New contact: iOS parity
```tsx
<NewContactForm variant="grouped" value={contact} onClose={close} onSave={save} />
```
```kotlin
EqualTheme {
    NewContactForm(
        value = NewContactValue(first = "Rahul (Electrician)", phone = "+91 98717 46113"),
        variant = NewContactVariant.Grouped,
        onClose = { /* close */ },
        onSave = { /* save */ },
    )
}
```

Example: New contact: WhatsApp parity
```tsx
<NewContactForm variant="outlined" value={contact} onSave={save} onSync={setSync} />
```
```kotlin
EqualTheme {
    var sync by remember { mutableStateOf(true) }
    NewContactForm(
        value = NewContactValue(first = "Rahul (Electrician)", phone = "+91 98717 46113", sync = sync),
        variant = NewContactVariant.Outlined,
        onSave = { /* save */ },
        onSync = { sync = it },
    )
}
```

Example: Offline
```tsx
<OfflineSheet onRefresh={refresh} />   // over a chat
<OfflineScreen onRetry={retry} />    // nothing to show yet
```
```kotlin
EqualTheme {
    OfflineSheet(onRefresh = { /* refresh */ })   // over a chat
    OfflineScreen(onRetry = { /* retry */ })      // nothing to show yet
}
```

### Group: Cards

#### Action card (`action-card`)

A card for something the assistant did or proposes (a WhatsApp reply, an appointment, a saved rule), with stacked actions underneath.

- React: `import { ActionCard, ActionCardBody, instructionLines } from '@equal/ds';`
- Compose: `ActionCard`
- Tokens: `bg/surface`, `bg/primary`, `stroke/subtle`, `text/primary`, `text/secondary`, `text/tertiary`, `text/action`, `button/primary`
- Source: §14 Action Card

Do: Put the positive action first (Confirm, Send), then the revise (Edit). Both are text rows. Name the source in the title ("WhatsApp · Amit Nanda") so the user knows where the action goes. Lead every action with its emoji (📤 Send, ✏️ Edit, 👍 Confirm, 🗑️ Delete).

Don't: Don't use a filled button inside an action card, not even for Confirm. Don't use a 3D category avatar for an instruction; use the note_stack icon with When / Do lines. Don't put the card on a green card; the grey body always sits on a white card. Don't use flat icons in action labels; the rows are emoji + text.

Anatomy:
1. Card: White card that frames the body and actions. (width 268 · bg/surface · radius 16 · padding 8 around the body)
2. Body: Grey quote block. (bg/primary · radius 12 · padding 8 · gap 12)
3. Source circle: Category avatar, Material icon or WhatsApp logo. (40 circle · bg/surface · icon 22 text/action · whatsapp brand/whatsapp)
4. Title: Where the action goes. (body2 · text/primary)
5. Quote / details: The quoted message or detail lines (When / Do for instructions). (body1 · text/secondary (primary / tertiary by tone))
6. Timestamp: When it happened. (micro · text/tertiary · right)
7. Action rows: Full-width emoji + label actions under dividers. (44 high · divider stroke/subtle · emoji 14 · gap 6 · button text/action (danger text/danger))

Accessibility:
- Role. Web: Each action is a <button> (TextButton); the body is text. Android: Each row is clickable(role = Role.Button); the body is text.
- Name. Web: Action names come from the label; the emoji is aria-hidden; WhatsApp logo is role=img "WhatsApp"; category avatar uses its alt. Android: Rows read the emoji glyph and the label; WhatsApp icon contentDescription "WhatsApp"; Material icon is null.
- Keyboard. Web: Tab to each action; Enter/Space activates. Android: TalkBack: swipe to each row, double-tap.
- Touch target. Web: Rows are 44 px high, full width, with eq-touch (48 px hit). Android: Rows are 44 dp high, plain clickable.
- Contrast. Web: Body text/secondary 7:1 and text/tertiary 4.8:1 on bg/primary. Action labels and the instruction icon use text/action: In light, text/action #00B140 on white is 2.85:1, below 4.5:1 for text; in dark it is lime #BAFF29 (13:1 on bg/surface #222222). Danger #C50000 passes. Android: Same tokens.
- State. Web: No state; danger is shown by red and the label (Delete). Android: Same.
- Motion. Web: No animation. Android: No animation.

Known accessibility gaps:
- Action row labels and the instruction icon use text/action #00B140 on white (2.85:1) in light (ActionCard.tsx, Cards.kt).
- Compose action rows draw the emoji with EmojiGlyph, so TalkBack reads it before the label (Cards.kt).
- Compose action rows are 44 dp with no minimumInteractiveComponentSize (Cards.kt).

Example: WhatsApp reply
```tsx
<ActionCard source="whatsapp" title="WhatsApp · Amit Nanda"
  quote="“Count me in for Sunday 8 PM 👍”" time="03:21"
  actions={[{ label: 'Send', emoji: '📤' }, { label: 'Edit reply', emoji: '✏️' }]} />
```
```kotlin
// The coded WhatsApp logo is the default when no category or icon is set
ActionCard(
    title = "WhatsApp · Amit Nanda",
    quote = "“Count me in for Sunday 8 PM 👍”",
    timestamp = "03:21",
    actions = listOf(
        ActionCardAction("Send", emoji = "📤", onClick = {}),
        ActionCardAction("Edit reply", emoji = "✏️", onClick = {}),
    ),
)
```

Example: Appointment: Confirm + Edit
```tsx
<ActionCard category="others" title="Dr. Mehta's Clinic Appointment"
  details={[
    { text: 'Tomorrow, 9:00 AM' },
    { text: 'Bring previous medical reports', tone: 'secondary' },
  ]}
  time="03:21"
  actions={[{ label: 'Confirm', emoji: '👍' }, { label: 'Edit', emoji: '✏️' }]} />
```
```kotlin
ActionCard(
    category = EqualCategory.Others,
    title = "Dr. Mehta's Clinic Appointment",
    lines = listOf(
        ActionCardLine("Tomorrow, 9:00 AM"),
        ActionCardLine("Bring previous medical reports", ActionCardTone.Tertiary),
    ),
    timestamp = "03:21",
    actions = listOf(
        ActionCardAction("Confirm", emoji = "👍", onClick = {}),
        ActionCardAction("Edit", emoji = "✏️", onClick = {}),
    ),
)
```

Example: Instruction saved
```tsx
<ActionCard icon="instructions" title="Instruction saved"
  details={instructionLines('Delivery agents call', 'Ask them to leave parcels with security')}
  time="03:21" actions={[{ label: 'Edit rule', emoji: '✏️' }]} />
```
```kotlin
ActionCard(
    icon = EqualIcons.Instructions,
    title = "Instruction saved",
    lines = instructionLines("Delivery agents call", "Ask them to leave parcels with security"),
    timestamp = "03:21",
    actions = listOf(ActionCardAction("Edit rule", emoji = "✏️", onClick = {})),
)
```

Example: Instruction (body only)
```tsx
<ActionCardBody icon="instructions" title="Instructions"
  details={instructionLines('Bank calls come', 'Tell callers I’ll call back after 6 PM')}
  time="03:21" />
```
```kotlin
ActionCardBody(
    icon = EqualIcons.Instructions,
    title = "Instructions",
    lines = instructionLines("Bank calls come", "Tell callers I’ll call back after 6 PM"),
    timestamp = "03:21",
)
```

#### Assistant toggle (`assistant-toggle`)

The card at the top of Chats and the You tab that turns the AI assistant on or off, with the mascot dimming when it is off.

- React: `import { AssistantToggle } from '@equal/ds';`
- Compose: `AssistantToggleCard`
- Tokens: `assistant-toggle/bg`, `bg/surface`, `stroke/subtle`, `text/primary`, `text/secondary`, `button/primary`, `button/disabled`, `action/stroke/unread`
- Source: §3 Assistant Availability Toggle

Do: Put it directly under the top bar on Chats (HomeHeader does this) and first under YOUR ASSISTANT on the You tab. Let the default copy explain the state: on manages unknown calls, off lets them ring normally.

Don't: Don't crop or replace the mascot; it dims itself when off. Don't add a Save button; the change applies immediately.

Anatomy:
1. Card: Rounded card whose fill shows on or off. (min height 64 · padding 12 10 12 12 · radius 20 · on: gradient/assistant-toggle · off: bg/surface + 1 px stroke/subtle)
2. Mascot: Robot mascot that greys out when off. (36 · off: greyscale, opacity 0.7)
3. Title: States on or off. (subheading · text/primary · "AI Assistant is On / Off")
4. Description: What the state means. (caption Regular · text/secondary · one line)
5. Switch: The control. (track 40 × 24 · thumb 18 · on button/primary, thumb text/on-action · off button/disabled)

Accessibility:
- Role. Web: Only the switch is interactive: <button role="switch">; the mascot is role=img. Android: The whole card is toggleable(role = Role.Switch); the inner EqualSwitch is visual only.
- Name. Web: Switch aria-label "AI Assistant"; mascot aria-label "Equal assistant". Android: Merged card text: mascot "Equal assistant", title and description.
- Keyboard. Web: Tab to the switch; Space/Enter toggles; the change applies at once. Android: TalkBack: one stop for the card, double-tap to toggle.
- Touch target. Web: Switch is 40 × 24 with eq-touch for a 48 px hit area; the rest of the card is not tappable. Android: Whole 64 dp card is the target.
- Contrast. Web: Title text/primary and description text/secondary on both fills. Switch track is weak: off #DDDDDD on white 1.36:1, on #00B140 2.85:1 in light. Android: Same tokens.
- State. Web: aria-checked on the switch, and the title spells On/Off, so not colour alone. Android: toggleable exposes checked; title and description change with state.
- Motion. Web: Track, thumb, card and mascot transitions go to 0 ms under prefers-reduced-motion. Android: EqualSwitch animates over 500 ms, 0 ms when Remove animations is on; card fill changes instantly.

Known accessibility gaps:
- Switch off track button/disabled #DDDDDD on white is 1.36:1, below 3:1 for a control boundary (Switch.css, EqualSwitch.kt); the title text does state On/Off.

Example: Interactive
```tsx
const [on, setOn] = useState(true);

<AssistantToggle on={on} onChange={setOn} />
```
```kotlin
var on by remember { mutableStateOf(true) }
AssistantToggleCard(checked = on, onCheckedChange = { on = it })
```

Example: On and off
```tsx
<AssistantToggle on />
<AssistantToggle on={false} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    AssistantToggleCard(checked = true, onCheckedChange = {})
    AssistantToggleCard(checked = false, onCheckedChange = {})
}
```

#### Feedback card (`feedback-card`)

The post-call card that asks the user to rate the call from one to five stars and share feedback.

- React: `import { FeedbackCard } from '@equal/ds';`
- Compose: `FeedbackCard`
- Tokens: `bg/surface`, `rating/star-filled`, `rating/star-empty`, `text/placeholder`, `stroke/subtle`, `text/action`
- Source: §13 Feedback Card

Do: Show it once, right after the call summary, indented to line up with the summary bubble. Keep the question short and about the call itself.

Don't: Don't add a text field to the card; Share Feedback opens the next step. Don't use emoji or images for the stars; they are coded.

Anatomy:
1. Card: White card for the rating. (width 246 · bg/surface · radius 12)
2. Question: Asks the user to rate the call. (body1 · text/primary · padding 12 10 10)
3. Stars: Five tappable stars. (32 px (web) / 28 dp (Compose) · gap 8 · filled rating/star-filled · empty outline text/placeholder)
4. Divider: Separates the rating from the action. (1 px stroke/subtle)
5. Share Feedback: Sends the rating. (40 high (web) / 36 dp (Compose) · button text/action · chevron-right)

Accessibility:
- Role. Web: Stars are <button role="radio"> in a role="radiogroup" aria-label "Rating"; Share is a <button>. Android: Stars use selectable(role = Role.RadioButton); the Row has no selectableGroup(); Share row is Role.Button.
- Name. Web: Stars aria-label "1 star" … "5 stars"; Share from its text. Android: Star icon contentDescription "1 star" … "5 stars"; Share reads "Share Feedback".
- Keyboard. Web: Each star is its own Tab stop; arrow keys do nothing, though a radiogroup should move with arrows. Android: TalkBack: swipe through stars, double-tap to rate.
- Touch target. Web: Stars are 32 × 32 px with no eq-touch; Share is a TextButton with eq-touch (48 px). Android: Stars are 28 dp with no minimumInteractiveComponentSize; Share row is 36 dp.
- Contrast. Web: Empty star #AAAAAA on white 2.3:1 and filled #FFC700 1.56:1, both below 3:1 in light (dark passes). Share is text/action: In light, text/action #00B140 on white is 2.85:1, below 4.5:1 for text; in dark it is lime #BAFF29 (13:1 on bg/surface #222222). Android: Same tokens.
- State. Web: aria-checked on the chosen star; filled vs outline shape also shows the rating. Android: selected on the chosen star; filled vs outline icon.
- Motion. Web: Star fill transition and press scale go to 0 ms under reduced motion; hover previews the rating. Android: No animation.

Known accessibility gaps:
- Star radios have no arrow-key navigation or roving tabindex (FeedbackCard.tsx).
- Stars are 32 px (FeedbackCard.tsx) and 28 dp (Cards.kt) with no 48 dp touch target.
- Star colours fail 3:1 in light: empty #AAAAAA 2.3:1, filled #FFC700 1.56:1 on white (FeedbackCard.tsx, Cards.kt).
- Compose star Row is missing Modifier.selectableGroup() (Cards.kt).
- Share Feedback row is 36 dp high with plain clickable (Cards.kt).
- Share Feedback uses text/action #00B140 on white (2.85:1) in light (FeedbackCard.tsx, Cards.kt).

Example: Interactive
```tsx
const [rating, setRating] = useState(0);

<FeedbackCard rating={rating} onRate={setRating} onShare={(r) => submit(r)} />
```
```kotlin
var rating by remember { mutableIntStateOf(0) }
FeedbackCard(
    question = "How would you rate the call?",
    rating = rating,
    onRatingChange = { rating = it },
    // Compose: the share callback takes no argument; read `rating` from state
    onShareFeedbackClick = {},
)
```

Example: Rated
```tsx
<FeedbackCard rating={4} />
```
```kotlin
// Compose: always controlled, so the question and rating callback are required
FeedbackCard(
    question = "How would you rate the call?",
    rating = 4,
    onRatingChange = {},
    onShareFeedbackClick = {},
)
```

#### Meet Your Assistant card (`meet-assistant-card`)

Introduces the voice assistant with its persona avatar and a “Call me” pill. Compact on Chats once the assistant is back; banner as a standalone promo.

- React: `import { MeetAssistantCard } from '@equal/ds';`
- Compose: `MeetAssistantCard`
- Tokens: `gradient/meet-assistant`, `gradient/call-me`, `text/primary`, `text/action`, `text/secondary`, `text/on-action`, `text/placeholder`
- Source: Flows: Temporarily Unavailable

Do: Use the compact layout in the Chats promo slot, the same slot as What’s New. Keep “Call me” as the only action.

Don't: Don’t show it together with a What’s New card. Don’t crop or recolour the avatar-assistant art; the orb badge is part of the file.

Anatomy:
1. Card: Green-tint promo card. (gradient/meet-assistant · compact radius 16, padding 14 16 · banner radius 20, padding 20 16 20 18)
2. Assistant avatar: Persona art with the orb badge. (compact 84 × 94 left · banner 100 × 112 right)
3. Title: Meet Your Assistant. (compact subheading text/primary · banner title Bold text/action)
4. Body: Banner only. (body1 · text/secondary)
5. Call me pill: Starts a call with the assistant. (CallMeButton 40 high (52 block) · padding 0 22 0 18 · gradient/call-me · call-sparkle 18 · button text/on-action)
6. Close: Optional dismiss. (32 · icon 20 · text/placeholder · top 6 right 6)

Accessibility:
- Role. Web: Title is an <h3>; Call me and close are <button>s; avatar is an img. Android: Call me Row Role.Button; close Box Role.Button; title plain text.
- Name. Web: Avatar alt "Your assistant"; Call me from its label (icon aria-hidden); close aria-label "Dismiss". Android: Avatar contentDescription "Your assistant"; Call me reads its label; close "Dismiss".
- Keyboard. Web: Tab to Call me, then Dismiss; Enter/Space activates. Android: TalkBack: swipe to the avatar, title, Call me, Dismiss.
- Touch target. Web: Call me is 40 px high with no eq-touch (52 in block); close 32 px with eq-touch (48). Android: Call me 40 dp plain clickable; close 32 dp plain clickable.
- Contrast. Web: Compact title text/primary. Banner title text/action on the tint is 2.56:1 in light; Call me white on the green gradient is 2.85:1 or less. In dark both are lime with black text (17:1). Android: Same tokens.
- State. Web: No state. Android: No state.
- Motion. Web: Static. Android: Static.

Known accessibility gaps:
- Call me pill is 40 dp high with no 48 dp target (SystemStatus.tsx CallMeButton, SystemStatus.kt CallMeButton).
- Call me label white on gradient/call-me is 2.85:1 or less in light (SystemStatus.tsx, SystemStatus.kt).
- Banner and hero titles use text/action #00B140 on the tint (2.56:1), below 3:1 even as large text, in light (SystemStatus.tsx, SystemStatus.kt).
- Close button is 32 dp with no minimumInteractiveComponentSize (SystemStatus.kt).
- Avatar art is announced as "Your assistant" though the title already says it; it could be decorative (SystemStatus.tsx, SystemStatus.kt).

Example: Compact (Chats)
```tsx
<MeetAssistantCard onCall={startAssistantCall} onDismiss={dismiss} />
```
```kotlin
MeetAssistantCard(onCallClick = {}, onDismiss = {})
```

Example: Banner
```tsx
<MeetAssistantCard layout="banner" onCall={startAssistantCall} onDismiss={dismiss} />
```
```kotlin
MeetAssistantCard(layout = MeetAssistantLayout.Banner, onCallClick = {}, onDismiss = {})
```

#### System status card (`system-status-card`)

Takes the assistant toggle’s place on Chats while Equal AI is down: a SYSTEM STATUS pill, the sleeping robot, and a “Notify me when ready” pill that turns into a confirmation.

- React: `import { SystemStatusCard } from '@equal/ds';`
- Compose: `SystemStatusCard`
- Tokens: `gradient/status-card`, `component/status-card/pill-bg`, `component/status-card/button`, `component/status-card/button-text`, `text/primary`, `text/secondary`, `text/action`
- Source: Flows: Temporarily Unavailable

Do: Put it where the assistant toggle sits (HomeHeader `status`), so the outage reads as the assistant’s state. Hide promo cards (What’s New, Meet Your Assistant) while the card is showing.

Don't: Don’t show it for a single failed call; it means the whole service is down. Don’t keep the Notify pill tappable after the user has subscribed.

Anatomy:
1. Card: Warm gradient card in the assistant toggle's place. (min height 140 · radius 20 · padding 16 · gradient/status-card)
2. Status pill: SYSTEM STATUS label. (20 high · padding 0 8 · radius full · status-card/pill-bg · overline 10 · text/secondary)
3. Title: Temporarily Unavailable. (18/24 Bold · text/primary · one line)
4. Body: Short reassurance. (caption Regular · text/secondary · max width 190)
5. Notify pill: Subscribe to the recovery notice. (32 high · padding 0 14 0 12 · status-card/button · status-card/button-text · notify-me 16 · buttonSmall Bold)
6. Confirmation: Replaces the pill after the tap. (check 16 · buttonSmall Bold · text/action)
7. Sleeping mascot: Decorative art on the right. (104 · right 0 · vertically centred)

Accessibility:
- Role. Web: Card is role="status" with an <h3> title; Notify is a <button>; the mascot is alt="". Android: Card has liveRegion = Polite; Notify pill is clickable(role = Role.Button); title is plain text; mascot has no contentDescription.
- Name. Web: Notify from its text "Notify me when ready"; the notify icon is aria-hidden. Android: Notify reads its text; icons are null.
- Keyboard. Web: Tab to Notify; Enter/Space. After the tap the button is removed, so focus is lost. Android: TalkBack: swipe to Notify, double-tap; the live region announces the change.
- Touch target. Web: Notify pill is 32 px high with no eq-touch. Android: Notify pill is 32 dp with plain clickable.
- Contrast. Web: Title text/primary; body text/secondary 6.4:1; pill text #3D2600 on #FAAF39 7.6:1. Confirmation text/action on the gradient is about 2.4:1 in light; lime in dark. Android: Same tokens.
- State. Web: "notified" swaps the button for text with a check icon, so not colour alone; role=status announces it. Android: Same, announced through the polite live region.
- Motion. Web: Static. Android: Static.

Known accessibility gaps:
- Notify pill is 32 px / 32 dp high with no 48 dp target (SystemStatus.tsx, SystemStatus.kt).
- After Notify is tapped the button unmounts and keyboard focus is lost; move focus to the confirmation (SystemStatus.tsx).
- Notified confirmation uses text/action #00B140 on gradient/status-card (about 2.4:1) in light (SystemStatus.tsx, SystemStatus.kt).
- Compose title has no semantics { heading() } (SystemStatus.kt).

Example: Unavailable
```tsx
<SystemStatusCard onNotify={subscribeToRecovery} />
```
```kotlin
SystemStatusCard(state = SystemStatusState.Unavailable, onNotifyClick = {})
```

Example: Notify requested
```tsx
<SystemStatusCard state="notified" />
```
```kotlin
// The confirmation is not tappable, so onNotifyClick is never called in this state
SystemStatusCard(state = SystemStatusState.Notified, onNotifyClick = {})
```

Example: In the Chats header
```tsx
<HomeHeader assistantOn={on} status={down ? <SystemStatusCard state={notify} onNotify={subscribe} /> : undefined} />
```
```kotlin
var on by remember { mutableStateOf(true) }
var notify by remember { mutableStateOf(SystemStatusState.Unavailable) }
val down = true
HomeHeader(
    assistantOn = on,
    onAssistantChange = { on = it },
    status = if (down) {
        { SystemStatusCard(state = notify, onNotifyClick = { notify = SystemStatusState.Notified }) }
    } else {
        null
    },
)
```

#### What's New card (`whats-new-card`)

A dismissible announcement card with the NEW FEATURE badge, a heading, body copy and one CTA. Built in three layers: a flat fill, a blurred circle in the bottom-right corner, and the illustration on top of the circle.

- React: `import { WhatsNewCard } from '@equal/ds';`
- Compose: `WhatsNewCard`
- Tokens: `whats-new/bg`, `whats-new/glow`, `badge/new-feature-stroke`, `text/action`, `text/secondary`, `text/placeholder`, `button/primary`
- Source: §22 What's New Card

Do: Keep the body to about two lines and one CTA that goes straight to the feature. Always offer onDismiss on the Chats list so the card can go away.

Don't: Don't stack more than one What's New card at a time. Don't add a second button; the card has a single commit.

Anatomy:
1. Card: Flat green-tint card with clipped layers. (width 322 · min height 172 · radius 20 · whats-new/bg · padding 18 16 18 18)
2. Glow: Blurred circle bottom-right. (150 circle blur 32 (web) / 230 dp radial gradient (Compose) · whats-new/glow)
3. Illustration: Robot art on the right. (125 · right 4 · top 35)
4. Feature badge: NEW FEATURE pill. (24 high · bg/surface · 1 px badge/new-feature-stroke · ⭐ 11 · badge text/secondary)
5. Heading: What the feature is. (18/24 Bold · text/action)
6. Body: About two lines. (caption Regular · text/secondary)
7. CTA: One filled button. (Button md 36 high · leading icon · button/primary · text/on-action)
8. Close: Optional dismiss. (32 · icon 22 · text/placeholder · top 8 right 8)

Accessibility:
- Role. Web: Heading is an <h3>; CTA and close are <button>s; illustration and glow are decorative (alt="", aria-hidden). Android: Heading is plain text (no heading()); CTA EqualButton Role.Button; close Box Role.Button.
- Name. Web: CTA from its label; close aria-label "Dismiss". Android: CTA from its label; close icon contentDescription "Close".
- Keyboard. Web: Tab to the CTA, then Dismiss; Enter/Space activates. Android: TalkBack: swipe to CTA and Close.
- Touch target. Web: CTA is a 36 px md button with no eq-touch; close is 32 px with eq-touch (48 px). Android: CTA uses minimumInteractiveComponentSize (48 dp); close is 32 dp plain clickable.
- Contrast. Web: Body text/secondary 6.9:1. Heading text/action on #EAFBE6 is 2.6:1 and close #AAAAAA 2.15:1 in light; in dark lime heading is 11.9:1. CTA text white on #00B140 2.85:1 (black on lime in dark 17:1). Android: Same tokens.
- State. Web: No state. Android: No state.
- Motion. Web: Static; button press scale goes to 0 ms under reduced motion. Android: Static.

Known accessibility gaps:
- Heading text/action #00B140 on whats-new/bg is 2.6:1 in light, below 4.5:1 for 18 px text (WhatsNewCard.tsx, Cards.kt).
- Close icon text/placeholder #AAAAAA on whats-new/bg is 2.15:1, below 3:1 (WhatsNewCard.tsx, Cards.kt).
- CTA Button md is 36 px high with no eq-touch, below 48 px (Button.tsx / WhatsNewCard.tsx).
- Close button is 32 dp with no minimumInteractiveComponentSize (Cards.kt).
- Compose heading has no semantics { heading() } (Cards.kt).
- Primary button label white on #00B140 is 2.85:1 in light (Button.css, Buttons.kt).

Example: Default
```tsx
<WhatsNewCard width="100%" heading="Language Preference"
  body="Set your preferred language and choose how your assistant sounds"
  ctaLabel="Try Voices" ctaIcon="translate" onCta={openVoices} onDismiss={dismiss} />
```
```kotlin
WhatsNewCard(
    title = "Language Preference",
    body = "Set your preferred language and choose how your assistant sounds",
    buttonLabel = "Try Voices",
    buttonIcon = EqualIcons.Translate,
    onButtonClick = {},
    onCloseClick = {},
)
```

Example: Custom badge and icon, not dismissible
```tsx
<WhatsNewCard width="100%" badge="Just added" heading="Instructions"
  body="Tell your assistant how to handle deliveries, sales calls and more."
  ctaLabel="Add instruction" ctaIcon="add" />
```
```kotlin
WhatsNewCard(
    badgeText = "Just added",
    title = "Instructions",
    body = "Tell your assistant how to handle deliveries, sales calls and more.",
    buttonLabel = "Add instruction",
    buttonIcon = EqualIcons.Add,
    onButtonClick = {},
    onCloseClick = null, // null hides the close (X)
)
```

### Group: Chat

#### AI panel (`ai-panel`)

The assistant's bottom panel inside a conversation: a suggestion from the orb, large action chips and a composer; AiSuggestion is the avatar-plus-prompt line on its own.

- React: `import { AiChatPanel, AiSuggestion } from '@equal/ds';`
- Compose: `AiChatPanel`, `AiSuggestion`
- Tokens: `bg/surface`, `text/secondary`, `text/primary`, `gradient/chip-large`, `action/stroke/unread`
- Source: §12b AI Chat — Within other conversation · §16 AI Suggestion

Do: Phrase the prompt as a question the user can answer with one chip ("Want me to send Amit a quick reply on WhatsApp?"). Offer at most two or three emoji chips, the most likely one first. Hide the composer (composer={false}) when only a quick decision makes sense, like during a live call.

Don't: Don't put a filled Button in the panel; the actions are large chips. Don't write the prompt in green; the assistant's words are text/secondary here.

Anatomy:
1. Panel: Bottom sheet-like panel with rounded top corners. (bg/surface · radius 24 24 0 0 · padding 20 16 16 · shadow 0 -4 16)
2. Suggestion: Equal orb and the assistant's prompt. (AiAvatar 36 · gap 12 · body1 text/secondary)
3. Action chips: Horizontally scrolling row of large emoji chips. (margin-top 20 (web) / 24 (Compose) · gap 6 · LargeActionChip 40 high · gradient/chip-large · 1 px action/stroke/unread · button text/primary)
4. Composer: Message input with the send button. (margin-top 16 (web) / 20 (Compose) · input 45 high radius full · send 45 circle)
5. AiSuggestion: line: Avatar plus prompt on its own. (AiAvatar 36 · gap 12 · body1 · tone primary or secondary (web))

Accessibility:
- Role. Web: Panel is a <section>; chips are <button>s; composer is a <form> with an <input> and a submit <button>. Android: Column; chips clickable(role = Role.Button); VoiceInputBar is a BasicTextField plus a Role.Button send.
- Name. Web: Orb role=img "Equal AI"; chips from their label (emoji is aria-hidden); input aria-label "Message"; send aria-label "Send". Android: AiAvatar "Equal AI"; chips read label and the emoji glyph; send contentDescription "Send"; the text field has no label beyond the placeholder.
- Keyboard. Web: Tab through chips, input and send; Enter submits; send is disabled while the input is empty. Android: TalkBack: swipe to chips, field and send; IME Send action submits.
- Touch target. Web: Chips are 40 px high with no eq-touch; send is 45 px. Android: Chips use minimumInteractiveComponentSize (48 dp); send is 45 dp.
- Contrast. Web: Prompt text/secondary 7.5:1 on white; chip text text/primary; placeholder text/tertiary 5.1:1. Chip border #9DDDB4 is 1.56:1 but the text marks the control. Android: Same tokens.
- State. Web: Send uses the native disabled attribute when empty. Android: Send clickable enabled = false when empty; disabled chips draw at 45% and ignore taps.
- Motion. Web: eq-pressable press scale and composer border transitions go to 0 ms under reduced motion. Android: Press feedback only.

Known accessibility gaps:
- LargeActionChip is 40 px high with no eq-touch (ActionChip.css), below the 48 px target on web.
- Compose LargeActionChip draws the emoji with EmojiGlyph, which TalkBack reads aloud; web hides it (ActionChips.kt).
- VoiceInputBar text field has no accessible label, only placeholder text (Composer.kt).

Example: After a call
```tsx
<AiChatPanel
  prompt="Want me to send Amit a quick reply on WhatsApp?"
  actions={[
    { label: 'Reply on WhatsApp', emoji: '💬' },
    { label: 'Add to Calendar', emoji: '🗓️' },
  ]}
  composer={{ onSend: send }} />
```
```kotlin
var draft by remember { mutableStateOf("") }

AiChatPanel(
    prompt = "Want me to send Amit a quick reply on WhatsApp?",
    actions = listOf(
        ActionChipData("Reply on WhatsApp", "💬"),
        ActionChipData("Add to Calendar", "🗓️"),
    ),
    onActionClick = {},
    composerValue = draft,
    onComposerValueChange = { draft = it },
    onSend = {},
)
```

Example: During a live call, no composer
```tsx
<AiChatPanel
  prompt="Arnav is at the gate with a parcel. Want to take over?"
  actions={[
    { label: 'Takeover', emoji: '📞' },
    { label: 'Ask to reschedule', emoji: '🗓️' },
  ]}
  composer={false} />
```
```kotlin
var draft by remember { mutableStateOf("") }

// Compose: AiChatPanel always shows the composer; there is no composer = false.
AiChatPanel(
    prompt = "Arnav is at the gate with a parcel. Want to take over?",
    actions = listOf(
        ActionChipData("Takeover", "📞"),
        ActionChipData("Ask to reschedule", "🗓️"),
    ),
    onActionClick = {},
    composerValue = draft,
    onComposerValueChange = { draft = it },
    onSend = {},
)
```

Example: AI suggestion
```tsx
<AiSuggestion>Want me to send Amit a quick reply on WhatsApp?</AiSuggestion>
<AiSuggestion tone="secondary">I can also add Sunday dinner to your calendar.</AiSuggestion>
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    AiSuggestion("Want me to send Amit a quick reply on WhatsApp?")
    // Compose: no `tone`; AiSuggestion is always text/primary.
    AiSuggestion("I can also add Sunday dinner to your calendar.")
}
```

#### Call status (`call-status`)

Centred thread markers: the day divider, call start/end events, and a notice when the thread switches to the assistant.

- React: `import { DayDivider, ThreadEvent, ThreadNotice } from '@equal/ds';`
- Compose: `DayDivider`, `ThreadEvent`, `ThreadNotice`
- Tokens: `bg/surface`, `stroke/subtle`, `text/primary`, `text/secondary`, `notice/bg`
- Source: §21 Call Status Indicators

Props of `DayDivider`:
- `label`: `string`. "Today", "12 July".

Props of `ThreadEvent`:
- `label`: `string`. "Call Started 03:31", "Call Ended 03:31".

Props of `ThreadNotice`:
- `children`: `ReactNode`. Notice text (captionWrap, centred, max width 240).

Do: Bracket every call with Call Started / Call Ended events. Use a ThreadNotice when the conversation changes hands ("You are now talking to your AI assistant").

Don't: Don't use a ThreadNotice for ordinary messages; it is for system state changes only. Don't style these as bubbles; they are centred pills without avatars.

Anatomy:
1. DayDivider: Centred pill naming the day. (24 high (web) / 22 dp (Compose) · padding 0 14 · radius 8 · bg/surface · 1 px stroke/subtle · micro text/primary)
2. ThreadEvent: Same pill for call start and end. (micro · text/secondary)
3. ThreadNotice: Centred note when the thread changes hands. (max width 240 (web) / 232 dp (Compose) · padding 8 16 · radius 8 · notice/bg · captionWrap text/secondary centred)

Accessibility:
- Role. Web: Plain divs and spans with text; no separator or status role. Android: Plain Box + EqualText; no extra semantics.
- Name. Web: Read as their visible text ("Today", "Call Started 03:31"). Android: Read as their visible text.
- Keyboard. Web: Not focusable; read in order when browsing. Android: TalkBack: swipe to each as plain text.
- Contrast. Web: DayDivider text/primary on white; ThreadEvent text/secondary 7.5:1; notice text/secondary on notice/bg 7.2:1 (dark 7.5:1). Android: Same tokens.
- State. Web: No state. Android: No state.
- Motion. Web: No animation. Android: No animation.

Example: All indicators
```tsx
<MessageList>
  <DayDivider label="Today" />
  <ThreadEvent label="Call Started 03:31" />
  <ThreadEvent label="Call Ended 03:31" />
  <ThreadNotice>Call has ended. You are now talking to your AI assistant.</ThreadNotice>
</MessageList>
```
```kotlin
Column(
    Modifier.fillMaxWidth(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(12.dp),
) {
    DayDivider("Today")
    ThreadEvent("Call Started 03:31")
    ThreadEvent("Call Ended 03:31")
    ThreadNotice("Call has ended. You are now talking to your AI assistant.")
}
```

Example: In a thread
```tsx
<ChatWallpaper>
  <MessageList>
    <DayDivider label="12 July" />
    <ThreadEvent label="Call Started 18:02" />
    <ChatBubble kind="outgoing" sender="Equal AI" time="18:02">Hi, who is this?</ChatBubble>
    …
    <ThreadEvent label="Call Ended 18:04" />
    <ThreadNotice>Call has ended. You are now talking to your AI assistant.</ThreadNotice>
  </MessageList>
</ChatWallpaper>
```
```kotlin
ChatWallpaper {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        DayDivider("12 July")
        ThreadEvent("Call Started 18:02")
        ChatBubble(type = ChatBubbleType.Outgoing, sender = "Equal AI", timestamp = "18:02", message = "Hi, who is this?")
        ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.NA, sender = "Amit Nanda",
            timestamp = "18:02", message = "It's Amit. Dinner at mine this Sunday, 8 PM?")
        ThreadEvent("Call Ended 18:04")
        ThreadNotice("Call has ended. You are now talking to your AI assistant.")
    }
}
```

#### Call summary (`call-summary`)

The post-call card in a thread: a recording player with a coded waveform and speed pill, the assistant's summary, and an optional share footer or "Instruction Applied" tag.

- React: `import { CallSummary, VoicePlayer } from '@equal/ds';`
- Compose: `CallSummaryBubble`, `VoiceNotePlayer`
- Tokens: `bg/surface`, `voice/player-bg`, `voice/player-stroke`, `stroke/subtle`, `waveform/bar`, `waveform/bar-played`, `playback/pill-bg`, `text/on-dark`, `text/tertiary`, `text/primary`, `text/action`
- Source: §11 Chat Bubbles · Voice note + Call Summary bubble

Do: Write the summary as the outcome for the user ("Amit invited you to dinner… confirm by tonight"), not a transcript. Tag the card 🪄 "Instruction Applied" when one of the user's instructions handled the call. Keep the same `seed` for a recording so its waveform is stable.

Don't: Don't use an image for the waveform; it is coded. Don't show the player for calls without a recording; use `noRecording`.

Anatomy:
1. Card: White card that holds the recording, the summary and the footer. (width 268 · bg/surface · radius lg (16) · overflow hidden)
2. Voice player: Recording box with play, waveform, speed pill and times. (8 margin · voice/player-bg · radius md (12) · padding 10 / 10 / 6)
3. Play / pause: Toggles playback. (icon 22 · text/secondary · gap 8)
4. Waveform: Coded bars that fill as the recording plays. (28 bars (web) · 3 wide, gap 2, 24 high · waveform/bar · waveform/bar-played)
5. Speed pill: Cycles 1x → 1.2x → 1.5x → 2x. (22 high · padding 0 8 · radius full · playback/pill-bg · caption tabular · text/on-dark)
6. Label and summary: "Call Summary" caption over the summary text. (caption text/tertiary · body1 text/primary · padding 0 10 6)
7. Tag and time: Optional pill (e.g. 🪄 Instruction Applied) and the timestamp. (tag 24 high · padding 0 10 · 1 px stroke/subtle · caption text/secondary · time micro text/tertiary)
8. Share footer: Divider and a centred Share action. (divider stroke/subtle · row 44 · TextButton share icon 18 · button text/action)

Accessibility:
- Role. Web: Play and speed are native <button>s; the waveform is aria-hidden; Share is a <button>. Android: Play: clickable(role = Role.Button); speed: Role.Button with onClickLabel "Change speed"; Share row: Role.Button.
- Name. Web: Play button aria-label switches "Play" / "Pause"; speed aria-label "Playback speed 1x"; Share from its visible text. Android: Play icon contentDescription "Play" / "Pause"; speed reads its label ("1x"); Share reads "Share".
- Keyboard. Web: Tab reaches play, speed and Share; Enter/Space activates. No seek control. Android: TalkBack: swipe to play, speed, Share; double-tap to activate.
- Touch target. Web: Play and speed use eq-touch for a 48 px hit area around the 22 px visuals; Share is a TextButton with eq-touch in a 44 px row. Android: Play is a 22 dp box and the speed pill 22 dp high with plain clickable (no minimumInteractiveComponentSize; only pointer hit-testing expands); Share row 44 dp.
- Contrast. Web: Summary text/primary; label/time text/tertiary 5.1:1; speed text white on #555555 7.5:1; unplayed bars #8A8A8A on #F2F2F2 3.1:1. Share is text/action: In light, text/action #00B140 on white is 2.85:1, below 4.5:1 for text; in dark it is lime #BAFF29 (13:1 on bg/surface #222222). Android: Same tokens.
- State. Web: Play/pause is told by the label, not colour; progress shows by bar colour and by the elapsed time text. Locked audio is aria-hidden behind an Unlock Audio pill. Android: Same; the locked player uses clearAndSetSemantics {} under UnlockAudioPill.
- Motion. Web: Bar colour transition (duration-fast) goes to 0 ms under prefers-reduced-motion via base.css. Android: Waveform progress is driven by the caller; no extra animation.

Known accessibility gaps:
- Share action uses text/action #00B140 on white (2.85:1), below 4.5:1 in light (VoiceNote.tsx, VoiceNote.kt).
- VoiceNotePlayer play button and speed pill are 22 dp with plain clickable and no minimumInteractiveComponentSize (VoiceNote.kt); Share row is 44 dp.
- Playback progress is not exposed to assistive tech (no progressbar/slider or stateDescription) in VoicePlayer (VoiceNote.tsx) or EqualWaveform (VoiceNote.kt).
- CallSummaryBubble tag emoji is drawn with EmojiGlyph, which TalkBack reads aloud ("magic wand"); web hides it (VoiceNote.kt).

Example: With recording and share
```tsx
<CallSummary
  summary="Amit invited you to dinner this Sunday, 8 PM at his place. He asked you to confirm by tonight."
  time="03:21" onShare={share} />
```
```kotlin
var playing by remember { mutableStateOf(false) }
var speed by remember { mutableStateOf(PlaybackSpeed.X1) }

CallSummaryBubble(
    summary = "Amit invited you to dinner this Sunday, 8 PM at his place. He asked you to confirm by tonight.",
    timestamp = "03:21",
    voiceNote = {
        // Compose: the player is controlled; drive progress/elapsed from your media player.
        VoiceNotePlayer(isPlaying = playing, onPlayPauseClick = { playing = !playing },
            progress = 0f, elapsed = "0:00", total = "2:37",
            speed = speed, onSpeedChange = { speed = it })
    },
    onShareClick = {},
)
```

Example: Instruction applied
```tsx
<CallSummary
  summary="Priya from Dr. Mehta's clinic confirmed your appointment for tomorrow at 10 AM. Bring your previous reports."
  time="03:32" tag={{ emoji: '🪄', label: 'Instruction Applied' }} />
```
```kotlin
CallSummaryBubble(
    summary = "Priya from Dr. Mehta's clinic confirmed your appointment for tomorrow at 10 AM. Bring your previous reports.",
    timestamp = "03:32",
    tag = CallSummaryTag(label = "Instruction Applied", emoji = "🪄"),
    modifier = Modifier.width(264.dp),
)
```

Example: Summary only
```tsx
<CallSummary noRecording
  summary="Vijay from NoBroker called with an offer on a 2BHK flat in Sector 12. You said you were not interested and ended the call."
  time="03:21" />
```
```kotlin
// No voiceNote slot = no recording player.
CallSummaryBubble(
    summary = "Vijay from NoBroker called with an offer on a 2BHK flat in Sector 12. You said you were not interested and ended the call.",
    timestamp = "03:21",
)
```

Example: Voice player
```tsx
<VoicePlayer duration={94} seed={7} />
```
```kotlin
var playing by remember { mutableStateOf(false) }
var speed by remember { mutableStateOf(PlaybackSpeed.X1) }

// Compose: no `seed`; pass `samples` for a recording-specific waveform (defaults are fixed).
VoiceNotePlayer(
    isPlaying = playing,
    onPlayPauseClick = { playing = !playing },
    progress = 0f,
    elapsed = "0:00",
    total = "1:34",
    speed = speed,
    onSpeedChange = { speed = it },
)
```

#### Chat bubble (`chat-bubble`)

Message bubbles for a call thread: outgoing (Equal AI or you on the call), incoming (the caller) and assistant (Equal AI talking to you), stacked with MessageList.

- React: `import { ChatBubble, MessageList } from '@equal/ds';`
- Compose: `ChatBubble`
- Tokens: `chat-bubble/user-bg`, `chat-bubble/user-title`, `chat-bubble/other-bg`, `chat-bubble/contact-title`, `bg/surface`, `text/action`, `text/primary`, `text/tertiary`
- Source: §11 Chat Bubbles

Do: Use `outgoing` with sender "Equal AI" when the assistant speaks for the user on a call, and "You" after a takeover. Use `assistant` only when Equal AI is talking to the user, not to the caller. Set first={false} on consecutive bubbles from the same sender.

Don't: Don't mix up outgoing and assistant; the green byline means Equal AI is addressing you. Don't put custom cards inside a padded bubble; use `bare`.

Anatomy:
1. Avatar: Caller category art (incoming) or the Equal orb (assistant), shown on the first bubble of a group only. (CategoryAvatar 28 dp · AiAvatar 24 dp · 28 dp column, gap 8 · outgoing has none)
2. Bubble container: Rounded fill whose colour and side tell outgoing, incoming and assistant apart. (max width 264 · radius md (12) · padding 8 / 10 / 6 · chat-bubble/user-bg · chat-bubble/other-bg · bg/surface)
3. Tail: Optional notch on the top outer corner of the first bubble. (tail + first · 10 × 12 notch · square top-outer corner (web) · 8 dp gutter (Compose))
4. Sender line: Who is speaking, on the first bubble of a group. (body2 · chat-bubble/user-title (outgoing) · chat-bubble/contact-title (incoming) · text/action (assistant))
5. Message: The message text, or custom content with bare. (body1 · text/primary · bare removes padding)
6. Timestamp: Time of the message, right-aligned. (micro · text/tertiary · 2 dp above)
7. MessageList: stack: Vertical list that applies the group rhythm. (gap 4 · 8 dp extra before a new group · padding 12)

Accessibility:
- Role. Web: Plain divs; the orb is role=img and the category avatar is an img with alt. MessageList is a plain div, not role=log. Android: Plain Row/Column of texts; no mergeDescendants, so sender, message and time are separate TalkBack stops.
- Name. Web: Content is read as text: avatar name ("Equal AI" or the category label), sender, message, time. Android: AiAvatar contentDescription "Equal AI"; CategoryAvatar uses category.label; texts read as written.
- Keyboard. Web: Not interactive; screen readers reach it in reading order. Android: TalkBack: swipe through sender, message and time one by one; should be one merged stop per bubble.
- Contrast. Web: text/primary on all fills; time text/tertiary 4.85:1 on user-bg; incoming sender #9A5B00 5.4:1; outgoing sender #006223 7.2:1. Assistant sender is text/action: In light, text/action #00B140 on white is 2.85:1, below 4.5:1 for text; in dark it is lime #BAFF29 (13:1 on bg/surface #222222). Android: Same tokens as web via EqualTheme.colors.
- State. Web: Side and fill show who sent it; only the first bubble of a group has a sender line, so follow-ups carry no sender for screen readers. Locked bubbles hide the text and read "Locked. Unlock Equal Unlimited to see this." Android: Same; LockedContent uses clearAndSetSemantics with the same locked sentence.
- Motion. Web: No animation. Android: No animation.

Known accessibility gaps:
- Assistant sender line uses text/action #00B140 on bg/surface (2.85:1), below 4.5:1 in light (ChatBubble.tsx, ChatBubble.kt).
- Follow-up bubbles (first={false} / isFirstInGroup = false) have no sender in their accessible text, so a screen reader can't tell who sent them (ChatBubble.tsx, ChatBubble.kt).
- MessageList in ChatBubble.tsx is a plain div; a live call thread should be role="log" so new messages are announced.
- ChatBubble.kt does not merge the bubble (semantics(mergeDescendants = true)), so TalkBack stops on sender, message and time separately.

Example: A call thread
```tsx
<MessageList>
  <ChatBubble kind="outgoing" sender="Equal AI" time="03:21">Hi, who is this?</ChatBubble>
  <ChatBubble kind="incoming" sender="Dr Mehta Clinic" time="03:21">
    This is Priya from Dr. Mehta's clinic. Your appointment is confirmed for tomorrow.
  </ChatBubble>
  <ChatBubble kind="outgoing" sender="You" time="03:21">Yes, I'll be there at 10 AM</ChatBubble>
  <ChatBubble kind="assistant" sender="Equal AI" time="03:21">
    Hey Keshav! Here is the summary of your call
  </ChatBubble>
</MessageList>
```
```kotlin
// Compose: no MessageList; a Column with 12dp spacing gives the between-group rhythm.
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    ChatBubble(type = ChatBubbleType.Outgoing, sender = "Equal AI", timestamp = "03:21", message = "Hi, who is this?")
    ChatBubble(type = ChatBubbleType.Incoming, sender = "Dr Mehta Clinic", timestamp = "03:21",
        message = "This is Priya from Dr. Mehta's clinic. Your appointment is confirmed for tomorrow.")
    ChatBubble(type = ChatBubbleType.Outgoing, sender = "You", timestamp = "03:21", message = "Yes, I'll be there at 10 AM")
    ChatBubble(type = ChatBubbleType.Incoming, sender = "Dr Mehta Clinic", timestamp = "03:21",
        message = "Great. Please bring your previous reports too.")
    ChatBubble(type = ChatBubbleType.Assistant, sender = "Equal AI", timestamp = "03:21",
        message = "Hey Keshav! Here is the summary of your call")
}
```

Example: Tails and grouping
```tsx
<ChatBubble kind="incoming" category="real-estate" sender="Vijay · NoBroker" time="03:21" tail>
  I have an offer on a 2BHK flat in Sector 12.
</ChatBubble>
<ChatBubble kind="incoming" category="real-estate" first={false} time="03:21">
  Are you free for a site visit this weekend?
</ChatBubble>
<ChatBubble kind="outgoing" sender="Equal AI" time="03:22" tail>
  Thanks, but Keshav is not interested right now.
</ChatBubble>
```
```kotlin
Column {
    ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.RealEstate,
        sender = "Vijay · NoBroker", timestamp = "03:21", tail = true,
        message = "I have an offer on a 2BHK flat in Sector 12.")
    // Follow-up in the same group: 4dp gap, no avatar, no sender line.
    ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.RealEstate,
        isFirstInGroup = false, timestamp = "03:21", modifier = Modifier.padding(top = 4.dp),
        message = "Are you free for a site visit this weekend?")
    ChatBubble(type = ChatBubbleType.Outgoing, sender = "Equal AI", timestamp = "03:22", tail = true,
        modifier = Modifier.padding(top = 12.dp), message = "Thanks, but Keshav is not interested right now.")
}
```

Example: Bare content
```tsx
<ChatBubble kind="assistant" bare>
  <CallSummary noRecording summary="Delivery agent will arrive between 4 and 5 PM." time="03:21" />
</ChatBubble>
```
```kotlin
// Compose: ChatBubble has no `bare` mode; lay the AI avatar beside the card yourself.
Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    AiAvatar(size = AiAvatarSize.Small)
    CallSummaryBubble(
        summary = "Delivery agent will arrive between 4 and 5 PM.",
        timestamp = "03:21",
        modifier = Modifier.width(240.dp),
    )
}
```

#### Chat list item (`chat-list-item`)

A row in the Chats list with avatar, name, date, preview, unread count and the small action chips; states come from `unread` and `selected`.

- React: `import { ChatListItem } from '@equal/ds';`
- Compose: `ChatListItem`
- Tokens: `bg/surface`, `action-card/highlight`, `state/chat-pressed`, `text/primary`, `text/secondary`, `text/action`, `text/tertiary`, `button/primary`, `text/on-action`
- Source: §6 Chat List Item

Do: Give unknown callers their category art and saved contacts their initials. Offer the next step as chips on the row (📞 Call Back, 🗓️ Add to Calendar) so it is one tap from the list. Use long-press to enter selection mode.

Don't: Don't set chip states yourself; the row derives them from unread and selected. Don't let the preview wrap; it is one line with an ellipsis.

Anatomy:
1. Row container: Full-width tappable row; fills green when selected. (padding 12 v / 16 start (web 0 end) · bg/surface · selected action-card/highlight · gap 16)
2. Avatar: Contact avatar or the orb for Equal AI. (48 · selected shows the check badge)
3. Name: Contact name, one line, with a verified tick for the official chat. (subheading 16/500 text/primary · verified 16 text/action, label 'Verified')
4. Date: Time or date of the last message. (micro 12/500 · text/action when unread (web also when selected), else text/tertiary · gap 8)
5. Preview: Last message or summary, blurred when locked. (body1 14/400 text/secondary · one line · locked blur 4)
6. Unread count: CountBadge at the end of the preview line; a crown-lock replaces it when locked. (20 · button/primary · gap 8)
7. Action chips: Scrolling row of SmallActionChips; state follows the row. (margin-top 8 · gap 12 · unread / read / outlined)

Accessibility:
- Role. Web: A <div role='button' tabIndex=0> with aria-selected, containing the chip <button>s. Android: combinedClickable on the Row with no role; chips are separate Role.Button nodes.
- Name. Web: All row text in order: name, 'Verified', date, preview, count; locked previews read 'Locked. Unlock Equal Unlimited to see this.' Android: Merged text of the row; LockedContent replaces the preview with the same locked message.
- Keyboard. Web: Tab to the row, Enter opens it; Space does nothing. Long-press maps to the context-menu event (right-click or the Menu key). Chips are later Tab stops. Android: TalkBack: double-tap opens, double-tap-and-hold triggers onLongClick (no custom label).
- Touch target. Web: Row is at least 72px high and full width; chips use .eq-touch. Android: Row is full width and at least 72dp; chips get 48dp.
- Contrast. Web: Name 17:1, preview text/secondary 7.5:1, read date text/tertiary 5.1:1; unread date text/action #00B140 is 2.85:1 in light (lime in dark passes). Android: Same tokens as web.
- State. Web: Unread shows the count badge as well as a green date; selected sets aria-selected (not valid on role=button) plus the avatar check and highlight fill. The row has outline: none and no focus style. Android: Unread shows the count badge; selected is drawn (fill, check 'Selected') but not set as selected semantics.
- Motion. Web: Background fades over 200ms; zeroed under prefers-reduced-motion. Android: Ripple-free; no animation.

Known accessibility gaps:
- ChatListItem.tsx: role='button' wraps the chip <button>s, which nests interactive controls; the row should be a list item with a separate open button or link.
- ChatListItem.tsx: aria-selected is not supported on role='button'; use aria-pressed, or role='option' / a checkbox in selection mode.
- ChatListItem.tsx: only Enter activates the row; Space should too.
- ChatListItem.tsx: inline outline: none removes the focus indicator and nothing replaces it.
- ChatListItem.kt: combinedClickable has no role, no onLongClickLabel (e.g. 'Select'), and the Selected state is not set in semantics.
- ChatListItem.tsx / ChatListItem.kt: unread date in text/action #00B140 on white is 2.85:1 for 12sp text in light mode.

Example: Unread and read
```tsx
<ChatListItem name="Arnav Raj" preview="You have a visitor" date="Yesterday"
  unread={5} avatar={{ category: 'na' }}
  actions={[
    { label: 'Call Back', emoji: '📞' },
    { label: 'Update Address', emoji: '✏️' },
    { label: 'Add to Calendar', emoji: '🗓️' },
  ]} />
<ChatListItem name="Amit Nanda" preview="Count me in for Sunday 8 PM 👍" date="12 July"
  avatar={{ initials: 'AN' }} actions={[{ label: 'Call Back', emoji: '📞' }]} />
```
```kotlin
ChatListItem(
    name = "Arnav Raj",
    preview = "You have a visitor",
    date = "Yesterday",
    state = ChatListItemState.Unread,
    unreadCount = 5,
    category = EqualCategory.NA,
    chips = listOf(
        ActionChipData("Call Back", "📞"),
        ActionChipData("Update Address", "✏️"),
        ActionChipData("Add to Calendar", "🗓️"),
    ),
)
ChatListItem(
    name = "Amit Nanda",
    preview = "Count me in for Sunday 8 PM 👍",
    date = "12 July",
    initials = "AN",
    chips = listOf(ActionChipData("Call Back", "📞")),
)
```

Example: Long-press to select
```tsx
<ChatListItem name="Dr Mehta Clinic" preview="Appointment confirmed for tomorrow, 10 AM"
  date="03:21" unread={2} avatar={{ category: 'others' }}
  actions={[{ label: 'Add to Calendar', emoji: '🗓️' }, { label: 'Call Back', emoji: '📞' }]}
  selected={selected} onLongPress={() => setSelected(true)} />
```
```kotlin
var selected by remember { mutableStateOf(false) }

ChatListItem(
    name = "Dr Mehta Clinic",
    preview = "Appointment confirmed for tomorrow, 10 AM",
    date = "03:21",
    state = if (selected) ChatListItemState.Selected else ChatListItemState.Unread,
    unreadCount = 2,
    category = EqualCategory.Others,
    chips = listOf(ActionChipData("Add to Calendar", "🗓️"), ActionChipData("Call Back", "📞")),
    onLongClick = { selected = true },
    onClick = { selected = false },
)
```

Example: The list
```tsx
{chats.map((c) => (
  <ChatListItem key={c.id} name={c.name} preview={c.preview} date={c.date}
    unread={c.unread} actions={c.actions}
    avatar={c.initials ? { initials: c.initials } : { category: c.category }} />
))}
```
```kotlin
val callBack = listOf(ActionChipData("Call Back", "📞"))
Column {
    ChatListItem(name = "Amit Nanda", preview = "Count me in for Sunday 8 PM 👍", date = "12 July",
        initials = "AN", chips = callBack)
    ChatListItem(name = "Vijay · NoBroker", preview = "Offer on a 2BHK flat in Sector 12", date = "10 July",
        category = EqualCategory.RealEstate, chips = callBack)
    ChatListItem(name = "Swiggy Delivery", preview = "Your order is at the gate", date = "09 July",
        category = EqualCategory.Delivery, chips = listOf(ActionChipData("Update Address", "✏️")))
    ChatListItem(name = "HDFC Bank", preview = "Pre-approved loan offer. You said not interested", date = "08 July",
        category = EqualCategory.Financial, chips = callBack)
}
```

#### Chat wallpaper (`chat-wallpaper`)

The doodle pattern behind chat threads and the instruction setup chat, tinted by token so one tile serves light and dark.

- React: `import { ChatWallpaper } from '@equal/ds';`
- Compose: `ChatWallpaper`
- Tokens: `chat/wallpaper-bg`, `chat/wallpaper-pattern`
- Source: Flows · Chat wallpaper

Do: Use it behind chat threads and the "Setting up instruction" chat only. Give it minHeight: 100% so the pattern fills short threads.

Don't: Don't put the wallpaper behind lists or settings screens. Don't tint the pattern yourself; it reads chat/wallpaper-pattern in both themes.

Anatomy:
1. Background: Flat fill behind the thread. (chat/wallpaper-bg)
2. Doodle pattern: Tiled doodles masked and tinted by token. (360 × 750 tile · chat/wallpaper-pattern rgba(115,115,115,0.08) · web ::before mask, pointer-events none · Compose drawBehind SrcIn)
3. Content: The thread drawn on top. (children / content slot)

Accessibility:
- Role. Web: Decorative: the pattern is a CSS ::before mask with no semantics. Android: Decorative: drawn in drawBehind, no semantics node.
- Name. Web: None; the pattern should never be announced. Android: None.
- Contrast. Web: The pattern is 8% grey so it stays under text; text contrast is set by the bubbles on top. Android: Same.
- Motion. Web: Static. Android: Static.

Example: Behind a thread
```tsx
<ChatWallpaper style={{ minHeight: '100%' }}>
  <MessageList>
    <DayDivider label="Today" />
    <ChatBubble kind="outgoing" sender="Equal AI" time="03:21">Hi, who is this?</ChatBubble>
    …
  </MessageList>
</ChatWallpaper>
```
```kotlin
ChatWallpaper(Modifier.fillMaxSize()) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        DayDivider("Today")
        ChatBubble(type = ChatBubbleType.Outgoing, sender = "Equal AI", timestamp = "03:21", message = "Hi, who is this?")
        ChatBubble(type = ChatBubbleType.Incoming, sender = "Dr Mehta Clinic", timestamp = "03:21",
            message = "This is Priya from Dr. Mehta's clinic. Your appointment is confirmed for tomorrow.")
    }
}
```

#### Missed call card (`missed-call`)

The thread card for a call the assistant couldn’t pick up. One component, three cases: we know why the caller usually calls, we know only their name, or we know nothing. Every case ends in Call back.

- React: `import { MissedCallCard } from '@equal/ds';`
- Compose: `MissedCallCard`
- Tokens: `bg/surface`, `missed-call/bg`, `missed-call/stroke`, `missed-call/icon-bg`, `missed-call/icon`, `text/primary`, `text/secondary`, `text/tertiary`, `text/action`, `stroke/subtle`

Do: Pick the case from what we know: reason + art, then name only, then unknown. Never invent a reason. Show thumbs only with a reason, since they rate the reason. Call back opens the same Call Back task as everywhere else (Flows → Call Back).

Don't: Don’t colour the whole card red; the warm tint says “missed”, not “error”. Don’t show caller art without a reason; the disc keeps the three cases distinct.

Anatomy:
1. Card: White card holding the head, reason and Call back. (width 320 · bg/surface · radius lg (16))
2. Head: Tinted strip that says the call was missed. (margin 6 · padding 10 / 12 · radius 12 · missed-call/bg · 1 px missed-call/stroke · gap 12)
3. Art or disc: Caller art with a missed badge (with a reason) or the red missed-call disc. (48 · badge 20 missed-call/icon-bg · phone-missed-fill 12 / 24 · missed-call/icon)
4. Title and why: "{caller} Called" or "Missed by the assistant", then why. (subheading text/primary · body2 Regular text/secondary)
5. Likely calls for: Optional reason block with bold key words and the time. (overline text/secondary · body1 Regular text/secondary · padding 4 16 6 · micro time)
6. Call back: Full-width action row. (48 high · call icon 20 · subheading · text/action · 1 px stroke/subtle top)
7. Feedback thumbs: Optional 👍 / 👎 to rate the reason. (40 circles · gap 8 · 1 px stroke/subtle · on: filled icon + text/action stroke)

Accessibility:
- Role. Web: Call back is a <button>; thumbs are <button aria-pressed> in a role=group; art and icons are hidden (alt="", aria-hidden). Android: Call back: clickable(role = Role.Button); thumbs: toggleable(role = Role.Button); art and icons have null contentDescription.
- Name. Web: Call back from its visible label; thumbs aria-label "Helpful" / "Not helpful"; group "Was this helpful?". Android: Call back reads its label; thumb icons contentDescription "Helpful" / "Not helpful"; Row contentDescription "Was this helpful?".
- Keyboard. Web: Tab to Call back and each thumb; Enter/Space activates; pressing the selected thumb clears it. Android: TalkBack: swipe to Call back and the thumbs, double-tap to activate.
- Touch target. Web: Call back row is 48 px high and full width; thumbs are 40 px with no eq-touch, so 40 × 40. Android: Call back 48 dp; thumbs 40 dp toggleable without minimumInteractiveComponentSize.
- Contrast. Web: Title text/primary, body text/secondary 7.2:1 on missed-call/bg; missed icon #D4380D on #FBE9E5 4.1:1. Call back is text/action: In light, text/action #00B140 on white is 2.85:1, below 4.5:1 for text; in dark it is lime #BAFF29 (13:1 on bg/surface #222222). Android: Same tokens; dark icon #FF8A6B on #45302C 5.3:1.
- State. Web: Thumb selection uses aria-pressed and swaps outline for filled icon plus green stroke, so not colour alone. Android: toggleable exposes on/off; the icon also swaps to filled.
- Motion. Web: eq-pressable scale on press; transitions go to 0 ms under reduced motion. Android: eqPressFeedback on press only.

Known accessibility gaps:
- Feedback thumbs are 40 × 40 px with no eq-touch (MissedCall.css) and 40 dp without minimumInteractiveComponentSize (MissedCall.kt), below 48.
- Call back label uses text/action #00B140 on white (2.85:1), below 4.5:1 in light (MissedCall.css, MissedCall.kt).

Example: With a reason
```tsx
<MissedCallCard
  caller="Kuldeep Solanki" category="real-estate"
  reason={<>Promote <b>L&amp;T Realty residential</b> projects.</>}
  time="03:21" onCallBack={callBack}
  feedback={feedback} onFeedback={setFeedback} />
```
```kotlin
EqualTheme {
    var feedback by remember { mutableStateOf<CallFeedback?>(null) }
    MissedCallCard(
        caller = "Kuldeep Solanki",
        category = EqualCategory.RealEstate,
        reason = buildAnnotatedString {
            append("Promote ")
            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("L&T Realty residential") }
            append(" projects.")
        },
        time = "03:21",
        onCallBack = { /* call back */ },
        feedback = feedback,
        onFeedback = { feedback = it },
    )
}
```

Example: Caller unknown
```tsx
<MissedCallCard time="3:31 PM" onCallBack={callBack} />
```
```kotlin
EqualTheme {
    MissedCallCard(time = "3:31 PM", onCallBack = { /* call back */ })
}
```

Example: Name only
```tsx
<MissedCallCard caller="Valluri" time="3:31 PM" onCallBack={callBack} />
```
```kotlin
EqualTheme {
    MissedCallCard(caller = "Valluri", time = "3:31 PM", onCallBack = { /* call back */ })
}
```

### Group: Display

#### Avatars (`avatars`)

Every face in the app: caller category art or initials for contacts, the Equal orb for the assistant, the ringed 3D profile avatar for the user, and the robot mascot.

- React: `import { ContactAvatar, CategoryAvatar, AiAvatar, EqualOrb, ProfileAvatar, Mascot } from '@equal/ds';`
- Compose: `ContactAvatar`, `CategoryAvatar`, `InitialsAvatar`, `AiAvatar`, `EqualLogoOrb`, `ProfileAvatar`, `EqualMascot`
- Tokens: `action-card/highlight`, `text/action`, `button/primary`, `text/on-action`, `bg/surface`
- Source: Icons, emoji, categories, logo · §12 AI Assistant Avatar

Do: Default unknown callers to `na` and incoming bubbles to `others` (the red telephone). Size ProfileAvatar by width only; its height follows so the head can rise above the ring. Use AiAvatar at 24 / 36 / 48 only.

Don't: Never crop category art or the profile avatar; the circle and ring are part of the image. Don't draw your own green circle for the assistant; the orb swaps light (#00B140) and dark (lime) files by theme. Don't use initials for business callers; they get their category art.

Anatomy:
1. ContactAvatar: image or disc: Category art for unknown callers, or a tinted disc with initials for saved contacts. (48 list · 36 header · 96 contact info · circle · 6 tones contact-avatar/*-bg)
2. ContactAvatar: initials: First two letters, uppercased. (Medium, 37.5% of size (18 at 48) · contact-avatar/*-text)
3. ContactAvatar: saved badge: Person badge marking a known contact. (36% of size · contact-avatar/badge-bg + badge-icon · bottom-right, offset 10%)
4. ContactAvatar: selected check: Green tick that replaces the saved badge in selection mode. (web 18, Compose 22 incl. 2dp bg/surface ring · button/primary · check 12 text/on-action)
5. AiAvatar / EqualOrb: The Equal orb for the assistant; light and dark files swap with the theme. (24 / 36 / 48 (FAB 58) · image drawn at size / 0.8, glow overflows)
6. ProfileAvatar: The user's 3D character, gold ring when paid. (width 72 default · height ≈ 1.12 × width · free = bust art)
7. Mascot: Robot for the assistant toggle card. (40 default · dimmed = greyscale at 70%)

Accessibility:
- Role. Web: EqualOrb, Mascot and the saved badge are role='img'; CategoryAvatar and ProfileAvatar are <img>; the initials disc is plain text. Android: Image with contentDescription; InitialsAvatar is text plus a 'Saved contact' badge node.
- Name. Web: Orb 'Equal AI', Mascot 'Equal assistant', ProfileAvatar 'Your profile', CategoryAvatar the category label, saved badge 'Saved contact'. Pass label/alt = '' when a visible name sits beside it. Android: Same defaults via contentDescription; pass null when the row already names the person. SelectedCheckBadge reads 'Selected'.
- Contrast. Web: The six initials tones are 4.6–6.5:1 in light and 4.7–8.7:1 in dark. The selected check is white on #00B140 (2.85:1) in light. Android: Same tokens as web.
- State. Web: Selected adds a tick shape, not only colour, but the tick has no text alternative. Mascot dimmed is visual only; the toggle beside it states on or off. Android: Selected is announced as 'Selected' via the check's contentDescription.
- Motion. Web: Mascot filter and opacity fade over 200ms; zeroed under prefers-reduced-motion. Android: None.

Known accessibility gaps:
- Avatar.tsx: ContactAvatar's selected check icon is aria-hidden with no label, so selection is not announced on web (Compose says 'Selected').
- Avatar.tsx: default labels ('Your profile', 'Equal AI', category names) are announced even when the avatar sits next to a visible name; components that embed it (e.g. BottomNav) should pass an empty label.

Example: Profile avatar: free vs paid
```tsx
<ProfileAvatar variant="male" size={70} tier="free" />
<ProfileAvatar variant="male" size={70} tier="paid" />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
    ProfileAvatar(variant = ProfileAvatarVariant.Male, width = 70.dp, tier = PlanTier.Free)
    ProfileAvatar(variant = ProfileAvatarVariant.Male, width = 70.dp, tier = PlanTier.Paid)
}
```

Example: Caller categories
```tsx
<CategoryAvatar category="na" />
<CategoryAvatar category="delivery" />
<CategoryAvatar category="real-estate" size={48} />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
    CategoryAvatar(category = EqualCategory.NA, size = 48.dp)
    CategoryAvatar(category = EqualCategory.Delivery, size = 48.dp)
    CategoryAvatar(category = EqualCategory.RealEstate, size = 48.dp)
}
```

Example: Contact avatar
```tsx
<ContactAvatar />
<ContactAvatar category="others" />
<ContactAvatar initials="AN" />
<ContactAvatar initials="AN" selected />
<ContactAvatar category="career" size={36} />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
    ContactAvatar(size = 48.dp)
    ContactAvatar(size = 48.dp, category = EqualCategory.Others)
    ContactAvatar(size = 48.dp, initials = "AN")
    ContactAvatar(size = 48.dp, initials = "AN", selected = true)
    ContactAvatar(size = 36.dp, category = EqualCategory.Career)
}
```

Example: Saved-contact colours
```tsx
<ContactAvatar initials="AN" />              // tone picked from the initials
<ContactAvatar initials="AR" tone="green" />  // blue · green · purple · orange · pink · teal
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
    // The tone is picked from the initials by default; pass tone to choose.
    listOf("AN", "AR", "KS", "PR", "VJ", "MS").zip(ContactTone.entries).forEach { (initials, tone) ->
        InitialsAvatar(initials = initials, size = 48.dp, tone = tone)
    }
}
```

Example: Assistant, user and mascot
```tsx
<AiAvatar size={24} />
<AiAvatar size={36} />
<AiAvatar size={48} />
<EqualOrb size={58} />
<ProfileAvatar size={70} />
<ProfileAvatar variant="female" size={70} />
<Mascot size={40} />
<Mascot size={40} dimmed />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.Bottom) {
    AiAvatar(size = AiAvatarSize.Small)
    AiAvatar(size = AiAvatarSize.Medium)
    AiAvatar(size = AiAvatarSize.Large)
    EqualLogoOrb(size = 58.dp)
    ProfileAvatar(variant = ProfileAvatarVariant.Male, width = 70.dp)
    ProfileAvatar(variant = ProfileAvatarVariant.Female, width = 70.dp)
    EqualMascot(size = 40.dp)
    EqualMascot(size = 40.dp, dimmed = true)
}
```

#### Badges (`badges`)

Small uppercase markers: NEW on settings rows, unread counts, the NEW FEATURE pill on announcements, and the gold UNLIMITED plan marker.

- React: `import { NewBadge, CountBadge, FeatureBadge, PlanBadge } from '@equal/ds';`
- Compose: `NewBadge`, `CountBadge`, `FeatureBadge`, `PlanBadge`
- Tokens: `button/primary`, `text/on-action`, `bg/surface`, `badge/new-feature-stroke`, `text/secondary`, `gradient/gold`, `text/on-dark`
- Source: §20 Badge

Do: Keep badge text to one or two words; badges never wrap. Pass normal-case strings; the components uppercase badge text in the string (rule 5). Use CountBadge for unread messages only; it hides itself at zero.

Don't: Don't use NewBadge for counts or statuses; it means "new" and nothing else. Don't recolour PlanBadge; the gold gradient marks the plan everywhere (top bar, profile).

Anatomy:
1. NewBadge: container: Small rectangle that marks something new. (16 high · padding h6 · radius/xs 4 · solid button/primary · soft action-card/highlight)
2. NewBadge: label: One word, uppercased in the string. (badge 10/500 · solid text/on-action · soft text/action)
3. CountBadge: circle: Unread count on a green circle. (20 min width / height (16 in nav) · padding h5 for 2+ digits · radius full · button/primary · badgeCount 10/500 text/on-action · web 99+, ring adds 1.5 bg/surface)
4. FeatureBadge: pill: 'NEW FEATURE' pill with a star. (24 high · padding 8/10 · radius full · bg/surface · 1px badge/new-feature-stroke · ⭐ 11 · gap 6 · badge text/secondary)
5. PlanBadge: tag: Plan marker beside the logo (UNLIMITED, PLAN EXPIRED). (16 high · padding h6 · radius 4 · paid gradient/gold + text/on-dark · expired plan-badge/expired-bg #D0302F + white)

Accessibility:
- Role. Web: Plain <span> text; none are interactive. Android: Plain Box/Row with text; no semantics added.
- Name. Web: Read as their text ('NEW', 'UNLIMITED'). CountBadge sets aria-label '{n} unread' on a span with no role, which most screen readers ignore, so they read the bare number. Android: Read as the text; CountBadge reads just the number, with no 'unread'.
- Contrast. Web: Solid NEW white on #00B140 2.85:1 and soft text/action on #DCFFE4 2.6:1 fail 4.5:1 at 10sp; PlanBadge white on gradient/gold is 2.2–4.3:1; expired white on #D0302F 5.1:1; FeatureBadge text/secondary 7.5:1. Dark: black on lime passes. Android: Same tokens as web.
- State. Web: Badges carry state in words or numbers, not colour alone; CountBadge renders nothing at 0. Android: Same; CountBadge caps at max+ (default 99).

Known accessibility gaps:
- Badge.tsx: CountBadge puts aria-label on a span with no role, which is not reliably announced; give it role='img' or visually hidden '{n} unread' text.
- Badges.kt: CountBadge has no semantics, so TalkBack reads a bare number with no 'unread'.
- Badge.css / Badges.kt: NewBadge solid (white on #00B140, 2.85:1) and soft (text/action on #DCFFE4, 2.6:1) fail 4.5:1 for 10sp text in light mode.
- Badge.css / Badges.kt: PlanBadge white text on gradient/gold is 2.2–4.3:1 in both themes.
- Badges.kt: FeatureBadge EmojiGlyph is not hidden, so TalkBack reads 'star' before the label (web hides it).

Example: All badges
```tsx
<NewBadge />
<NewBadge tone="soft" />
<CountBadge count={5} />
<CountBadge count={12} />
<CountBadge count={140} />   {/* renders 99+ */}
<FeatureBadge />
<PlanBadge />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
    NewBadge()
    // Compose: no tone = "soft"; NewBadge has the solid fill only.
    CountBadge(count = 5)
    CountBadge(count = 12)
    CountBadge(count = 140) // renders 99+
    FeatureBadge()
    PlanBadge()
}
```

Example: In context
```tsx
<TopBar />                                  {/* PlanBadge */}
<SettingsRow icon="instructions" label="Instructions" isNew
  description="Tell assistant how you'd like it to help" />   {/* NewBadge */}
<ChatListItem name="Arnav Raj" preview="You have a visitor"
  date="Yesterday" unread={5} />             {/* CountBadge */}
```
```kotlin
Column {
    TopBar() // PlanBadge
    RowGroup(inset = 0.dp) {
        SettingsRow(
            label = "Instructions",
            description = "Tell assistant how you'd like it to help",
            leadingIcon = EqualIcons.Instructions,
            showNewBadge = true, // NewBadge
        )
    }
    ChatListItem(
        name = "Arnav Raj",
        preview = "You have a visitor",
        date = "Yesterday",
        state = ChatListItemState.Unread,
        unreadCount = 5, // CountBadge
    )
}
```

#### Lottie animation (`lottie`)

Plays illustrative animations shipped as Lottie JSON: mascot moments, celebrations, typing. The same file plays on web and Android.

- React: `import { Lottie } from '@equal/ds';`
- Compose: `EqualLottie`
- Tokens: `text/action`
- Source: Motion · Animations

Do: Use Lottie for illustrative motion; keep micro-interactions (press, toggles, sheets) in code on the motion tokens. Export from After Effects with Bodymovin, shapes only (no images or text layers), 60 fps, under ~100 KB. Tint single-colour animations with `text/action` so they follow the theme.

Don't: Don't rebuild an animation by hand in code when a Lottie file exists. Don't autoplay looping animations behind text people are reading.

Anatomy:
1. Box: Fixed-size container the player draws into. (width / height 120 default · flex-shrink 0)
2. Animation: Lottie JSON from assets/lottie/, rendered as SVG. (lottie_light svg renderer (web) · LottieAnimation (Compose) · loop and autoplay default true)
3. Tint: Optional single colour for every fill and stroke. (--eq-lottie-tint (web) · LottieProperty.COLOR / STROKE_COLOR (Compose) · e.g. text/action)

Accessibility:
- Role. Web: With label: role="img"; without: aria-hidden="true". Android: With contentDescription: semantics contentDescription; without: no semantics.
- Name. Web: label prop, e.g. "Equal AI is typing". Omit for decorative motion. Android: contentDescription param.
- Keyboard. Web: Not interactive; no pause control. Android: Not interactive.
- Contrast. Web: Tint with text/action to follow the theme; meaningful animations need 3:1 against their background. Android: Same with EqualTheme.colors.textAction.
- State. Web: No state. Android: No state.
- Motion. Web: Under prefers-reduced-motion it does not autoplay or loop and shows the first frame (read once on mount). Otherwise it loops forever with no pause control. Android: When Remove animations (animator scale 0) is on it shows frame 0 and does not play; otherwise it repeats forever.

Known accessibility gaps:
- loop defaults to true with no pause or stop control, so looping animations over 5 s can't be paused (WCAG 2.2.2) unless reduced motion is on (Lottie.tsx, EqualLottie.kt).

Example: Typing dots
```tsx
// assets/lottie/typing-dots.json
<Lottie name="typing-dots" width={120} height={40} tint="var(--eq-text-action)" label="Equal AI is typing" />
```
```kotlin
// res/raw/lottie_typing_dots.json (copied from assets/lottie/ by `npm run assets`)
EqualLottie(
    rawRes = R.raw.lottie_typing_dots,
    width = 120.dp,
    height = 40.dp,
    tint = EqualTheme.colors.textAction,
    contentDescription = "Equal AI is typing",
)
```

Example: Original colours, play once
```tsx
<Lottie name="typing-dots" width={120} height={40} loop={false} />
```
```kotlin
EqualLottie(rawRes = R.raw.lottie_typing_dots, width = 120.dp, height = 40.dp, iterations = 1)
```

### Group: Flows

#### Address (`address`)

Saved address cards with an Edit / Delete overflow, and the add/edit form (label chips, address lines, city, pincode, guiding direction, Save).

- React: `import { AddressCard, AddressForm, formatAddress } from '@equal/ds';`
- Compose: `AddressCard`, `AddressForm`
- Tokens: `bg/surface`, `text/primary`, `text/secondary`, `text/tertiary`, `text/danger`, `chip/selected-bg`, `button/primary`
- Source: Flows · Addresses

Do: Use formatAddress so every card reads "line1, line2, City- pincode". Open the form in a titled BottomSheet ("Edit Address" / "Add Address"). Route Delete address through the trash confirm sheet.

Don't: Don't show Edit as a separate button; it lives in the ⋮ menu. Don't accept a pincode that isn't six digits; the form blocks Save.

Anatomy:
1. AddressCard: card: Card for one saved address. (bg/surface · radius 16 · padding 14/16 · 1dp stroke/subtle in dark)
2. AddressCard: label: Home, Work or a custom name. (subheading · text/primary)
3. AddressCard: address: Full address built by formatAddress. (captionWrap · text/secondary · 4 above)
4. AddressCard: overflow: ⋮ menu with Edit and Delete address. (OverflowMenu 32 · icon 20 · menu min width 168)
5. AddressForm: label chips: LABEL* overline above Home / Work / Other chips. (overline text/tertiary · SegmentedChips 36 high)
6. AddressForm: fields: Two address lines, then City and Pincode side by side. (TextField radius 12 · bodyLarge · min 48 · Pincode is digits only, 6 max, tabular)
7. AddressForm: guiding direction: Optional free-text field. (TextField with label + '(Optional)')
8. AddressForm: Save: Commit. Disabled until line 1, city and a 6-digit pincode are filled. (Button lg block · 45 high)

Accessibility:
- Role. Web: The card is a div. The chips are radios inside a radiogroup. The fields are textarea/input elements. Save is a button. Android: Chips use selectable(Role.RadioButton) inside selectableGroup(). Fields are BasicTextField. Save is Role.Button.
- Name. Web: The overflow is named '{label} options'. Fields use aria-label: 'Address line 1', 'Address line 2', 'City', 'Pincode'. The chip group has no name, because the LABEL* text is not linked. Android: Overflow contentDescription is '{label} options'. Fields use contentDescription with the same strings.
- Keyboard. Web: Tab through the chips (no arrow keys), the fields and Save. Pincode has inputMode numeric. The overflow menu closes on Escape. Android: TalkBack: swipe through the fields; Pincode opens the number keyboard. Double-tap Save.
- Touch target. Web: Chips are 36 tall with no eq-touch. Fields are at least 48. Save is 45 with no eq-touch. The overflow gets 48 through eq-touch. Android: Chips are 36dp with minimumInteractiveComponentSize (48). Save gets 48. The overflow trigger is 32dp with no minimum.
- Contrast. Web: Address text/secondary 7.5:1. Overlines text/tertiary 5.1:1. Error text/danger 6.2:1. Save is white on green, 2.85:1 in light. The selected chip is 12.6:1. Android: Same tokens.
- State. Web: Chips use aria-checked. Save uses native disabled. The pincode error shows as red text but is not linked: no aria-invalid or aria-describedby. Android: Chips are selected. Save is enabled = false. The pincode error is not exposed with semantics { error() }.
- Motion. Web: Chip colour transitions over duration-base, 0ms under reduced motion. Android: None.

Known accessibility gaps:
- SegmentedChips in Inputs.tsx (AddressForm): the radiogroup has no accessible name, there is no arrow-key navigation, and the 36px chips have no eq-touch.
- TextField in Inputs.tsx: the pincode error is not linked to the input (no aria-invalid / aria-describedby). EqualTextField in Inputs.kt does not set semantics { error() }.
- AddressForm in Flows.tsx: Save is an lg Button, 45px tall with no eq-touch, and native disabled hides it from Tab with no reason given.
- OverflowMenu in Flows.kt (AddressCard): the 32dp trigger has no minimumInteractiveComponentSize.
- Primary buttons put text/on-action white on button/primary #00B140 in light mode: 2.85:1, below AA 4.5:1 for 14sp text (Button.css / Buttons.kt). Dark (black on lime) is 17.4:1.

Example: Saved addresses
```tsx
{addresses.map((a) => (
  <AddressCard key={a.id} label={a.label} address={formatAddress(a)}
    onEdit={() => edit(a)} onDelete={() => confirmDelete(a)} />
))}
```
```kotlin
var addresses by remember { mutableStateOf(SampleAddresses) }
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    addresses.forEach { a ->
        AddressCard(
            label = a.label,
            address = formatAddress(a),
            onEdit = {},
            onDelete = { addresses = addresses - a },
        )
    }
}
```

Example: Long address
```tsx
<AddressCard label="Work"
  address="Flat 4B, Block C, Skyline Towers, Phase 2, HITECH city, MG Road, Opposite City Center Mall, Banjara Hills, Hyderabad- 500034"
  onEdit={edit} />
```
```kotlin
AddressCard(
    label = "Work",
    address = "Flat 4B, Block C, Skyline Towers, Phase 2, HITECH city, MG Road, Opposite City Center Mall, Banjara Hills, Hyderabad- 500034",
    onEdit = {},
)
```

Example: Edit address form
```tsx
<AddressForm
  initial={{ label: 'Home', line1: 'House no. 4, Tony Street', line2: 'Financial District', city: 'Hyderabad', pincode: '500032' }}
  onSave={(address) => save(address)} />
```
```kotlin
AddressForm(
    // Compose: SavedAddress needs an id (web takes a Partial)
    initial = SavedAddress(
        id = "a1",
        label = "Home",
        line1 = "House no. 4, Tony Street",
        line2 = "Financial District",
        city = "Hyderabad",
        pincode = "500032",
    ),
    onSave = {},
)
```

#### Call Handling (`call-handling`)

Pieces of the Call Handling setup and the known-call notification: radio choice cards, contact pickers with an A–Z index, the setup takeover, permission sheets, the done wash, the Android ongoing-call notification and the ongoing-call strip.

- React: `import { CallQuestion, ChoiceCard, InfoNote, ContactPick, ContactCheckRow, AlphabetIndex, SetupPrompt, SetupDone, PermissionSheet, CallNotification, OngoingCallBar } from '@equal/ds';`
- Compose: `CallQuestion`, `ChoiceCard`, `SuggestedTag`, `InfoNote`, `ContactPick`, `ContactCheckRow`, `AlphabetIndex`, `SetupPrompt`, `SetupDone`, `PermissionSheet`, `CallNotification`, `OngoingCallBar`
- Tokens: `choice/default-bg`, `action/fill/unread`, `gradient/choice-stroke`, `info-note/bg`, `initials-disc/bg`, `gradient/setup-done`, `gradient/setup-prompt`, `ongoing-bar/bg`, `ongoing-bar/text`
- Source: Known Calls (new users) · Known-call notifications

Props of `ChoiceCard`:
- `icon`: `IconName`. Leading icon.
- `title`: `string`. Option.
- `description`: `string`. What it means.
- `selected?`: `boolean`. Green outline + tint.
- `suggested?`: `boolean`. ⭐ Suggested tag.
- `disabled?`: `boolean`. Dimmed (e.g. no permission).
- `onSelect?`: `() => void`. Choose.

Props of `CallNotification`:
- `name`: `string`. Caller.
- `state`: `'answering' | 'summary' | 'expanded' | 'connecting'`. Stage of the call.
- `category?`: `Category` = 'home-services'. Avatar art.
- `elapsed?`: `string` = '00:06'. Timer.
- `summary?`: `string`. What the caller wants.
- `replies?`: `string[]`. Quick replies (expanded).

Props of `PermissionSheet`:
- `art`: `AssetName`. 3D art.
- `title`: `string`. Ask.
- `body`: `ReactNode`. Why.
- `cta`: `string`. Action.
- `secondary?`: `string`. Underlined text action (e.g. Skip, answer everyone).
- `onClose?`: `() => void`. Floating close.

Do: Ask for a permission only at the step that needs it, and say why in one line. Keep the notification to who, what they want and one tap to act; Takeover always comes first.

Don't: Don't style the notification beyond Android's shell; the system draws it. Don't make the user pick contacts before they've chosen All calls.

Anatomy:
1. CallQuestion: Hero art and the setup question. (280 × 208 art or 300 Lottie · title headline Bold (h1) · subtitle title Regular text/secondary)
2. ChoiceCard: Radio card for one call-handling option. (radius 20 · padding 18/18/18/20 · gap 16 · icon 28 · title subheading + description body1 text/secondary · 24 radio · selected: choice/selected-bg + 2dp gradient/choice-stroke · disabled 45%)
3. SuggestedTag + InfoNote: Suggested tag on a card, and the note that asks for a permission. (tag ⭐ + caption text/secondary pill · note radius 16, info-note/bg, padding 16, info 18 + subheading, body1, underlined text/action link with chevron)
4. ContactPick: Suggested contact to add or remove. (76 wide · 56 initials disc initials-disc/bg · 22 +/× badge text/secondary · name body2)
5. ContactCheckRow + AlphabetIndex: Contact row with a checkbox, and the A–Z jump index. (52 disc · name title Medium · phone body1 tabular · 26 checkbox · index letters 11/14 Medium, gap 1)
6. PermissionSheet: Ask-once permission sheet. (sheet/bg · radius 32 top · padding 32/20/24 · 110 art · headline title · title Regular body text/secondary · block lg CTA · 44 close top-right)
7. CallNotification: Android ongoing-call notification while the assistant answers. (radius 24 bg/surface · app line caption + 'Ongoing' text/action + timer pill · 40 avatar · name subheading · summary body1, 1–2 lines · 44 answer ring or 48 app tile · 34 reply chips)
8. SetupPrompt / SetupDone / OngoingCallBar: Setup takeover, done screen and the in-chat call strip. (gradient/setup-prompt takeover + Start · gradient/setup-done wash + Done · bar 44 high, ongoing-bar/bg, lime 'Ongoing call - 02:34' subheading)

Accessibility:
- Role. Web: ChoiceCard is a button role=radio with aria-checked (the caller adds role=radiogroup); ContactCheckRow uses a role=checkbox; AlphabetIndex is a nav of buttons; PermissionSheet and SetupPrompt are role=dialog; InfoNote is role=note; CallNotification and OngoingCallBar are role=status. Android: ChoiceCard is selectable(Role.RadioButton) (wrap in selectableGroup); the checkbox is toggleable(Role.Checkbox); ContactPick is Role.Button; sheets set paneTitle; CallNotification and OngoingCallBar are polite live regions.
- Name. Web: ChoiceCard reads title, Suggested and description; ContactPick 'Add Mom' / 'Remove Vijay Cousin'; checkbox 'Select Arnav Raj'; 'Answer the call'; close 'Close'; notification 'Equal AI is answering Mom'. Android: Same strings via contentDescription; index letters use onClickLabel 'Jump to A'.
- Keyboard. Web: Each ChoiceCard is its own Tab stop; arrow keys don't move between radios. PermissionSheet and SetupPrompt don't move or trap focus and ignore Escape. Android: TalkBack reads 'Only unknown numbers, selected, radio button'; double-tap selects. System Back is not handled by the sheets.
- Touch target. Web: AlphabetIndex letters are about 14 px tall; notification replies 34 px and the answer button 44 px have no eq-touch; the checkbox is 26 × 40; Button lg is 45 px. Android: AlphabetIndex letters, ReplyChip (34dp), the answer ring (44dp) and UnderlinedLink (36dp) have no minimum size; ChoiceCard, ContactPick, the checkbox and buttons meet 48dp.
- Contrast. Web: The selected radio and choice stroke use button/primary green, 2.85:1 on white (under 3:1); the InfoNote link is 2.5:1 on info-note/bg; note text 15:1; ongoing bar lime on #262626 12.6:1; primary buttons are white on green 2.85:1. Dark uses lime with black content. Android: Same tokens and ratios as web.
- State. Web: Selected uses aria-checked plus the radio dot and outline; disabled uses the disabled attribute plus 45% opacity; checked uses aria-checked. The notification and ongoing bar are live regions, so each timer tick is announced. Android: selected/enabled on selectable, toggleable state on the checkbox; the live regions also announce every timer change.
- Motion. Web: SetupPrompt fades in and PermissionSheet slides up; both stop under prefers-reduced-motion. The CallQuestion Lottie shows its first frame. Android: SetupPrompt and PermissionSheet start visible under rememberReduceMotion; EqualLottie doesn't play.

Known accessibility gaps:
- AlphabetIndex (CallHandling.tsx and CallHandling.kt) letters are about 14 px/dp tall, far below 48.
- CallNotification reply chips (34) and answer button (44) have no touch extension in CallHandling.tsx or CallHandling.kt; UnderlinedLink in CallHandling.kt is 36dp.
- ContactCheckRow uses Checkbox (Checkbox.tsx) at 26 × 40 px with no eq-touch, and the row itself isn't clickable.
- ChoiceCard in CallHandling.tsx has role=radio but no roving tabindex or arrow-key handling.
- PermissionSheet and SetupPrompt in CallHandling.tsx are role=dialog with no focus move, focus trap or Escape.
- OngoingCallBar and CallNotification (both platforms) are live regions around a ticking timer, so every second is announced.
- Selected radio (button/primary) is 2.85:1 and the InfoNote link (text/action on info-note/bg) 2.5:1 in light theme.

Example: Choice cards
```tsx
<div role="radiogroup">
  <ChoiceCard icon="globe" title="All calls, except a few" description="I answer everyone. You pick who I skip." selected={mode === 'all'} onSelect={() => setMode('all')} />
  <ChoiceCard icon="call" title="Only unknown numbers" description="I answer numbers that are not saved in your phone." selected={mode === 'unknown'} onSelect={() => setMode('unknown')} />
</div>
<InfoNote title="Contact access needed" body="Without it, the assistant can’t handle all calls." link="Give contacts permission" onLink={askContacts} />
```
```kotlin
var mode by remember { mutableStateOf(CallMode.All) }
Column(Modifier.selectableGroup(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
    ChoiceCard(
        icon = EqualIcons.Globe,
        title = "All calls, except a few",
        description = "I answer everyone. You pick who I skip.",
        selected = mode == CallMode.All,
        onSelect = { mode = CallMode.All },
    )
    ChoiceCard(
        icon = EqualIcons.Call,
        title = "Only unknown numbers",
        description = "I answer numbers that are not saved in your phone.",
        selected = mode == CallMode.Unknown,
        onSelect = { mode = CallMode.Unknown },
    )
    InfoNote(
        title = "Contact access needed",
        body = "Without it, the assistant can’t handle all calls.",
        link = "Give contacts permission",
        onLink = { /* ask for READ_CONTACTS */ },
    )
}
```

Example: Contact pickers
```tsx
<ContactPick initials="SU" name="Mom" onClick={add} />
<ContactPick initials="VC" name="Vijay Cousin" mark="remove" onClick={remove} />
<ContactCheckRow initials="AR" name="Arnav Raj" phone="+91 8986461540" checked={picked} onToggle={toggle} />
<AlphabetIndex onPick={jumpTo} />
```
```kotlin
var picked by remember { mutableStateOf(true) }
Column {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ContactPick(initials = "SU", name = "Mom", onClick = { /* add */ })
        ContactPick(initials = "VC", name = "Vijay Cousin", onClick = { /* remove */ }, mark = ContactPickMark.Remove)
    }
    Box(Modifier.fillMaxWidth()) {
        ContactCheckRow(initials = "AR", name = "Arnav Raj", phone = "+91 8986461540", checked = picked, onCheckedChange = { picked = it })
        AlphabetIndex(Modifier.align(Alignment.CenterEnd).padding(end = 2.dp), onPick = { /* jump to letter */ })
    }
}
```

Example: Permission sheet
```tsx
<PermissionSheet art="permission-contacts" title="Allow contacts permission" body="I need your contact list to know who is calling." cta="Allow" onAllow={requestContacts} onClose={close} />
```
```kotlin
// Overlay: fills the screen (scrim + sheet); pass inline = true to draw only the sheet
PermissionSheet(
    art = EqualAssets.PermissionContacts,
    title = "Allow contacts permission",
    body = "I need your contact list to know who is calling.",
    cta = "Allow",
    onAllow = { /* request READ_CONTACTS */ },
    onClose = { /* hide the sheet */ },
)
```

Example: Call notification
```tsx
<CallNotification name="Mom" state="answering" />
<CallNotification name="Mom" state="expanded" summary={liveSummary} replies={['Takeover', 'I’ll bring them all', 'I’ll call back to get more']} onReply={reply} onAnswer={answer} />
<CallNotification name="Mom" state="connecting" />
```
```kotlin
// Design reference + in-app preview. On device, build the same content into an ongoing
// NotificationCompat (CATEGORY_CALL, custom RemoteViews); the system draws the shell.
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    CallNotification(name = "Mom", state = CallNotificationState.Answering)
    CallNotification(
        name = "Mom",
        state = CallNotificationState.Expanded,
        category = EqualCategory.HomeServices,
        summary = SampleCallSummary,
        replies = listOf("Takeover", "I’ll bring them all", "I’ll call back to get more"),
        onReply = { /* say it (it == "Takeover": pick up) */ },
        onAnswer = { /* pick up */ },
    )
    CallNotification(name = "Mom", state = CallNotificationState.Connecting)
}
```

Example: Ongoing call bar
```tsx
<OngoingCallBar elapsed="02:34" />
```
```kotlin
OngoingCallBar(elapsed = "02:34")
```

#### Gender selector (`gender-selector`)

The two-card Male / Female picker in Personal Details; the choice sets the profile avatar across the app.

- React: `import { GenderSelector } from '@equal/ds';`
- Compose: `GenderSelector`
- Tokens: `bg/surface`, `button/primary`, `gradient/gender-selected`, `gradient/gender-selected-stroke`, `gender/stroke`, `text/primary`
- Source: Flows · Profile

Do: Update the profile avatar (hero and bottom nav) as soon as the user picks. Place it under a GENDER overline, below the Name field.

Don't: Don't crop the bust art; if it is missing the card falls back to the ringed avatar. Don't add a third card or a text input here.

Anatomy:
1. Group: Two-column grid of cards. (2 columns · gap 12)
2. Card: One option, Male or Female. (120 high · radius 16 · bg/surface · 2dp transparent border (stroke/dark in dark))
3. Watermark: Faint ♂ or ♀ in the bottom-left corner. (96 · text/primary at 5% · clipped)
4. Label: 'Male' or 'Female'. (subheading · text/primary · 12 from the top)
5. Art: Bust for free users; gold-ringed avatar for paid users. (bust 60×56 · paid avatar 52 · bottom centre)
6. Selected state: Green outline and tinted fill on the chosen card. (gradient/gender-selected · 2dp button/primary border)

Accessibility:
- Role. Web: role="radiogroup" with aria-label 'Gender'. Each card is a button with role="radio". The watermark is aria-hidden. Android: The Row has selectableGroup(). Each card is selectable(role = Role.RadioButton).
- Name. Web: Each radio is named by its text, 'Male' or 'Female'. With tier paid, or when the bust is missing, ProfileAvatar adds alt 'Your profile', so the name becomes 'Male Your profile'. Android: The card merges its text. ProfileAvatar passes contentDescription null, but the ♂/♀ watermark text is not hidden and is read too.
- Keyboard. Web: Each radio is its own Tab stop, with Enter/Space to select. Arrow keys do nothing, unlike a native radio group. Android: TalkBack: swipe between the two cards, double-tap to select. TalkBack reads 'selected / not selected'.
- Touch target. Web: Cards are 120 tall and half the width. Android: Cards are 120dp tall and weighted to half the width.
- Contrast. Web: Label 18.9:1. The selected 2dp border is button/primary #00B140 on white: 2.85:1, under the 3:1 needed for a state indicator. In dark it is lime (#BAFF29), which passes. Android: Same tokens.
- State. Web: aria-checked. Visually, only the border and tint change; there is no check mark. Android: selected = true on the card. Visually, only the border and tint change.
- Motion. Web: Press scale (eq-pressable), 0ms under reduced motion. Android: None.

Known accessibility gaps:
- GenderSelector in Flows.tsx: with tier paid, or when the bust asset is missing, ProfileAvatar's default alt 'Your profile' joins each radio's name ('Male Your profile'). Pass label="".
- GenderSelector in Flows.tsx: each radio is a separate Tab stop with no arrow-key roving, which a radiogroup is expected to have.
- GenderCard in Flows.kt: the ♂/♀ watermark BasicText is not cleared from semantics, so TalkBack reads it as part of the option.
- GenderSelector (Flows.css / Flows.kt): selection is shown only by a #00B140 border (2.85:1 on white in light) and a tint, with no check mark.

Example: Free vs paid
```tsx
<GenderSelector value={gender} onChange={setGender} tier="free" />
<GenderSelector value={gender} onChange={setGender} tier="paid" />
```
```kotlin
var gender by remember { mutableStateOf(Gender.Male) }
Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    GenderSelector(value = gender, onValueChange = { gender = it }, tier = PlanTier.Free)
    GenderSelector(value = gender, onValueChange = { gender = it }, tier = PlanTier.Paid)
}
```

Example: Interactive
```tsx
const [gender, setGender] = useState<Gender>('male');

<GenderSelector value={gender} onChange={setGender} />
<ProfileAvatar variant={gender} size={56} />
```
```kotlin
var gender by remember { mutableStateOf(Gender.Male) }
GenderSelector(value = gender, onValueChange = { gender = it })
ProfileAvatar(
    variant = if (gender == Gender.Male) ProfileAvatarVariant.Male else ProfileAvatarVariant.Female,
    width = 56.dp,
)
```

Example: In Personal Details
```tsx
<AppBar title="Personal Details" onBack={goBack} />
<TextField label="Name" value={name} onChange={setName}
  helper="Your AI will call you 'Keshav'" />
<SectionHeader inset={0}>Gender</SectionHeader>
<GenderSelector value={gender} onChange={setGender} />
```
```kotlin
var name by remember { mutableStateOf("Keshav") }
var gender by remember { mutableStateOf(Gender.Female) }
EqualAppBar(title = "Personal Details", onBackClick = {})
EqualTextField(
    value = name,
    onValueChange = { name = it },
    label = "Name",
    helper = AnnotatedString("Your AI will call you '$name'"),
)
SectionHeader(title = "Gender", inset = 0.dp)
GenderSelector(value = gender, onValueChange = { gender = it })
```

#### Instruction cards (`instruction-cards`)

The pieces of the Instructions flow: recommended and preset cards on the hub, preset and active instruction cards with When / Do rows, and the preview shown in the setup chat.

- React: `import { RecommendedCard, SuggestionsComingCard, PresetCard, PresetInstructionCard, InstructionCard, WhenDoRow, InstructionPreview } from '@equal/ds';`
- Compose: `RecommendedCard`, `SuggestionsComingCard`, `PresetCard`, `PresetInstructionCard`, `InstructionCard`, `WhenDoRow`, `InstructionPreview`
- Tokens: `bg/surface`, `chip/when-bg`, `chip/do-bg`, `preset/tint-green`, `preset/tint-blue`, `preset/tint-orange`, `preset/tint-lime`, `gradient/suggestion-card`, `text/primary`, `text/secondary`, `text/tertiary`, `text/action`, `button/primary`
- Source: Flows · Instructions · Instruction Card

Do: Write When as the situation and Do as the assistant's behaviour, in plain first person ("say I am not interested"). Use sentence-case When / Do on presets and uppercase WHEN / DO on active instructions (`upper`). Confirm with 👍 Confirm (unread) next to ✍️ Edit (read) under the preview. Show SuggestionsComingCard once every recommendation is applied.

Don't: Don't delete an instruction straight from the ⋮ menu; confirm first. Don't use Material icons on preset or recommended cards; they lead with emoji. Don't put two filled buttons on a preset instruction; Apply is the only commit.

Anatomy:
1. RecommendedCard: Horizontal card with an emoji, + add, title and description. (188 wide · min 114 · radius 16 · 1dp stroke/subtle · emoji 26 · add 30 circle icon-button/bg, add 20 text/action)
2. SuggestionsComingCard: Shown once every recommendation is added. (gradient/suggestion-card · radius 16 · orb 18 + caption · bodyLarge · illustration 112)
3. PresetCard: Tappable preset with an emoji in a tinted circle and a chevron. (flow card · emoji 16 in 26 circle (preset/tint-*) · chevron 22 text/placeholder · subheading + captionWrap)
4. PresetInstructionCard: Preset instruction with Apply, which becomes an 'Applied' pill. (title subheading (h3) · Button sm 24 · Applied pill 24 action-card/highlight + check 16 text/action)
5. WhenDoRow: When / Do line: a flat chip on presets, a fading pill on active instructions. (preset chip 26 high, min 42, chip/when-bg / chip/do-bg · active pill 51×24 gradient/when-chip / do-chip · text 13/18)
6. InstructionCard: Active instruction: bold title + ⋮, source pill, divider, WHEN and DO. (radius 16 · 1dp stroke/subtle · padding 17 · title 17/20 Bold · source pill 24 high)
7. InstructionPreview: Preview in the setup chat, with an optional ✅ reaction. (white frame radius 16 · padding 8 · max 280 · reaction 32 circle, shadow/raised)

Accessibility:
- Role. Web: RecommendedCard is a div with an add <button>. PresetCard is a <button>. Instruction titles are h3. The overflow is a button with aria-expanded. Emoji are aria-hidden. Android: Add, PresetCard and Apply are Role.Button. The overflow is a clickable Box. Titles have no heading(). EmojiGlyph text is not hidden.
- Name. Web: Add is 'Add {title}'. PresetCard is named by its title and description. The overflow is 'Instruction options' on every card. The ✅ reaction has aria-label 'Confirmed' on a span with no role. Android: Add has onClickLabel and contentDescription 'Add {title}'. Overflow: 'Instruction options'. Emoji are read by their Unicode names.
- Keyboard. Web: Tab to add, the preset cards, Apply and ⋮, then Enter/Space. When Apply becomes the 'Applied' span, focus is lost. Android: TalkBack: swipe through the cards, double-tap to act. Back closes the overflow popup.
- Touch target. Web: Add (30) uses eq-touch for 48. The sm Apply button uses eq-touch. The overflow gets 48 through IconButton. Android: Add is a 30dp Box and the overflow a 32dp Box, both with no minimum size. Apply (sm) gets 48 from EqualButton.
- Contrast. Web: Titles 18.9:1, descriptions text/secondary 7.5:1. Below 3:1 in light: the add icon on icon-button/bg (2.55:1), the Applied text on its highlight (2.64:1), and the chevron in text/placeholder (2.32:1). The preset When/Do chip label is 4.43:1 in dark. Android: Same tokens. In dark, add and Applied are lime on dark tints, above 10:1.
- State. Web: Applied is shown by the check icon and the 'Applied' text. The change is not announced. Android: Same visuals. The change is not announced.
- Motion. Web: Press scale only, 0ms under reduced motion. Android: None.

Known accessibility gaps:
- RecommendedCard add (30dp) and OverflowMenu (32dp) in Flows.kt have no minimumInteractiveComponentSize.
- PresetInstructionCard in Flows.tsx: Apply is replaced by a non-focusable 'Applied' span, so keyboard focus is lost and the change is not announced (no live region on web or Android).
- InstructionPreview in Flows.tsx: the reaction's aria-label 'Confirmed' is on a span with no role, so it is not announced. In Flows.kt the ✅ EmojiGlyph is read as a raw emoji name.
- EmojiGlyph in Foundation.kt (used in RecommendedCard, PresetCard and the source pill) is not hidden from TalkBack, so emoji names are read aloud.
- InstructionCard (Flows.tsx / Flows.kt): every overflow button is labelled 'Instruction options', without the instruction title, so they can't be told apart in a list.
- Contrast below 3:1 in light: the add icon text/action on icon-button/bg (2.55:1), the Applied pill text/action on action-card/highlight (2.64:1), and the PresetCard chevron text/placeholder (2.32:1). The preset When/Do chip label is text/tertiary on chip/when-bg at 4.43:1 in dark.

Example: Recommended for you
```tsx
<RecommendedCard emoji="🚫" title="Decline sales & spam"
  description="Politely declines sales and insurance calls." onAdd={add} />
<RecommendedCard emoji="💬" title="Take a message"
  description="Takes their name, number and message." onAdd={add} />

{allApplied && <SuggestionsComingCard />}
```
```kotlin
var added by remember { mutableStateOf(setOf<String>()) }
if (added.size < 2) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        if ("decline" !in added) {
            RecommendedCard(
                emoji = "🚫",
                title = "Decline sales & spam",
                description = "Politely declines sales and insurance calls.",
                onAdd = { added = added + "decline" },
            )
        }
        if ("message" !in added) {
            RecommendedCard(
                emoji = "💬",
                title = "Take a message",
                description = "Takes their name, number and message.",
                onAdd = { added = added + "message" },
            )
        }
    }
} else {
    SuggestionsComingCard()
}
```

Example: Browse presets
```tsx
<PresetCard emoji="🛡️" tint="green" title="Screen & Protect"
  description="Decline spam, hold the line on loan and payments call, close wrong call" onClick={open} />
<PresetCard emoji="📞" tint="blue" title="Handle everyday calls"
  description="Take message, guide deliveries, relay to family, start in your language" onClick={open} />
<PresetCard emoji="💼" tint="orange" title="Run my business"
  description="Capture enquiries, orders, bookings, job, and supplier calls" onClick={open} />
```
```kotlin
PresetCard(
    emoji = "🛡️", tint = PresetTint.Green, title = "Screen & Protect",
    description = "Decline spam, hold the line on loan and payments call, close wrong call", onClick = {},
)
PresetCard(
    emoji = "📞", tint = PresetTint.Blue, title = "Handle everyday calls",
    description = "Take message, guide deliveries, relay to family, start in your language", onClick = {},
)
PresetCard(
    emoji = "💼", tint = PresetTint.Orange, title = "Run my business",
    description = "Capture enquiries, orders, bookings, job, and supplier calls", onClick = {},
)
```

Example: Preset instructions
```tsx
<PresetInstructionCard instruction={instructionLibrary.declineSales}
  applied={applied} onApply={apply} />
```
```kotlin
var applied by remember { mutableStateOf(false) }
PresetInstructionCard(
    instruction = InstructionLibrary.declineSales,
    applied = applied,
    onApply = { applied = true },
)
```

Example: Active instructions
```tsx
<InstructionCard instruction={{
  id: 'decline-sales',
  title: 'Decline sales, promo spam calls',
  source: { emoji: '✨', label: 'Recommended for you' },
  when: 'The caller is selling loan, insurance, credit card, product, or another unsolicited offer',
  do: 'Politely say I am not interested and end the conversation without discussing the offer',
}} onEdit={edit} onDelete={confirmDelete} />
```
```kotlin
InstructionCard(
    instruction = Instruction(
        id = "decline-sales",
        title = "Decline sales, promo spam calls",
        source = InstructionSource(emoji = "✨", label = "Recommended for you"),
        whenText = "The caller is selling loan, insurance, credit card, product, or another unsolicited offer",
        doText = "Politely say I am not interested and end the conversation without discussing the offer",
    ),
    onEdit = {},
    onDelete = {},
)
```

Example: Preview in the setup chat
```tsx
<InstructionPreview title="Decline sales calls"
  when="Caller is selling a loan, insurance or product"
  action="Politely decline and end the conversation"
  time="03:21" confirmed={confirmed} />
```
```kotlin
var confirmed by remember { mutableStateOf(false) }
InstructionPreview(
    title = "Decline sales calls",
    whenText = AnnotatedString("Caller is selling a loan, insurance or product"),
    action = AnnotatedString("Politely decline and end the conversation"),
    time = "03:21",
    confirmed = confirmed,
)
```

### Group: Inputs

#### Checkbox (`checkbox`)

A coded checkbox with an optional label, used for multi-select such as "Select All" in chat-list selection mode.

- React: `import { Checkbox } from '@equal/ds';`
- Compose: `EqualCheckbox`
- Tokens: `button/primary`, `text/secondary`, `text/primary`
- Source: §5 Chat Header · Selection mode

Do: Use for multi-select lists; the whole label is the tap target. Use bodyLarge labels in headers ("Select All") and body1 in dense lists.

Don't: Don't use a checkbox for an instant on/off setting; that is a Switch. Don't replace the coded box with an image; checkboxes are coded, never images.

Anatomy:
1. Box: The Material checkbox glyph that shows checked or blank. (Web 22 default · Compose 18 · checked button/primary · unchecked web text/secondary, Compose text/tertiary)
2. Label: Optional text beside the box; part of the same tap target. (gap 12 · bodyLarge 16/400 or body1 14/400 · text/primary)

Accessibility:
- Role. Web: <button role='checkbox'> with aria-checked; the icon is aria-hidden. Android: toggleable(role = Role.Checkbox) when onCheckedChange is set; with null the row (e.g. SelectionChatHeader Select All) owns it.
- Name. Web: The visible label inside the button; with no label pass ariaLabel (e.g. 'Select Arnav Raj'). Android: contentDescription parameter when nothing beside it names it; otherwise the parent row's merged text.
- Keyboard. Web: Tab to focus, Space or Enter toggles. Android: TalkBack: swipe to focus, double-tap to toggle; announces 'checked' or 'not checked'.
- Touch target. Web: minHeight 40 and no .eq-touch: a labelled checkbox is 40px high, an icon-only one is 22 × 40. Android: minimumInteractiveComponentSize() gives 48dp around the 18dp glyph.
- Contrast. Web: Unchecked text/secondary on white is 7.5:1; checked button/primary #00B140 is 2.85:1 in light (below 3:1), lime in dark passes. Android: Unchecked text/tertiary #6E6E6E is 5.1:1 on white; checked uses the same #00B140.
- State. Web: aria-checked; the glyph changes from an empty box to a filled box with a tick, so state is not colour alone. There is no disabled prop. Android: toggleableState from toggleable; the glyph changes shape. No enabled parameter.

Known accessibility gaps:
- Checkbox.tsx: no eq-touch and only minHeight 40, so the hit area is 40px high (22 × 40 with no label).
- Checkbox.tsx / EqualSwitch.kt (EqualCheckbox): no disabled / enabled support on either platform.
- Checkbox.tsx / EqualSwitch.kt: checked glyph button/primary #00B140 on white is 2.85:1 in light mode, below 3:1.

Example: Interactive
```tsx
const [all, setAll] = useState(false);

<Checkbox checked={all} onChange={setAll} label="Select All" />
<Checkbox checked={a} onChange={setA} label="Loan Offers" labelVariant="body1" />
```
```kotlin
var all by remember { mutableStateOf(false) }
var loanOffers by remember { mutableStateOf(false) }

// Compose: no label / labelVariant params; put an EqualText beside the box.
Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
    EqualCheckbox(checked = all, onCheckedChange = { all = it })
    EqualText(text = "Select All", style = EqualTheme.type.bodyLarge, color = EqualTheme.colors.textPrimary)
}
Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
    EqualCheckbox(checked = loanOffers, onCheckedChange = { loanOffers = it })
    EqualText(text = "Loan Offers", style = EqualTheme.type.body1, color = EqualTheme.colors.textPrimary)
}
```

Example: Sizes and bare
```tsx
<Checkbox checked size={18} />
<Checkbox checked={false} size={18} />
<Checkbox checked />
<Checkbox checked={false} />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
    EqualCheckbox(checked = true, onCheckedChange = {}, size = 18.dp)
    EqualCheckbox(checked = false, onCheckedChange = {}, size = 18.dp)
    // Compose: default size is 18.dp (web defaults to 22), so pass 22.dp explicitly.
    EqualCheckbox(checked = true, onCheckedChange = {}, size = 22.dp)
    EqualCheckbox(checked = false, onCheckedChange = {}, size = 22.dp)
}
```

Example: In the selection header
```tsx
<SelectionHeader count={selected.length} allSelected={all}
  onSelectAll={(v) => setSelected(v ? ids : [])} />
```
```kotlin
val ids = listOf("arnav", "amit", "priya")
var selected by remember { mutableStateOf(setOf<String>()) }

SelectionChatHeader(
    selectedCount = selected.size,
    allSelected = selected.size == ids.size,
    onSelectAllChange = { all -> selected = if (all) ids.toSet() else emptySet() },
    onBackClick = {},
    onMarkReadClick = {},
    onDeleteClick = {},
)
```

#### Composer (`composer`)

The message input bar with a send button that stays disabled until there is text, used at the bottom of a chat and in the AI panel.

- React: `import { Composer } from '@equal/ds';`
- Compose: `VoiceInputBar`
- Tokens: `bg/surface`, `stroke/subtle`, `action/stroke/unread`, `shadow/focusRing`, `gradient/send-disabled`, `gradient/fab`, `shadow/fab`, `text/tertiary`, `text/primary`
- Source: §15 Voice Input Bar (Composer)

Do: Pin the composer to the bottom of the chat or AI panel. Leave send disabled on empty input; the component does this for you.

Don't: Don't add attachment or emoji buttons inside the bar; the spec is input + send only. Don't change the send glyph; it is the coded send icon rotated −35°.

Anatomy:
1. Input: Pill text field where the user types a message. (45 high · radius full · padding h20 · bg/surface · 1px stroke/subtle · focus action/stroke/unread + shadow/focusRing · body1 14/400)
2. Placeholder: Hint shown while empty. (web 'Type a message...' · Compose 'Type a message' · text/tertiary)
3. Send button: Circle that sends the message; enabled only when there is text. (45 circle · gap 10 · disabled gradient/send-disabled · active gradient/fab + shadow/fab)
4. Send icon: Paper-plane glyph rotated −35°. (send 20 · active text/on-action · disabled text/on-dark)

Accessibility:
- Role. Web: <form> with a native <input> and a <button type='submit'>. Android: BasicTextField plus a Box with clickable(role = Role.Button).
- Name. Web: Input aria-label 'Message'; send button aria-label 'Send'. Android: Input has no contentDescription (placeholder only); send uses sendContentDescription ('Send') as both onClickLabel and icon description.
- Keyboard. Web: Enter submits the form; Tab moves to Send, which is skipped while disabled. Android: IME action Send calls onSend when there is text; TalkBack double-tap on the send button.
- Touch target. Web: Send is 45px with no .eq-touch. Android: Send is a 45dp Box without minimumInteractiveComponentSize.
- Contrast. Web: Text 17:1, placeholder text/tertiary 5.1:1. Active send icon is white on #86E63B→#00B140 (1.6–2.85:1) in light; dark is black on lime (about 17:1). Android: Same tokens as web.
- State. Web: Send uses the native disabled attribute until there is text; the fill also changes. Android: clickable(enabled = canSend) exposes disabled; enabled = false on the bar disables both.
- Motion. Web: Border, ring and send shadow fade over 200ms; press scale on send; zeroed under prefers-reduced-motion. Android: Press scale on send via eqPressFeedback, following the system animator scale.

Known accessibility gaps:
- Composer.tsx: the 45px send button has no eq-touch, so its hit area is below 48px.
- Composer.kt: SendButton is 45dp without minimumInteractiveComponentSize().
- Composer.kt: VoiceInputBar's BasicTextField has no contentDescription; the name relies on the placeholder (web uses aria-label 'Message').
- Composer.css / Composer.kt: active send icon is white on gradient/fab (#86E63B → #00B140), 1.6–2.85:1 in light mode, below 3:1.

Example: Interactive
```tsx
<Composer onSend={(text) => setSent((s) => [...s, text])} />
```
```kotlin
val sent = remember { mutableStateListOf<String>() }
var text by remember { mutableStateOf("") }

// Compose: always controlled; clear the value yourself after send.
VoiceInputBar(
    value = text,
    onValueChange = { text = it },
    onSend = {
        sent += text.trim()
        text = ""
    },
)
```

Example: States
```tsx
<Composer />
<Composer forceFocus />
<Composer value="Sure, I'll be there!" onChange={setText} />
```
```kotlin
var text by remember { mutableStateOf("Sure, I'll be there!") }

Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    VoiceInputBar(value = "", onValueChange = {}, onSend = {})
    // Compose: no forceFocus; the focused look appears when the field has focus.
    VoiceInputBar(value = text, onValueChange = { text = it }, onSend = {})
}
```

#### Search (`search`)

The search screen’s pieces: the outlined search bar with back inside, section labels with Clear all, recent searches as avatar tiles, message hits with the match in bold, loading dots and the three illustration states.

- React: `import { SearchBar, SearchSection, RecentSearches, MessageResult, LoadingDots, SearchState } from '@equal/ds';`
- Compose: `SearchBar`, `SearchSection`, `RecentSearches`, `MessageResult`, `LoadingDots`, `SearchState`
- Tokens: `button/primary`, `bg/surface`, `text/tertiary`, `text/primary`
- Source: Search

Props of `SearchBar`:
- `value`: `string`. Query.
- `onChange?`: `(v: string) => void`. Typing.
- `onBack?`: `() => void`. Back arrow inside the bar.
- `placeholder?`: `string` = 'Search for names'. Hint.

Props of `MessageResult`:
- `name`: `string`. Who.
- `time`: `string`. When.
- `text`: `string`. The message line.
- `query`: `string`. Bolded wherever it appears.

Props of `SearchState`:
- `art`: `AssetName`. Illustration.
- `title`: `string`. Headline.
- `body`: `string`. One line of help.
- `size?`: `number` = 160. Art size.

Do: Show chats first and messages after; chats come back fastest. Bold the match in message hits so people see why each one showed up.

Don't: Don't show a spinner for the whole screen; load each section in place with the dots. Don't reuse the no-results art for errors; offline has its own.

Anatomy:
1. SearchBar: Pill search field with back inside and clear once there is a query. (52 high · margin 8/16 · radius full · bg/surface · 1.5dp button/primary outline · back 40 (48 touch) · bodyLarge input, placeholder text/tertiary, caret text/action · clear × 18 text/tertiary)
2. SearchSection: Section label with optional Clear all. (overline uppercase text/tertiary · padding 14/16/8 · Clear all caption pill bg/surface, padding 4/12)
3. RecentSearches: Recent searches as avatar tiles. (72 wide tiles · gap 14 · 52 avatar · caption name truncated)
4. MessageResult: A message hit with the match in bold. (padding 10/16 · name subheading + time micro text/tertiary · line body1, match Bold text/primary · 1dp stroke/subtle between hits)
5. LoadingDots: Three dots that pulse while a section loads. (9 dots · gap 8 · button/primary · pulse 1s, staggered 0.15s · padding 24)
6. SearchState: Illustration state: start, no internet, no results. (art 160 (100–120 in use) · title title Medium (h2 on web) · body body1 text/secondary, max 280)

Accessibility:
- Role. Web: Input is a plain text input (not type=search); back, clear, Clear all, tiles and hits are buttons; LoadingDots is role=status; SearchState title is h2; section labels are plain text. Android: BasicTextField with contentDescription; back and clear are Role.Button; LoadingDots is a polite live region; section labels and SearchState titles are plain text, not heading().
- Name. Web: Input named by its placeholder ('Search for names'); 'Back'; 'Clear search'; 'Clear all'; tiles by avatar alt plus label (e.g. 'Career Amit Nanda'); hits by name, time and line. Android: Same strings; recent tiles have onClickLabel 'Search Amit Nanda'.
- Keyboard. Web: Tab: back, input, clear; Enter/Space on buttons. The input has autoFocus when asked. Android: TalkBack: swipe to the field and double-tap to edit; double-tap tiles and hits.
- Touch target. Web: Back and clear use eq-touch (48); Clear all eq-touch; tiles 72 wide; hits full width. Android: Back, clear and Clear all use minimumInteractiveComponentSize; tiles and hits are large rows.
- Contrast. Web: Placeholder and section labels text/tertiary 5.1:1 on white; highlight Bold text/primary. The green bar outline and loading dots (button/primary) are 2.85:1 in light; lime in dark. Android: Same tokens and ratios as web.
- State. Web: The match is shown by weight (Bold), not colour. Loading is announced via role=status 'Loading'. Result counts are not announced. Android: Loading announced by the live region; matches bolded.
- Motion. Web: LoadingDots pulse; stopped under prefers-reduced-motion (dots stay solid). Android: LoadingDots stop under rememberReduceMotion.

Known accessibility gaps:
- SearchSection labels and SearchState titles in Search.kt are not marked heading(), and web SearchSection is plain text, so results can't be skimmed by heading.
- SearchBar outline and LoadingDots use button/primary at 2.85:1 in light theme, under 3:1 for UI parts.
- RecentSearches tiles in Search.tsx include the CategoryAvatar alt in the button name ('Career Amit Nanda'); the avatar should be decorative there.

Example: Search bar
```tsx
<SearchBar value={q} onChange={setQ} onBack={goBack} autoFocus />
```
```kotlin
var q by remember { mutableStateOf("") }
SearchBar(value = q, onValueChange = { q = it }, onBack = {}, autoFocus = true)
```

Example: Recent searches
```tsx
<SearchSection title="Recent searches" onClear={clearRecent} />
<RecentSearches items={recent} onPick={setQ} />
```
```kotlin
var q by remember { mutableStateOf("") }
var recent by remember {
    mutableStateOf(
        listOf(
            RecentSearch("Amit Nanda", EqualCategory.Career),
            RecentSearch("Shankar", EqualCategory.Ride),
            RecentSearch("DSR Builder", EqualCategory.Financial),
        ),
    )
}
Column {
    SearchBar(value = q, onValueChange = { q = it })
    SearchSection(title = "Recent searches", onClear = { recent = emptyList() })
    RecentSearches(items = recent, onPick = { q = it })
}
```

Example: Message results
```tsx
<MessageResult name="Santosh Anna" time="3:02 PM" text={line} query={q} onClick={openMessage} />
```
```kotlin
val q = "Sa"
Column {
    SearchSection(title = "Messages")
    MessageResult(name = "Santosh Anna", time = "3:02 PM", text = "Caller said that they’ll call you in the evening", query = q, onClick = {})
    EqualDivider()
    MessageResult(name = "Amit Nanda", time = "3:02 PM", text = "Same address, near Gachibowli", query = q, onClick = {})
}
```

Example: States
```tsx
<SearchState art="illustration-search" title="Search across your calls" body="…" />
<SearchState art="illustration-no-internet" title="No internet connection" body="…" />
<SearchState art="illustration-no-results" title="No results found" body="…" />
<LoadingDots />
```
```kotlin
Column {
    // Compose: SearchState takes an EqualAssets illustration and a size in dp
    SearchStateView(art = EqualAssets.IllustrationSearch, size = 170.dp, title = "Search across your calls", body = "Look for names, phone numbers, categories, keywords")
    SearchStateView(art = EqualAssets.IllustrationNoInternet, size = 130.dp, title = "No internet connection", body = "We could not connect to a stable internet. Check your connection and try again.")
    SearchStateView(art = EqualAssets.IllustrationNoResults, size = 150.dp, title = "No results found", body = "Couldn’t find anything matching. Try a different name, number, category or keyword")
    LoadingDots()
}
```

#### Search field (`search-field`)

A pill search input with a leading search icon and a clear button, used to filter chats.

- React: `import { SearchField } from '@equal/ds';`
- Compose: `SearchField`
- Tokens: `bg/surface`, `text/tertiary`, `text/primary`, `text/placeholder`
- Source: Surfaces from the Typography screen inventory · Search Field

Do: Say what is being searched in the placeholder ("Search chats"). Show an EmptyState with the query in it when nothing matches.

Don't: Don't add a separate search button; results filter as you type. Don't use it as a general form field; use TextField.

Anatomy:
1. Container: Full-width pill that holds the search input. (48 high · radius full · bg/surface · web 1px stroke/subtle border, focus action/stroke/unread + shadow/focusRing · padding 16 start / 14 end)
2. Search icon: Leading magnifier that marks the field as search. (search 20 · text/tertiary · gap web 10, Compose 8 · decorative)
3. Input / placeholder: The query text, or 'Search for names' while empty. (bodyLarge 16/400 · text/primary · placeholder web text/tertiary, Compose text/placeholder)
4. Clear button: Web only: appears once there is text and empties the field. (close 18 · text/tertiary · .eq-touch 48 hit area · aria-label 'Clear')

Accessibility:
- Role. Web: Native <input> inside a <label>; with onActivate it becomes a readOnly input that hands off to the search screen. Android: BasicTextField when editable; with onActivate a Row with clickable(role = Role.Button).
- Name. Web: aria-label is the placeholder ('Search for names'); the clear button is 'Clear'. Android: No contentDescription; the name relies on the placeholder drawn in the decoration box. The onActivate row uses onClickLabel = placeholder plus the visible text.
- Keyboard. Web: Tab to the input, type; Tab again reaches Clear. With onActivate, focusing the input blurs it at once and calls onActivate. Android: TalkBack: double-tap to edit; the onActivate variant is a button, double-tap opens search.
- Touch target. Web: Container 48px high; Clear gets 48px via .eq-touch. Android: 48dp high, full width.
- Contrast. Web: Text 17:1; placeholder and icon text/tertiary on white 5.1:1 (dark #999999 on #222222 5.6:1). The 1px stroke/subtle border is 1.2:1. Android: Placeholder uses text/placeholder #AAAAAA (2.3:1 on white), lower than web.
- State. Web: Clear appears only when there is a value; focus shows a green border and ring. Android: No clear control or focus styling.
- Motion. Web: Border and ring fade over 200ms; zeroed under prefers-reduced-motion. Android: None.

Known accessibility gaps:
- Inputs.tsx: with onActivate the field is a readOnly input that blurs itself on focus, so keyboard and screen-reader users lose focus; it should be a <button> styled as the field.
- Inputs.kt: the editable SearchField has no contentDescription and no clear button; the name relies on placeholder text in the decoration box.
- Inputs.kt: SearchField placeholder uses text/placeholder #AAAAAA (2.3:1 on white) where web uses text/tertiary (5.1:1).

Example: Empty
```tsx
const [q, setQ] = useState('');

<SearchField value={q} onChange={setQ} />
```
```kotlin
var q by remember { mutableStateOf("") }

// Compose: the default placeholder is "Search", so pass "Search chats".
SearchField(value = q, onValueChange = { q = it }, placeholder = "Search chats")
```

Example: With a query
```tsx
<SearchField value="Amit" onChange={setQ} />
```
```kotlin
var q by remember { mutableStateOf("Amit") }

// Compose: no built-in clear (X) button; clear by setting the value to "".
SearchField(value = q, onValueChange = { q = it }, placeholder = "Search chats")
```

Example: Filtering the chat list
```tsx
<SearchField value={q} onChange={setQ} />
{results.length === 0
  ? <EmptyState title="No chats found" body={`Nothing matches "\${q}". Try a name or number.`} />
  : results.map((c) => <ChatListItem key={c.id} {...c} />)}
```
```kotlin
val chats = listOf("Arnav Raj", "Amit Kumar", "Priya Nair")
var q by remember { mutableStateOf("") }
val results = chats.filter { it.contains(q, ignoreCase = true) }

SearchField(value = q, onValueChange = { q = it }, placeholder = "Search chats")
if (results.isEmpty()) {
    EmptyState(title = "No chats found", body = "Nothing matches \"$q\". Try a name or number.")
} else {
    results.forEach { name ->
        ChatListItem(name = name, preview = "You have a visitor", date = "Yesterday")
    }
}
```

#### Segmented chips (`segmented-chips`)

A single-select row of pill chips for a short, fixed set of options, like the Home / Work / Other address label.

- React: `import { SegmentedChips } from '@equal/ds';`
- Compose: `SegmentedChips`
- Tokens: `chip/selected-bg`, `chip/selected-text`, `stroke/medium`, `text/secondary`
- Source: Surfaces from the Typography screen inventory · Segmented Label Chips

Do: Use for two to four short options where exactly one is always selected. Declare options `as const` so value and onChange are typed to the union.

Don't: Don't use it for multi-select; use checkboxes. Don't use it for long labels that would wrap; the chips wrap as a row, not the text.

Anatomy:
1. Group: Row of mutually exclusive chips (Home / Work / Other). (gap 8 · wraps on web)
2. Chip: One option pill. (36 high · padding h16 · radius full · 1px stroke/medium · bg/surface)
3. Label: The option name. (button 14/500 · text/secondary)
4. Selected chip: The chosen option, filled dark. (fill + border chip/selected-bg (#333333 light, #F7F7F7 dark) · label chip/selected-text)

Accessibility:
- Role. Web: role='radiogroup' on the row and <button role='radio'> per chip. Android: selectableGroup() on the Row and selectable(role = Role.RadioButton) per chip.
- Name. Web: Each chip is named by its label; the group has no accessible name. Android: Each chip by its text; the group has no label.
- Keyboard. Web: Every chip is its own Tab stop and Enter/Space selects; arrow keys do nothing. Android: TalkBack: swipe between options, double-tap to select; announces 'selected' and position in the group.
- Touch target. Web: 36px high with no .eq-touch, so the hit area is under 48px. Android: minimumInteractiveComponentSize() gives 48dp around the 36dp chip.
- Contrast. Web: Unselected text/secondary on white 7.5:1; selected white on #333333 12.6:1 (dark #111111 on #F7F7F7). The stroke/medium border is 1.3:1. Android: Same tokens as web.
- State. Web: aria-checked on the selected radio; selection is a full fill swap, not just a hue change. Android: selected = true is exposed by selectable.
- Motion. Web: Fill, colour and border fade over 200ms, plus press scale; zeroed under prefers-reduced-motion. Android: No animation.

Known accessibility gaps:
- Inputs.tsx: SegmentedChips radios have no arrow-key handling or roving tabindex; each chip is a separate Tab stop.
- Inputs.tsx / Inputs.kt: the radiogroup / selectableGroup has no accessible name and no prop to set one.
- Inputs.css: .eq-seg is 36px high with no eq-touch, so the web hit area is under 48px.

Example: Address label
```tsx
const LABELS = ['Home', 'Work', 'Other'] as const;
const [label, setLabel] = useState<(typeof LABELS)[number]>('Home');

<SegmentedChips options={LABELS} value={label} onChange={setLabel} />
```
```kotlin
val labels = listOf("Home", "Work", "Other")
var selected by remember { mutableStateOf(0) }

SegmentedChips(options = labels, selectedIndex = selected, onSelectedIndexChange = { selected = it })
```

Example: Any string union
```tsx
const SPEEDS = ['Slow', 'Normal', 'Fast'] as const;

<SegmentedChips options={SPEEDS} value={v} onChange={setV} />
```
```kotlin
val speeds = listOf("Slow", "Normal", "Fast")
var selected by remember { mutableStateOf(1) }

// Compose: options are a List<String> addressed by index, not a typed union.
SegmentedChips(options = speeds, selectedIndex = selected, onSelectedIndexChange = { selected = it })
```

#### Switch (`switch`)

A controlled on/off toggle (40 × 24 track) for settings that take effect immediately, such as the assistant or promotional-call muting.

- React: `import { Switch } from '@equal/ds';`
- Compose: `EqualSwitch`
- Tokens: `button/primary`, `button/disabled`, `brand/white`, `shadow/raised`
- Source: §3 Assistant Availability Toggle · Switch

Do: Use a Switch when the change applies instantly (Mute Promotional Calls, Get updates on WhatsApp). Put the visible label in the row beside it and pass the same text as `label`. Confirm with a sheet when turning something off has consequences, as WhatsApp Updates does ("Turn off WhatsApp updates?").

Don't: Don't use a Switch for a choice that needs a Save button; use Checkbox or SegmentedChips. Don't recolour the track; on is button/primary and off is button/disabled in both themes.

Anatomy:
1. Track: The pill that shows on or off and takes the tap. (40 × 24 · radius full · on button/primary · off button/disabled)
2. Thumb: The circle that slides to the on side. (18 circle · inset 3 · travel 16 · shadow/raised · on text/on-action (white in light, black on lime in dark) · off brand/white)

Accessibility:
- Role. Web: <button role='switch'> with aria-checked. Android: toggleable(role = Role.Switch) when onCheckedChange is set; with null the parent row (AssistantToggleCard, ToggleRow) owns the semantics.
- Name. Web: Required `label` prop set as aria-label; it should match the visible row label (e.g. 'AI Assistant'). Android: No contentDescription parameter: the name comes from the parent row's merged text. Use onCheckedChange = null inside a labelled row.
- Keyboard. Web: Tab to focus, Space or Enter toggles; disabled removes it from the tab order. Android: TalkBack: swipe to focus, double-tap to toggle; it announces 'on' or 'off'.
- Touch target. Web: .eq-touch gives a 48px hit area around the 40 × 24 track. Android: minimumInteractiveComponentSize() on the toggleable gives 48dp; a parent row usually supplies a larger target.
- Contrast. Web: On track #00B140 on white is 2.85:1 and off track #DDDDDD is 1.36:1, both below 3:1; dark lime on #222222 passes, off #444444 is 1.63:1. Thumb position also shows state. Android: Same tokens as web.
- State. Web: aria-checked true/false; the thumb moves right as well as changing colour, so state is not colour alone. Disabled uses the disabled attribute and 50% opacity. Android: toggleableState is announced; enabled = false sets disabled semantics but draws no visual change.
- Motion. Web: Track and thumb animate over motion.switchToggle (500ms ease-in-out); base.css zeroes it under prefers-reduced-motion. Android: Thumb offset and track colour tween over 500ms, set to 0ms when rememberReduceMotion() is true.

Known accessibility gaps:
- Switch.css / EqualSwitch.kt: off track button/disabled #DDDDDD on white is 1.36:1 (dark #444444 on #222222 is 1.63:1) and on track #00B140 on white is 2.85:1, below the 3:1 non-text minimum.
- EqualSwitch.kt: no contentDescription parameter, so a standalone switch with onCheckedChange has no accessible name.
- EqualSwitch.kt: enabled = false changes nothing visually (web dims to 50%).

Example: Interactive
```tsx
const [on, setOn] = useState(true);

<Switch checked={on} onChange={setOn} label="AI Assistant" />
```
```kotlin
var on by remember { mutableStateOf(true) }

// Compose: no label param; set the accessible label with semantics.
EqualSwitch(
    checked = on,
    onCheckedChange = { on = it },
    modifier = Modifier.semantics { contentDescription = "AI Assistant" },
)
```

Example: States
```tsx
<Switch checked label="On" />
<Switch checked={false} label="Off" />
<Switch checked disabled label="On, disabled" />
<Switch checked={false} disabled label="Off, disabled" />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
    EqualSwitch(checked = true, onCheckedChange = {})
    EqualSwitch(checked = false, onCheckedChange = {})
    EqualSwitch(checked = true, onCheckedChange = {}, enabled = false)
    EqualSwitch(checked = false, onCheckedChange = {}, enabled = false)
}
```

Example: In context
```tsx
<RowGroup>
  <ToggleRow label="Mute Promotional Calls" wrap
    description="Equal AI Assistant can identify Promotional Calls and automatically mute them"
    checked={mute} onChange={setMute} />
</RowGroup>
```
```kotlin
var mute by remember { mutableStateOf(true) }

RowGroup {
    ToggleRow(
        label = "Mute Promotional Calls",
        description = "Equal AI Assistant can identify Promotional Calls and automatically mute them",
        descriptionWraps = true,
        checked = mute,
        onCheckedChange = { mute = it },
    )
}
```

#### Text field (`text-field`)

A borderless white form field with an uppercase overline label, bodyLarge value, helper and error text, used in the Personal Details and Address forms.

- React: `import { TextField } from '@equal/ds';`
- Compose: `EqualTextField`
- Tokens: `bg/surface`, `stroke/medium`, `action/stroke/unread`, `shadow/focusRing`, `text/primary`, `text/placeholder`, `text/tertiary`, `text/secondary`, `text/danger`
- Source: Surfaces from the Typography screen inventory · Text Field

Do: Write the overline label in the string's natural case; the component uppercases it (rule 5). Use `pill` for single short values (Name) and `rounded` for address lines. Add `className="eq-tnum"` on numeric fields; postal codes use tabular figures (rule 6).

Don't: Don't add a border in light mode; fields are borderless white on bg/primary. Don't put instructions in the placeholder that the user needs after typing; use `helper`. Don't show both helper and error; the error replaces the helper.

Anatomy:
1. Label: Uppercase overline that names the field, with * when required. (overline 11/500 · text/tertiary · margin-bottom 8)
2. Optional marker: '(Optional)' after the label for fields the user may skip. (caption Regular 12/400 · text/tertiary · gap 6)
3. Input container: The surface the user types into. (min height 48 · radius/md 12 · padding 12/14 · bg/surface · border transparent in light, stroke/subtle in dark · focus action/stroke/unread + shadow/focusRing · error text/danger)
4. Value / placeholder: The entered text, or a hint while empty. (bodyLarge 16/400 · text/primary · placeholder text/placeholder · multiline 2 rows)
5. Helper or error: One line below the field: guidance, or the error that replaces it. (captionWrap 12/400 · margin-top 6 · helper text/secondary · error text/danger)

Accessibility:
- Role. Web: Native <input> or <textarea> (textbox). Android: BasicTextField (editable text node).
- Name. Web: A <label htmlFor> wraps the overline, but aria-label={label} overrides it, so the name is the raw label without the * or '(Optional)'. Fields without a label need aria-label. Android: contentDescription ?: label is set in semantics on the field; pass contentDescription when a group shares one label.
- Keyboard. Web: Tab to focus, type; textarea accepts Enter for new lines. Android: TalkBack: double-tap to edit; keyboardOptions sets the IME type and action.
- Touch target. Web: Input min height 48px, full width. Android: heightIn(min = 48.dp), full width.
- Contrast. Web: Value text/primary passes (17:1); label text/tertiary on bg/primary is 4.8:1; placeholder #AAAAAA is 2.3:1. In light the field edge is white on #F7F7F7 (1.07:1) and the focus border #9DDDB4 is 1.6:1. Android: Same tokens; dark mode adds a stroke/subtle border (1.2:1 on #222222).
- State. Web: Error shows a red border plus error text, so it is not colour alone, but the input gets no aria-invalid and the text is not linked with aria-describedby; `required` is not passed to the input. Android: enabled maps to disabled semantics; error is only drawn text, with no semantics { error() }.
- Motion. Web: Border and focus ring fade over 200ms; zeroed under prefers-reduced-motion. Android: No animation; border colour switches instantly.

Known accessibility gaps:
- Inputs.tsx: error and helper text are not linked to the input (no aria-describedby) and errors set no aria-invalid.
- Inputs.kt: EqualTextField does not expose error in semantics (semantics { error(...) }), so TalkBack does not announce it on focus.
- Inputs.tsx: `required` is destructured and never reaches the input (no required / aria-required), and aria-label={label} hides the visible '*'.
- Inputs.tsx: the multiline textarea ignores ...rest, so disabled, required and aria-* props are dropped.
- Inputs.css / Inputs.kt: in light mode the field has a transparent border, so its edge is white on #F7F7F7 (1.07:1), below 3:1.
- Inputs.css / Inputs.kt: focus border action/stroke/unread #9DDDB4 (1.6:1) plus a 12% ring is a weak focus indicator.
- Inputs.css / Inputs.kt: placeholder text/placeholder #AAAAAA on white is 2.3:1.

Example: Name
```tsx
const [name, setName] = useState('Keshav');

<TextField label="Name" value={name} onChange={setName}
  placeholder="Your name" helper="Your AI will call you 'Keshav'" />
```
```kotlin
var name by remember { mutableStateOf("Keshav") }

EqualTextField(
    value = name,
    onValueChange = { name = it },
    label = "Name",
    placeholder = "Your name",
    helper = AnnotatedString("Your AI will call you 'Keshav'"),
)
```

Example: Optional label
```tsx
<TextField label="Guiding direction" optional value={v} onChange={setV}
  placeholder="e.g. Near City Center Mall" />
```
```kotlin
var direction by remember { mutableStateOf("") }

EqualTextField(
    value = direction,
    onValueChange = { direction = it },
    label = "Guiding direction",
    optional = true,
    placeholder = "e.g. Near City Center Mall",
)
```

Example: Multiline and grouped
```tsx
<TextField aria-label="Address line 1" placeholder="Flat, house no., building"
  value={l1} onChange={setL1} multiline />
<TextField aria-label="Address line 2" placeholder="Street, area, landmark"
  value={l2} onChange={setL2} multiline />
```
```kotlin
var line1 by remember { mutableStateOf("") }
var line2 by remember { mutableStateOf("") }

// Fields that share one ADDRESS label omit `label` and pass contentDescription instead.
EqualTextField(
    value = line1,
    onValueChange = { line1 = it },
    contentDescription = "Address line 1",
    placeholder = "Flat, house no., building",
    multiline = true,
)
EqualTextField(
    value = line2,
    onValueChange = { line2 = it },
    contentDescription = "Address line 2",
    placeholder = "Street, area, landmark",
    multiline = true,
)
```

Example: Error
```tsx
<TextField aria-label="Pincode" placeholder="Pincode" value={pin}
  onChange={(v) => setPin(v.replace(/\D/g, '').slice(0, 6))}
  inputMode="numeric" className="eq-tnum" align="center"
  error={/^\d{6}$/.test(pin) ? undefined : 'Enter a 6-digit pincode'} />
```
```kotlin
var pin by remember { mutableStateOf("") }

EqualTextField(
    value = pin,
    onValueChange = { pin = it.filter(Char::isDigit).take(6) },
    contentDescription = "Pincode",
    placeholder = "Pincode",
    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
    tabular = true,
    align = TextFieldAlign.Center,
    error = if (pin.length == 6) null else "Enter a 6-digit pincode",
)
```

### Group: Lists & rows

#### Call history (`call-history`)

The Contact Info call-history card (radius 16; outlined in dark) and its rows: direction icon, call type, meta line and time.

- React: `import { CallHistoryList, CallHistoryRow } from '@equal/ds';`
- Compose: `CallHistoryList`, `CallHistoryRow`
- Tokens: `bg/surface`, `stroke/subtle`, `stroke/medium`, `text/primary`, `text/secondary`, `text/tertiary`, `text/danger`
- Source: Contact Info · Call history

Do: Separate date and duration in `meta` with " • " ("Today • 30 Sec."). Group rows in a CallHistoryList under a `SectionHeader size="label"` CALL HISTORY header (inset 22).

Don't: Don't colour the "Missed Call" label red; only the icon uses text/danger. Don't pass your own label; the direction sets it.

Anatomy:
1. List card: Rounded card that holds the call rows. (inset 22 · radius 16 · bg/surface · dividers stroke/subtle (stroke/medium in dark) · dark adds a 1dp stroke/subtle outline)
2. Direction icon: Incoming, outgoing or missed arrow. Only the missed icon is red. (24dp · text/primary, text/danger when missed)
3. Call type: Label set by the direction: Incoming Call, Outgoing Call or Missed Call. (bodyLarge, line height 20 · text/primary)
4. Meta line: Date and duration, e.g. 'Today • 30 Sec.'. (11/14 Regular · text/tertiary)
5. Time: Time of the call. (body1 · text/secondary · tabular)
6. Trailing: Optional content after the time, e.g. a play button. (web: any node (e.g. IconButton 32/20) · Compose: onCallClick adds a 48dp call-back button in text/action)

Accessibility:
- Role. Web: Rows are plain divs inside a div; there is no list role. The icon is aria-hidden. Android: Rows are plain Rows. The icon has contentDescription null. The rows are not merged or marked as list items.
- Name. Web: Each row reads as its text: call type, meta, time. Direction comes from the 'Missed Call' text, not the icon. Android: TalkBack reads the label, meta and time as three separate items. The call button is 'Call back'.
- Keyboard. Web: Rows are not focusable. A trailing IconButton is reached with Tab. Android: TalkBack: swipe through the texts. Double-tap 'Call back' when it is shown.
- Touch target. Web: Rows are at least 63 tall. A trailing IconButton at size 32 gets 48 through eq-touch. Android: Rows are at least 63dp. PlainIconButton is 48dp with minimumInteractiveComponentSize.
- Contrast. Web: Type text/primary 18.9:1, meta text/tertiary 5.1:1, time text/secondary 7.5:1, missed icon text/danger 6.2:1. In dark: 14.9, 5.6, 8.3 and 5.6:1. Android: Same tokens and ratios.
- State. Web: Missed is said in the label, so red is not the only signal. Android: Same: the label says 'Missed Call'.
- Motion. Web: None. Android: None.

Known accessibility gaps:
- CallHistoryList and CallHistoryRow in Profile.tsx have no list/listitem semantics, so screen readers don't announce the number of calls.
- CallHistoryRow in Rows.kt doesn't merge descendants, so TalkBack stops on the call type, meta and time separately for every row.

Example: Directions
```tsx
<SectionHeader size="label" inset={22}>Call history</SectionHeader>
<CallHistoryList>
  <CallHistoryRow direction="incoming" meta="Today • 30 Sec." time="02:30 PM" />
  <CallHistoryRow direction="missed" meta="Yesterday" time="11:04 AM" />
  <CallHistoryRow direction="outgoing" meta="12 July • 2 Min." time="06:15 PM" />
</CallHistoryList>
```
```kotlin
SectionHeader(title = "Call history", size = SectionHeaderSize.Label, inset = 22.dp)
CallHistoryList {
    CallHistoryRow(CallDirection.Incoming, meta = "Today • 30 Sec.", time = "02:30 PM")
    CallHistoryRow(CallDirection.Missed, meta = "Yesterday", time = "11:04 AM")
    CallHistoryRow(CallDirection.Outgoing, meta = "12 July • 2 Min.", time = "06:15 PM")
}
```

Example: With trailing
```tsx
<CallHistoryRow direction="incoming" meta="Today • 2 Min." time="03:21 PM"
  trailing={<IconButton icon="play" label="Play recording" size={32} iconSize={20} />} />
```
```kotlin
CallHistoryList {
    // Compose: no custom trailing slot; onCallClick adds the only trailing button (call back, not play)
    CallHistoryRow(CallDirection.Incoming, meta = "Today • 2 Min.", time = "03:21 PM", onCallClick = {})
}
```

#### Empty state (`empty-state`)

A centred illustration, title, body and optional action for empty lists and no-results, plus IllustrationHeader for the art at the top of settings detail screens.

- React: `import { EmptyState, IllustrationHeader } from '@equal/ds';`
- Compose: `EmptyState`, `IllustrationHeader`
- Tokens: `text/primary`, `text/tertiary`, `button/primary`
- Source: Surfaces from the Typography screen inventory · Empty / Error State

Do: Say what the feature does for the user in the title ("Never explain your address again"). Put the query back in no-results copy and suggest what to try.

Don't: Don't crop or recolour the 3D illustrations. Don't show an action when the list fills from elsewhere; if the add button is pinned below, leave it off.

Anatomy:
1. Container: Centred column that fills the empty list area. (full width · padding 32 web / 24 Compose · centred)
2. Illustration: Optional 3D illustration on top. (96dp · decorative)
3. Title: Says what the feature does or what is missing. (subheading · text/primary · 16 below the art)
4. Body: Explains the empty state or suggests what to try. (captionWrap · text/tertiary · max 260 web · 4 above)
5. Action: Optional filled button. (Button md 36 · 20 above web / 16 Compose)
6. IllustrationHeader: Large centred art at the top of a settings detail screen. (160dp by default · padding 8 top, 16 bottom)

Accessibility:
- Role. Web: The title is an h2 and the body a p. Illustrations are <img alt="">, so they are decorative. Android: The title is plain text with no heading(). EqualAssetImage has contentDescription null by default, so the art is skipped.
- Name. Web: The action button is named by actionLabel. Android: The button is named by actionLabel.
- Keyboard. Web: Only the action is focusable: Tab, then Enter/Space. Android: TalkBack: swipe title → body → button, double-tap to act.
- Touch target. Web: The md Button is 36px tall with no eq-touch. Android: EqualButton applies minimumInteractiveComponentSize (48dp).
- Contrast. Web: Title text/primary 18.9:1 and body text/tertiary 5.1:1 on bg/surface (4.8:1 on bg/primary). The primary button is 2.85:1 in light and fails; dark is black on lime. Android: Same tokens.
- State. Web: A no-results state is not announced when it appears; it has no live region. Android: Same: no liveRegion.
- Motion. Web: None. Android: None.

Known accessibility gaps:
- EmptyState in Dialog.tsx: the md action Button is 36px tall with no eq-touch, so its hit height is 36.
- EmptyState in Overlays.kt: the title has no heading() semantics.
- No-results EmptyState (Dialog.tsx / Overlays.kt) is not announced when it replaces the list. Wrap it in role="status" / liveRegion when it follows a search.
- Primary buttons put text/on-action white on button/primary #00B140 in light mode: 2.85:1, below AA 4.5:1 for 14sp text (Button.css / Buttons.kt). Dark (black on lime) is 17.4:1.

Example: Addresses empty
```tsx
<EmptyState illustration="illustration-addresses-empty"
  title="Never explain your address again"
  body="Save frequently used addresses, and your assistant will use them to handle delivery, pickup calls, etc. more naturally."
  actionLabel="Add new Address" onAction={addAddress} />
```
```kotlin
EmptyState(
    title = "Never explain your address again",
    body = "Save frequently used addresses, and your assistant will use them to handle delivery, pickup calls, etc. more naturally.",
    // Compose: the illustration is a slot, not an asset name
    illustration = { EqualAssetImage(EqualAssets.IllustrationAddressesEmpty, 96.dp) },
    actionLabel = "Add new Address",
    onActionClick = {},
)
```

Example: No results
```tsx
<EmptyState title="No chats found" body={`Nothing matches "\${q}". Try a name or number.`} />
```
```kotlin
val query = "Priya"
EmptyState(title = "No chats found", body = "Nothing matches \"$query\". Try a name or number.")
```

Example: Illustration header
```tsx
<IllustrationHeader asset="illustration-silent-mode" />
<RowGroup>
  <ToggleRow label="Mute Promotional Calls" … />
</RowGroup>
```
```kotlin
IllustrationHeader(asset = EqualAssets.IllustrationSilentMode)
RowGroup {
    ToggleRow(
        label = "Mute Promotional Calls",
        description = "Equal AI Assistant can identify Promotional Calls and automatically mute them",
        descriptionWraps = true,
        checked = true,
        onCheckedChange = {},
    )
}
```

#### Settings row (`settings-row`)

The dense settings row (icon, subheading label, caption description, chevron or switch), grouped into rounded cards with RowGroup.

- React: `import { SettingsRow, ToggleRow, RowGroup } from '@equal/ds';`
- Compose: `SettingsRow`, `ToggleRow`, `RowGroup`
- Tokens: `bg/surface`, `stroke/subtle`, `text/primary`, `text/tertiary`, `text/placeholder`, `button/primary`
- Source: You tab · Settings row

Do: Group related rows under a SectionHeader with matching inset. Use `wrap` for descriptions longer than one line so they switch to Regular (rule 3). Use ToggleRow for instant settings and a chevron row for anything that opens a screen.

Don't: Don't mix a chevron and a switch on one row. Don't truncate a description that matters; set `wrap`.

Anatomy:
1. Row container: Full-width row. It becomes a button when it has onClick. (min height 64 · padding 12/12/12/16 · gap 12 · bg/surface)
2. Leading icon: Optional icon for the setting. (24dp · text/primary)
3. Label: Name of the setting, with an optional NEW badge after it. (subheading · text/primary · truncates · badge gap 8)
4. Description: Secondary line; with wrap it can span several lines. (caption Regular (captionWrap when wrap) · text/tertiary)
5. Trailing: Chevron by default, nothing, or custom content such as a count. (chevron-right 22 · text/placeholder)
6. ToggleRow: switch: Trailing switch for settings that apply at once. (track 40×24 · thumb 18 · on button/primary, off button/disabled · thumb text/on-action when on)
7. RowGroup: card: Rounded card that groups rows, with dividers between them. (inset 20 · radius 16 · bg/surface · 1dp stroke/subtle dividers)

Accessibility:
- Role. Web: A row with onClick is a <button>; otherwise a div. ToggleRow's Switch is a button with role="switch". Android: Clickable rows use clickable(role = Role.Button). ToggleRow makes the whole row toggleable(role = Role.Switch), and the switch inside is visual only.
- Name. Web: A button row is named by its text: label, NEW and description. The switch's aria-label is the row label; the description is not linked. Android: The clickable or toggleable row merges its label, badge and description into one TalkBack item.
- Keyboard. Web: Tab to the row button or switch, then Enter/Space. A focus ring shows through eq-reset-btn:focus-visible. Android: TalkBack: swipe to the row, double-tap to open or toggle.
- Touch target. Web: Rows are at least 64 tall. In ToggleRow only the switch is interactive; it is 40×24 with eq-touch for a 48 area, and tapping the row does nothing. Android: Rows are at least 64dp, and in ToggleRow the whole row toggles.
- Contrast. Web: Label text/primary 18.9:1, description text/tertiary 5.1:1. The chevron in text/placeholder is 2.32:1. The NEW badge is white on green at 10sp (2.85:1) in light. The off switch track (button/disabled #DDD on white) is 1.36:1. Android: Same tokens. In dark, the chevron is 3.55:1, and the switch and badge go lime with black content.
- State. Web: The switch uses aria-checked. Thumb position shows the state as well as colour. Android: toggleable exposes On/Off. The thumb moves 3 → 19dp.
- Motion. Web: The switch track and thumb animate over 500ms ease-in-out. Reduced motion sets the duration to 0ms. Android: EqualSwitch animates over 500ms and is instant when rememberReduceMotion() is true.

Known accessibility gaps:
- ToggleRow in SettingsRow.tsx: only the 40×24 switch toggles, so tapping the row does nothing, and the description is not linked to the switch via aria-describedby.
- The chevron (text/placeholder #AAAAAA on white, 2.32:1) and the off switch track (button/disabled on white, 1.36:1) are below 3:1 in light (SettingsRow.tsx / Rows.kt, Switch.css / EqualSwitch.kt).
- NewBadge (Badge.css / Badges.kt): white on #00B140 at 10sp is 2.85:1 in light mode.

Example: You tab group
```tsx
<SectionHeader>Your assistant</SectionHeader>
<RowGroup>
  <SettingsRow icon="instructions" label="Instructions" isNew
    description="Tell assistant how you'd like it to help" onClick={open} />
  <SettingsRow icon="health-check" label="Assistant Health Check"
    description="Check Real-Time Assistant Connectivity" onClick={open} />
  …
</RowGroup>
```
```kotlin
SectionHeader(title = "Your assistant")
RowGroup {
    SettingsRow(
        label = "Instructions",
        description = "Tell assistant how you'd like it to help",
        leadingIcon = EqualIcons.Instructions,
        showNewBadge = true,
        onClick = {},
    )
    SettingsRow(label = "Assistant Health Check", description = "Check Real-Time Assistant Connectivity", leadingIcon = EqualIcons.HealthCheck, onClick = {})
    SettingsRow(label = "Silent Mode", description = "Mute promotional calls", leadingIcon = EqualIcons.SilentMode, onClick = {})
    SettingsRow(label = "Voice & Language", description = "How your assistant sounds", leadingIcon = EqualIcons.VoiceLanguage, onClick = {})
}
```

Example: Toggle rows
```tsx
<RowGroup>
  <ToggleRow label="Mute Promotional Calls" wrap
    description="Equal AI Assistant can identify Promotional Calls and automatically mute them"
    checked={mute} onChange={setMute} />
</RowGroup>
```
```kotlin
var mute by remember { mutableStateOf(true) }
RowGroup {
    ToggleRow(
        label = "Mute Promotional Calls",
        description = "Equal AI Assistant can identify Promotional Calls and automatically mute them",
        descriptionWraps = true,
        checked = mute,
        onCheckedChange = { mute = it },
    )
}
```

Example: Trailing variants
```tsx
<SettingsRow label="Active Instructions" description="3 Active" onClick={open} />
<SettingsRow label="Muted Contacts" trailing={<span>4</span>} onClick={open} />
<SettingsRow label="Version" description="2.4.0" trailing="none" />
```
```kotlin
RowGroup {
    SettingsRow(label = "Active Instructions", description = "3 Active", onClick = {})
    SettingsRow(label = "Muted Contacts", onClick = {}, trailing = {
        EqualText(text = "4", style = EqualTheme.type.body1, color = EqualTheme.colors.textSecondary)
    })
    SettingsRow(label = "Version", description = "2.4.0", trailing = null) // null = no chevron
}
```

### Group: Monetization

#### Cancellation (`cancel-sheet`)

Three steps to cancel: tell us why (Proceed stays disabled until there is text), confirm, and the request submitted with access kept until the end date.

- React: `import { CancelSheet } from '@equal/ds';`
- Compose: `CancelSheet`
- Tokens: `gradient/status-neutral`, `button/primary`, `stroke/subtle`
- Source: Monetization Flow · cancellation

Props of `CancelSheet`:
- `step`: `'feedback' | 'confirm' | 'submitted'`. Step.
- `accessUntil?`: `string` = '15 June 2026'. Access end date.
- `reason / onReasonChange?`: `string / (v) => void`. Feedback text (controlled or not).
- `onProceed / onKeep / onConfirm / onRedirect?`: `() => void`. Step actions.

Do: Say how long access lasts at every step.

Don't: Don't make Proceed tappable before the user writes a reason.

Anatomy:
1. Scrim: Dimmed layer behind the sheet. It takes taps but does not close the sheet. (scrim · full-size layer · no close action)
2. Sheet panel: Bottom panel that holds the status card and footer (StatusSheet). (bg/surface · radius 24 top (24 all round inline) · padding 12/12/20 · shadow 0 -8 30 black/12%)
3. Status card: Neutral ring card with the 3D art: sad face for feedback and confirm, thumbs up when submitted. (gradient/status-neutral · radius 20 · 1dp stroke/subtle · padding 18/16 · art 100dp)
4. Title lines: Two display lines, light line first: 'We're Sad to / See you Cancel', 'Are you really / Sure?', 'Your Request is / Submitted'. (light 22/26 Regular · strong 28/32 Bold, -0.02em · text/primary · centred)
5. Body: Says when access ends and what happens to autopay. (body1 · text/secondary · centred · 8 above)
6. Reason field (feedback): Three-line text area for the reason for cancelling. (radius 12 · 1dp stroke/subtle, action/stroke/unread when focused · bg/surface · padding 12/14 · body1)
7. Footer: Proceed (disabled until there is text); or Cancel (outline) + Confirm; or the 3s redirect note. (Button lg block · gap 12 · RedirectNote body2 text/action · footer padding 16 top, 8 sides)

Accessibility:
- Role. Web: The panel is role="dialog" with aria-modal in overlay mode. The title lines are plain divs, not headings. Android: The panel sets semantics { paneTitle = label }. The title lines are plain text with no heading().
- Name. Web: aria-label per step: 'Cancel subscription', 'Confirm cancellation', 'Request submitted'. The textarea is labelled 'Why are you cancelling?'. Android: paneTitle uses the same three labels. The reason field has contentDescription 'Why are you cancelling?'.
- Keyboard. Web: No Escape handler, no close button, and focus is not moved into the sheet or trapped there. Tab reaches the textarea and the footer buttons. Android: TalkBack: swipe through the card, field and buttons, double-tap to activate. There is no BackHandler, so system Back does not close the sheet.
- Touch target. Web: lg buttons are 45px tall with no eq-touch, so they fall just short of 48. Android: EqualButton applies minimumInteractiveComponentSize, so the 45dp buttons get a 48dp target.
- Contrast. Web: Body text/secondary on the neutral gradient passes. White on green for Proceed/Confirm and the green outline Cancel label are 2.85:1 in light, which fails. In dark they are black on lime and lime on #222. Android: Same tokens: the light-mode primary and outline buttons are 2.85:1 and fail AA. Dark passes.
- State. Web: Proceed uses the native disabled attribute until there is text, so it drops out of the tab order with no reason given. The redirect countdown is aria-live="polite". Android: Proceed is enabled = false, which TalkBack reads as 'disabled'. RedirectNote is a polite liveRegion.
- Motion. Web: The panel rises in with eq-sheet-up (320ms). Under prefers-reduced-motion the animation is turned off. Android: The panel slides up 40% and fades in over motion.slow. This is not gated on rememberReduceMotion(); only the title rise is.

Known accessibility gaps:
- CancelSheet (Monetization.tsx / Monetization.kt): the feedback step has no way out. There is no close button, the scrim does nothing, and neither Escape (web) nor Back (Android) dismisses it.
- StatusSheet in Monetization.tsx does not move focus into the dialog, trap it, or return it on close.
- StatusCard title lines (Monetization.tsx / Monetization.kt) are not headings, so screen readers get no heading for each step.
- Proceed in CancelSheet (Monetization.tsx) uses native disabled, so keyboard users can't reach it and nothing explains that a reason is required. Use aria-disabled plus a hint instead.
- RedirectNote (Monetization.tsx / .kt) redirects after 3s with no way to pause, and its polite live region announces every second.
- StatusSheet in Monetization.kt: the enter slide/fade is not gated on rememberReduceMotion().
- The lg Buttons in the CancelSheet footer are 45px tall on web with no eq-touch, so they are under 48 (Button.tsx).
- The outline Cancel label (text/action #00B140 on white) and RedirectNote text are 2.85:1 in light mode, below 4.5:1.
- Primary buttons put text/on-action white on button/primary #00B140 in light mode: 2.85:1, below AA 4.5:1 for 14sp text (Button.css / Buttons.kt). Dark (black on lime) is 17.4:1.

Example: Feedback
```tsx
<CancelSheet step="feedback" reason={reason} onReasonChange={setReason} onProceed={next} />
```
```kotlin
var reason by remember { mutableStateOf("") }
CancelSheet(step = CancelStep.Feedback, reason = reason, onReasonChange = { reason = it },
    onProceed = { /* next step */ }, inline = true)
```

Example: Feedback filled
```tsx
<CancelSheet step="feedback" reason="Felt it too expensive…" onReasonChange={setReason} onProceed={next} />
```
```kotlin
var reason by remember { mutableStateOf("Felt it too expensive, I hope it would be under my budget") }
CancelSheet(step = CancelStep.Feedback, reason = reason, onReasonChange = { reason = it },
    onProceed = { /* next step */ }, inline = true)
```

Example: Are you really sure?
```tsx
<CancelSheet step="confirm" accessUntil="15 June 2026" onKeep={close} onConfirm={cancel} />
```
```kotlin
CancelSheet(step = CancelStep.Confirm, accessUntil = "15 June 2026", onKeep = { /* close */ },
    onConfirm = { /* cancel subscription */ }, inline = true)
```

Example: Request submitted
```tsx
<CancelSheet step="submitted" accessUntil="15 June 2026" onRedirect={goHome} />
```
```kotlin
CancelSheet(step = CancelStep.Submitted, accessUntil = "15 June 2026", onRedirect = { /* go home */ }, inline = true)
```

#### Coupon ticket (`coupon-ticket`)

A notched ticket with the coupon code, what it saves, APPLY / APPLIED and the big discount line.

- React: `import { CouponTicket } from '@equal/ds';`
- Compose: `CouponTicket`
- Tokens: `bg/surface`, `gradient/coupon-stroke`, `paywall/divider`, `text/gold`, `gradient/gold-text`
- Source: Monetization Flow · EQUAL25

Props of `CouponTicket`:
- `code`: `string`. Coupon code.
- `description`: `ReactNode`. What it saves.
- `discount`: `string`. Big gold line, e.g. "25% OFF".
- `applied?`: `boolean`. Shows APPLIED; the price above drops.
- `onApply?`: `() => void`. APPLY tap.

Do: Drop the price in PriceTag when the coupon applies (₹249 → ₹149).

Don't: Don't show more than one coupon at a time.

Anatomy:
1. Ticket: Notched card. (radius 20 · 9 dp notches at 58% height · gradient/coupon · 1 px paywall/card-stroke · padding 14 16 12)
2. Code: The coupon code. (subheading Bold · text/gold)
3. Description: What it saves. (caption Regular · text/secondary)
4. APPLY / APPLIED: Apply action, then its applied state. (buttonSmall Bold · text/gold · padding-top 4)
5. Dashed rule and seal: Divider with the 3D % seal. (1 px dashed paywall/divider · seal 28 · gap 10)
6. Discount: Big discount line. (30/36 Bold · gradient/gold-text · centred)

Accessibility:
- Role. Web: APPLY is a <button>; APPLIED is a span with aria-live="polite"; the seal is alt="". Android: APPLY text clickable(role = Role.Button); APPLIED has liveRegion = Polite; seal has no contentDescription.
- Name. Web: Button reads "APPLY" with no code; should say "Apply EQUAL25". Android: Button reads "APPLY"; the code is a separate text node.
- Keyboard. Web: Tab to APPLY; Enter/Space. When applied the button is removed and focus is lost. Android: TalkBack: swipe to APPLY, double-tap.
- Touch target. Web: APPLY uses eq-touch for a 48 px hit area. Android: APPLY uses minimumInteractiveComponentSize (48 dp).
- Contrast. Web: Code and APPLY text/gold #8C5817 on #FFF4DE 5.5:1; description text/secondary 6.8:1; discount gradient top is about 3.2:1 (large text). Dark: gold 8.6:1. Android: Same tokens.
- State. Web: Applied swaps APPLY for the word APPLIED (not colour); the live region is mounted with the text, so it may not be announced. Android: Applied swaps the text; the polite live region announces it.
- Motion. Web: Static; the price drop above it animates in PriceTag. Android: Static.

Known accessibility gaps:
- APPLY has no coupon context in its name; use aria-label / contentDescription "Apply EQUAL25" (Monetization.tsx, Monetization.kt).
- APPLIED live region is created in the same render as its text, so screen readers often skip it; keep a persistent live region (Monetization.tsx).
- When APPLY is replaced by APPLIED, keyboard focus is lost (Monetization.tsx).

Example: Available
```tsx
<CouponTicket code="EQUAL25" description="Save Flat ₹100 with this Code" discount="25% OFF" onApply={apply} />
```
```kotlin
CouponTicket(code = "EQUAL25", description = "Save Flat ₹100 with this Code", discount = "25% OFF", onApply = {})
```

Example: Applied
```tsx
<CouponTicket code="EQUAL25" description="Save Flat ₹100 with this Code" discount="25% OFF" applied />
```
```kotlin
CouponTicket(code = "EQUAL25", description = "Save Flat ₹100 with this Code", discount = "25% OFF", applied = true)
```

#### Discount badge & price drop (`discount-badge`)

The green 25% OFF seal with its label, and the price drop it rides on: APPLY strikes the old price, the new price lands beside the list price with Saved ₹100, then the badge pops.

- React: `import { DiscountBadge, PriceTag } from '@equal/ds';`
- Compose: `DiscountBadge`, `PriceTag`
- Tokens: `text/brand`, `gradient/gold-text`
- Source: Monetization local components

Props of `DiscountBadge`:
- `label?`: `string` = 'Discounted!!'. Green label.
- `off?`: `string` = '25%'. Seal text.
- `animate?`: `boolean`. Pop in.

Props of `PriceTag`:
- `price`: `number`. Price now.
- `was?`: `number`. Struck list price; adds /Monthly and Saved ₹.
- `badge?`: `string`. A DiscountBadge under the price.
- `animate?`: `boolean`. Run the strike → land → pop sequence (still under reduced motion).

Do: Animate only when the user caused the change (APPLY).

Don't: Don't animate a price that was already discounted when the page opened.

Anatomy:
1. DiscountBadge pill: White pill that holds the seal and its label. (radius full · bg/surface · padding 2/10/2/2 · gap 6 · shadow 0 2 10 black 8%)
2. OffSeal: Coded green wavy seal with the discount. (28dp · 12 lobes · text/brand fill · '25%' over 'OFF' Bold text/on-action)
3. Label: What the discount is. (caption Bold · text/brand · 'Discounted!!' or 'Special Coupon Applied!')
4. PriceTag: label: Promotion line over the price. (caption uppercase · text/gold · 🎊 emoji either side (aria-hidden on web))
5. PriceTag: price: Big gold price between hairlines. (44/48 Bold · gradient/gold-text · paywall/divider fading rules · gap 16)
6. PriceTag: was + period: Struck list price and the period beside the price. (14 Medium tabular, struck · '/Monthly' 14 · text/secondary · gap 6 on the baseline)
7. PriceTag: saved line: How much the user saves. ('Saved ₹100' · caption Bold · text/brand)
8. Strike line: Gold bar that strikes the old price during the drop. (3dp · text/gold · 108% wide · 52% down · radius 2 · animation only)

Accessibility:
- Role. Web: DiscountBadge is role=status (polite live region); OffSeal is an aria-hidden svg; PriceTag is plain text. Android: DiscountBadge uses clearAndSetSemantics with liveRegion Polite; the struck price has its own contentDescription.
- Name. Web: The badge reads only the label ('Discounted!!') because the seal is hidden, so '25% off' is lost. The price reads '₹149 ₹249 /Monthly'; strikethrough isn't announced. Android: Badge reads '25% off. Discounted!!'; the struck price reads 'was ₹249 /Monthly'.
- Contrast. Web: Label and Saved line (text/brand) and the seal's white text are 2.85:1 in light (fail); dark is lime with black text, 17:1. Gold price gradient is 3.5–7.3:1 on white, fine for 44 px text; text/gold label 6:1. Android: Same tokens and ratios as web.
- State. Web: The discount is in text (seal, label, struck price, Saved ₹), not colour. During the drop only the badge, as a live region, announces the change. Android: Same; the badge's live region announces when it appears.
- Motion. Web: Strike draws at 300ms over 450ms, new price lands at 800ms (motion.priceDrop), badge pops with a spring after 120ms and the seal spins in. Under prefers-reduced-motion the CSS animations stop, but the timed old → strike → done swap still runs. Android: Same sequence; under rememberReduceMotion the final state shows at once.

Known accessibility gaps:
- DiscountBadge in Monetization.tsx hides the OffSeal (aria-hidden), so screen readers hear 'Discounted!!' without '25% off'.
- PriceTag in Monetization.tsx gives the struck list price no 'was' text; Monetization.kt already adds one.
- text/brand label and Saved line, and the seal's white text on text/brand, are 2.85:1 in light theme.
- PriceTag in Monetization.tsx still waits through the old → strike → done phases (about 0.8s) under reduced motion; it should jump to done like Compose.

Example: Badges
```tsx
<DiscountBadge />
<DiscountBadge label="Special Coupon Applied!" />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
    DiscountBadge()
    DiscountBadge(label = "Special Coupon Applied!")
}
```

Example: Price drop
```tsx
<PriceTag price={149} was={249} badge="Special Coupon Applied!" animate={justApplied} />
```
```kotlin
var replay by remember { mutableIntStateOf(0) }
Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
    // Strike the old price → land the new one with "Saved ₹100" → pop the badge
    key(replay) {
        PriceTag(price = "149", was = 249, badge = "Special Coupon Applied!", animate = true)
    }
    EqualButton(text = "Replay", onClick = { replay++ }, variant = EqualButtonVariant.Secondary, size = EqualButtonSize.Sm)
}
```

#### FAQ (`faq`)

The FREQUENTLY ASKED QUESTIONS accordion on the paywall and the subscription page, and the hairline section label it sits under.

- React: `import { FaqList, DividerLabel } from '@equal/ds';`
- Compose: `FaqList`, `DividerLabel`
- Tokens: `bg/surface`, `stroke/subtle`, `paywall/divider`, `text/secondary`
- Source: Monetization Flow · FAQ

Props of `FaqList`:
- `items`: `{ q: string; a: ReactNode }[]`. Questions.
- `title?`: `string | null` = 'Frequently asked questions'. Label above.
- `defaultOpen?`: `number[]` = []. Expanded rows.

Do: Answer cancellation and refunds plainly.

Don't: Don't put the FAQ above the CTA.

Anatomy:
1. DividerLabel: Section label between two gold hairlines. (1dp paywall/divider rules · gap 12 · caption uppercase +0.02em · text/primary (gold tone text/gold))
2. Card: One card that holds every question. (radius 16 · bg/surface · 1dp stroke/subtle · 14 below the label)
3. Question row: FaqEntry button that opens and closes the answer. (padding 16/14 · bodyLarge text/primary · gap 12)
4. Chevron: Shows whether the row is open. (chevron-down 20 · text/secondary · rotated 180 when open · decorative)
5. Answer: The answer, shown only while open. (body1 · text/secondary · padding 0 16 14)
6. Row divider: Hairline between questions. (1dp stroke/subtle)

Accessibility:
- Role. Web: Each question is a button with aria-expanded inside a section; DividerLabel is plain text, not a heading. Android: Question row is clickable(Role.Button) with stateDescription; DividerLabel is plain text.
- Name. Web: The question text; the chevron icon is aria-hidden. Android: The question text; the chevron has contentDescription null.
- Keyboard. Web: Tab to each question, Enter/Space toggles; the answer follows the button in reading order. Android: TalkBack reads 'question, Collapsed, Button'; double-tap toggles.
- Touch target. Web: Full-width rows about 52 px tall. Android: Full-width rows about 52dp tall.
- Contrast. Web: Question text/primary; answer and chevron text/secondary 7.5:1 on white, #BBBBBB on #222222 8.3:1 in dark. Gold label tone text/gold is 6:1 on white. Android: Same tokens and ratios as web.
- State. Web: Open state is aria-expanded plus the visible answer and chevron rotation, not colour. Android: stateDescription 'Expanded' / 'Collapsed' plus the visible answer; open rows survive configuration changes.
- Motion. Web: No animation; the chevron flips and the answer appears instantly. Android: No animation.

Known accessibility gaps:
- DividerLabel (Monetization.tsx and Monetization.kt) is plain text, so the FAQ section title can't be reached by heading navigation.
- FaqEntry in Monetization.tsx has aria-expanded but no aria-controls linking the button to its answer.

Example: Accordion
```tsx
<FaqList items={faq} defaultOpen={[3]} />
```
```kotlin
val faq = listOf(
    FaqItem("What do I get with Equal Unlimited?", "Unlimited call screenings, full recordings, summaries, and zero daily cap."),
    FaqItem("Will Equal screen all types of calls?", "Yes! Delivery, ride pickups, spam, loan calls, Equal handles them all."),
    FaqItem("Can I cancel my Equal Unlimited plan later?", "Yes, cancel anytime. Your Unlimited access stays active until the end of your billing period."),
    FaqItem("Will I get a refund if I’m not happy with Equal Unlimited?", "We don’t offer refunds, but you can write to our support team and we’ll do our best to help."),
)
FaqList(items = faq, defaultOpen = listOf(3))
```

Example: Section label
```tsx
<DividerLabel>Why people choose</DividerLabel>
```
```kotlin
DividerLabel(text = "Why people choose")
```

#### Feature list (`feature-list`)

What You Get on the plan page: one card per Unlimited feature with its 3D gold icon (24/7 Unlimited Call Screening, Unlimited Recordings, Unlimited Summaries).

- React: `import { FeatureList, unlimitedFeatures } from '@equal/ds';`
- Compose: `FeatureList`
- Tokens: `stroke/subtle`, `bg/surface`
- Source: Monetization value · Manage Plan

Props of `FeatureList`:
- `items?`: `{ art: AssetName; label: string }[]` = unlimitedFeatures. Features, top to bottom; art is a 3D feature-* asset.

Do: Keep labels to one line. Use the 3D feature-* art; add a new asset for a new feature.

Don't: Don't swap in flat Material icons here. Don't list more than five; the page already has FAQ and proof.

Anatomy:
1. List: The stack of Unlimited features under What You Get. (web ul · Compose Column · gap 10)
2. Card: One card per feature. (radius 12 · bg/surface · 1dp stroke/subtle · padding 14/16 · gap 12)
3. Art: 3D gold feature icon. (28dp feature-* asset (call-screening, recordings, summaries) · decorative)
4. Label: The feature, on one line. (subheading Regular · text/primary)

Accessibility:
- Role. Web: A ul of li items, so screen readers announce a list of N items. Android: A plain Column of Rows with no collection semantics.
- Name. Web: The label text; art has alt=''. Android: The label text; art has contentDescription null.
- Keyboard. Web: Not interactive; no Tab stops. Android: Not interactive; TalkBack reads each label in order.
- Contrast. Web: text/primary on bg/surface in both themes; the card border is decorative. Android: Same tokens as web.

Known accessibility gaps:
- FeatureList in PlanValue.kt has no list semantics (collectionInfo), so TalkBack doesn't say how many features there are.

Example: What You Get
```tsx
<DividerLabel>What You Get</DividerLabel>
<FeatureList items={unlimitedFeatures} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    DividerLabel(text = "What You Get")
    FeatureList(items = UnlimitedFeatures)
}
```

#### Help Center sheet (`help-center-sheet`)

Opened from Support on the paywall (or Contact Support after a pending payment): call or mail the team.

- React: `import { HelpCenterSheet } from '@equal/ds';`
- Compose: `HelpCenterSheet`
- Tokens: `bg/surface`, `stroke/subtle`, `action-card/highlight`, `text/action`
- Source: Monetization Flow · Help Center

Props of `HelpCenterSheet`:
- `phone / email?`: `string` = +91 9876 543210 / hello@equal.in. Contact rows.
- `onCall / onMail?`: `() => void`. Row taps.

Do: Keep it to the two contact routes.

Don't: Don't send people to a web page from here.

Anatomy:
1. Sheet panel: StatusSheet panel over the scrim, labelled Help Center. (bg/surface · radius 24 top · padding 12/12/20 · content inset 8/8/0)
2. SheetHeading: title: The sheet's title. (title Medium · text/primary · h2 on web, heading() in Compose)
3. SheetHeading: body: One line saying how the team can help. (body1 · text/secondary · 4 above)
4. HelpContactRow: A tappable route to support: Call Us or Mail Us. (radius 14 · 1dp stroke/subtle · padding 12/12/12/16 · gap 12 · 16 above the first, 12 between)
5. HelpContactRow: text: What the route is and the number or address. (title subheading text/primary over value body1 text/secondary)
6. HelpContactRow: icon tile: Green pill with the call or mail icon. (52 × 36 · radius full · action-card/highlight · 22dp icon text/action · decorative)

Accessibility:
- Role. Web: Panel is role=dialog (aria-modal in overlay) with an h2; each HelpContactRow is a native button. Android: Panel has paneTitle 'Help Center'; SheetHeading title has heading(); rows are clickable(Role.Button).
- Name. Web: Each row is named by its text, e.g. 'Call Us +91 9876 543210'; the icon has no label. Android: Row text merges into 'Call Us, +91 9876 543210'; the icon has contentDescription null.
- Keyboard. Web: Tab to each row, Enter/Space activates. No Escape, no focus trap, and the scrim has no click handler, so the sheet cannot be closed from inside. Android: TalkBack: jump to the 'Help Center' heading, swipe to the rows, double-tap. The scrim swallows taps and system Back is not handled.
- Touch target. Web: Rows are full width and about 66 px tall. Android: Rows are full width and about 66dp tall.
- Contrast. Web: Title text/primary and value text/secondary (7.5:1) pass. The icon text/action on action-card/highlight is 2.64:1 in light (below 3:1); lime on #2F3423 is 10.7:1 in dark. Android: Same tokens and ratios as web.
- State. Web: No selected or disabled state; press shows a 0.97 scale (eq-pressable). Android: No state; press shows the ripple.
- Motion. Web: Sheet slides up (motion.slow); off under prefers-reduced-motion. Android: StatusSheet slides up and does not check rememberReduceMotion.

Known accessibility gaps:
- HelpCenterSheet (Monetization.tsx and Monetization.kt) has no way to close from inside: no close button, no scrim tap, no Escape or Back handling.
- HelpContactRow icon (text/action on action-card/highlight) is 2.64:1 in light theme, below 3:1 for icons.
- StatusSheet in Monetization.tsx does not move focus into the dialog or trap it.

Example: Default
```tsx
<HelpCenterSheet phone="+91 9876 543210" email="hello@equal.in" onCall={call} onMail={mail} />
```
```kotlin
HelpCenterSheet(phone = "+91 9876 543210", email = "hello@equal.in", onCall = {}, onMail = {}, inline = true)
```

#### Locked content (`locked-content`)

How free users see what Unlimited unlocks: blurred previews with the crown-lock badge, the Unlock All Details card, and the Unlock Audio pill. Each is a paywall touchpoint.

- React: `import { Locked, LockBadge, UnlockDetailsCard, UnlockAudioPill, ChatListItem, ChatBubble, CallSummary } from '@equal/ds';`
- Compose: `LockedContent`, `LockBadge`, `UnlockDetailsCard`, `UnlockAudioPill`
- Tokens: `locked/badge-bg`, `locked/badge-stroke`, `gradient/status-gold`, `button/primary`
- Source: Monetization Flow · touchpoints

Props of `Locked`:
- `children`: `ReactNode`. Real content, blurred.
- `badge?`: `boolean` = true. Crown-lock badge.
- `inline?`: `boolean`. One line (chat-list previews).

Props of `UnlockDetailsCard`:
- `title / body / cta?`: `string` = Unlock All Details…. Copy.
- `onUnlock?`: `() => void`. Opens the paywall.

Props of `ChatListItem · ChatBubble · CallSummary`:
- `locked?`: `boolean · boolean · 'audio' | 'all'`. Locked state on the existing components.
- `onUnlock?`: `() => void`. CallSummary: Unlock Audio tap.

Do: Blur the real content so the user sees there is something there. Route every locked tap to the paywall with its touchpoint.

Don't: Don't lock the caller's name or the time; only the content. Don't show the crown-lock to paid users.

Anatomy:
1. Locked wrapper: Wraps the real content in place so the layout stays the same while it is hidden. (web span.eq-locked inline-flex · gap 6 · Compose LockedContent Box (Row when inline, full width, gap 6))
2. Blurred content: The real preview, blurred so the user can tell something is there. (blur 4px / Modifier.blur(4.dp) · pointer-events none, user-select none on web · Compose blur needs API 31+)
3. LockBadge: Gold crown with a padlock that marks the item as locked. (crown-lock asset · 18dp (16 inline) · on locked/badge-bg circle, 2dp padding, 6 right / 8 below the corner · inline: no disc)
4. UnlockDetailsCard: header: Paywall card docked over a locked conversation: crown, title and one line. (radius 20 · gradient/status-gold · white rings · padding 16/16/18 · AnimatedCrown 56 · title 22/26 Bold · body body1 text/secondary)
5. UnlockDetailsCard: CTA: Gold button with the lock icon that opens the paywall. (Button gold lg (45 high) · leading lock icon · gradient/cta-gold · white Bold label · 14 above)
6. UnlockAudioPill: Green pill over a locked recording that opens the paywall. (32 high · padding 0 16 · radius full · button/primary · lock 14 + buttonSmall Bold text/on-action · gap 6 · shadow 0 6 16 button/primary 30%)

Accessibility:
- Role. Web: Locked is a span: the content is aria-hidden and a visually hidden sentence replaces it; LockBadge is an img. UnlockDetailsCard CTA and UnlockAudioPill are native buttons. Android: LockedContent uses clearAndSetSemantics with one contentDescription; LockBadge is an Image with contentDescription; UnlockAudioPill is clickable(Role.Button); the CTA is EqualButton.
- Name. Web: Locked reads 'Locked. Unlock Equal Unlimited to see this.' then the badge alt 'Locked' again. Buttons use their visible labels, Unlock Details and Unlock Audio. Android: LockedContent reads 'Locked. Unlock Equal Unlimited to see this.' (the badge is cleared inside it). Buttons use their visible labels.
- Keyboard. Web: Locked itself is not focusable; the parent row or bubble, or the Unlock buttons, take Tab and Enter/Space. Android: TalkBack: swipe to the locked block, which reads as one item; double-tap Unlock Details or Unlock Audio to open the paywall.
- Touch target. Web: UnlockAudioPill is 32 px tall with no eq-touch, so the hit area is 32 px; the lg CTA is 45 px. Both should be at least 48 px. Android: UnlockAudioPill uses minimumInteractiveComponentSize (48dp); EqualButton also enforces 48dp.
- Contrast. Web: UnlockAudioPill: white on button/primary #00B140 is 2.85:1 in light (fails 4.5:1); in dark it is black on lime #BAFF29, 17:1. Card title text/primary and body text/secondary (7.5:1) pass; the gold CTA's white label runs 6.2:1 down to 3.1:1 across gradient/cta-gold. Android: Same tokens as web: the pill's white on green is 2.85:1 in light and fails; dark is black on lime. Gold-on-light card text passes.
- State. Web: Locked is shown by blur plus the crown badge and spoken as text, so it never relies on blur alone. Android: Locked is spoken as text and marked by the badge. Below API 31 the blur is a no-op, so the content is drawn readable.
- Motion. Web: AnimatedCrown sways (4.8s loop) and the gold CTA has a sheen and glow; all stop under prefers-reduced-motion. Android: AnimatedCrown and the gold CTA sheen/glow are static when rememberReduceMotion() is true (animator duration scale 0).

Known accessibility gaps:
- Locked in Monetization.tsx renders LockBadge with alt 'Locked' after the sr-only sentence, so screen readers hear 'Locked' twice; the badge should be decorative (alt='') inside Locked.
- UnlockAudioPill in Monetization.tsx/.css is 32 px tall with no eq-touch, below the 48 px target.
- UnlockAudioPill (Monetization.tsx and Monetization.kt) puts white text on button/primary #00B140, 2.85:1 in light theme; fails 4.5:1.
- Button size lg (Button.css, used by UnlockDetailsCard) is 45 px tall with no touch extension on web.
- LockedContent in Monetization.kt: Modifier.blur is a no-op below API 31, so locked content is readable on older Android.

Example: Locked chat rows
```tsx
<ChatListItem name="Vijay CA" preview="Your KYC is pending" date="1 May"
  avatar={{ category: 'financial' }} locked onClick={openPaywall} />
```
```kotlin
Column {
    ChatListItem(name = "Amit Nanda", preview = "Amit is done with onboarding.", date = "Yesterday",
        category = EqualCategory.Career)
    ChatListItem(name = "Vijay CA", preview = "Your KYC is pending", date = "1 May",
        category = EqualCategory.Financial, locked = true, onClick = { /* open paywall */ })
    ChatListItem(name = "Vijay OLA", preview = "On the gate, need approval.", date = "1 Jul",
        category = EqualCategory.Ride, locked = true, onClick = { /* open paywall */ })
}
```

Example: Locked bubbles and audio
```tsx
<ChatBubble kind="incoming" locked>…</ChatBubble>
<CallSummary summary="…" locked="audio" onUnlock={openPaywall} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    ChatBubble(type = ChatBubbleType.Outgoing, timestamp = "03:21", message = "Hello, who is this?", locked = true)
    ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.RealEstate, timestamp = "03:21",
        message = "We have a 2BHK in Sector 12 with good offer", locked = true)
    CallSummaryBubble(
        summary = "Hey Keshav! Here is the summary of your call.",
        timestamp = "03:22",
        locked = CallSummaryLock.Audio,
        onUnlock = { /* open paywall */ },
        voiceNote = {
            VoiceNotePlayer(isPlaying = false, onPlayPauseClick = {}, progress = 0f, elapsed = "0:00",
                total = "2:37", speed = PlaybackSpeed.X1, onSpeedChange = {})
        },
    )
}
```

Example: Unlock All Details
```tsx
<UnlockDetailsCard onUnlock={openPaywall} />
```
```kotlin
UnlockDetailsCard(onUnlock = { /* open paywall */ })
```

Example: Badge and wrapper
```tsx
<LockBadge />
<Locked><Text variant="body1">…</Text></Locked>
<UnlockAudioPill onClick={openPaywall} />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
    LockBadge()
    LockedContent {
        EqualText(text = "Hey this is vijay calling from magicbrick", style = EqualTheme.type.body1,
            color = EqualTheme.colors.textPrimary)
    }
    UnlockAudioPill(onClick = { /* open paywall */ })
}
```

#### Payment status (`payment-status`)

The result sheets after the user pays: Waiting for Confirmation, Payment Confirmed, Pending, Failed and Congratulations. All share the ring StatusCard.

- React: `import { PaymentStatusSheet, StatusCard, StatusSheet, RedirectNote } from '@equal/ds';`
- Compose: `PaymentStatusSheet`, `StatusCard`, `StatusSheet`, `RedirectNote`
- Tokens: `gradient/status-neutral`, `gradient/status-success`, `gradient/status-warning`, `gradient/status-danger`, `gradient/status-gold`, `scrim`
- Source: Monetization Flow · payment results

Props of `PaymentStatusSheet`:
- `status`: `'waiting' | 'confirmed' | 'pending' | 'failed' | 'welcome'`. Result.
- `cardLast4?`: `string` = '2652'. In the refund line.
- `onRetry / onContactSupport / onRedirect?`: `() => void`. Actions.
- `waitingArt?`: `'status-waiting' | 'status-waiting-cash'` = 'status-waiting'. Experiment: coin or cash art.
- `mode?`: `'overlay' | 'inline'` = 'overlay'. Inline for docs.

Props of `StatusCard`:
- `tone`: `'neutral' | 'success' | 'warning' | 'danger' | 'gold'`. Tint.
- `art`: `AssetName`. 3D art (100dp).
- `strong`: `string`. Bold line 28/32.
- `light?`: `string`. Regular line 22/26.
- `strongFirst?`: `boolean` = true. Order of the lines.

Do: Say what happens to the money on pending and failed. Auto-redirect after success, with the countdown visible.

Don't: Don't add a close button; each result has one next step.

Anatomy:
1. Sheet panel: StatusSheet: the panel over a dimmed screen that holds the result; it has no close button. (scrim token · bg/surface · radius 24 top (24 all round inline) · padding 12/12/20 · shadow 0 -8 30 black 12%)
2. StatusCard container: Tinted ring card that carries the result. (radius 20 · 1dp stroke/subtle · gradient/status-neutral|success|warning|danger|gold · padding 18/16 · white rings (20% in dark))
3. Sunburst: Slowly turning ray burst behind the art on success and welcome. (24 rays · sunburst/ray · centred 70 down · radius 280 · one turn per motion.reward · decorative)
4. Art: 3D result art. (100dp · status-waiting / status-waiting-cash, status-confirmed, status-pending, status-failed · AnimatedCrown 100 for welcome · decorative)
5. Title lines: Two display lines that name the result. (strong 28/32 Bold -0.02em · light 22/26 Regular · text/primary · order from strongFirst · 10 below art)
6. Body: One line on what happens next or to the money. (body1 text/secondary · 8 above · refund line names card **2652)
7. Footer: The single next step. (padding 16 top, 8 sides · RedirectNote body2 text/action, or block lg primary button Contact Support / Retry Payment)

Accessibility:
- Role. Web: StatusSheet panel is role=dialog, aria-modal in overlay mode; the title lines are divs, not headings; RedirectNote has aria-live=polite. Android: Panel sets paneTitle; RedirectNote has liveRegion Polite; art and Sunburst carry no semantics.
- Name. Web: aria-label is built as strong + light, so Waiting reads 'Confirmation Waiting for'. It should follow the visual order: 'Waiting for Confirmation', 'Payment Confirmed'. Android: paneTitle is built as light + strong, so Confirmed reads 'Confirmed Payment'. It should follow strongFirst.
- Keyboard. Web: Focus is not moved into the dialog or trapped; Tab reaches the footer button and Enter/Space activates it. There is no close, so Escape does nothing by design. Android: TalkBack: swipe through title, body and footer; double-tap Contact Support or Retry Payment. The component does not handle system Back.
- Touch target. Web: Footer Button lg is 45 px tall with no touch extension; it should be 48 px. Android: EqualButton Block enforces a 48dp minimum.
- Contrast. Web: Titles text/primary and body text/secondary (7.5:1) pass on the tints. Footer buttons: white on button/primary #00B140 is 2.85:1 in light (fails 4.5:1); in dark it is black on lime #BAFF29, 17:1. RedirectNote text/action on bg/surface is 2.85:1 in light, lime 13:1 in dark. Android: Same tokens and ratios as web.
- State. Web: The result is said in words and art as well as tint. Waiting steps (Connecting To Razorpay, Verifying Transaction) change every 1.4s with no live region. RedirectNote announces every one-second tick. Android: Waiting steps change the paneTitle; the card has no live region. RedirectNote's live region announces every tick.
- Motion. Web: Sheet slides up, each title rises in, Sunburst turns and the crown sways; all stop under prefers-reduced-motion. Android: Title rise, Sunburst and crown check rememberReduceMotion(); the StatusSheet slide-up does not.

Known accessibility gaps:
- PaymentStatusSheet in Monetization.tsx names the dialog strong + light ('Confirmation Waiting for'); Monetization.kt uses light + strong ('Confirmed Payment'). Both should follow strongFirst.
- RedirectNote (Monetization.tsx and Monetization.kt) is a polite live region updated every second, so the countdown is announced five times; announce once.
- Waiting progress steps in PaymentStatusSheet (Monetization.tsx) change the title with no live region, so screen-reader users miss them.
- StatusSheet in Monetization.tsx is role=dialog but does not move focus into the panel or trap it.
- StatusSheet in Monetization.kt always plays the slide-up; it does not check rememberReduceMotion like the other sheets.
- Contact Support / Retry Payment (white on button/primary) and RedirectNote (text/action on white) are 2.85:1 in light theme.
- Footer Button lg (Button.css) is 45 px tall on web with no touch extension.

Example: Waiting for Confirmation (Compose)
```kotlin
PaymentStatusSheet(status = PaymentStatus.Waiting, inline = true)
```

Example: Payment Confirmed (Compose)
```kotlin
PaymentStatusSheet(status = PaymentStatus.Confirmed, onRedirect = { /* go home */ }, inline = true)
```

Example: Payment Pending (Compose)
```kotlin
PaymentStatusSheet(status = PaymentStatus.Pending, onContactSupport = { /* open HelpCenterSheet */ }, inline = true)
```

Example: Payment Failed (Compose)
```kotlin
PaymentStatusSheet(status = PaymentStatus.Failed, onRetry = { /* retry payment */ }, inline = true)
```

Example: Congratulations (Compose)
```kotlin
PaymentStatusSheet(status = PaymentStatus.Welcome, onRedirect = { /* go home */ }, inline = true)
```

#### Paywall (`paywall`)

The Equal Unlimited paywall: gold hero with the 3D crown, the price, a preview of what is locked (it changes with the touchpoint), and the sticky gold CTA.

- React: `import { PaywallHero, PriceTag, LockedPreviewCard, PaywallFooter, AnimatedCrown } from '@equal/ds';`
- Compose: `PaywallHero`, `PriceTag`, `LockedPreviewCard`, `PaywallFooter`, `AnimatedCrown`
- Tokens: `gradient/paywall-hero`, `gradient/gold-text`, `gradient/cta-gold`, `text/gold`, `paywall/card-bg`, `paywall/card-stroke`, `paywall/divider`
- Source: Monetization Flow · Unlock Equal Unlimited

Props of `PaywallHero`:
- `title?`: `string` = 'Unlock Equal'. Regular first line.
- `titleStrong?`: `string` = 'Unlimited'. Bold display line.
- `subtitle?`: `ReactNode` = Unlock Summaries…. Experiment: copy variant.
- `onBack / onSupport?`: `() => void`. Header actions; Support opens the Help Center sheet.
- `children?`: `ReactNode`. Price, preview, coupon.

Props of `PriceTag`:
- `price`: `number | string`. Shown price (drops when the coupon applies).
- `label?`: `string | null` = 'Limited time discount'. Gold caps label with 🎊.
- `currency?`: `string` = '₹'. Prefix.

Props of `PaywallFooter`:
- `cta?`: `string` = 'Unlock Unlimited'. Gold block button.
- `note?`: `string | null` = 'Cancel Anytime. Automatically renews'. Caption under it.
- `onClick?`: `() => void`. Starts payment.
- `variant?`: `'gold' | 'gold-outline' | 'primary'` = 'gold'. gold-outline for Cancel Subscription on the plan page.
- `disabled?`: `boolean`. While a payment is processing.
- `flat?`: `boolean`. No surface or shadow, inside the sheet paywall.
- `above?`: `ReactNode`. Above the button, e.g. the processing toast.

Do: Pick the preview from the touchpoint the user came from. Keep one gold CTA; it is the only commit on the page.

Don't: Don't use a serif for the display lines; the system is DM Sans only. Don't hide the auto-renew note.

Anatomy:
1. Hero: Gold gradient with soft rings. (gradient/paywall-hero · rings every 70 from r 47 · padding-bottom 8)
2. Top bar: Back and Support. (56 high · padding 0 12 0 4 · IconButton arrow-back · help-circle 20 + body2)
3. AnimatedCrown: 3D gold crown with a slow sway. (64 · 4.8 s turntable sway ±20° · drop shadow)
4. Titles: "Unlock Equal" over "Unlimited". (22/26 Regular · 38/42 Bold −0.03em · text/primary)
5. Subtitle: What Unlimited unlocks. (body1 · text/secondary · max width 300 · centred)
6. PriceTag: Discount label and the big gold price. (caption text/gold 🎊 · price 44/48 gradient/gold-text · paywall/divider hairlines)
7. LockedPreviewCard: Cream frame around a preview of what is locked. (radius 20 · paywall/card-bg · 1 px paywall/card-stroke · padding 8 · inner radius 14 bg/surface)
8. PaywallFooter: Sticky gold CTA and the renew note. (bg/surface · shadow 0 -6 18 · padding 12 16 16 · Button lg block 45 · gradient/cta-gold · caption text/secondary)

Accessibility:
- Role. Web: Hero is a <section>; "Unlimited" is the <h1> ("Unlock Equal" is a div); Back is an IconButton, Support and CTA are <button>s; crown is alt="". Android: Back PlainIconButton, Support Row Role.Button, CTA EqualButton Role.Button; no heading() on the titles; crown has no contentDescription.
- Name. Web: Back aria-label "Back"; Support and CTA from their text; 🎊 is aria-hidden. Android: Back "Back"; "Unlimited" has contentDescription "Unlock Equal Unlimited" so the first line is read twice; was-price reads "was ₹249 /Monthly".
- Keyboard. Web: Tab: Back, Support, the preview content, coupon, CTA. Rows inside PaywallPreview are role=button and focusable even though they are only a preview. Android: TalkBack: swipe through bar, titles, price, preview, CTA.
- Touch target. Web: Back 40 px and Support use eq-touch (48); CTA is 45 px high, full width. Android: Back 48 dp; Support minimumInteractiveComponentSize; CTA EqualButton (≥ 48 dp).
- Contrast. Web: Titles text/primary on gold 14:1; subtitle 6.5:1. Price gradient top #B57E32 is about 3:1 on the hero (passes only as large text). CTA white on gold is 6.2:1 → 3.1:1 left to right, about 4.6:1 at the centre. Android: Same tokens; dark gold text 10:1.
- State. Web: Footer disabled uses the native disabled attribute while a payment processes. The struck list price is an <s> with no spoken "was". Android: EqualButton enabled = false; was-price has a "was" contentDescription.
- Motion. Web: Crown sway, gold CTA sheen and glow, and price-drop animations stop under prefers-reduced-motion; the price phase timers still swap the value after 800 ms. Android: Crown, sheen, glow and price drop all hold still when rememberReduceMotion() is true.

Known accessibility gaps:
- Only "Unlimited" is the h1; "Unlock Equal" sits outside the heading (Monetization.tsx PaywallHero).
- PaywallPreview rows (ChatListItem role=button tabIndex=0) are focusable inside a non-interactive preview; mark the preview inert or aria-hidden with a text summary (MonetizationScreens.tsx).
- PriceTag list price is an <s> with no "was" text for screen readers (Monetization.tsx).
- Compose titles: contentDescription "Unlock Equal Unlimited" on titleStrong makes TalkBack read "Unlock Equal" twice, and neither line is a heading() (Monetization.kt PaywallHero).
- Compose PriceTag 🎊 EmojiGlyphs are read aloud by TalkBack (Monetization.kt).

Example: Hero with price and preview
```tsx
<PaywallHero onBack={back} onSupport={openHelp}>
  <PriceTag price={249} />
  <LockedPreviewCard>…what's locked…</LockedPreviewCard>
</PaywallHero>
```
```kotlin
PaywallHero(onBack = {}, onSupport = { /* open HelpCenterSheet */ }) {
    PriceTag(price = "249")
    LockedPreviewCard {
        Column {
            ChatListItem(name = "HDFC RM", preview = "Loan pre-approval request", date = "1:00 PM",
                category = EqualCategory.GateAlert)
            EqualDivider()
            ChatListItem(name = "Vijay NoBroker", preview = "About miniature painting", date = "Yesterday",
                category = EqualCategory.RealEstate, locked = true)
        }
    }
}
```

Example: Preview by touchpoint
```tsx
<PaywallPreview touchpoint="chat-list" />
<PaywallPreview touchpoint="chat" />
<PaywallPreview touchpoint="audio" />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    // Chat list
    LockedPreviewCard {
        ChatListItem(name = "Vijay NoBroker", preview = "About miniature painting", date = "Yesterday",
            category = EqualCategory.RealEstate, locked = true)
    }
    // Chat
    LockedPreviewCard {
        Column(Modifier.padding(horizontal = 4.dp, vertical = 12.dp)) {
            ChatBubble(type = ChatBubbleType.Outgoing, timestamp = "03:21", message = "Hello, who is this?")
            ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.RealEstate,
                timestamp = "03:21", message = "Vijay from no broker", modifier = Modifier.padding(top = 12.dp))
            ChatBubble(type = ChatBubbleType.Incoming, incomingCategory = EqualCategory.RealEstate,
                isFirstInGroup = false, timestamp = "03:21", locked = true, modifier = Modifier.padding(top = 4.dp),
                message = "Hey this is vijay calling from magicbrick a property advisor")
        }
    }
    // Audio
    LockedPreviewCard {
        CallSummaryBubble(
            summary = "Hey Keshav! Here is the summary of your call.",
            timestamp = "03:21",
            locked = CallSummaryLock.Audio,
            onUnlock = { /* open paywall */ },
            voiceNote = {
                VoiceNotePlayer(isPlaying = false, onPlayPauseClick = {}, progress = 0f, elapsed = "0:00",
                    total = "2:37", speed = PlaybackSpeed.X1, onSpeedChange = {})
            },
            modifier = Modifier.padding(4.dp),
        )
    }
}
```

Example: Animated crown
```tsx
<AnimatedCrown size={64} />
<AnimatedCrown size={64} animated={false} />
```
```kotlin
// Turntable sway (4.8s loop); static when animations are off. Stands in for the crown video.
AnimatedCrown(size = 64.dp)
```

Example: Sticky footer
```tsx
<PaywallFooter cta="Unlock Unlimited" note="Cancel Anytime. Automatically renews" onClick={buy} />
```
```kotlin
PaywallFooter(
    onClick = { /* start payment */ },
    cta = "Unlock Unlimited",
    note = "Cancel Anytime. Automatically renews",
)
```

#### Paywall experiments (`monetization-experiments`)

The pieces the Android team A/B tests around the paywall: full-screen payment results, the processing strip, the sheet paywall with its coupon row, Help Center and exit offer, the offer strip, home notice and usage cards, Equal AI’s own notice, crown-locked actions and recordings.

- React: `import { PaymentResult, ProcessingStrip, PaywallSheet, CouponRow, HelpFaqSheet, ExitOfferDialog, OfferStrip, HomeNoticeCard, UsageCapCard, AssistantNoticeCard, SummaryActions, LockedRecording } from '@equal/ds';`
- Compose: `PaymentResult`, `ProcessingStrip`, `PaywallSheet`, `CouponRow`, `HelpFaqSheet`, `ExitOfferDialog`, `OfferStrip`, `HomeNoticeCard`, `UsageCapCard`, `AssistantNoticeCard`, `SummaryActions`, `LockedRecording`
- Tokens: `gradient/result-success`, `gradient/result-pending`, `gradient/result-failed`, `result/ring`, `processing/bg`, `processing/ring`, `offer-strip/bg`, `plan-badge/expired-bg`, `plan-badge/expired-stroke`, `gradient/expired-badge`
- Source: All Payment States · Payment Pending · Home / Conversation Screen (light & dark) · Plan Expired & Usage Cap touchpoints · Recordings + Transcripts Locked · Actions on Home Page

Props of `PaymentResult`:
- `status`: `'success' | 'pending' | 'failed'`. Which page.
- `activeTill?`: `string` = '10th Sept 2026'. Success date.
- `pendingAction?`: `'refresh' | 'support'` = 'refresh'. Pending CTA.
- `header?`: `ReactNode`. Status bar on the wash.

Props of `PaywallSheet`:
- `price?`: `number` = 249. List price.
- `discountedPrice?`: `number` = 149. With EQUAL25.
- `applied?`: `boolean`. Coupon applied.
- `processing?`: `boolean`. Toast + disabled CTA.
- `cta?`: `string` = 'Unlock Equal AI Unlimited'. CTA copy (experiment).
- `mode?`: `'overlay' | 'inline'` = 'overlay'. Docs: inline.

Props of `ExitOfferDialog`:
- `dismissLabel?`: `string` = 'Not Now'. Leave in chats.
- `claimLabel?`: `string` = 'Claim 25% Off'. Keep 25% Off in chats.

Props of `ProcessingStrip`:
- `variant?`: `'strip' | 'card' | 'toast'` = 'strip'. Where it sits.

Do: Pass experiments as props on the same screen (Home, Chat, Paywall); never fork a screen per variant. While a payment is processing, show it everywhere it matters and disable the paywall CTA.

Don't: Don't show the exit offer more than once per session. Don't lock the caller's name, the time or the summary label; only content and actions.

Anatomy:
1. PaymentResult: Full-screen payment result with a tinted wash. (gradient/result-success|pending|failed · result/ring rings · 36/44 close or back chip · 84 art · title 30/36 Bold (h1) · body body1 text/secondary · block lg action pinned at the bottom)
2. ProcessingStrip: Payment processing notice with a spinning ring. (processing/bg · padding 8/12 · gap 10 · 30 ring, 3dp processing/ring arc around an 18 info dot · title body2 Medium + caption text/secondary · strip / card radius 12 / toast)
3. PaywallSheet card: Compact gold paywall in a bottom sheet. (bg/surface panel radius 28 top · card radius 20 gradient/paywall-hero, 1dp paywall/card-stroke · Support top-right · crown 56 · 'Unlimited' 34/38 Bold · price 34/40 gold)
4. CouponRow: EQUAL25 coupon with APPLY / APPLIED. (radius 14 · gradient/coupon · 1dp paywall/card-stroke · padding 10/14 · code subheading Bold text/gold · APPLY body2 Bold text/gold)
5. ExitOfferDialog + OfferStrip: Exit offer card and the home strip after declining. (dialog radius 20, bg/surface, padding 18/16/16, black 55% scrim, gold-outline + gold md buttons · strip offer-strip/bg, offer-strip/text, underlined Claim Now)
6. HomeNoticeCard / UsageCapCard: Home card with a CTA and optional usage bar. (radius 16 · bg/surface · 1dp stroke/subtle · padding 12/14 · title subheading + caption · md primary button · 6dp bar stroke/subtle track, button/primary fill)
7. AssistantNoticeCard: Equal AI's own message with a voice note and CTA. (radius 16 · bg/surface · voice player · 'Equal AI' body2 text/action · title subheading · 48 CTA row with crown-lock, text/action)
8. SummaryActions + LockedRecording: Locked actions and recording on the free plan. (48 rows, 1dp stroke/subtle top · locked: crown-lock 16 + text/gold · recording blurred 2.5 on gold wash · 40 gold badge with crown-lock 26)

Accessibility:
- Role. Web: PaymentResult is a section with aria-label and an h1; ProcessingStrip is role=status; PaywallSheet and HelpFaqSheet are role=dialog; ExitOfferDialog is role=alertdialog; OfferStrip is role=status; usage bar is role=progressbar; LockedRecording is a button. Android: PaymentResult, PaywallSheet, HelpFaqSheet and ExitOfferDialog set paneTitle; ProcessingStrip merges with liveRegion Polite; price and APPLIED are live regions; LockedRecording is Role.Button with one description.
- Name. Web: Chips 'Close' / 'Back'; LockedRecording 'Recording locked. Unlock Equal AI Unlimited'; locked actions read 'Locked Call Back'; buttons by text. The usage bar has no label. Android: Same strings; usage bar reads 'N% used'; locked crown 'Locked'.
- Keyboard. Web: Tab through actions; Enter/Space activate. Sheets and dialogs don't move or trap focus and ignore Escape; scrim clicks call onScrim. Android: TalkBack: swipe and double-tap; scrims have onClickLabel 'Close'. System Back is not handled.
- Touch target. Web: Result chips 36 with eq-touch (48); APPLY, Support and Claim Now use eq-touch; ExitOfferDialog and HomeNoticeCard md buttons are 36 px and lg buttons 45 px with no extension. Android: EqualButton and APPLY/Support/Claim Now meet 48dp; the PaymentResult close/back chip is 44dp with no minimum size.
- Contrast. Web: Primary buttons are white on green 2.85:1 in light; text/action CTAs and labels on white 2.85:1. Offer strip 9.2:1 light / 9.0:1 dark; processing text primary, ring gold 5.3:1; locked gold labels 6:1 on white; gold CTAs white 6.2→3.1:1. Android: Same tokens and ratios as web.
- State. Web: Processing is announced (role=status) and disables the CTA (disabled attribute). Locked actions show the crown and gold label plus 'Locked' in the name. APPLIED on CouponRow is plain text with no live region. Android: Processing is a live region and the CTA is disabled; APPLIED and the new price are polite live regions.
- Motion. Web: Sheet slide-up, exit-offer spring, processing ring spin, price land, crown and gold CTA sheen; all stop under prefers-reduced-motion. Android: SheetLayer, exit spring, ring spin and price land check rememberReduceMotion.

Known accessibility gaps:
- CouponRow in MonetizationExperiments.tsx swaps APPLY for APPLIED with no live region (Compose announces it).
- HomeNoticeCard usage bar in MonetizationExperiments.tsx is role=progressbar with no accessible name.
- ExitOfferDialog (alertdialog), PaywallSheet and HelpFaqSheet in MonetizationExperiments.tsx don't move or trap focus or close on Escape.
- ExitOfferDialog and HomeNoticeCard md buttons (36 px) and lg buttons (45 px) have no touch extension on web.
- PaymentResult close/back chip in MonetizationExperiments.kt is 44dp with no minimumInteractiveComponentSize.
- Primary buttons and text/action labels (Refresh Status, Retry payment, AssistantNoticeCard CTA, unlocked SummaryActions) are 2.85:1 in light theme.

Example: Payment results
```tsx
<PaymentResult status="success" activeTill="10th Sept 2026" />
<PaymentResult status="pending" onClose={close} onRefresh={refresh} />   // pendingAction="support" → Contact Support
<PaymentResult status="failed" onBack={back} onRetry={retry} onContactSupport={support} />
```
```kotlin
Row(Modifier.height(440.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
    PaymentResult(status = PaymentResultStatus.Success, activeTill = "10th Sept 2026", modifier = Modifier.weight(1f))
    // pendingAction = PendingAction.Support → Contact Support
    PaymentResult(status = PaymentResultStatus.Pending, onClose = {}, onRefresh = {}, modifier = Modifier.weight(1f))
    PaymentResult(status = PaymentResultStatus.Failed, onBack = {}, onRetry = {}, onContactSupport = {}, modifier = Modifier.weight(1f))
}
```

Example: Payment processing
```tsx
<ProcessingStrip />                 // under a chat header
<ProcessingStrip variant="card" />  // under the home toggle
<ProcessingStrip variant="toast" /> // above the disabled paywall CTA
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    ProcessingStrip() // under a chat header
    ProcessingStrip(variant = ProcessingStripVariant.Card) // under the home toggle
    ProcessingStrip(variant = ProcessingStripVariant.Toast, modifier = Modifier.padding(horizontal = 12.dp)) // above the disabled paywall CTA
}
```

Example: Sheet paywall
```tsx
<PaywallSheet applied={applied} onApply={apply} onSupport={openHelp} onScrim={askToLeave} onUnlock={pay} />
```
```kotlin
var applied by remember { mutableStateOf(false) }
// Over a screen: draw it last in a full-size Box (onScrim → the exit offer). Docs: inline = true.
PaywallSheet(
    applied = applied,
    onApply = { applied = true },
    onSupport = { /* HelpFaqSheet */ },
    onScrim = { /* ExitOfferDialog */ },
    onUnlock = { /* pay */ },
    inline = true,
)
```

Example: Exit offer and offer strip
```tsx
<ExitOfferDialog onDismiss={leave} onClaim={claim} />          // chat: dismissLabel="Leave" claimLabel="Keep 25% Off"
<OfferStrip onClick={reopenWithCoupon} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    // In a chat: dismissLabel = "Leave", claimLabel = "Keep 25% Off"
    ExitOfferDialog(onDismiss = {}, onClaim = {}, inline = true, modifier = Modifier.padding(horizontal = 16.dp))
    OfferStrip(onClick = { /* reopen the sheet with EQUAL25 applied */ })
}
```

Example: Home cards
```tsx
<HomeNoticeCard lead="👑" title="Your Plan Expired" subtitle="Renew to get Unlimited access back" cta="Renew Now" onCta={renew} />
<UsageCapCard left={7} limit={30} resets="Mon" onUpgrade={openPaywall} />
```
```kotlin
Column {
    HomeNoticeCard(
        lead = { EmojiGlyph(emoji = "👑", size = 14.dp) },
        title = "Your Plan Expired",
        subtitle = "Renew to get Unlimited access back",
        cta = "Renew Now",
        onCta = { /* renew */ },
    )
    UsageCapCard(left = 7, limit = 30, resets = "Mon", onUpgrade = { /* open the paywall */ })
}
```

Example: Equal AI notice
```tsx
<AssistantNoticeCard title="Your Plan Expired" body="Renew to unlock unlimited recordings, …" cta="Renew Equal AI Unlimited" onCta={openPaywall} />
```
```kotlin
AssistantNoticeCard(
    title = "Your Plan Expired",
    body = "Renew to unlock unlimited recordings, call summaries, transcripts, and unlimited call screening.",
    cta = "Renew Equal AI Unlimited",
    onCta = { /* open the paywall */ },
)
```

Example: Locked recording and actions
```tsx
<LockedRecording onUnlock={openPaywall} />
<SummaryActions locked actions={[{ label: 'Call Back', icon: 'call-filled' }, { label: 'Add to Calendar', icon: 'calendar' }]} onLocked={openPaywall} />
<SmallActionChip label="Call Back" emoji="📞" locked />   // ChatListItem lockedActions
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    LockedRecording(onUnlock = { /* open the paywall */ })
    SummaryActions(
        actions = listOf(SummaryAction("Call Back", EqualIcons.CallFilled), SummaryAction("Add to Calendar", EqualIcons.CalendarMonth)),
        locked = true,
        onLocked = { /* open the paywall */ },
    )
    // ChatListItem(lockedActions = true) draws its chips like this
    SmallActionChip(label = "Call Back", emoji = "📞", onClick = {}, locked = true)
}
```

#### Plan banner (`plan-banner`)

The amber "Reactivate your current Plan…" strip for lapsed plans, under the plan card in Settings or at the top of a chat; plus the plan card link label (Manage plan / Restore Plan / Reactivate plan).

- React: `import { PlanBanner, PlanCard } from '@equal/ds';`
- Compose: `PlanBanner`
- Tokens: `plan-banner/bg`, `plan-banner/text`
- Source: Monetization Flow · lapsed plan

Props of `PlanBanner`:
- `children`: `ReactNode`. Message.
- `attached?`: `boolean`. Hangs under the plan card.
- `onClick?`: `() => void`. Makes the strip tappable.

Do: Use it only when the plan has lapsed or autopay is off.

Don't: Don't use red; it is a nudge, not an error.

Anatomy:
1. Strip: Amber strip that nudges a lapsed plan. (plan-banner/bg · padding 8/12 · gap 8 · attached: inset 8, pulled 14 up under PlanCard, top padding 20, radius 14 bottom only)
2. Info icon: Marks the strip as a notice. (info-fill 16 · plan-banner/text · decorative)
3. Message: What to do, e.g. 'Reactivate your current Plan to use Equal Unlimited'. (caption · plan-banner/text)

Accessibility:
- Role. Web: role=status when static; with onClick it becomes a div role=button with tabIndex 0. Android: Plain text when static; with onClick the Row is clickable(Role.Button). No live region.
- Name. Web: The message text; the icon is aria-hidden. Android: The message text; the icon has contentDescription null.
- Keyboard. Web: When tappable it takes focus but has no key handler, so Enter/Space do nothing. It should be a <button> or handle both keys. Android: TalkBack: swipe to the strip, double-tap to reactivate.
- Touch target. Web: About 32 px tall (44 attached) when tappable; should be at least 48 px. Android: About 32dp tall (44 attached) with no minimum size; should be at least 48dp.
- Contrast. Web: plan-banner/text on plan-banner/bg is 6.0:1 light, 9.0:1 dark. Android: Same tokens: 6.0:1 light, 9.0:1 dark.
- State. Web: The lapsed plan is stated in the text; amber is supporting, never the only signal. Android: Same: the text carries the meaning.

Known accessibility gaps:
- PlanBanner in Monetization.tsx with onClick is a div role=button with no onKeyDown, so Enter/Space don't activate it.
- PlanBanner (Monetization.tsx and Monetization.kt) is about 32 px/dp tall when tappable, below the 48 target.

Example: Under the plan card
```tsx
<PlanCard onManage={reactivate} actionLabel="Reactivate plan" />
<PlanBanner attached>Reactivate your current Plan to use Equal Unlimited</PlanBanner>
```
```kotlin
Column {
    PlanCard(onManageClick = { /* reactivate */ }, manageLabel = "Reactivate plan")
    PlanBanner(text = "Reactivate your current Plan to use Equal Unlimited", attached = true)
}
```

Example: At the top of a chat
```tsx
<PlanBanner onClick={reactivate}>Reactivate your current Plan to keep using Equal Unlimited</PlanBanner>
```
```kotlin
PlanBanner(text = "Reactivate your current Plan to keep using Equal Unlimited", onClick = { /* reactivate */ })
```

#### Plan expiry banner (`plan-expiry-banner`)

The strip under the home header as a plan runs out: amber while days remain, red on the last day and after it ends, always with Renew Now.

- React: `import { PlanExpiryBanner } from '@equal/ds';`
- Compose: `PlanExpiryBanner`
- Tokens: `expiry-banner/warning-bg`, `expiry-banner/warning-icon-bg`, `expiry-banner/danger-icon-bg`, `expiry-banner/warning-text`, `expiry-banner/danger-bg`, `expiry-banner/danger-text`
- Source: Monetization value · Home Screen

Props of `PlanExpiryBanner`:
- `expiry`: `{ state: 'expiring', days } | { state: 'today' } | { state: 'expired', date }`. Where the plan stands; picks the tone and copy.
- `onRenew?`: `() => void`. Renew Now.

Do: Show it full width directly under the home header. Use amber while days remain, red from the last day.

Don't: Don't show it while the plan is comfortably active. Don't stack it with the Reactivate plan banner.

Anatomy:
1. Strip: Full-width strip under the home header as the plan runs out. (min 44 high · padding 6/12 · gap 10 · expiry-banner/warning-bg (days left) or expiry-banner/danger-bg (today, expired))
2. Icon disc: Info icon in a soft disc of the text colour. (info-fill 20 · 3dp padding · circle of the text colour at 12% · decorative)
3. Message: Where the plan stands, with the key part in Bold. (body2 · 'Your Plan Expires in 2 Days' / 'Expires Today' / 'Expired on 30th July' · expiry-banner/*-text)
4. Renew Now: Text action that opens renewal. (button token Bold · underlined, offset 3 · same text colour · 48 touch target)

Accessibility:
- Role. Web: The strip is role=status with a native button inside. Android: The message has liveRegion Polite; Renew Now is clickable(Role.Button).
- Name. Web: Message text, e.g. 'Your Plan Expires in 2 Days'; button 'Renew Now'; icon aria-hidden. Android: Message text and 'Renew Now'; icon contentDescription null.
- Keyboard. Web: Tab to Renew Now, Enter/Space activates. Android: TalkBack reads the message, then 'Renew Now, Button'; double-tap renews.
- Touch target. Web: Renew Now uses eq-touch for a 48 px hit area around the text. Android: Renew Now uses minimumInteractiveComponentSize (48dp).
- Contrast. Web: Warning text 7.1:1 light / 9.0:1 dark; danger text 8.9:1 light / 7.7:1 dark. The link is marked by underline and Bold, not colour. Android: Same tokens and ratios as web.
- State. Web: Amber vs red always comes with the words 'Expires in N Days', 'Today' or 'Expired on'; the live region announces it when it appears. Android: Same; the polite live region announces the message.
- Motion. Web: No animation. Android: No animation.

Example: States
```tsx
<PlanExpiryBanner expiry={{ state: 'expiring', days: 2 }} onRenew={renew} />
<PlanExpiryBanner expiry={{ state: 'today' }} onRenew={renew} />
<PlanExpiryBanner expiry={{ state: 'expired', date: '30th July' }} onRenew={renew} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    PlanExpiryBanner(expiry = PlanExpiry.Expiring(days = 2), onRenew = { /* open PaywallScreen */ })
    PlanExpiryBanner(expiry = PlanExpiry.Today, onRenew = { /* open PaywallScreen */ })
    PlanExpiryBanner(expiry = PlanExpiry.Expired(date = "30th July"), onRenew = { /* open PaywallScreen */ })
}
```

#### Social proof (`social-proof`)

The subscription page proof block: a big gold stat, the rating pill and a testimonial carousel.

- React: `import { StatBlock, RatingPill, TestimonialCarousel } from '@equal/ds';`
- Compose: `StatBlock`, `RatingPill`, `TestimonialCarousel`
- Tokens: `gradient/gold-text`, `text/gold`, `paywall/card-stroke`
- Source: Monetization Flow · Why people choose

Props of `StatBlock`:
- `value`: `string`. "400k+".
- `label`: `string`. Under it.

Props of `RatingPill`:
- `rating`: `number`. 4.5
- `outOf?`: `number` = 5. Scale.

Props of `TestimonialCarousel`:
- `items`: `{ quote; name; avatar? }[]`. Cards (240 wide), with page dots.

Do: Use real numbers and real reviews only.

Don't: Don't invent testimonials for production.

Anatomy:
1. Panel: SocialProof: gold-washed block with the section label. (radius 28 bottom · bg/surface → paywall/card-bg (30%) wash · padding 24/16/20 · gap 16 · DividerLabel 'Why people choose' over 'EQUAL UNLIMITED' title Bold text/gold)
2. StatBlock: Big gold stat with its label. (value 52/56 Bold -0.04em gradient/gold-text · label body2 text/primary)
3. RatingPill: Rating out of five. (36 high · padding 0 14 · radius 10 · bg/surface · 1dp paywall/card-stroke · gold star 20 · 'Rated' body2 · rating body2 Bold · '/5' body1 text/tertiary)
4. TestimonialCarousel: card: One review card in a sideways scroller. (240 wide · gap 12 · radius 16 · bg/surface · 1dp stroke/subtle · padding 14 · quote body1 text/secondary · avatar 36 + name body2)
5. TestimonialCarousel: dots: Page dots under the cards. (6dp · gap 6 · stroke/medium, current text/gold · decorative)

Accessibility:
- Role. Web: Cards are figure with blockquote and figcaption; the track is a plain scrolling div; dots are aria-hidden. Android: Cards are Columns in a LazyRow; RatingPill is cleared to one description; dots are cleared.
- Name. Web: Stat reads '400k+ People never miss a call'; rating reads 'Rated 4.5 /5' as separate spans; star alt is empty. Android: Rating reads 'Rated 4.5 out of 5'; star has no description.
- Keyboard. Web: The track has no tabIndex and no buttons, so keyboard users can't scroll to later testimonials. Android: TalkBack swipes card by card and scrolls the LazyRow.
- Contrast. Web: Gold stat gradient is 3.5–7.3:1 on white (52 px, large text); 'EQUAL UNLIMITED' text/gold 5.9:1 on paywall/card-bg; quotes text/secondary 7.5:1; '/5' text/tertiary 5.1:1. Gold-on-light passes; dark uses the light gold tokens. Android: Same tokens and ratios as web.
- State. Web: Current page is shown only by the gold dot, which is hidden from assistive tech; no position is announced. Android: Dots are cleared; no page position is announced.
- Motion. Web: Scroll snapping only; no animation. Android: Snap fling only; no animation.

Known accessibility gaps:
- TestimonialCarousel track in Monetization.tsx is not focusable and has no controls, so keyboard users can't reach later testimonials.
- StatBlock in Monetization.tsx paints text with background-clip and color: transparent, so it disappears in forced-colors / high-contrast mode.
- DividerLabel 'Why people choose' (Monetization.tsx and Monetization.kt) is not a heading.

Example: Stat and rating
```tsx
<StatBlock value="400k+" label="People never miss a call" />
<RatingPill rating={4.5} />
```
```kotlin
Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
    StatBlock(value = "400k+", label = "People never miss a call")
    RatingPill(rating = 4.5f)
}
```

Example: Testimonials
```tsx
<TestimonialCarousel items={[{ quote, name, avatar: <ProfileAvatar variant="female" size={36} /> }, …]} />
```
```kotlin
val avatar = @Composable { asset: EqualAssets -> EqualAssetImage(asset, size = 36.dp, modifier = Modifier.clip(CircleShape)) }
TestimonialCarousel(
    items = listOf(
        Testimonial(
            quote = "As a freelancer, client calls and spam used to mix together. Now I get proper summaries.",
            name = "keerthana",
            avatar = { avatar(EqualAssets.AvatarTestimonial1) },
        ),
        Testimonial(
            quote = "It is a very useful app for screening the unknown calls. This is a must download.",
            name = "Arnav Raj",
            avatar = { avatar(EqualAssets.AvatarTestimonial2) },
        ),
        Testimonial(
            quote = "My parents get loan and insurance calls all day. Equal answers them, and I just read the summary.",
            name = "Riya Kapoor",
            avatar = { avatar(EqualAssets.AvatarTestimonial3) },
        ),
    ),
)
```

#### Value card & sheet (`value-card`)

What Unlimited saved you: calls handled, the perks, the expiry chip and the current plan. Inside the sheet that rises after a call near the end of a plan, and on the plan page (circuit pattern, no perks). For free users the QuotaCard counts the week’s calls instead.

- React: `import { ValueCard, QuotaCard, ValueSheet, ExpiryChip, PremiumIcon } from '@equal/ds';`
- Compose: `ValueCard`, `QuotaCard`, `ValueSheet`, `ExpiryChip`, `PremiumIcon`
- Tokens: `premium-icon/start`, `premium-icon/end`, `gradient/value-card`, `value-card/stroke`, `value-card/perks-bg`, `value-card/ring`, `expiry-chip/warning-bg`, `expiry-chip/danger-bg`, `expiry-chip/active-bg`
- Source: Monetization value · Value Bottom Sheet Once Called

Props of `ValueCard`:
- `calls`: `number`. Calls the assistant handled.
- `expiry`: `PlanExpiry`. active (until) · expiring (days) · today · expired (date).
- `title?`: `string | null` = 'What Unlimited saved you'. In-card heading; null on the plan page.
- `perks?`: `ValuePerk[] | null` = defaultValuePerks. The three rows; null hides them.
- `price?`: `number` = 39. Current price.
- `was?`: `number` = 49. Struck list price.
- `pattern?`: `'rings' | 'circuit'` = circuit when perks is null. Rings (sheet) or the gold circuit lines (plan page).

Props of `PremiumIcon`:
- `name`: `IconName`. A filled Material Symbol (the -fill icons, timer, person, call-log).
- `size?`: `number` = 16. dp.

Props of `QuotaCard`:
- `quota`: `{ used: number; limit: number; resetsInDays: number }`. This week; used ≥ limit shows Limit Reached.
- `perks?`: `ValuePerk[] | null` = quotaPerks. What Unlimited adds.
- `price?`: `number` = 149. Price.
- `was?`: `number` = 249. Struck list price.

Props of `ValueSheet`:
- `expiry?`: `PlanExpiry`. Paid plan state.
- `quota?`: `Quota`. Free plan: show the QuotaCard (CTA Get Equal AI Unlimited).
- `calls?`: `number` = 20. Calls handled.
- `variant?`: `'card' | 'flush'` = 'card'. Inset card or the card as the sheet (experiment).
- `cta?`: `string` = 'Renew your Equal AI'. Gold CTA.
- `onRenew?`: `() => void`. CTA.
- `onClose?`: `() => void`. The floating close and the scrim.

Do: Show the sheet once, after the assistant handles a call in the last days of a plan. Lead with the number; the user should see what they get before the ask. Perk icons are filled Material Symbols at 16 dp in the premium gold gradient (PremiumIcon), never outlined or flat-tinted. Light cards sit on the premium-glow art; dark cards use the coded black-gold gradient.

Don't: Don't show the sheet on every call or app open. Don't use it for users who never subscribed; they get the paywall.

Anatomy:
1. Container: ValueCard: the gold card that shows what Unlimited did before asking for renewal. (radius 20 · 1dp value-card/stroke · light rings: bg/surface + premium-glow art · dark: gradient/value-card + value-card/ring rings · circuit: paywall/card-bg → bg/surface + gold circuit · padding 18/14 · gap 14)
2. Title: In-card heading, hidden on the plan page. (DividerLabel · subheading Medium uppercase · paywall/divider hairlines · inset 16)
3. Stat: Calls the assistant handled. (count 48/52 Bold -0.04em tabular text/primary · 'Calls Handled' title Medium over 'by your Assistant' body1 · gap 12)
4. Perks: Three things Unlimited did, each with a gold icon. (inset 16 · radius 14 · value-card/perks-bg · 1dp value-card/stroke · rows padding 10/12 · PremiumIcon 16 (premium-icon/start → end) + body2)
5. Date row + ExpiryChip: When the plan ends, with a tinted chip. (paywall/divider rules · label body1 · chip 30 high, radius 6, padding 0 8, 18 Bold tabular · active text/gold on expiry-chip/active-bg · warning/danger expiry-chip tokens)
6. Plan row: Current plan and its price. ('Current Plan' caption text/secondary over plan title SemiBold · ₹price subheading Bold · struck ₹was and period caption text/secondary)
7. ValueSheet: close and CTA: The sheet around the card: floating close and the gold renew button. (panel sheet/bg radius 24 top · 44 neutral close 16 above, centred (48 touch) · block gold CTA 'Renew your Equal AI', padding 16 · flush: card is the top, CTA on bg/surface)
8. QuotaCard: head and bar: Free plan: calls left this week and a gold bar. ('6 out of 30' 30/36 Bold + 'Calls Left' 18 Medium · 10dp bar, paywall/divider track, gradient/cta-gold fill · 'Limit Reached' replaces both at the limit)

Accessibility:
- Role. Web: ValueCard and QuotaCard are <section aria-label>; perks are a ul; the quota bar is role=progressbar with min, max and now; ValueSheet is role=dialog (aria-modal in overlay). Android: The stat row uses clearAndSetSemantics; the quota bar sets progressBarRangeInfo; the sheet panel sets paneTitle.
- Name. Web: Section label is the title or 'N out of M calls left' / 'Limit reached'; bar 'Calls handled this week'; close 'Close'; CTA by its text. PremiumIcon is aria-hidden. Android: Stat reads '20 Calls Handled by your Assistant'; bar 'Calls handled this week'; close 'Close'; scrim onClickLabel 'Close'. PremiumIcon has no description.
- Keyboard. Web: Tab reaches Close then the CTA; the scrim click closes. No Escape key and no focus trap. Android: TalkBack: swipe through the card, then the CTA; Close sits above the panel. System Back is not handled by the component.
- Touch target. Web: Close is 44 px with eq-touch (48); the gold CTA is a 45 px lg button with no extension. Android: Close is a 44dp circle in a 48dp box; EqualButton enforces 48dp.
- Contrast. Web: Text is text/primary or text/secondary (7.5:1). ExpiryChip: active 5.3:1 light / 7.3:1 dark, warning 6.6 / 9.7, danger 5.6 / 7.2. Gold CTA white label runs 6.2:1 to 3.1:1 across gradient/cta-gold. PremiumIcon is decorative (2.2:1 at its light stop). Light cards sit on premium-glow art, dark on the black-gold gradient. Android: Same tokens and ratios as web.
- State. Web: Expiry tone always comes with words ('Plan Expires in', 'Today', 'Expired on'). The quota bar exposes its value; at the limit the bar is replaced by 'Limit Reached'. The struck ₹was is an <s>, which screen readers usually don't announce. Android: Same wording carries the tone. The struck ₹was is a LineThrough span with no description, so it reads as a second price.
- Motion. Web: Sheet slides up (motion.slow); gold CTA sheen and glow; all stop under prefers-reduced-motion. Android: Gold CTA sheen/glow stop under rememberReduceMotion; the ValueSheet slide-up does not check it.

Known accessibility gaps:
- ValueSheet in Monetization.tsx is role=dialog with no Escape to close and no focus trap.
- ValueCard/QuotaCard plan row: the struck ₹was (<s> in Monetization.tsx, LineThrough span in PlanValue.kt) has no 'was' text, so screen readers read '₹39 ₹49 /Monthly'.
- ValueSheet in PlanValue.kt always plays the slide-up and fade; it does not check rememberReduceMotion.
- The gold CTA (Button lg, Button.css) is 45 px tall on web with no touch extension.

Example: Sheet
```tsx
<ValueSheet expiry={{ state: 'expiring', days: 3 }} onRenew={renew} onClose={close} />
```
```kotlin
// Overlay: fills the screen (scrim + sheet); pass inline = true to draw only the panel
ValueSheet(
    expiry = PlanExpiry.Expiring(days = 3),
    onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
    onClose = { /* hide the sheet */ },
)
```

Example: Flush sheet (experiment)
```tsx
<ValueSheet variant="flush" expiry={{ state: 'today' }} onRenew={renew} onClose={close} />
```
```kotlin
ValueSheet(
    expiry = PlanExpiry.Today,
    variant = ValueSheetVariant.Flush,
    onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
    onClose = { /* hide the sheet */ },
)
```

Example: On the plan page
```tsx
<DividerLabel>What Unlimited Saved You</DividerLabel>
<ValueCard calls={20} title={null} perks={null} expiry={{ state: 'expired', date: '30th July' }} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
    DividerLabel(text = "What Unlimited Saved You")
    ValueCard(calls = 20, title = null, perks = null, expiry = PlanExpiry.Expired(date = "30th July"))
}
```

Example: Quota: calls left
```tsx
<QuotaCard quota={{ used: 24, limit: 30, resetsInDays: 4 }} />
```
```kotlin
// Free plan: "6 out of 30 Calls Left" with the gold progress bar
QuotaCard(quota = Quota(used = 24, limit = 30, resetsInDays = 4))
```

Example: Quota: limit reached
```tsx
<QuotaCard quota={{ used: 30, limit: 30, resetsInDays: 2 }} />
// in the sheet: <ValueSheet quota={{ used: 30, limit: 30, resetsInDays: 2 }} onRenew={openPaywall} onClose={close} />
```
```kotlin
QuotaCard(quota = Quota(used = 30, limit = 30, resetsInDays = 2))
// in the sheet: ValueSheet(quota = Quota(used = 30, limit = 30, resetsInDays = 2), onRenew = openPaywall, onClose = close)
```

Example: Expiry chips
```tsx
<ExpiryChip tone="active">25th Jun ’26</ExpiryChip>
<ExpiryChip tone="warning">03 Days</ExpiryChip>
<ExpiryChip tone="danger">Today</ExpiryChip>
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
    ExpiryChip(text = "25th Jun ’26", tone = ExpiryTone.Active)
    ExpiryChip(text = "03 Days", tone = ExpiryTone.Warning)
    ExpiryChip(text = "Today", tone = ExpiryTone.Danger)
}
```

### Group: Navigation

#### App bar (`app-bar`)

The standard screen header with back, a subheading title and trailing actions, plus the uppercase section header that labels groups of rows.

- React: `import { AppBar, SectionHeader } from '@equal/ds';`
- Compose: `EqualAppBar`, `SectionHeader`
- Tokens: `bg/primary`, `bg/surface`, `shadow/header`, `text/primary`, `text/tertiary`
- Source: Surfaces from the Typography screen inventory · App Bar, Section Header

Do: Centre the title in flow screens (Personal Details, Your Addresses, Contact Info). Keep SectionHeader side inset equal to the RowGroup inset below it (20 on the You tab).

Don't: Don't write section headers in capitals in source; pass normal text and let the component uppercase it. Don't put a filled Button in the app bar; trailing actions are icon or text buttons.

Anatomy:
1. Container: Header surface at the top of a screen. (center 56 high · start 64 high · bg/primary default, bg/surface or transparent · elevated adds shadow/header)
2. Status bar: Optional mock status bar on the same background. (52 high · statusBar prop)
3. Back button: Ghost icon button that goes back. (arrow-back 24 · web 40 + eq-touch, Compose 48 · padding 4 start / 8 end)
4. Title: Screen name, one line, centred by default. (subheading 16/500 · text/primary · ellipsis · centre uses equal side columns)
5. Trailing actions: Optional actions at the end. (`trailing` / `actions` slot)
6. SectionHeader: Uppercase region label with an optional action. (overline 11/500 text/tertiary · padding 24 top / 12 bottom / inset 20 · label size 13 text/secondary, 30 / 18)

Accessibility:
- Role. Web: <header> landmark with the title as <h1>; SectionHeader is plain text, not a heading. Android: Column/Row with plain text; the title has no heading() semantics.
- Name. Web: Back is IconButton label 'Back'; the h1 text names the screen. Android: PlainIconButton contentDescription 'Back'.
- Keyboard. Web: Tab reaches Back, then trailing actions; screen-reader users can jump to the h1. Android: TalkBack: swipe through Back, title and actions; headings navigation does not find the title.
- Touch target. Web: Back is 40px with .eq-touch for 48px. Android: PlainIconButton is 48dp with minimumInteractiveComponentSize(); the SectionHeader action is clickable text with no minimum size.
- Contrast. Web: Title text/primary 17:1; SectionHeader text/tertiary on bg/primary 4.8:1, label size text/secondary 7:1. Android: Same tokens; a SectionHeader action in text/action #00B140 is 2.85:1 on white.

Known accessibility gaps:
- ChatHeader.kt: EqualAppBar's title has no semantics { heading() } (web uses <h1>).
- AppBar.tsx / Rows.kt: SectionHeader is not exposed as a heading (web span, Compose plain text).
- Rows.kt: the SectionHeader action is a clickable EqualText with no minimumInteractiveComponentSize, so its target is about 16dp high, and its text/action label is 2.85:1 in light.

Example: Centred (flows)
```tsx
<AppBar title="Personal Details" onBack={goBack} />
```
```kotlin
EqualAppBar(title = "Personal Details", onBackClick = {})
```

Example: Start-aligned, elevated, with trailing
```tsx
<AppBar title="Active Instructions" align="start" surface="surface" elevated
  onBack={goBack} trailing={<TextButton leadingIcon="add">Add</TextButton>} />
```
```kotlin
EqualAppBar(
    title = "Active Instructions",
    onBackClick = {},
    align = AppBarAlign.Start,
    background = EqualTheme.colors.bgSurface,
    elevated = true,
) {
    EqualTextButton(text = "Add", onClick = {}, leadingIcon = EqualIcons.Add)
}
```

Example: Section headers
```tsx
<SectionHeader>Your assistant</SectionHeader>
<SectionHeader qualifier="(Optional)">Guiding direction</SectionHeader>
<SectionHeader action={<TextButton size="small">Clear all</TextButton>}>
  Recommended for you
</SectionHeader>
```
```kotlin
// Pass normal text; SectionHeader uppercases it.
SectionHeader(title = "Your assistant")
// Compose: no `qualifier` slot; it is appended to the title (and uppercased with it).
SectionHeader(title = "Guiding direction (Optional)")
SectionHeader(title = "Recommended for you", actionLabel = "Clear all", onActionClick = {})
```

#### Bottom nav (`bottom-nav`)

The floating two-tab pill (Chats, You) with an unread count, beside the Equal orb FAB that opens the assistant.

- React: `import { BottomNav, Fab } from '@equal/ds';`
- Compose: `BottomNavBar`, `EqualFab`
- Tokens: `bg/surface`, `shadow/nav`, `nav/selected-bg`, `text/action`, `text/tertiary`, `text/secondary`, `button/primary`, `text/on-action`
- Source: §4 Tab Bar (Bottom Navigation)

Do: Float the nav over content and leave ~104dp bottom padding so the last row is reachable. Pass the user's gender as `avatar` so the You tab matches the profile avatar.

Don't: Don't add a third tab; the pill is Chats and You. Don't replace the FAB orb with an icon; the orb carries its own glow.

Anatomy:
1. Pill container: Floating surface that holds the two tabs. (padding 8 · radius full · bg/surface · shadow/nav)
2. Tab item: One destination capsule; the selected one is filled. (web 84 × 56, Compose 99 × 52 · radius full · selected nav/selected-bg)
3. Icon: Chats bubble (filled when selected) or the user's ProfileAvatar. (24 · selected text/action · unselected text/secondary · avatar lifted 3)
4. Count badge: Unread count on the Chats icon. (16 · 1.5 bg/surface ring · button/primary · web 99+, Compose 9+)
5. Label: Tab name under the icon. (caption 12/500 · gap 2 · selected text/action · unselected text/tertiary)
6. Fab: The Equal orb button beside the pill that opens the assistant. (58 · gap 16 · orb image carries its glow)

Accessibility:
- Role. Web: <nav aria-label='Main'> with <button> items; the current one has aria-current='page'. Fab is a <button>. Android: selectable(role = Role.Tab) per item; EqualFab is clickable(role = Role.Button). The row has no selectableGroup().
- Name. Web: Item text plus contents: 'Chats' plus the count digits, and 'Your profile You' because ProfileAvatar keeps its alt. Fab aria-label 'Talk to Equal AI'. Android: Merged text: the count then 'Chats'; the You avatar has contentDescription = null. Fab 'Ask Equal AI'.
- Keyboard. Web: Tab through Chats, You, Fab; Enter or Space activates. Android: TalkBack: swipe between tabs, announces 'selected' and 'tab'; double-tap to switch.
- Touch target. Web: Items 84 × 56, Fab 58. Android: Items 99 × 52, Fab 58.
- Contrast. Web: Unselected label text/tertiary on white 5.1:1; selected text/action #00B140 on #F1FAF3 is 2.7:1 in light; dark lime on #272C1E 11.9:1. Android: Same tokens as web.
- State. Web: aria-current='page'; selection also fills the capsule and switches the chat icon to filled, not colour alone. Android: selected semantics from selectable; the capsule fill and icon change too.
- Motion. Web: Capsule fill and colour fade over 200ms; Fab press scale; zeroed under prefers-reduced-motion. Android: Fab press scale via eqPressFeedback; tab switch is instant.

Known accessibility gaps:
- BottomNav.tsx: the You tab's name includes ProfileAvatar's alt, so it reads 'Your profile You'; pass an empty label.
- BottomNav.tsx / BottomNavBar.kt: the Chats count is read as a bare number (web aria-label on a role-less span is ignored; Compose NavCountBadge has no semantics); it should say 'N unread'.
- BottomNav.css / BottomNavBar.kt: selected label text/action #00B140 on nav/selected-bg #F1FAF3 is 2.7:1 in light mode.
- BottomNavBar.kt: the tab Row has no selectableGroup(), so TalkBack does not announce the tab count or position.
- BottomNav.tsx / BottomNavBar.kt: Fab names differ ('Talk to Equal AI' on web, 'Ask Equal AI' on Android).

Example: Interactive
```tsx
const [tab, setTab] = useState<NavTab>('chats');

<BottomNav active={tab} onChange={setTab} unread={7} />
```
```kotlin
var tab by remember { mutableStateOf(EqualTab.Chats) }

BottomNavBar(
    selectedTab = tab,
    onTabSelected = { tab = it },
    onFabClick = {},
    chatsBadgeCount = 7,
)
```

Example: You active, female avatar, no FAB
```tsx
<BottomNav active="you" avatar="female" showFab={false} />
```
```kotlin
// Compose: BottomNavBar always draws the FAB; there is no showFab = false.
BottomNavBar(
    selectedTab = EqualTab.You,
    onTabSelected = {},
    onFabClick = {},
    avatar = ProfileAvatarVariant.Female,
)
```

Example: FAB on its own
```tsx
<Fab onClick={openAssistant} />
```
```kotlin
EqualFab(onClick = {})
```

#### Chat header (`chat-header`)

Headers for the chat surfaces: the in-conversation header (with the Takeover pill on a live call), the chat-list selection header, and the home header with the assistant toggle.

- React: `import { ChatHeader, TakeoverPill, SelectionHeader, HomeHeader } from '@equal/ds';`
- Compose: `ChatHeader`, `TakeoverPill`, `SelectionChatHeader`, `HomeHeader`
- Tokens: `bg/surface`, `bg/primary`, `shadow/header`, `gradient/takeover`, `takeover/text`, `takeover/stroke`, `action/stroke/unread`, `shadow/glass`, `text/action`, `text/primary`, `text/tertiary`, `button/danger`
- Source: §5 Chat Header (In-Conversation)

Do: Show the phone number as the subtitle normally and a status line ("You have a visitor") during a live call. During a live call show only the Takeover pill; the call and more buttons go away. Route selection-mode Delete through the delete confirm sheet.

Don't: Don't show Takeover alongside the call button; that is two actions for the same intent. Don't truncate the phone number with custom styles; it is tabular and one line.

Anatomy:
1. Container: White header at the top of a conversation. (64 high · bg/surface · shadow/header · padding web 4/8, Compose h12)
2. Back button: Goes back to the chat list. (arrow-back 24 · web 36 + eq-touch, Compose 48)
3. Avatar: Contact or category avatar, or the orb for Equal AI's own chat. (36 · ContactAvatar or AiAvatar)
4. Name and subtitle: Who the chat is with, and a phone number or status line. (name subheading 16/500 text/primary · subtitle caption Regular 12/400 text/tertiary, tabular for numbers · gap 12 after avatar)
5. Trailing actions: Call and More options, or the Takeover pill on a live call. (call + more-vert 24 · web 36 + eq-touch, Compose 48)
6. TakeoverPill: Glass pill that takes over a live call. (34 high · padding h14 · gradient/takeover · 1px action/stroke/unread · shadow/glass · call-filled 18 + button text/action)
7. SelectionHeader: Selection-mode bar: count, Mark read, Delete, then Select All. (row 64 · 'N Selected' subheading · Mark read 26 high pill · delete button/danger · Select All row 40 with checkbox)
8. HomeHeader: Status bar, TopBar and the assistant toggle card on bg/primary. (bg/primary · shadow/header · toggle card padding 0 12 12)

Accessibility:
- Role. Web: <header> with IconButtons; the name is a <div>, not a heading. Takeover and Mark read are <button>s. Android: Row with PlainIconButtons (Role.Button); name is plain text with no heading().
- Name. Web: 'Back', 'Call', 'More options'; Takeover and Mark read use visible text; selection back is 'Exit selection'; the home toggle switch is 'AI Assistant'. Android: 'Back', 'Call', 'More options', 'Delete'; Takeover and Mark read by text; selection back is 'Back'.
- Keyboard. Web: Tab order: Back, Call, More (or Takeover); in selection mode Back, Mark read, Delete, Select All. Android: TalkBack: swipe in the same order; the Select All row is one checkbox node.
- Touch target. Web: 36px buttons get 48px via .eq-touch, but with a 4px gap their hit areas overlap by 8px; Takeover and Mark read use .eq-touch; Select All is 40px high. Android: Icon buttons 48dp; TakeoverPill and MarkReadPill use minimumInteractiveComponentSize(); the Select All row is 40dp high with none.
- Contrast. Web: Name 17:1, subtitle text/tertiary 5.1:1; Takeover text/action on gradient/takeover is about 2.6:1 in light, lime on #2F3423 in dark passes; delete #C50000 6.2:1. Android: Same tokens as web.
- State. Web: Live call is shown by Takeover replacing Call and More; the selection count is text but is not announced when it changes. Android: Select All exposes checked state via toggleable(Role.Checkbox); the count is plain text with no live region.
- Motion. Web: Press scale on buttons and pills; zeroed under prefers-reduced-motion. Android: eqPressFeedback on pills, following the system animator scale.

Known accessibility gaps:
- ChatHeader.tsx / ChatHeader.kt: the contact name is not a heading (web div, Compose text without heading()).
- ChatHeader.tsx / ChatHeader.kt: the 'N Selected' count is not a live region, so changes are not announced.
- ChatHeader.kt: the SelectionChatHeader Select All row is 40dp high with no minimumInteractiveComponentSize; on web the Checkbox is also 40px.
- ChatHeader.tsx: 36px icon buttons 4px apart with eq-touch give 48px hit areas that overlap by 8px.
- ChatHeader.css / ChatHeader.kt: TakeoverPill text/action on gradient/takeover is about 2.6:1 in light mode.

Example: Default
```tsx
<ChatHeader name="Amit Nanda" subtitle="+91 98717 46113"
  avatar={{ initials: 'AN' }} onBack={goBack} onCall={call} onMore={openInfo} />
```
```kotlin
ChatHeader(
    name = "Amit Nanda",
    subtitle = "+91 98717 46113",
    initials = "AN",
    onBackClick = {},
    onCallClick = {},
    onMoreClick = {},
)
```

Example: Live call
```tsx
<ChatHeader name="Arnav Raj" subtitle="You have a visitor" live
  onBack={goBack} onTakeover={takeover} />
```
```kotlin
ChatHeader(
    name = "Arnav Raj",
    subtitle = "You have a visitor",
    subtitleIsPhone = false,
    variant = ChatHeaderVariant.LiveCall,
    onBackClick = {},
    onTakeoverClick = {},
)
```

Example: Selection mode
```tsx
<SelectionHeader count={1} allSelected={false}
  onSelectAll={selectAll} onBack={exit} onMarkRead={markRead} onDelete={confirmDelete} />
```
```kotlin
var allSelected by remember { mutableStateOf(false) }

SelectionChatHeader(
    selectedCount = if (allSelected) 3 else 1,
    allSelected = allSelected,
    onSelectAllChange = { allSelected = it },
    onBackClick = {},
    onMarkReadClick = {},
    onDeleteClick = {},
)
```

Example: Home
```tsx
const [on, setOn] = useState(true);

<HomeHeader assistantOn={on} onAssistantChange={setOn} />
```
```kotlin
var on by remember { mutableStateOf(true) }

HomeHeader(assistantOn = on, onAssistantChange = { on = it })
```

Example: Takeover pill
```tsx
<TakeoverPill onClick={takeover} />
```
```kotlin
TakeoverPill(onClick = {})
```

#### Status bar (`status-bar`)

The Material 3 Android status bar (52dp: Roboto time; wifi, triangle signal and an upright battery) for mocks, flows and screen demos.

- React: `import { StatusBar } from '@equal/ds';`
- Compose: `StatusBar`
- Tokens: `bg/primary`, `text/primary`
- Source: §1 Status Bar

Do: Use it only in mocks and flow demos; the app draws edge-to-edge and pads with `WindowInsets.statusBars`. Match `background` to the surface beneath (bg/surface under white headers).

Don't: Don't add carrier names or extra icons; the Material 3 bar is time + wifi + signal + battery.

Anatomy:
1. Container: Full-width strip at the top of a mock screen. (52 high · padding h24 · bg/primary default (match the header))
2. Time: Clock text on the left. (Roboto Medium 14/20 · tracking 0.1 · tabular · text/primary)
3. System icons: Wifi, signal and battery on the right. (18 each · gap 4 · order wifi, signal, battery · text/primary)

Accessibility:
- Role. Web: Plain <div>; the icons are aria-hidden, but the time text is exposed. Android: Row with BasicText time and icons with contentDescription = null.
- Name. Web: None needed: it is a mock of system chrome and should be hidden (aria-hidden='true') so the fake '12:30' is not read. Android: Should be hidden (clearAndSetSemantics {}) in catalog screens; real apps draw under the system bar with WindowInsets.statusBars.
- Contrast. Web: text/primary on bg/primary is 17.6:1 in light, #F7F7F7 on #141414 in dark; a custom `color` must keep 4.5:1. Android: Same tokens; the `color` parameter must keep 4.5:1 on `background`.

Known accessibility gaps:
- StatusBar.tsx: the mock bar is not aria-hidden, so screen readers read the fake time '12:30'.
- HomeChrome.kt: StatusBar's time text is exposed to TalkBack; wrap it in clearAndSetSemantics {}.

Example: Default
```tsx
<StatusBar />
```
```kotlin
StatusBar()
```

Example: On a white header
```tsx
<StatusBar time="9:41" background="var(--eq-bg-surface)" />
<AppBar title="Contact Info" surface="surface" onBack={goBack} />
```
```kotlin
Column {
    StatusBar(time = "9:41", background = EqualTheme.colors.bgSurface)
    EqualAppBar(title = "Contact Info", onBackClick = {}, background = EqualTheme.colors.bgSurface)
}
```

#### Top bar (`top-bar`)

The Chats home bar: the vector Equal AI logo with the plan marker, plus the logo and mark on their own.

- React: `import { TopBar, EqualLogo, EqualMark } from '@equal/ds';`
- Compose: `TopBar`, `EqualLogo`, `EqualMark`
- Tokens: `text/action`, `gradient/gold`, `text/on-dark`
- Source: §2 Top Bar (Logo + Availability Status)

Do: Use the vector logo in text/action so it is #00B140 in light and lime in dark. Keep the logo 20dp high in the top bar.

Don't: Don't use a raster logo; the logo is coded as vector paths. Don't stretch or recolour the lockup outside text/action.

Anatomy:
1. Container: Home bar holding the logo, plan marker and trailing actions. (56 high · padding h16 · gap 8 · transparent on bg/primary)
2. EqualLogo: Six-dot mark plus 'equal ai' wordmark. (20 high · 113:24 aspect · text/action (#00B140 light, lime dark))
3. PlanBadge: Plan marker after the logo. (16 high · radius 4 · gradient/gold + text/on-dark, or expired #D0302F + white)
4. Trailing slot: Optional actions at the end, e.g. search. (pushed right by a flex spacer)
5. EqualMark: The six-dot mark alone. (width 23 default · 488:428 aspect)

Accessibility:
- Role. Web: Plain <div>; EqualLogo is an <svg role='img'>; EqualMark is aria-hidden unless given a title. Android: Row; EqualLogo is an Image; EqualMark contentDescription defaults to null.
- Name. Web: Logo reads 'Equal AI', then the badge text ('UNLIMITED' or 'PLAN EXPIRED'). Trailing buttons need their own labels. Android: EqualLogo contentDescription 'Equal AI', then the PlanBadge text.
- Keyboard. Web: Nothing focusable except what you put in `trailing`. Android: TalkBack: logo and badge are read in order; trailing actions are focusable.
- Contrast. Web: The logo is exempt as a logotype. PlanBadge white on gradient/gold is 2.2–4.3:1 (fails); the expired badge is 5.1:1. Android: Same tokens as web.
- State. Web: Plan state is in the badge text, not colour alone. Android: Same.

Known accessibility gaps:
- TopBar.tsx / HomeChrome.kt: the PlanBadge it renders has white text on gradient/gold at 2.2–4.3:1, below 4.5:1.

Example: Default
```tsx
<TopBar />
```
```kotlin
TopBar()
```

Example: Without a plan, with a trailing action
```tsx
<TopBar plan={null} trailing={<IconButton icon="search" label="Search chats" />} />
```
```kotlin
TopBar(planLabel = null) {
    EqualIconButton(icon = EqualIcons.Search, contentDescription = "Search chats", onClick = {})
}
```

Example: Logo and mark
```tsx
<EqualLogo height={20} />
<EqualLogo height={20} variant="wordmark" />
<EqualMark width={23} />
```
```kotlin
Row(horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
    EqualLogo(height = 20.dp)
    EqualLogo(height = 20.dp, variant = EqualLogoVariant.WORDMARK)
    EqualMark(width = 23.dp, color = EqualTheme.colors.textAction)
}
```

### Group: Overlays

#### Bottom sheet (`bottom-sheet`)

Sheets that rise over the current screen: the standard sheet with a floating close or title row, the centred confirm content for destructive actions, and the full-height sheet for the instruction setup chat.

- React: `import { BottomSheet, ConfirmSheetContent, FullSheet } from '@equal/ds';`
- Compose: `EqualBottomSheet`, `ConfirmSheetContent`, `FullSheet`
- Tokens: `scrim`, `sheet/bg`, `bg/surface`, `shadow/raised`, `text/secondary`, `text/primary`, `button/danger`, `text/on-danger`, `chat/wallpaper-bg`
- Source: §17 Bottom Sheet

Do: Name the thing being deleted in the title and put its number in `subject` ("Delete chat with Amit Nanda", "(+91 9871746113)"). State the consequence in the body ("This action cannot be undone."). Render overlays inside a positioned container such as PhoneFrame; use mode="inline" in docs.

Don't: Don't put a Cancel button next to the confirm; the close button and scrim are the revise path. Don't use a sheet for a quick yes/no that needs no context; use a Dialog. Don't show both a title row and the floating close.

Anatomy:
1. Scrim: Dims the screen. Tapping it closes the sheet. (scrim · fades over duration-slow)
2. Sheet container: Panel anchored to the bottom that holds the content and scrolls when tall. (sheet/bg · radius 32 top (24 with a title) · padding 24/24/28 web, 24 Compose · max height 92%)
3. Close button: Floating close in the top-right corner, shown when there is no title. (IconButton neutral 44 · bg/surface · shadow/raised · close 22 text/secondary · inset 16 web / 12 Compose)
4. Title row: Optional row: close (X) on the left and a centred title. It replaces the floating close. (grid 40 / 1fr / 40 · subheading · centred · close ghost 40 (48 in Compose))
5. ConfirmSheetContent: illustration: Centred 3D illustration above the confirm text. (72dp · illustration-trash by default)
6. ConfirmSheetContent: title, subject, body: Names the thing affected, then the consequence. (title token text/primary · subject body1 text/secondary tabular · body body1 text/secondary, 12 above)
7. ConfirmSheetContent: confirm button: One full-width commit, danger with the trash icon when destructive. (Button lg block · 45 high · 28 above · button/danger + text/on-danger)
8. FullSheet: header and body: Full-height variant: orb, title and close over the chat wallpaper, with an optional pinned footer. (top 72 · radius 24 top · header padding 14/14/14/16 · orb 32 · 1dp stroke/subtle below · chat/wallpaper-bg)

Accessibility:
- Role. Web: The sheet is role="dialog" with aria-modal in overlay mode. A title renders as an h2, and so does the ConfirmSheetContent title. FullSheet is a section with role="dialog" and aria-modal. Android: EqualBottomSheet and FullSheet are plain Boxes with no paneTitle or dialog semantics. The scrim is a Role.Button with onClickLabel 'Dismiss'.
- Name. Web: aria-label is the title, or the label prop (default 'Sheet'). Close buttons are labelled 'Close'. Android: Close icons have contentDescription 'Close'. The sheet itself has no name, so TalkBack does not announce it when it opens.
- Keyboard. Web: Escape and a scrim click call onClose. Focus is not moved into the sheet, trapped, or returned to the trigger. Android: TalkBack: swipe to the close button and double-tap. There is no BackHandler, so system Back does not close the sheet, and content behind the scrim stays in the swipe order.
- Touch target. Web: Close IconButtons (44 or 40) use eq-touch for a 48px area. The lg confirm button is 45px with no eq-touch. Android: EqualIconButton and PlainIconButton apply minimumInteractiveComponentSize (48dp), and so does the 45dp confirm button.
- Contrast. Web: Body text/secondary on sheet/bg is 7.1:1 in light and 7.6:1 in dark. Danger text/on-danger on button/danger is 6.2:1 light and 7.3:1 dark. A non-destructive primary confirm is white on green, 2.85:1 in light. Android: Same tokens and ratios. In dark the primary confirm is black on lime.
- State. Web: The closed overlay gets aria-hidden plus visibility:hidden, so it leaves the tab order. A closed FullSheet only gets aria-hidden and pointer-events:none. Android: Visibility comes from AnimatedVisibility. No open/closed state is exposed to accessibility services.
- Motion. Web: The sheet slides up and the scrim fades over duration-slow. The base.css reduced-motion rule sets these transitions to 0ms. Android: Scrim fade 200ms, slide 320ms standard (FullSheet 320ms both). Not gated on rememberReduceMotion().

Known accessibility gaps:
- BottomSheet.tsx and FullSheet in Flows.tsx: focus is not moved into the dialog, not trapped, and not returned to the trigger on close, and the page behind is not made inert.
- FullSheet in Flows.tsx: when closed, the panel is only aria-hidden and pointer-events:none, so its Close button can still be reached with Tab. Add visibility:hidden or inert.
- EqualBottomSheet (BottomSheet.kt) and FullSheet (Flows.kt) have no BackHandler and no paneTitle, and the content behind the scrim stays reachable by TalkBack.
- EqualBottomSheet and FullSheet animations are not gated on rememberReduceMotion() (BottomSheet.kt, Flows.kt).
- The ConfirmSheetContent title is not marked as a heading in Compose (BottomSheet.kt).
- The ConfirmSheetContent lg Button is 45px tall on web with no eq-touch, so it is under 48 (BottomSheet.tsx).
- Primary buttons put text/on-action white on button/primary #00B140 in light mode: 2.85:1, below AA 4.5:1 for 14sp text (Button.css / Buttons.kt). Dark (black on lime) is 17.4:1.

Example: Delete confirm (inline)
```tsx
<BottomSheet open mode="inline">
  <ConfirmSheetContent
    title={<>Delete chat with<br />Amit Nanda</>}
    subject="(+91 9871746113)"
    body="All past conversations will be deleted. This action cannot be undone."
    confirmLabel="Delete"
    destructive />
</BottomSheet>
```
```kotlin
// Compose: no inline mode; the sheet always draws over its parent with the scrim
EqualBottomSheet(visible = true, onDismissRequest = {}) {
    ConfirmSheetContent(
        title = "Delete chat with\nAmit Nanda",
        phone = "(+91 9871746113)",
        body = "All past conversations will be deleted. This action cannot be undone.",
        confirmLabel = "Delete",
        destructive = true,
        onConfirm = {},
    )
}
```

Example: Titled sheet (inline)
```tsx
<BottomSheet open mode="inline" title="Turn off WhatsApp updates?">
  <IllustrationHeader asset="illustration-whatsapp" size={120} />
  …
  <Button block size="lg">Turn off updates</Button>
</BottomSheet>
```
```kotlin
// Compose: no inline mode; the sheet always draws over its parent with the scrim
EqualBottomSheet(visible = true, onDismissRequest = {}, title = "Turn off WhatsApp updates?") {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IllustrationHeader(asset = EqualAssets.IllustrationWhatsapp, size = 120.dp)
        EqualText(
            text = "You'll stop getting call alerts and account updates on WhatsApp.",
            style = EqualTheme.type.body1,
            color = EqualTheme.colors.textSecondary,
            textAlign = TextAlign.Center,
        )
        EqualButton(text = "Turn off updates", onClick = {}, size = EqualButtonSize.Block, modifier = Modifier.padding(top = 16.dp))
    }
}
```

Example: Overlay in a phone
```tsx
<PhoneFrame height={560}>
  <Button variant="danger" leadingIcon="delete" onClick={() => setOpen(true)}>Delete chat</Button>
  <BottomSheet open={open} onClose={() => setOpen(false)}>
    <ConfirmSheetContent title={<>Delete chat with<br />Amit Nanda</>}
      subject="(+91 9871746113)" confirmLabel="Delete" destructive
      onConfirm={deleteChat} />
  </BottomSheet>
</PhoneFrame>
```
```kotlin
var open by remember { mutableStateOf(false) }
Box(Modifier.fillMaxSize()) {
    EqualButton(text = "Delete chat", onClick = { open = true }, variant = EqualButtonVariant.Danger, leadingIcon = EqualIcons.Delete)
    EqualBottomSheet(visible = open, onDismissRequest = { open = false }) {
        ConfirmSheetContent(
            title = "Delete chat with\nAmit Nanda",
            phone = "(+91 9871746113)",
            // Compose: body is required
            body = "All past conversations will be deleted. This action cannot be undone.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = { open = false },
        )
    }
}
```

Example: Full sheet
```tsx
<FullSheet open={open} onClose={() => setOpen(false)} title="Setting up instruction"
  footer={
    <ChipRow gap={8}>
      <LargeActionChip emoji="✍️" label="Edit" state="read" />
      <LargeActionChip emoji="👍" label="Confirm" onClick={confirm} />
    </ChipRow>
  }>
  <MessageList>…</MessageList>
</FullSheet>
```
```kotlin
var open by remember { mutableStateOf(false) }
FullSheet(
    visible = open,
    onDismissRequest = { open = false },
    title = "Setting up instruction",
    footer = {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LargeActionChip(label = "Edit", emoji = "✍️", onClick = {}, state = LargeActionChipState.Read)
            LargeActionChip(label = "Confirm", emoji = "👍", onClick = { open = false })
        }
    },
) {
    // Compose: no MessageList; stack bubbles in a Column
    Column(Modifier.padding(horizontal = 12.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ChatBubble(message = "Take a message & Callback request", timestamp = "03:21", type = ChatBubbleType.Outgoing, sender = "You")
        ChatBubble(message = "Got it! Here's your instruction:", timestamp = "03:21", type = ChatBubbleType.Assistant, sender = "Equal AI")
    }
}
```

#### Context menu (`context-menu`)

The long-press menu of icon + label items, and OverflowMenu, the ⋮ button that opens one anchored to a card.

- React: `import { ContextMenu, OverflowMenu } from '@equal/ds';`
- Compose: `ContextMenu`, `ContextMenuPopup`, `OverflowMenu`
- Tokens: `bg/surface`, `shadow/card`, `stroke/subtle`, `text/primary`, `text/tertiary`, `text/danger`
- Source: §18 Context Menu (Long-press)

Do: Put the destructive item last and mark it `danger`. Name the object in destructive labels ("Delete instruction", "Delete address").

Don't: Don't put more than four or five items in a menu. Don't delete straight from the menu; open the confirm sheet.

Anatomy:
1. Container: Floating surface that holds the menu items. (bg/surface · radius 12 · shadow/card · min width 131 (168 in OverflowMenu))
2. Item: One full-width row per action. (40 high · padding 0 16 0 12 web, h12 Compose · gap 10)
3. Item icon: Leading glyph for the action. (16dp · text/tertiary (text/danger when danger))
4. Item label: Verb naming the action, e.g. 'Delete instruction'. (body1 · text/primary (text/danger when danger))
5. Divider: Hairline between items. (1dp · stroke/subtle)
6. OverflowMenu: trigger: The ⋮ button that opens the menu anchored to a card. (IconButton 32 · more-vert 20 · menu 30 below, 6 in from the right)

Accessibility:
- Role. Web: The container is role="menu" and each item is a button with role="menuitem". The ⋮ trigger is a button with aria-expanded. Android: Items are clickable Rows with Role.Button. OverflowMenu opens a focusable Popup. The trigger is a clickable Box with Role.Button.
- Name. Web: Items are named by their visible label (icons are aria-hidden). The trigger's aria-label defaults to 'More options'; AddressCard passes '{label} options', and InstructionCard passes 'Instruction options'. Android: Item labels are their text. The trigger contentDescription defaults to 'More options' and uses the same strings.
- Keyboard. Web: Enter or Space on ⋮ toggles the menu. Escape or a click outside closes it. Focus stays on the trigger, and items are reached with Tab; there is no Arrow/Home/End handling. Android: The Popup is focusable, so Back or a tap outside dismisses it. TalkBack: swipe through the items, double-tap to select. The menu closes before onSelect runs.
- Touch target. Web: Items are 40px tall with no eq-touch. The 32px trigger gets 48 through IconButton's eq-touch. Android: Items are 40dp tall. The OverflowMenu trigger is a 32dp Box with no minimumInteractiveComponentSize.
- Contrast. Web: Labels text/primary 18.9:1. Icons text/tertiary 5.1:1. Danger text/danger 6.2:1 in light and 5.6:1 in dark. Android: Same tokens and ratios.
- State. Web: Open state is aria-expanded on the trigger. Danger items are marked by colour and by the explicit verb ('Delete …'). Android: Open and closed are not exposed; there is no stateDescription on the trigger. Danger items use colour plus the verb.
- Motion. Web: The menu appears without animation. Android: The Popup appears without animation.

Known accessibility gaps:
- ContextMenu.tsx and ContextMenu.kt: items are 40 tall, below the 48 minimum target.
- OverflowMenu in Flows.tsx: focus is not moved into the menu on open, and there is no Arrow/Home/End navigation or aria-haspopup="menu", all of which role=menu implies.
- OverflowMenu in Flows.kt: the 32dp trigger has no minimumInteractiveComponentSize, and it exposes no expanded/collapsed state.

Example: Chat long-press
```tsx
<ContextMenu items={[
  { label: 'Mark as read', icon: 'done-all' },
  { label: 'Call back', icon: 'call' },
  { label: 'Delete chat', icon: 'delete', danger: true },
]} />
```
```kotlin
ContextMenu(
    items = listOf(
        ContextMenuItem("Mark as read", EqualIcons.DoneAll, onClick = {}),
        ContextMenuItem("Call back", EqualIcons.Call, onClick = {}),
        ContextMenuItem("Delete chat", EqualIcons.Delete, onClick = {}, destructive = true),
    ),
)
```

Example: Overflow menu
```tsx
<OverflowMenu items={[
  { label: 'Edit', icon: 'edit', onSelect: edit },
  { label: 'Delete instruction', icon: 'delete', danger: true, onSelect: confirmDelete },
]} />
```
```kotlin
OverflowMenu(
    items = listOf(
        ContextMenuItem("Edit", EqualIcons.Edit, onClick = {}),
        ContextMenuItem("Delete instruction", EqualIcons.Delete, onClick = {}, destructive = true),
    ),
)
```

#### Dialog (`dialog`)

A centred decision dialog with a text cancel and one filled commit, plus the inverse-surface Snackbar that confirms an action afterwards.

- React: `import { Dialog, Snackbar } from '@equal/ds';`
- Compose: `EqualDialog`, `EqualDialogContent`, `EqualSnackbar`
- Tokens: `bg/surface`, `shadow/nav`, `scrim`, `text/primary`, `text/secondary`, `text/tertiary`, `button/primary`, `button/danger`, `button/secondary`
- Source: Surfaces from the Typography screen inventory · Dialog, Snackbar/Toast

Do: Commit is filled and cancel is a text action, right-aligned (rule 4). Reuse the verb from the control: Turn off → "Turn off" button → "Call learning turned off" snackbar. Offer Undo on the snackbar for reversible deletes.

Don't: Don't write "OK" / "Yes" as the commit; name the action. Don't stack a snackbar on an open dialog.

Anatomy:
1. Scrim: Dims the screen behind the dialog. Tapping it cancels. (scrim · web overlay covers the nearest positioned ancestor · Compose uses a platform Dialog window)
2. Container: Centred surface that holds the decision. (312 wide (max 100% - 48) · bg/surface · radius 24 · padding 24 · shadow/nav (web))
3. Title: The question, e.g. 'Turn off Call Learning?'. (title token · text/primary)
4. Subject: Optional line naming what the dialog applies to. (caption · text/tertiary · 2 above (web))
5. Body: States the consequence. (body1 · text/secondary · 12 above web / 8 Compose)
6. Actions: Right-aligned text cancel and a filled commit (danger when destructive). (TextButton neutral text/secondary + Button md 36 · gap 20 web / 8 Compose · 24 above)
7. Snackbar: Inverse toast confirming the action afterwards, with an optional text action such as Undo. (bg text/primary · message body1 bg/surface · radius 12 · padding 12/16 · action button/secondary web, text/action Compose)

Accessibility:
- Role. Web: The box is role="alertdialog" and the title is an h2. Snackbar is role="status". Android: EqualDialog uses a platform Dialog window. The title is plain text with no heading(). EqualSnackbar is a plain Row.
- Name. Web: aria-label is the title. The body is not linked with aria-describedby. Button names come from their visible labels. Android: TalkBack reads the dialog content in order. Button labels come from their text.
- Keyboard. Web: Buttons are reachable with Tab. There is no Escape handler, focus is not moved into the dialog or trapped, and it is not returned on close. Android: The platform Dialog takes focus, and Back calls onDismissRequest. TalkBack: swipe between title, body and buttons, double-tap to activate.
- Touch target. Web: TextButton uses eq-touch (48). The md commit Button is 36px tall with no eq-touch. The Snackbar action uses eq-touch. Android: EqualButton and EqualTextButton apply minimumInteractiveComponentSize. The Snackbar action is clickable text with no minimum size.
- Contrast. Web: Body text/secondary 7.5:1 and subject text/tertiary 5.1:1 on bg/surface. The primary commit is 2.85:1 in light and fails, while danger is 6.2:1. The Snackbar action is lime on #111 in light (15.7:1) but green on #F7F7F7 in dark (2.66:1, fails). Android: Same dialog tokens. The Snackbar action uses text/action: green on #111 is 6.6:1 in light, but lime on #F7F7F7 is 1.13:1 in dark, which fails.
- State. Web: Destructive is shown by the danger fill and the verb in the label ('Delete'), not by colour alone. Android: Same: danger variant plus a named verb.
- Motion. Web: The dialog and snackbar have no animation. Android: The platform Dialog window uses the system animation, which follows the system animation scale.

Known accessibility gaps:
- Dialog.tsx: no Escape to cancel, no aria-modal, no focus move, trap or return, and the body is not linked via aria-describedby.
- The commit Button in Dialog.tsx is md (36px) with no eq-touch, so its hit height is 36.
- EqualDialogContent (Overlays.kt): the title has no heading() semantics.
- EqualSnackbar (Overlays.kt) has no liveRegion, so TalkBack does not announce it, and its action text has no 48dp minimum target.
- Snackbar action in dark mode fails contrast: button/secondary on text/primary is 2.66:1 (Dialog.tsx), and text/action lime on #F7F7F7 is 1.13:1 (Overlays.kt).
- Primary buttons put text/on-action white on button/primary #00B140 in light mode: 2.85:1, below AA 4.5:1 for 14sp text (Button.css / Buttons.kt). Dark (black on lime) is 17.4:1.

Example: Inline
```tsx
<Dialog open mode="inline" title="Turn off Call Learning?" subject="Call learning"
  body="Your assistant will stop learning from new calls. What it already knows stays until you clear it."
  confirmLabel="Turn off" />
```
```kotlin
// EqualDialogContent is the dialog surface without the window, for inline use
EqualDialogContent(
    title = "Turn off Call Learning?",
    subject = "Call learning",
    body = "Your assistant will stop learning from new calls. What it already knows stays until you clear it.",
    confirmLabel = "Turn off",
    onConfirm = {},
    onDismiss = {},
)
```

Example: Destructive
```tsx
<Dialog open mode="inline" destructive title="Delete address?" subject="Work"
  body="Your assistant will no longer share this address with delivery partners."
  confirmLabel="Delete" />
```
```kotlin
EqualDialogContent(
    title = "Delete address?",
    subject = "Work",
    body = "Your assistant will no longer share this address with delivery partners.",
    confirmLabel = "Delete",
    destructive = true,
    onConfirm = {},
    onDismiss = {},
)
```

Example: Overlay + snackbar
```tsx
<Dialog open={open} title="Turn off Call Learning?" confirmLabel="Turn off"
  onCancel={() => setOpen(false)}
  onConfirm={() => { setOpen(false); setToast('Call learning turned off'); }} />

{toast && <Snackbar message={toast} actionLabel="Undo" onAction={undo} />}
```
```kotlin
var open by remember { mutableStateOf(false) }
var toast by remember { mutableStateOf<String?>(null) }
EqualButton(text = "Turn off Call Learning", onClick = { toast = null; open = true })
if (open) {
    EqualDialog(
        onDismissRequest = { open = false },
        title = "Turn off Call Learning?",
        subject = "Call learning",
        body = "Your assistant will stop learning from new calls. What it already knows stays until you clear it.",
        confirmLabel = "Turn off",
        onConfirm = { open = false; toast = "Call learning turned off" },
    )
}
toast?.let { EqualSnackbar(message = it, actionLabel = "Undo", onActionClick = { toast = null }) }
```

Example: Snackbars
```tsx
<Snackbar message="Contact saved" />
<Snackbar message="Chat deleted" actionLabel="Undo" onAction={undo} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    EqualSnackbar(message = "Contact saved")
    EqualSnackbar(message = "Chat deleted", actionLabel = "Undo", onActionClick = {})
}
```

#### System notification (`system-notification`)

The Android heads-up notification Equal AI posts, drawn over the status bar in mocks and flows (e.g. “Equal AI Assistant is back on”).

- React: `import { SystemNotification } from '@equal/ds';`
- Compose: `SystemNotificationPreview`
- Tokens: `component/notification/bg`, `text/primary`, `text/secondary`, `text/placeholder`
- Source: Flows: Temporarily Unavailable

Do: Keep the title under about 32 characters, so it fits on one line on a 360dp phone.

Don't: Don’t use it as an in-app toast; it stands for the OS notification.

Anatomy:
1. Shell: Rounded heads-up card. (radius 20 · padding 12 16 16 · component/notification/bg · shadow 0 8 28 / 0 1 3)
2. Header row: App name, dot and time. (micro 10 · text/primary · 3 dot text/placeholder · gap 6)
3. Orb: Equal app icon. (EqualOrb 32 · gap 10)
4. Title: Bold first line. (caption Bold · text/primary)
5. Body: Second line. (caption Regular · text/secondary)

Accessibility:
- Role. Web: role="alert" on the shell; orb is role=img. On a real device the OS draws and announces the notification. Android: No semantics beyond text; the real notification is posted with NotificationCompat.
- Name. Web: Read as app, time, "Equal AI" (orb), title and body. Android: App, time, title, body; orb contentDescription null.
- Keyboard. Web: Not interactive. Android: Not interactive in the preview.
- Contrast. Web: Title text/primary; body text/secondary 7.5:1 on white (dark 7.5:1). Android: Same tokens.
- State. Web: No state. Android: No state.
- Motion. Web: The shell has no animation; flows wrap it in .eq-heads-up (slide in), which is off under prefers-reduced-motion. Android: No animation.

Known accessibility gaps:
- role="alert" on a mock component makes screen readers interrupt as soon as a docs page or flow renders it (SystemStatus.tsx); use role="status" or none for mocks.

Example: Back on
```tsx
<SystemNotification title="Equal AI Assistant is back on"
  body="Equal AI is now handling all your unknown calls." />
```
```kotlin
// On a device, post a NotificationCompat instead; this preview is for mocks and flows
SystemNotificationPreview(
    title = "Equal AI Assistant is back on",
    body = "Equal AI is now handling all your unknown calls.",
)
```

### Group: You tab

#### AI summary card (`ai-summary-card`)

The "Your AI Summary" card, prose the assistant wrote about the user, with empty, loading and ready states.

- React: `import { AiSummaryCard } from '@equal/ds';`
- Compose: `AiSummaryCard`
- Tokens: `gradient/ai-summary`, `skeleton`, `text/primary`, `text/secondary`, `text/tertiary`
- Source: You tab · AI Summary card

Do: Write the summary in the assistant's voice, second person, short sentences. Use the loading state while the summary refreshes rather than hiding the card.

Don't: Don't show a stale summary with a spinner; use `status="loading"`. Don't use bullet lists; the summary is prose.

Anatomy:
1. Card: Soft green-tinted card for the summary. (gradient/ai-summary · radius 20 · padding 16 · min height 212 · gap 12)
2. Header: Orb and label. (orb 28 · caption · text/secondary · gap 8)
3. Body: Empty message, loading skeleton, or the summary prose. (bodyLarge text/primary · empty: Medium, centred)
4. Skeleton: Loading bars that pulse. (5 bars × 17 high · gap 4 · skeleton token · 0.95 ↔ 0.45 over 1.4s, staggered 90ms)
5. Footer: 'Last Updated: 8:06 AM' or 'Usually ready after your first few calls'. (caption Regular · text/tertiary · right-aligned)

Accessibility:
- Role. Web: A div with aria-busy while loading. The orb is role="img". The skeleton is a div with aria-label but no role. Android: A plain Column. EqualLogoOrb has contentDescription 'Equal AI'. The skeleton has no semantics.
- Name. Web: The orb reads 'Equal AI', then the label 'Your AI Summary'. 'Summary is updating' is on a div with no role, so many screen readers ignore it. Android: TalkBack reads 'Equal AI', 'Your AI Summary', the body and the footer.
- Keyboard. Web: Nothing is focusable. Android: TalkBack: swipe through the texts.
- Touch target. Web: Not interactive. Android: Not interactive.
- Contrast. Web: Body text/primary on the gradient passes. Footer text/tertiary is 4.6:1 at the #E6F7EA stop in light and 4.5:1 at #2F3423 in dark, both at the AA edge. Android: Same tokens.
- State. Web: Loading is exposed only through aria-busy; the footer text also changes to 'Last Updated'. Android: Loading is not exposed; only the footer text changes.
- Motion. Web: The skeleton pulses (eq-shimmer). Under reduced motion the base.css rule sets animation-duration to 0ms. Android: The skeleton pulse runs from rememberInfiniteTransition and does not check rememberReduceMotion().

Known accessibility gaps:
- AiSummaryCard in YouTab.tsx: the 'Summary is updating' aria-label sits on a div with no role. Use role="status" or visually hidden text so the loading state is announced.
- AiSummaryCard in YouTab.kt: the loading state has no semantics (stateDescription or contentDescription), so TalkBack can't tell it is updating.
- SummarySkeleton in YouTab.kt: the infinite pulse is not gated on rememberReduceMotion().

Example: Ready
```tsx
<AiSummaryCard summary="Your family calls you a lot. They always say it's urgent. They almost never say why." />
```
```kotlin
// Compose: status isn't inferred from summary; pass Ready explicitly
AiSummaryCard(
    status = AiSummaryStatus.Ready,
    summary = "Your family calls you a lot. They always say it's urgent. They almost never say why.",
)
```

Example: Empty
```tsx
<AiSummaryCard />
```
```kotlin
AiSummaryCard()
```

Example: Loading
```tsx
<AiSummaryCard status="loading" lastUpdated="8:06 AM" />
```
```kotlin
AiSummaryCard(status = AiSummaryStatus.Loading, lastUpdated = "8:06 AM")
```

#### Contact info header (`contact-info-header`)

The top of the Contact Info screen: a 96dp avatar, name, phone and a row of action tiles (Call, Mute, Save, Share).

- React: `import { ContactInfoHeader } from '@equal/ds';`
- Compose: `ContactInfoHeader`
- Tokens: `bg/surface`, `stroke/subtle`, `text/action`, `text/primary`, `text/secondary`
- Source: Contact Info (Contact Info)

Do: Use the four tiles Call · Mute · Save · Share, with Material Symbols icons in text/action. Flip the Mute tile label to Unmute when the contact is muted.

Don't: Don't add more than four tiles; they share one row. Don't use emoji on the tiles; these are icon tiles, not action chips.

Anatomy:
1. Avatar: Initials avatar with the saved-contact badge, or category art for unknown callers. (96dp · initials 36sp on a tinted disc · person badge 35% of size)
2. Name: Contact or caller name. (22/28 Bold · text/primary · 10 above)
3. Phone: Phone number. (bodyLarge · text/tertiary · tabular)
4. Action tiles: Row of equal-width tiles: Call, Mute, Save, Share. (72 high · radius 8 · gap 12 · bg/surface · faint shadow, 1dp stroke/subtle in dark · 24 above)
5. Tile icon: Material Symbol for the action. (24dp · text/action)
6. Tile label: Action name; Mute flips to Unmute. (body1 · text/primary · 8 below the icon)

Accessibility:
- Role. Web: The name is an h1. Each tile is a <button>, and the icon is aria-hidden. The saved badge is role="img". Android: The name is plain text with no heading(). Tiles are clickable Columns with Role.Button that merge the icon and label.
- Name. Web: Tiles are named by their label. The category avatar's alt is the category name, and the saved badge's is 'Saved contact'. Android: Tiles are named by their label. The category avatar's contentDescription is the category label, and the saved badge's is 'Saved contact'.
- Keyboard. Web: Tab through the tiles, Enter/Space to activate. The focus ring comes from eq-reset-btn. Android: TalkBack: swipe to a tile, double-tap.
- Touch target. Web: Tiles are 72 tall and about 77 wide in the 390 frame. Android: Tiles are 72dp tall and share the row width.
- Contrast. Web: Name 18.9:1 and phone text/tertiary 5.1:1. Tile icons are text/action #00B140 on white: 2.85:1, under the 3:1 icon minimum. In dark the icons are lime on #222 (13.2:1). Android: Same tokens and ratios.
- State. Web: Mute shows its state through the label (Mute / Unmute), not through colour. Android: Same, via defaultContactInfoActions(muted).
- Motion. Web: Press scale (eq-pressable), 0ms under reduced motion. Android: eqPressFeedback on press.

Known accessibility gaps:
- ContactInfoHeader tile icons (Profile.tsx / Profile.kt): text/action #00B140 on white is 2.85:1 in light, under 3:1 for icons.
- ContactInfoHeader in Profile.kt: the name has no heading() semantics.

Example: Saved contact
```tsx
<ContactInfoHeader name="Amit Nanda" phone="+91 98717 46113" avatar={{ initials: 'AN' }}
  actions={[
    { icon: 'call', label: 'Call' },
    { icon: 'silent-mode', label: 'Mute' },
    { icon: 'person-add', label: 'Save' },
    { icon: 'share', label: 'Share' },
  ]} />
```
```kotlin
ContactInfoHeader(
    name = "Amit Nanda",
    phone = "+91 98717 46113",
    initials = "AN",
    actions = listOf(
        ContactInfoAction("Call", EqualIcons.Call, onClick = {}),
        ContactInfoAction("Mute", EqualIcons.SilentMode, onClick = {}),
        ContactInfoAction("Save", EqualIcons.PersonAdd, onClick = {}),
        ContactInfoAction("Share", EqualIcons.Share, onClick = {}),
    ),
)
```

Example: Unknown caller, with history
```tsx
<ContactInfoHeader name="Arnav Raj" phone="+91 98717 46113"
  avatar={{ category: 'career' }} actions={actions} />
<SectionHeader size="label" inset={22}>Call history</SectionHeader>
<CallHistoryList>
  <CallHistoryRow direction="incoming" meta="Today • 30 Sec." time="02:30 PM" />
  <CallHistoryRow direction="missed" meta="Yesterday" time="11:04 AM" />
</CallHistoryList>
```
```kotlin
ContactInfoHeader(
    name = "Arnav Raj",
    phone = "+91 98717 46113",
    category = EqualCategory.Career,
    // Call · Mute · Save · Share
    actions = defaultContactInfoActions(onCall = {}, onMute = {}, onSave = {}, onShare = {}),
)
SectionHeader(title = "Call history")
RowGroup {
    CallHistoryRow(direction = CallDirection.Incoming, meta = "Today • 30 Sec.", time = "02:30 PM")
    CallHistoryRow(direction = CallDirection.Missed, meta = "Yesterday", time = "11:04 AM")
}
```

#### Invite card (`invite-card`)

The mint "Invite a Friend" pill at the bottom of the You tab, with the high-five art rising above it and a share button.

- React: `import { InviteCard } from '@equal/ds';`
- Compose: `InviteCard`
- Tokens: `invite/bg`, `invite/stroke`, `bg/surface`, `text/primary`, `text/secondary`
- Source: You tab · Invite card

Do: Leave ~29dp of space above the card for the art to rise into. Keep it the last item on the You tab, above the bottom nav.

Don't: Don't rotate the art again; the tilt is baked into the file. Don't crop the high-five illustration to fit the card.

Anatomy:
1. Card: Mint pill near the bottom of the You tab. (invite/bg · 1dp invite/stroke · radius 24 · min height 68 · padding 10/6/10/108 · 32 above)
2. High-five art: 3D illustration rising above the card, flush left. (illustration-high-five 113×112 · 29 above the card top · tilt baked in)
3. Title: 'Invite a Friend'. (subheading · text/primary · truncates)
4. Subtitle: 'Invite Friends To Join'. (caption Regular · text/secondary · truncates)
5. Share button: Pill button that opens sharing. (56×40 · bg/surface · share 22 · text/secondary)

Accessibility:
- Role. Web: A div. Share is a <button>. The art is <img alt="">. Android: A Box. Share is a clickable Box with Role.Button. The art has contentDescription null.
- Name. Web: Share's aria-label is 'Share invite'. Android: onClickLabel and the icon contentDescription are both 'Share invite'.
- Keyboard. Web: Tab to Share, then Enter/Space. Android: TalkBack: swipe to 'Share invite', double-tap.
- Touch target. Web: Share is 56×40 with no eq-touch, so it is 40 tall. Android: Share is 56×40dp with no minimumInteractiveComponentSize, so it is 40dp tall.
- Contrast. Web: Title text/primary 17.8:1 and subtitle text/secondary 7.0:1 on invite/bg (13.4 and 7.5:1 in dark). The share icon text/secondary on bg/surface is 7.5:1. Android: Same tokens.
- State. Web: No states. Android: No states.
- Motion. Web: Press scale only (eq-pressable), 0ms under reduced motion. Android: None.

Known accessibility gaps:
- The InviteCard share button is 56×40 with no eq-touch (YouTab.tsx/.css), and has no minimumInteractiveComponentSize (YouTab.kt), so its target is 40 tall.

Example: Default
```tsx
<InviteCard onShare={shareInvite} />
```
```kotlin
InviteCard(onShare = {})
```

Example: Custom copy
```tsx
<InviteCard title="Give a month free" subtitle="Share Equal AI with family" onShare={shareInvite} />
```
```kotlin
InviteCard(title = "Give a month free", subtitle = "Share Equal AI with family", onShare = {})
```

#### Plan card (`plan-card`)

The dark card showing the user's current plan (Equal AI UNLIMITED, ₹149/Monthly), with a Manage plan action and an expired state.

- React: `import { PlanCard } from '@equal/ds';`
- Compose: `PlanCard`
- Tokens: `plan-card/bg`, `plan-card/pill-stroke`, `plan-card/pill-bg`, `gradient/unlimited-text`, `plan-badge/expired-stroke`, `gradient/expired-badge`, `plan-card/pattern`, `text/on-dark`, `text/on-dark-secondary`, `text/accent-gold`, `text/danger`
- Source: You tab · Plan card

Do: Show the price with the period ("₹149/Monthly"); it renders in tabular figures. Use the expired state with Manage plan so renewing is one tap.

Don't: Don't replace the coded gold pattern with an image. Don't place the plan card on a white surface; it belongs in the gold hero.

Anatomy:
1. Card: Dark card for the current plan. (plan-card/bg #2B2B2B · radius 20 · padding 14/16/16)
2. Gold pattern: Coded stepped gold lines on the right side (PlanPattern). (right 60% · plan-card/pattern · stroke 0.9 · fades 0 → 0.55 → 0.8)
3. Status pill: 'Current Plan', or 'Plan Expired' on a red fill. (24 high · radius 8 · 1dp plan-card/pill-stroke · white 4% fill · caption text/on-dark · expired: plan-card/expired-pill)
4. Manage plan: Underlined text action. (buttonSmall · text/on-dark · underline)
5. Product and tier: 'Equal AI UNLIMITED' with the tier in gold. (title · text/on-dark · tier text/accent-gold · 12 above)
6. Price: Price and period, e.g. '₹149/Monthly'. (caption Regular · text/on-dark-secondary · tabular)

Accessibility:
- Role. Web: A plain div. Manage plan is a <button>. The pattern SVG is aria-hidden. Android: A Box. Manage plan is clickable text with Role.Button. The pattern Canvas has no semantics.
- Name. Web: Manage plan is named by its label (actionLabel, default 'Manage plan'). Android: Named by manageLabel.
- Keyboard. Web: Tab to Manage plan, then Enter/Space. Android: TalkBack reads the pill, product, tier and price, then 'Manage plan, button'.
- Touch target. Web: Manage plan uses eq-touch, giving at least 48. Android: Manage plan is clickable text with no minimum size, about 16dp tall.
- Contrast. Web: text/on-dark 14.2:1, text/on-dark-secondary 6.1:1, accent-gold 6.5:1 (7.7:1 dark) on #2B2B2B. White on the expired pill is 5.1:1. The card looks the same in both themes. Android: Same tokens and ratios.
- State. Web: Expired shows as the text 'Plan Expired' as well as the red fill. Android: Same: the label changes to expiredLabel.
- Motion. Web: None. Android: None.

Known accessibility gaps:
- PlanCard in YouTab.kt: 'Manage plan' is clickable text with no minimumInteractiveComponentSize, so the target is well under 48dp.

Example: Current and expired
```tsx
<PlanCard onManage={managePlan} />
<PlanCard status="expired" onManage={managePlan} />
```
```kotlin
Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    PlanCard(onManageClick = {})
    // Compose: status="expired" is a Boolean flag
    PlanCard(expired = true, onManageClick = {})
}
```

Example: Custom tier
```tsx
<PlanCard tier="LITE" price="₹49/Monthly" />
```
```kotlin
PlanCard(tier = "LITE", price = "₹49/Monthly")
```

#### Profile hero (`profile-hero`)

The gold header at the top of the You tab (avatar, name, plan marker, edit, phone) that hosts the plan card, plus the compact ProfileHeader.

- React: `import { ProfileHero, ProfileHeader } from '@equal/ds';`
- Compose: `ProfileHero`, `ProfileHeader`
- Tokens: `gradient/profile-hero`, `gradient/gold`, `text/primary`, `text/secondary`
- Source: You tab · Profile hero

Do: Put the PlanCard inside the hero as children so it sits on the gold. Drive `avatar` from the gender chosen in Personal Details.

Don't: Don't add more actions to the hero row; edit is the only one. Don't format the phone number without tabular figures.

Anatomy:
1. Hero background: Gold gradient header with two faint arcs. In dark mode it becomes a panel with rounded bottom corners. (gradient/profile-hero · arcs r250/r290, 1.2 stroke, white 55% · padding 20 top, 12 sides · dark: radius 24 bottom, ends 56 above the bottom)
2. Avatar: ProfileAvatar: the gold-ringed avatar for paid users, the plain bust for free users. (70dp · tier paid when a plan is set)
3. Name: User's name. (headline · text/primary (light tokens in both themes) · truncates)
4. Plan badge: Plan marker, e.g. UNLIMITED. (PlanBadge · 16 high · gradient/gold · text/on-dark · badge token)
5. Edit button: Opens profile editing. (28dp · icon edit-profile 18 · text/primary web, text/secondary Compose)
6. Phone: Phone number. (body1 · text/secondary · tabular)
7. Footer slot: Holds the PlanCard so it sits on the gold. (16 below the row)
8. ProfileHeader: Compact version without the gold background. (avatar 56 · gap 16 web / 12 Compose · padding 16 web)

Accessibility:
- Role. Web: A <section>. The name is an h1, the arcs are aria-hidden, and Edit is an IconButton (<button>). Android: Plain Column. The name has no heading(). Edit is a clickable Box with Role.Button.
- Name. Web: The avatar's alt is 'Your profile', and the Edit button's aria-label is 'Edit profile'. Android: ProfileAvatar contentDescription is 'Your profile'. Edit has onClickLabel and an icon contentDescription of 'Edit profile'.
- Keyboard. Web: Tab reaches Edit, then Enter/Space. Android: TalkBack: swipe to 'Edit profile', double-tap.
- Touch target. Web: Edit is 28px with eq-touch, giving a 48 area. Android: Edit is a 28dp Box with clickable and no minimumInteractiveComponentSize, so the target is 28dp, despite the code comment.
- Contrast. Web: The content renders with light tokens in both themes (data-theme="light"): name #111 on #F8E4A2 is 14.9:1, phone text/secondary 5.9:1. The gold header stays light in dark mode. Android: The row renders under EqualTheme(darkTheme = false), so the ratios match web in both themes.
- State. Web: Plan shown as badge text, e.g. 'UNLIMITED'. Android: Plan shown as badge text.
- Motion. Web: None, apart from the eq-pressable press scale on Edit, which is 0ms under reduced motion. Android: None, apart from the press feedback.

Known accessibility gaps:
- HeroRow in YouTab.kt: the 28dp edit button has no minimumInteractiveComponentSize, so its target is 28dp, not 48.
- ProfileHero (YouTab.kt) and ProfileHeader (Profile.kt): the name has no heading() semantics, while web uses an h1.

Example: You tab hero with plan card
```tsx
<ProfileHero name="Keshav" phone="+91 98789 56749" onEdit={editProfile}>
  <PlanCard onManage={managePlan} />
</ProfileHero>
```
```kotlin
ProfileHero(name = "Keshav", phone = "+91 98789 56749", onEdit = {}) {
    PlanCard(onManageClick = {})
}
```

Example: Female avatar, no plan
```tsx
<ProfileHero name="Priya Sharma" phone="+91 99100 22114" avatar="female" plan={null} onEdit={editProfile} />
```
```kotlin
ProfileHero(
    name = "Priya Sharma",
    phone = "+91 99100 22114",
    avatar = ProfileAvatarVariant.Female,
    plan = null,
    onEdit = {},
)
```

Example: Compact header
```tsx
<ProfileHeader name="Keshav" phone="+91 98789 56749" />
```
```kotlin
ProfileHeader(name = "Keshav", phone = "+91 98789 56749")
```

## Core screens (the revamped app: start every flow from these)

- `home` Chats: `<HomeScreen />`
  ```kotlin
  EqualTheme {
      HomeScreenSample()
  }
  ```
- `live` Chat, live call: `<ChatScreen live />`
  ```kotlin
  EqualTheme {
      // Compose: ChatScreenSample renders the live-call thread; the after-call variant is a web-only sample
      ChatScreenSample()
  }
  ```
- `after` Chat, after the call: `<ChatScreen chat={sampleChats[1]} />`
  ```kotlin
  EqualTheme {
      // Compose: same sample as the live call; compose the after-call thread from ChatHeader + MessageList
      ChatScreenSample()
  }
  ```
- `you-no-plan` You, no plan (free, not subscribed): `<YouScreen plan="none" />`
- `you` You, summary ready: `<YouScreen summary="ready" />`
  ```kotlin
  EqualTheme {
      YouScreenSample(summary = AiSummaryStatus.Ready)
  }
  ```
- `you-loading` You, summary loading: `<YouScreen summary="loading" />`
  ```kotlin
  EqualTheme {
      YouScreenSample(summary = AiSummaryStatus.Loading)
  }
  ```
- `you-empty` You, summary empty: `<YouScreen summary="empty" avatar="female" />`
  ```kotlin
  EqualTheme {
      YouScreenSample(summary = AiSummaryStatus.Empty, avatar = ProfileAvatarVariant.Female)
  }
  ```
- `contact` Contact info: `<ContactInfoScreen />`
  ```kotlin
  EqualTheme {
      ContactInfoScreen(name = "Amit Nanda", phone = "+91 9871746113", onBack = {})
  }
  ```
- `search` Search: `<SearchScreen />`
  ```kotlin
  EqualTheme {
      SearchScreen(onBack = {}, onOpenChat = {})
  }
  ```

## Flows (18)

### Monetization (`/flows/monetization`)

Equal Unlimited: the free-plan touchpoints that open the paywall, the paywall itself, payment results, managing and cancelling the plan, and lapsed plans. The Android team experiments here, so every screen takes the experiment knobs (price, coupon, copy, entry touchpoint) as props.

Source: Monetization Flow

1. Touchpoints (where the paywall opens from): locked rows in the chat list (blurred preview, crown-lock), a locked conversation (Unlock All Details), locked audio (Unlock Audio), Manage plan on the You tab’s plan card, and the Reactivate banners on a lapsed plan. They sit on the revamped screens as props: HomeScreen lockedFrom, ChatScreen lock (details · audio · lapsed) and YouScreen plan (none · active · restore · reactivate). Pass the entry as touchpoint so the paywall previews what the user was trying to see.
2. Paywall: gold hero with the crown, “Unlock Equal Unlimited”, the price under LIMITED TIME DISCOUNT, the preview card, the EQUAL25 coupon (APPLY → APPLIED drops ₹249 to ₹149), FAQ, and the sticky gold Unlock Unlimited with “Cancel Anytime. Automatically renews”.
3. Payment: Waiting for Confirmation (auto) → Payment Confirmed (redirect in 5s) → Congratulations (redirect to home). Pending offers Contact Support; Failed offers Retry Payment; both say the refund comes within 24 hours. Support opens the Help Center sheet.
4. After: the home header shows UNLIMITED and avatars turn gold. The You tab’s plan card has Manage plan → the subscription page (plan end date, 400k+, rating, testimonials, FAQ).
5. Cancel: tell us why (Proceed disabled until there is text) → are you really sure (Cancel / Confirm) → request submitted (redirect in 3s). Access stays until the end date; the page then offers Re-Subscribe.
6. Lapsed: the You tab shows Restore Plan or Reactivate plan with the amber banner; chats show “Reactivate your current Plan to keep using Equal Unlimited”.
7. Experiments (props, not forks): price / discountedPrice (₹249, ₹149), coupon (none · available · applied), subtitle (“Unlock Summaries…” · “Get Unlimited Summaries…”), touchpoint (chat-list · chat · audio), waitingArt (coin · cash), HomeScreen lockedFrom (how many free chats).

States:
- `home-free` Home, free plan (locked chats): `<HomeScreen tier="free" lockedFrom={4} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Free plan: rows from index 4 on are locked; tapping one opens the paywall
      HomeScreenSample(
          tier = PlanTier.Free,
          lockedFrom = 4,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onLockedChat = { /* open PaywallScreen(touchpoint = PaywallTouchpoint.ChatList) */ },
      )
  }
  ```
- `chat-locked` Chat: Unlock All Details: `<ChatScreen lock="details" />`
  ```kotlin
  EqualTheme {
      // Free plan: bubbles blurred, recording locked, Unlock All Details instead of the AI panel
      ChatScreenSample(lock = ChatLock.Details, onUnlock = { /* open PaywallScreen(touchpoint = PaywallTouchpoint.Chat) */ })
  }
  ```
- `chat-audio` Chat: Unlock Audio: `<ChatScreen lock="audio" />`
  ```kotlin
  EqualTheme {
      // Free plan: only the call summary recording is locked (Unlock Audio)
      ChatScreenSample(lock = ChatLock.Audio, onUnlock = { /* open PaywallScreen(touchpoint = PaywallTouchpoint.Audio) */ })
  }
  ```
- `paywall` Paywall (Try it: apply, unlock): `<PaywallScreen touchpoint="chat-list" />`
  ```kotlin
  EqualTheme {
      // Live: APPLY drops ₹249 to ₹149; Unlock → Waiting → Confirmed → Welcome
      PaywallScreen(touchpoint = PaywallTouchpoint.ChatList)
  }
  ```
- `paywall-chat` Paywall from a chat: `<PaywallScreen touchpoint="chat" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.Chat)
  }
  ```
- `paywall-audio` Paywall from audio, coupon applied: `<PaywallScreen touchpoint="audio" coupon="applied" subtitle="get" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.Audio, coupon = PaywallCoupon.Applied, subtitle = PaywallSubtitle.Get)
  }
  ```
- `waiting` Waiting for Confirmation: `<PaywallScreen overlay="waiting" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Waiting)
  }
  ```
- `confirmed` Payment Confirmed: `<PaywallScreen overlay="confirmed" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Confirmed)
  }
  ```
- `pending` Payment Pending: `<PaywallScreen overlay="pending" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Pending)
  }
  ```
- `failed` Payment Failed: `<PaywallScreen overlay="failed" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Failed)
  }
  ```
- `help` Help Center: `<PaywallScreen overlay="help" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Help)
  }
  ```
- `welcome` Congratulations: `<PaywallScreen overlay="welcome" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(overlay = PaywallOverlay.Welcome)
  }
  ```
- `home-paid` Home, paid: `<HomeScreen promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Paid (the default tier): nothing locked
      HomeScreenSample(promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) })
  }
  ```
- `settings-none` You: no plan yet: `<YouScreen plan="none" />`
  ```kotlin
  EqualTheme {
      // No subscription and no plan: mint header, no plan card, rows without NEW markers.
      YouScreenSample(plan = YouPlan.None)
  }
  ```
- `settings` You: Manage plan: `<YouScreen plan="active" />`
  ```kotlin
  EqualTheme {
      YouScreenSample(plan = YouPlan.Active, onManagePlan = { /* open SubscriptionScreen() */ })
  }
  ```
- `subscription` Subscription (Try it: cancel): `<SubscriptionScreen />`
  ```kotlin
  EqualTheme {
      // Live: Cancel Subscription → feedback → confirm → submitted → cancelled (Re-Subscribe)
      SubscriptionScreen()
  }
  ```
- `cancel-feedback` Cancel: tell us why: `<SubscriptionScreen cancelStep="feedback" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(cancelStep = CancelStep.Feedback)
  }
  ```
- `cancel-filled` Cancel: reason written: `<SubscriptionScreen cancelStep="feedback" reason="Felt it too expensive, I hope it would be under my budget" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(cancelStep = CancelStep.Feedback, reason = "Felt it too expensive, I hope it would be under my budget")
  }
  ```
- `cancel-confirm` Cancel: are you sure?: `<SubscriptionScreen cancelStep="confirm" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(cancelStep = CancelStep.Confirm)
  }
  ```
- `cancel-submitted` Cancel: request submitted: `<SubscriptionScreen cancelStep="submitted" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(cancelStep = CancelStep.Submitted)
  }
  ```
- `cancelled` Cancelled: Re-Subscribe: `<SubscriptionScreen state="cancelled" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(state = SubscriptionState.Cancelled)
  }
  ```
- `settings-restore` You: Restore Plan: `<YouScreen tier="free" plan="restore" />`
  ```kotlin
  EqualTheme {
      // Plan ended: free tier, Restore Plan
      YouScreenSample(tier = PlanTier.Free, plan = YouPlan.Restore, onManagePlan = { /* open PaywallScreen() */ })
  }
  ```
- `settings-reactivate` You: Reactivate plan: `<YouScreen plan="reactivate" />`
  ```kotlin
  EqualTheme {
      // Autopay off: Reactivate plan + the attached banner under the plan card
      YouScreenSample(plan = YouPlan.Reactivate, onManagePlan = { /* open SubscriptionScreen() */ })
  }
  ```
- `chat-lapsed` Chat: plan lapsed: `<ChatScreen lock="lapsed" />`
  ```kotlin
  EqualTheme {
      // Plan lapsed: readable, Reactivate banner under the header
      ChatScreenSample(lock = ChatLock.Lapsed, onUnlock = { /* open SubscriptionScreen() */ })
  }
  ```

### Temporarily unavailable (`/flows/system-status`)

What Chats shows while Equal AI is down, and how it tells you it’s back. Switch to Try it and tap “Notify me when ready” to run the whole flow.

Source: Temporarily Unavailable

1. Unavailable: the System status card takes the assistant toggle’s place, with the sleeping robot and an amber “Notify me when ready”. The promo card is hidden while the system is down.
2. Notify requested: the pill becomes a green “✓ You’ll be notified soon”. Nothing else on the screen changes.
3. Back on: a heads-up notification (“Equal AI Assistant is back on”) drops in, the toggle returns as “AI Assistant is On”, and Meet Your Assistant with “Call me” sits above Conversations.

States:
- `down` Unavailable: `<SystemStatusFlow stage="unavailable" />`
  ```kotlin
  EqualTheme {
      SystemStatusFlowSample(stage = SystemStatusStage.Unavailable)
  }
  ```
- `notified` Notify requested: `<SystemStatusFlow stage="notified" />`
  ```kotlin
  EqualTheme {
      SystemStatusFlowSample(stage = SystemStatusStage.Notified)
  }
  ```
- `back` Back on: `<SystemStatusFlow stage="back-on" />`
  ```kotlin
  EqualTheme {
      SystemStatusFlowSample(stage = SystemStatusStage.BackOn)
  }
  ```
- `live` Live flow (Try it): `<SystemStatusFlow />`
  ```kotlin
  EqualTheme {
      // No stage: tap Notify, and the system recovers after recoverAfterMillis
      SystemStatusFlowSample(recoverAfterMillis = 2500)
  }
  ```

### Profile flow (`/flows/profile`)

Personal Details, Silent Mode and WhatsApp Updates: the nested screens behind the You tab.

Source: Nested Profile Screen

1. Personal Details: the name field uses the pill shape; the helper line reads “Your AI will call you ‘Keshav’” with the first name bolded. Choosing a gender card swaps the profile avatar across the app.
2. Silent Mode: the master toggle mutes promotional calls; the five category toggles dim and lock while it’s off. Muted Contacts opens the list of people you’ve muted.
3. WhatsApp Updates: turning the toggle off never happens silently. It opens a confirm sheet with the WhatsApp illustration and a primary “Turn off updates”.

States:
- `personal` Personal Details: `<PersonalDetailsScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      PersonalDetailsScreen(onBack = {}, onChange = { name, gender -> })
  }
  ```
- `silent` Silent Mode: `<SilentModeScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      SilentModeScreen(onBack = {})
  }
  ```
- `wa` WhatsApp Updates: `<WhatsAppUpdatesScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      WhatsAppUpdatesScreen(onBack = {})
  }
  ```
- `wa-sheet` Turn-off confirm: `<WhatsAppUpdatesScreen onBack={goBack} showSheet />`
  ```kotlin
  EqualTheme {
      WhatsAppUpdatesScreen(onBack = {}, showSheet = true)
  }
  ```

### Addresses flow (`/flows/addresses`)

Empty state, the saved list with an overflow menu, the Edit Address sheet and the delete confirm.

Source: Addresses

1. Empty: the illustration, “Never explain your address again”, and a pinned “Add new Address”.
2. List: each card shows its label and address, with ⋮ → Edit / Delete address.
3. Edit / Add: a titled sheet with LABEL* chips (the selected chip is dark), two address lines, City + Pincode (6 digits, checked), an optional guiding direction and Save.
4. Delete: a confirm sheet with the trash illustration and a destructive Delete.

States:
- `empty` Empty: `<AddressesScreen onBack={goBack} initial={[]} />`
  ```kotlin
  EqualTheme {
      AddressesScreen(onBack = {}, initial = emptyList())
  }
  ```
- `list` Saved addresses: `<AddressesScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      AddressesScreen(onBack = {}, initial = SampleAddresses)
  }
  ```
- `edit` Edit Address sheet: `<AddressesScreen onBack={goBack} openEdit={sampleAddresses[3].id} />`
  ```kotlin
  EqualTheme {
      AddressesScreen(onBack = {}, openEdit = SampleAddresses[3].id)
  }
  ```
- `delete` Delete confirm: `<AddressesScreen onBack={goBack} confirmDelete={sampleAddresses[0].id} />`
  ```kotlin
  EqualTheme {
      AddressesScreen(onBack = {}, confirmDelete = SampleAddresses[0].id)
  }
  ```

### Instructions flow (`/flows/instructions`)

The hub, presets, the “Setting up instruction” chat and Active Instructions. Switch to Try it and apply an instruction end to end.

Source: Instructions

1. Hub: horizontal recommended cards (or “New suggestions coming…” once they’re all applied), an Active Instructions row, three presets and a pinned “Add New Instruction”.
2. Preset: the description plus instruction cards with When / Do rows and + Apply, which turns into Applied.
3. Setup chat, no input: You → Equal AI “Got it! Here’s your instruction:” → preview → ✍️ Edit / 👍 Confirm. Confirm adds ✅ and saves.
4. Setup chat, input needed: Equal AI asks each follow-up (the landmark, then the wait time); the answers are bolded in the preview → ✏️ Change something else / 👌 That’s all.
5. Active: cards with a source chip, WHEN / DO, and ⋮ Edit / Delete instruction; plus an empty state.

States:
- `hub` Hub: `<InstructionsFlow initialActive={[]} />`
  ```kotlin
  EqualTheme {
      InstructionsFlow(onBack = {}, initialActive = emptyList())
  }
  ```
- `preset` Preset: Screen & Protect: `<InstructionsFlow initialActive={[]} initialView={{ preset: 'screen' }} />`
  ```kotlin
  EqualTheme {
      InstructionsFlow(initialActive = emptyList(), initialView = InstructionsView.PresetDetail("screen"))
  }
  ```
- `setup` Setup chat, no input: `<InstructionSetupDemo which="decline" />`
  ```kotlin
  EqualTheme {
      InstructionSetupDemo(which = SetupDemo.Decline)
  }
  ```
- `setup-input` Setup chat, input needed: `<InstructionSetupDemo which="delivery" />`
  ```kotlin
  EqualTheme {
      InstructionSetupDemo(which = SetupDemo.Delivery)
  }
  ```
- `active` Active instructions: `<InstructionsFlow initialView="active" />`
  ```kotlin
  EqualTheme {
      InstructionsFlow(initialView = InstructionsView.Active)
  }
  ```
- `active-empty` Active, empty: `<InstructionsFlow initialActive={[]} initialView="active" />`
  ```kotlin
  EqualTheme {
      InstructionsFlow(initialActive = emptyList(), initialView = InstructionsView.Active)
  }
  ```
- `no-recs` No recommendations: `<InstructionsFlow noRecommendations />`
  ```kotlin
  EqualTheme {
      InstructionsFlow(noRecommendations = true)
  }
  ```

### Plan value & renewal (`/flows/plan-renewal`)

Before a plan ends, show what it did for the user, then make renewing one tap. Home carries the expiry strip, a call near the end brings up the What Unlimited saved you sheet, and Manage plan leads to the renewal page and the paywall.

Source: Monetization value, Monetization local components

1. Expiry strip under the home header: amber “Your Plan Expires in 2 Days”, red “Expires Today” and “Expired on 30th July”, each with Renew Now. Pass planExpiry to HomeScreen; nothing shows while the plan is comfortably active.
2. Value sheet once called: after the assistant handles a call near the end of the plan, the What Unlimited saved you sheet rises over home: calls handled, three perks, the expiry chip (03 Days amber, Today / 30th July red) and the current plan, with Renew your Equal AI. Close floats above the sheet. valueSheet="flush" is the experiment where the card is the sheet. In dark mode the card turns black with a gold glow.
3. Free plan quota: the same sheet for free users counts the week’s calls. Under the limit it reads “6 out of 30 Calls Left” with a gold progress bar; at the limit, “Limit Reached · 30 out of 30 (100%)”. Both show when the quota resets and Subscribe to Equal AI Unlimited at ₹149, with Get Equal AI Unlimited opening the paywall. Pass quotaSheet to HomeScreen.
4. Plan card: active shows Current Plan; expired shows the red Plan Expired pill and a plain avatar. Manage plan opens the plan page either way.
5. Plan page: Equal AI Unlimited hero, What Unlimited Saved You (calls, plan active until or expired on, price), What You Get, social proof and FAQ. The plan action is pinned: Cancel Subscription (gold outline) while active, Renew your Equal AI once expired, which opens the paywall with Get Equal AI Unlimited.
6. Motion (local components): APPLY strikes the old price, lands the new one with the list price and “Saved ₹100”, and pops the Special Coupon Applied! badge. The gold CTA has a sheen sweep. The waiting sheet steps through Connecting To Razorpay → Waiting for Confirmation → Verifying Transaction, then Payment Confirmed with the ray burst behind the seal. Everything holds still under reduced motion.

States:
- `home-expiring` Home: expires in 2 days: `<HomeScreen planExpiry={{ state: 'expiring', days: 2 }} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Amber strip under the header; Renew Now opens the paywall
      HomeScreenSample(
          planExpiry = PlanExpiry.Expiring(days = 2),
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `home-today` Home: expires today: `<HomeScreen planExpiry={{ state: 'today' }} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(
          planExpiry = PlanExpiry.Today,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `home-expired` Home: expired: `<HomeScreen tier="free" planExpiry={{ state: 'expired', date: '30th July' }} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(
          tier = PlanTier.Free,
          planExpiry = PlanExpiry.Expired(date = "30th July"),
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `value-sheet` Value sheet (Try it: close): `<HomeScreen planExpiry={{ state: 'expiring', days: 3 }} valueSheet promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // After a call near the end of the plan: What Unlimited saved you; close or the scrim hides it
      HomeScreenSample(
          planExpiry = PlanExpiry.Expiring(days = 3),
          valueSheet = ValueSheetVariant.Card,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `value-sheet-flush` Value sheet, flush (experiment): `<HomeScreen planExpiry={{ state: 'expiring', days: 3 }} valueSheet="flush" promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Experiment: the value card is the sheet
      HomeScreenSample(
          planExpiry = PlanExpiry.Expiring(days = 3),
          valueSheet = ValueSheetVariant.Flush,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `value-sheet-today` Value sheet: expires today: `<HomeScreen planExpiry={{ state: 'today' }} valueSheet promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(
          planExpiry = PlanExpiry.Today,
          valueSheet = ValueSheetVariant.Card,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `value-sheet-expired` Value sheet: expired: `<HomeScreen tier="free" planExpiry={{ state: 'expired', date: '30th July' }} valueSheet promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(
          tier = PlanTier.Free,
          planExpiry = PlanExpiry.Expired(date = "30th July"),
          valueSheet = ValueSheetVariant.Card,
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `quota-left` Free: 6 of 30 calls left: `<HomeScreen tier="free" quotaSheet={{ used: 24, limit: 30, resetsInDays: 4 }} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Free plan: 6 out of 30 Calls Left; Get Equal AI Unlimited opens the paywall
      HomeScreenSample(
          tier = PlanTier.Free,
          quotaSheet = Quota(used = 24, limit = 30, resetsInDays = 4),
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `quota-limit` Free: limit reached: `<HomeScreen tier="free" lockedFrom={4} quotaSheet={{ used: 30, limit: 30, resetsInDays: 2 }} promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      // Limit Reached · 30 out of 30 (100%); rows from the 5th on are locked
      HomeScreenSample(
          tier = PlanTier.Free,
          lockedFrom = 4,
          quotaSheet = Quota(used = 30, limit = 30, resetsInDays = 2),
          promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) },
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `you-active` You: plan active: `<YouScreen plan="active" />`
  ```kotlin
  EqualTheme {
      YouScreenSample(plan = YouPlan.Active, onManagePlan = { /* open SubscriptionScreen() */ })
  }
  ```
- `manage-active` Manage plan: active: `<SubscriptionScreen />`
  ```kotlin
  EqualTheme {
      // Value card (plan active until), What You Get, proof, FAQ; Cancel Subscription pinned
      SubscriptionScreen()
  }
  ```
- `you-expired` You: plan expired: `<YouScreen tier="free" plan="expired" />`
  ```kotlin
  EqualTheme {
      // Red "Plan Expired" pill, plain avatar; Manage plan opens the renewal page
      YouScreenSample(
          tier = PlanTier.Free,
          plan = YouPlan.Expired,
          onManagePlan = { /* open SubscriptionScreen(state = SubscriptionState.Expired) */ },
      )
  }
  ```
- `manage-expired` Manage plan: expired (Renew): `<SubscriptionScreen state="expired" />`
  ```kotlin
  EqualTheme {
      SubscriptionScreen(
          state = SubscriptionState.Expired,
          onRenew = { /* open PaywallScreen(cta = "Get Equal AI Unlimited") */ },
      )
  }
  ```
- `renew-paywall` Renew: paywall (Try it: apply): `<PaywallScreen touchpoint="chat-list" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      // APPLY strikes ₹249, lands ₹149 with "Saved ₹100" and pops Special Coupon Applied!
      PaywallScreen(touchpoint = PaywallTouchpoint.ChatList, cta = "Get Equal AI Unlimited")
  }
  ```
- `progress` Payment progress steps: `<PaywallScreen overlay="waiting" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      // Connecting To Razorpay → Waiting for Confirmation → Verifying Transaction (every 1.4s)
      PaywallScreen(overlay = PaywallOverlay.Waiting, cta = "Get Equal AI Unlimited")
  }
  ```
- `confirmed` Payment Confirmed: `<PaywallScreen overlay="confirmed" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      // Payment Confirmed with the ray burst behind the seal
      PaywallScreen(overlay = PaywallOverlay.Confirmed, cta = "Get Equal AI Unlimited")
  }
  ```

### Global MYA (`/flows/global-mya`)

Tap the green orb anywhere and your assistant answers in a sheet: a greeting, quick actions and suggestions, then a request typed or spoken. The request turns into a short task conversation that ends with the result to confirm.

Source: Global MYA

1. Open: the green orb (the nav FAB) opens the sheet over whatever screen you’re on: orb, “Good morning, Keshav” (name in green), “What can I help you with today?”, three quick-action tiles, suggestion chips, and a message field with the mic.
2. Type: focusing the field hides the tiles and lifts the input above the keyboard (green outline). Enter sends.
3. Speak: the mic swaps the field for Send voice note with a keyboard toggle. Tap it to record: “Try saying …”, then delete, the timer with a live waveform, and send. Or press and hold: “Release to send, slide left to cancel”, and sliding left turns the waveform red (“Release to cancel”).
4. Task: once sent, the sheet grows into a conversation titled with what the assistant is doing (“Setting up a reminder…”), with close. Your voice note (player + transcript) → Thinking… → the result card (here a WhatsApp reminder) with Edit / Confirm.
5. Inside a chat: the chat’s own AI layer (“Want me to send Amit a quick reply on WhatsApp?”) works the same way. Tapping a chip or sending a message raises the task sheet, which stops below the chat header so you can still see whose chat it is. “Replying Amit on WhatsApp” shows the drafted reply with ✏️ Edit / 📤 Send and the 📤 Send · ✏️ Edit draft · 🖋️ Custom chips. Confirming shows “Opening WhatsApp…” and greys the chips out.
6. Done: Confirm ticks the card, the sheet closes, and the chat it acted on now reads “Reminder added”. Saved contacts carry the person badge on their initials.

States:
- `home` Home (Try it: tap the orb): `<HomeScreen chats={chats} promo="meet-assistant-carousel" />`
  ```kotlin
  EqualTheme {
      // Home: tap the green orb (nav FAB) to open the live sheet
      HomeScreenSample(chats = MyaSampleChats, promo = { MeetAssistantCarousel(onDismiss = {}) })
  }
  ```
- `greeting` Greeting & quick actions: `<HomeScreen chats={chats} assistantResult={{ chatId: 'c3', preview: 'Reminder added' }} />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(chats = MyaSampleChats, promo = { MeetAssistantCarousel(onDismiss = {}) }, assistant = MyaStage.Greeting)
  }
  ```
- `chat-ai` In a chat: the AI layer (Try it): `<ChatScreen chat={amit} />`
  ```kotlin
  EqualTheme {
      // Tap Reply on WhatsApp (or send a message) to open the task sheet
      ChatScreenSample(name = "Amit Nanda", initials = "AN", category = EqualCategory.NA, subtitle = "+91 98717 46113")
  }
  ```
- `chat-task` In a chat: Replying Amit on WhatsApp: `<ChatScreen chat={amit} aiTask="draft" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(name = "Amit Nanda", initials = "AN", category = EqualCategory.NA, subtitle = "+91 98717 46113", aiTask = ChatTaskStage.Draft)
  }
  ```
- `chat-sending` In a chat: Opening WhatsApp: `<ChatScreen chat={amit} aiTask="sending" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(name = "Amit Nanda", initials = "AN", category = EqualCategory.NA, subtitle = "+91 98717 46113", aiTask = ChatTaskStage.Sending)
  }
  ```

### Monetization touchpoints (`/flows/monetization-touchpoints`)

Where a free user meets Equal Unlimited. Each touchpoint is an experiment option the Android team A/B tests, built as props on the same Home, Chat and Paywall screens.

Source: Plan Expired Touchpoint · Usage Cap Touchpoint (options 1 & 2) · Touchpoint: Actions on Home Page · Recordings + Transcripts Locked (with / without actions) · Component 25

1. Plan expired, option 1: the red PLAN EXPIRED badge, and Equal AI’s own verified chat on top (“Your Plan Expired…”, 👑 Renew Now). Its message is a voice note plus Renew Equal AI Unlimited, which opens the paywall previewing a locked summary.
2. Plan expired, option 2: no chat, a card under the header instead (👑 Your Plan Expired · Renew Now).
3. Usage cap: the assistant switches Off at the weekly limit. Option 1 is again an Equal AI message (“Weekly call limit reached…”). Option 2 is a meter card: “7 Calls left this week · Resets Mon | Unlimited on premium” with Get Unlimited.
4. Actions locked: action chips turn gold with the crown-lock. Tapping one opens the paywall (here the sheet) with “Unlock Unlimited Actions…” and the locked row as its preview.
5. Recordings locked: bubbles blur, the recording washes gold under the crown-lock, and Unlock All Details sits at the bottom. With actions, Call Back / Add to Calendar stay visible under the summary and show locked in the paywall preview.
6. Toggle art (Component 25): the phone-with-sparkles is an experiment on the toggle; the robot stays the default.

States:
- `expired-home` Plan expired 1: Equal AI chat: `<HomeScreen tier="free" planExpired official="plan-expired" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, planExpired = true, official = OfficialNotice.PlanExpired)
  }
  ```
- `expired-chat` Plan expired 1: the message: `<ChatScreen official="plan-expired" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(official = OfficialNotice.PlanExpired)
  }
  ```
- `expired-paywall` Plan expired 1: paywall: `<PaywallScreen touchpoint="recordings" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.Recordings, cta = "Get Equal AI Unlimited")
  }
  ```
- `expired-card` Plan expired 2: home card: `<HomeScreen tier="free" planExpired homeNotice="plan-expired" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, planExpired = true, homeNotice = HomeNotice.PlanExpired)
  }
  ```
- `cap-chat-home` Usage cap 1: Equal AI chat: `<HomeScreen tier="free" assistantOff official="usage-cap" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, assistantOff = true, official = OfficialNotice.UsageCap)
  }
  ```
- `cap-chat` Usage cap 1: the message: `<ChatScreen official="usage-cap" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(official = OfficialNotice.UsageCap)
  }
  ```
- `cap-card` Usage cap 2: calls left: `<HomeScreen tier="free" assistantOff homeNotice={{ callsLeft: 7, limit: 30 }} />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, assistantOff = true, homeNotice = HomeNotice.UsageCap(callsLeft = 7, limit = 30))
  }
  ```
- `actions-home` Actions locked: home (Try it): `<HomeScreen tier="free" lockedActions paywallSheet promo="meet-assistant-carousel" />`
  ```kotlin
  EqualTheme {
      // Try it: a locked chip opens the sheet paywall
      HomeScreenSample(tier = PlanTier.Free, lockedActions = true, paywallSheet = true, promo = { MeetAssistantCarousel() })
  }
  ```
- `actions-paywall` Actions locked: paywall: `<PaywallScreen touchpoint="actions" subtitle="actions" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.Actions, subtitle = PaywallSubtitle.Actions, cta = "Get Equal AI Unlimited")
  }
  ```
- `recordings` Recordings locked (without actions): `<ChatScreen chat={sampleChats[1]} lock="details" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(lock = ChatLock.Details)
  }
  ```
- `recordings-actions` Recordings locked (with actions): `<ChatScreen chat={sampleChats[1]} lock="details" summaryActions />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(lock = ChatLock.Details, summaryActions = true)
  }
  ```
- `recordings-paywall` Recordings locked: paywall: `<PaywallScreen touchpoint="recordings-actions" cta="Get Equal AI Unlimited" />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.RecordingsActions, cta = "Get Equal AI Unlimited")
  }
  ```
- `phone-toggle` Toggle art: phone (Component 25): `<HomeScreen assistantArt="phone" promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(assistantArt = AssistantToggleArt.Phone, promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) })
  }
  ```

### Sheet paywall & payment (`/flows/paywall-sheet`)

The experiment that opens the paywall as a sheet over the screen the user was on, offers EQUAL25 when they try to leave, and shows full-screen payment results. If the user closes a pending payment, every surface says it is processing and the paywall locks.

Source: Light / Dark Mode: Home Screen · Conversation Screen · All Payment States · Payment Pending: Home Screen · If User Closes the payment pending page · Dark Mode_Monetization

1. Sheet: a compact gold card (crown, Equal AI Unlimited, “Trusted by 10 Lakh+ Indians”, ₹249, EQUAL25 · APPLY) with Unlock Equal AI Unlimited. Support opens the Help Center FAQ sheet, and back returns.
2. Exit offer: tapping outside asks Leave Without Unlocking? “Claim 25% off with EQUAL25 first, go Unlimited for ₹149/month.” On home the buttons read Not Now / Claim 25% Off; in a chat, Leave / Keep 25% Off. Claim reopens the sheet at ₹149 with APPLIED. Not Now closes it and leaves the Go unlimited for ₹149 with EQUAL25 · Claim Now strip on home.
3. Results are full screens on a tinted wash with rings. Congratulations, You’re Unlimited, shows Plan active till. Payment Pending has × and Refresh Status, or Contact Support. Payment Failed has ‹ and suggests another UPI app, with Retry payment and Contact Support.
4. Closed while pending: a “Payment processing · We’ll update your order once it’s confirmed.” strip under the chat header and as a card under the home toggle. On the paywall it’s a toast above a disabled Unlock Unlimited, so nobody pays twice.
5. Dark mode: everything follows the theme switch (black and gold paywall, deep green / brown / red result washes, lime buttons).

States:
- `sheet` Sheet paywall (Try it): `<HomeScreen tier="free" paywallSheet="sheet" />`
  ```kotlin
  EqualTheme {
      // Try it: Support → Help Center, tap outside → exit offer, Claim → EQUAL25 applied
      HomeScreenSample(tier = PlanTier.Free, paywallSheetStage = PaywallSheetStage.Sheet)
  }
  ```
- `help` Help Center sheet: `<HomeScreen tier="free" paywallSheet="help" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, paywallSheetStage = PaywallSheetStage.Help)
  }
  ```
- `exit` Leave Without Unlocking?: `<HomeScreen tier="free" paywallSheet="exit" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, paywallSheetStage = PaywallSheetStage.Exit)
  }
  ```
- `offer` Declined: offer strip: `<HomeScreen tier="free" offerStrip promo="meet-assistant-carousel" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, offerStrip = true, promo = { MeetAssistantCarousel() })
  }
  ```
- `claimed` Claimed: EQUAL25 applied: `<HomeScreen tier="free" paywallSheet="claimed" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(tier = PlanTier.Free, paywallSheetStage = PaywallSheetStage.Claimed)
  }
  ```
- `chat-sheet` From a chat: sheet: `<ChatScreen chat={sampleChats[1]} lock="details" summaryActions paywallSheet="sheet" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(lock = ChatLock.Details, summaryActions = true, paywallSheetStage = PaywallSheetStage.Sheet)
  }
  ```
- `chat-exit` From a chat: Leave / Keep 25% Off: `<ChatScreen chat={sampleChats[1]} lock="details" summaryActions paywallSheet="exit" />`
  ```kotlin
  EqualTheme {
      // In a chat the exit offer reads Leave / Keep 25% Off
      ChatScreenSample(lock = ChatLock.Details, summaryActions = true, paywallSheetStage = PaywallSheetStage.Exit)
  }
  ```
- `success` Congratulations: `<PaymentResultScreen status="success" />`
  ```kotlin
  EqualTheme {
      PaymentResultScreen(status = PaymentResultStatus.Success)
  }
  ```
- `pending` Payment Pending (Try it: Refresh): `<PaymentResultScreen status="pending" />`
  ```kotlin
  EqualTheme {
      // Try it: Refresh Status → Congratulations
      PaymentResultScreen(status = PaymentResultStatus.Pending)
  }
  ```
- `failed` Payment Failed (Try it: Retry): `<PaymentResultScreen status="failed" />`
  ```kotlin
  EqualTheme {
      // Try it: Retry payment → Payment Pending
      PaymentResultScreen(status = PaymentResultStatus.Failed)
  }
  ```
- `pending-support` Pending: Contact Support: `<PaymentResultScreen status="pending" pendingAction="support" />`
  ```kotlin
  EqualTheme {
      PaymentResultScreen(status = PaymentResultStatus.Pending, pendingAction = PendingAction.Support)
  }
  ```
- `processing-chat` Closed pending: chat strip: `<ChatScreen chat={sampleChats[1]} lock="details" summaryActions paymentProcessing />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(lock = ChatLock.Details, summaryActions = true, paymentProcessing = true)
  }
  ```
- `processing-paywall` Closed pending: paywall locked: `<PaywallScreen touchpoint="recordings-actions" processing />`
  ```kotlin
  EqualTheme {
      PaywallScreen(touchpoint = PaywallTouchpoint.RecordingsActions, processing = true)
  }
  ```
- `processing-home` Closed pending: home card: `<HomeScreen paymentProcessing promo="meet-assistant" />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(paymentProcessing = true, promo = { MeetAssistantCard(onCallClick = {}, onDismiss = {}) })
  }
  ```

### Call Handling (`/flows/call-handling`)

You → Your assistant → Call Handling: which calls the assistant answers and who always rings you. New users are invited into it from home: two questions, one minute. The wording is an experiment, so the question screen takes a copy prop.

Source: Known Calls (new users)

1. Where it lives: You → Your assistant → Call Handling (“Choose which calls I answer”). New users see the “Talk With Your Assistant” home, then the dark Set up your calls takeover: “Two questions. One minute.”
2. Question 1: “Which calls should I answer? You decide. I follow.” Two radio cards: All calls, except a few and Only unknown numbers. The copy experiment (copy="whose") asks “Whose calls should I answer?”, tags All calls as ⭐ Suggested, and says what each option means for your contacts.
3. All calls: needs the contacts permission (sheet: “I need your contact list to know who is calling.”) and offers call history so frequent callers sort first. Then Anyone you want to answer yourself?: search, suggested people, all contacts with checkboxes and an A–Z index; the button counts the picks. Ends on Perfect! naming who will always ring you.
4. Only unknown numbers: ends on All Sorted! (“Your contacts will ring you, like always.”). Without the permission, All calls is dimmed and a blue note offers Give contacts permission ›.
5. Later: if the user stops halfway, home shows Finish your setup? with Finish or Skip, answer everyone. Always ring me edits the list; with no saved contacts, Direct Calls explains why it’s empty. The hero art on the contact screens is also a Lottie (call-handling-contacts).

States:
- `home-new` Home, new user: `<CallHandlingScreen />`
  ```kotlin
  EqualTheme {
      // No chats yet: the search field hides and the hero promo fills the home
      HomeScreenSample(
          chats = emptyList(),
          promo = { MeetAssistantHero() },
          assistantDescription = "Equal is managing your calls!",
      )
  }
  ```
- `exclude` Exclude contacts: `<CallHandlingScreen step="exclude" picked={[]} />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(step = CallHandlingStep.Exclude, picked = emptyList())
  }
  ```
- `exclude-picked` Exclude contacts: 2 picked: `<CallHandlingScreen step="exclude" />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(step = CallHandlingStep.Exclude)
  }
  ```
- `perfect` Perfect!: `<CallHandlingScreen step="perfect" />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(step = CallHandlingStep.Perfect)
  }
  ```
- `unknown` Only unknown numbers: `<CallHandlingScreen mode="unknown" />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(mode = CallMode.Unknown)
  }
  ```
- `whose` Copy experiment: whose calls: `<CallHandlingScreen copy="whose" mode="unknown" />`
  ```kotlin
  EqualTheme {
      // Copy experiment
      CallHandlingScreen(copy = CallHandlingCopy.Whose, mode = CallMode.Unknown)
  }
  ```
- `sorted` All Sorted!: `<CallHandlingScreen step="sorted" mode="unknown" />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(step = CallHandlingStep.Sorted, mode = CallMode.Unknown)
  }
  ```
- `no-permission` No contacts permission: `<CallHandlingScreen copy="whose" mode="unknown" contactsAllowed={false} />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(copy = CallHandlingCopy.Whose, mode = CallMode.Unknown, contactsAllowed = false)
  }
  ```
- `perm-contacts` Allow contacts: `<CallHandlingScreen copy="whose" step="perm-contacts" contactsAllowed={false} />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(copy = CallHandlingCopy.Whose, step = CallHandlingStep.PermContacts, contactsAllowed = false)
  }
  ```
- `perm-history` Allow call history: `<CallHandlingScreen copy="whose" step="perm-history" />`
  ```kotlin
  EqualTheme {
      CallHandlingScreen(copy = CallHandlingCopy.Whose, step = CallHandlingStep.PermHistory)
  }
  ```
- `finish` Finish your setup?: `<AlwaysRingScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      HomeScreenSample(
          chats = emptyList(),
          promo = { MeetAssistantHero() },
          assistantDescription = "Equal is managing your calls!",
          callSetup = CallSetupOverlay.Finish,
          onCallSetup = { /* open CallHandlingScreen(step = CallHandlingStep.Exclude) */ },
          onSkipCallSetup = { /* answer everyone */ },
      )
  }
  ```
- `no-contacts` Direct Calls: no contacts: `<DirectCallsEmptyScreen onBack={goBack} onDone={goBack} />`
  ```kotlin
  EqualTheme {
      DirectCallsEmptyScreen(onBack = { /* pop */ }, onDone = { /* pop */ })
  }
  ```
- `you` You: Call Handling row: `<YouScreen onOpen={(page) => page === "call-handling" && open("call-handling")} />`
  ```kotlin
  EqualTheme {
      YouScreenSample(onOpenCallHandling = { /* open CallHandlingScreen() */ })
  }
  ```

### Known-call notifications (`/flows/known-calls`)

When the assistant answers someone you know, Android shows an ongoing notification that tells you who it is and what they want, with quick replies, and hands the call to you when it needs you. Opening it shows the live chat.

Source: Known-call notifications

1. Answering: “Equal AI • Ongoing” with a live timer; the caller (their avatar) and “Your Equal AI is answering your call.”, with the Equal app badge.
2. Summary: the line updates to what the caller wants as the call goes on.
3. Expanded: two lines, a call button to pick up, and quick replies: Takeover first, then suggested answers the assistant can say for you.
4. Hand-off: when it needs you, the replies give way to “This needs your attention, connecting this call to you”.
5. Open: the chat shows the call live under a black Ongoing call - 02:34 strip with Takeover in the header and the assistant’s follow-up below. Android draws the notification shell; the system wallpaper here is a coded stand-in.

States:
- `answering` Answering: `<CallNotification name="Mom" state="answering" />`
  ```kotlin
  EqualTheme {
      CallNotification(name = "Mom", state = CallNotificationState.Answering)
  }
  ```
- `summary` What they want: `<CallNotification name="Mom" state="summary" summary={liveSummary} />`
  ```kotlin
  EqualTheme {
      CallNotification(name = "Mom", state = CallNotificationState.Summary, summary = SampleCallSummary)
  }
  ```
- `expanded` Expanded: quick replies: `<CallNotification name="Mom" state="expanded" replies={["Takeover", "I’ll bring them all", "I’ll call back to get more"]} onReply={reply} onAnswer={answer} />`
  ```kotlin
  EqualTheme {
      CallNotification(
          name = "Mom",
          state = CallNotificationState.Expanded,
          replies = listOf("Takeover", "I’ll bring them all", "I’ll call back to get more"),
          onReply = { /* say it (it == "Takeover": pick up) */ },
          onAnswer = { /* pick up */ },
      )
  }
  ```
- `connecting` Needs you: connecting: `<CallNotification name="Mom" state="connecting" />`
  ```kotlin
  EqualTheme {
      // Docs: on the coded wallpaper. On device the system draws the shade.
      KnownCallNotificationScreen(state = CallNotificationState.Connecting)
  }
  ```
- `chat` Live chat: `<ChatScreen chat={mom} live ongoing="02:34" />`
  ```kotlin
  EqualTheme {
      ChatScreenSample(
          name = "Mom",
          category = EqualCategory.HomeServices,
          live = true,
          ongoing = "02:34",
          onTakeover = { /* pick up */ },
      )
  }
  ```

### Search (`/flows/search`)

Search from home: names, numbers, categories and keywords across calls. Results arrive in two passes, chats first and messages after, so something useful shows while the slower search finishes.

Source: Search

1. Open: tapping “Search for names” on home opens search with the keyboard up. The bar is a green-outlined pill with back inside it.
2. Before typing: recent searches show as avatar tiles with Clear all. With none, the robot and “Search across your calls · Look for names, phone numbers, categories, keywords”.
3. Typing: green dots under CHATS, then matching chats (with their action chips). Messages load next under MESSAGES, each hit showing who, when, and the line with the match in bold.
4. Nothing found: the thinking robot, “No results found”, and a nudge to try another name, number, category or keyword.
5. Offline: the struck-through wifi, “No internet connection”. The same art works anywhere the network is needed.

States:
- `empty` Empty: `<SearchScreen keyboard state="empty" />`
  ```kotlin
  EqualTheme {
      // keyboard = true draws the system keyboard stand-in (docs only)
      SearchScreen(state = SearchState.Empty, keyboard = true)
  }
  ```
- `offline` No internet: `<SearchScreen keyboard state="offline" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.Offline, keyboard = true)
  }
  ```
- `recent` Recent searches (Try it: type): `<SearchScreen keyboard />`
  ```kotlin
  EqualTheme {
      // Live: type to run loading → chats → messages
      SearchScreen(keyboard = true)
  }
  ```
- `no-results` No results: `<SearchScreen keyboard state="no-results" query="Xyz" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.NoResults, query = "Xyz", keyboard = true)
  }
  ```
- `loading` Loading: `<SearchScreen keyboard state="loading" query="S" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.Loading, query = "S", keyboard = true)
  }
  ```
- `results` Results: chats: `<SearchScreen keyboard state="results" query="S" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.Results, query = "S", keyboard = true)
  }
  ```
- `messages-loading` Results: messages loading: `<SearchScreen keyboard state="messages-loading" query="S" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.MessagesLoading, query = "S", keyboard = true)
  }
  ```
- `messages` Results: messages included: `<SearchScreen keyboard state="messages" query="Sa" />`
  ```kotlin
  EqualTheme {
      SearchScreen(state = SearchState.Messages, query = "Sa", keyboard = true)
  }
  ```

### Call Back (`/flows/call-back`)

The AI layer calls someone back for you: it suggests what to ask, hands off to the phone’s dialer, and leaves an Outgoing call card in the chat.

Source: Call Back

1. Prompt: “Want me to give a quick call back to the clinic?” with 📞 Call Back, 🗓️ Add to Calendar and 🔔 Set reminder chips.
2. Task sheet: “Calling Dr. Mehta’s Clinic” (stops below the chat header). The assistant lists what to ask (reports, location, charges, insurance) with 📞 Call Back.
3. Hand-off: the phone’s own dialer places the call; the system draws it, so the docs show a coded stand-in.
4. Result: an Outgoing call card (“You called back Dr. Mehta’s Clinic · Bring previous medical reports”) with 📞 Call back.
5. From a missed call: when the assistant couldn’t pick up, the thread shows a missed-call card instead of a summary. With a reason: the caller’s art with a missed badge, “LIKELY CALLS FOR …” and 👍/👎. With only a name: “Valluri Called”. With nothing: “Missed by the assistant”. Its Call back opens the same task.

States:
- `live` Chat (Try it: tap Call Back): `<ChatActionScreen action="call-back" />`
  ```kotlin
  EqualTheme {
      // Runs live from the chat: tap the chip, then follow the task sheet
      ChatActionScreen(action = ChatAction.CallBack, onBack = { /* pop */ })
  }
  ```
- `ask` Calling: what to ask: `<ChatActionScreen action="call-back" step="ask" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.CallBack, step = "ask", onBack = { /* pop */ })
  }
  ```
- `dialer` Dialer (system, stand-in): `<ChatActionScreen action="call-back" step="dialer" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.CallBack, step = "dialer", onBack = { /* pop */ })
  }
  ```
- `done` Back in the chat: `<ChatActionScreen action="call-back" step="done" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.CallBack, step = "done", onBack = { /* pop */ })
  }
  ```
- `missed-reason` Missed call: with reason (Try it): `<ChatActionScreen action="call-back" missed="reason" />`
  ```kotlin
  EqualTheme {
      // The card's Call back opens the ask step
      ChatActionScreen(action = ChatAction.CallBack, missed = MissedCase.Reason, onBack = { /* pop */ })
  }
  ```
- `missed-name` Missed call: name only: `<ChatActionScreen action="call-back" missed="name" />`
  ```kotlin
  EqualTheme {
      // The card's Call back opens the ask step
      ChatActionScreen(action = ChatAction.CallBack, missed = MissedCase.Name, onBack = { /* pop */ })
  }
  ```
- `missed-unknown` Missed call: caller unknown: `<ChatActionScreen action="call-back" missed="unknown" />`
  ```kotlin
  EqualTheme {
      // The card's Call back opens the ask step
      ChatActionScreen(action = ChatAction.CallBack, missed = MissedCase.Unknown, onBack = { /* pop */ })
  }
  ```

### Mute (`/flows/mute`)

Muting a caller from the chat: the assistant double-checks, because muting means missing their calls even when they matter.

Source: Mute

1. Ask: 🔕 Mute from the AI layer opens “Muting Amit Nanda”.
2. Confirm: “Are you sure? You’ll not get any call from them even if it’s important” with 🔕 Mute.
3. Result: “This caller has been muted” and a card “+91-81720 33604 muted · Calls from this caller will be muted” with 📋 Open muted caller list.

States:
- `live` Chat (Try it: tap Mute): `<ChatActionScreen action="mute" />`
  ```kotlin
  EqualTheme {
      // Runs live from the chat: tap the chip, then follow the task sheet
      ChatActionScreen(action = ChatAction.Mute, onBack = { /* pop */ })
  }
  ```
- `confirm` Are you sure?: `<ChatActionScreen action="mute" step="confirm" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.Mute, step = "confirm", onBack = { /* pop */ })
  }
  ```
- `done` Muted: `<ChatActionScreen action="mute" step="done" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.Mute, step = "done", onBack = { /* pop */ })
  }
  ```

### Reply on WhatsApp (`/flows/reply-whatsapp`)

The assistant drafts a WhatsApp reply from the call. The user sends it as is or edits it in place, WhatsApp opens with the message entered, and the chat keeps a record.

Source: Reply On WhatsApp

1. Draft: “Replying Amit on WhatsApp”: You “Reply on whatsapp”, then the draft with ✏️ Edit / 📤 Send.
2. Edit: “Edit Message” dims the chat and floats the draft above the keyboard. The bubble grows with the text (about 11 lines, then scrolls); the green check saves.
3. Send: “send as is” → Opening WhatsApp…, chips grey out; WhatsApp opens with the message entered.
4. Confirmation: “Wrote a draft for Amit” and a WhatsApp card with the message and 👀 View message.

States:
- `live` Chat (Try it): `<ChatActionScreen action="reply-whatsapp" />`
  ```kotlin
  EqualTheme {
      // Runs live from the chat: tap the chip, then follow the task sheet
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, onBack = { /* pop */ })
  }
  ```
- `draft` Draft: `<ChatActionScreen action="reply-whatsapp" step="draft" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, step = "draft", onBack = { /* pop */ })
  }
  ```
- `sending` Opening WhatsApp: `<ChatActionScreen action="reply-whatsapp" step="sending" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, step = "sending", onBack = { /* pop */ })
  }
  ```
- `edit` Edit message: `<ChatActionScreen action="reply-whatsapp" step="edit" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, step = "edit", onBack = { /* pop */ })
  }
  ```
- `edit-long` Edit: long message: `<ChatActionScreen action="reply-whatsapp" step="edit-long" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, step = "edit-long", onBack = { /* pop */ })
  }
  ```
- `done` Confirmation: `<ChatActionScreen action="reply-whatsapp" step="done" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.ReplyWhatsApp, step = "done", onBack = { /* pop */ })
  }
  ```

### Save Contact (`/flows/save-contact`)

Saving an unknown caller as a contact from the chat, including editing the details, the contact form, and every path through the contacts permission.

Source: Save Contact

1. Prompt: “This number isn’t saved. Add Rahul to your contacts?” with 👤 Save contact.
2. Review: “Saving contact”: the pre-filled card (Rahul (Electrician), number) with ✏️ Edit / 💾 Save and “Looks right? Tap Save to add them.”
3. Edit: by voice (“What should I change?”, Hold to speak) or in the contact form. Two forms are on the table: iOS-revamp parity (grouped rows) and exact WhatsApp parity (outlined fields, Sync contact to phone).
4. No permission: a centred dialog “Allow contacts permission · Open Settings”. Back from Settings, the chat offers ▶️ Continue saving. If granted, the pre-filled card returns with ✏️ Edit / 👍 Confirm; if not, a “Contact Permission Required” card with ⚙️ Open Settings.
5. Saved: “Saved! Rahul is in your contacts now.” with 👤 View contact.

States:
- `live` Chat (Try it): `<ChatActionScreen action="save-contact" />`
  ```kotlin
  EqualTheme {
      // Runs live from the chat: tap the chip, then follow the task sheet
      ChatActionScreen(action = ChatAction.SaveContact, onBack = { /* pop */ })
  }
  ```
- `review` Review: Edit / Save: `<ChatActionScreen action="save-contact" step="review" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "review", onBack = { /* pop */ })
  }
  ```
- `saved` Saved: `<ChatActionScreen action="save-contact" step="saved" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "saved", onBack = { /* pop */ })
  }
  ```
- `edit-ask` Edit: what should I change?: `<ChatActionScreen action="save-contact" step="edit-ask" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "edit-ask", onBack = { /* pop */ })
  }
  ```
- `form` Contact form (iOS parity): `<ChatActionScreen action="save-contact" step="form" keyboard />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "form", keyboard = true, onBack = { /* pop */ })
  }
  ```
- `form-outlined` Contact form (WhatsApp parity): `<ChatActionScreen action="save-contact" step="form-outlined" keyboard />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "form-outlined", keyboard = true, onBack = { /* pop */ })
  }
  ```
- `no-permission` No permission: allow: `<ChatActionScreen action="save-contact" step="no-permission" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "no-permission", onBack = { /* pop */ })
  }
  ```
- `resume` Back from Settings: `<ChatActionScreen action="save-contact" step="resume" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "resume", onBack = { /* pop */ })
  }
  ```
- `granted` Permission granted: `<ChatActionScreen action="save-contact" step="granted" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "granted", onBack = { /* pop */ })
  }
  ```
- `denied` Still no permission: `<ChatActionScreen action="save-contact" step="denied" />`
  ```kotlin
  EqualTheme {
      ChatActionScreen(action = ChatAction.SaveContact, step = "denied", onBack = { /* pop */ })
  }
  ```

### Error states (`/flows/error-states`)

How the AI layer fails: say what happened in one line and offer the one action that fixes it.

Source: Error states

1. Generation failure: “Sorry, I couldn’t do that just now. Please try again.” with 🔄 Retry, inside the task.
2. Offline in a task: “It looks like you’re offline. Try again once you’re back online.” with 🔄 Retry.
3. Voice input failure: the AI layer asks again: “Sorry, I didn’t catch that. Could you hold and speak again?”
4. Offline sheet: over the chat, the struck wifi, “No internet connection” and Refresh. Full screen: the same with Try again, when there is nothing to show yet.

States:
- `generation` Generation failure: `<ChatErrorScreen state="generation" onRetry={retry} />`
  ```kotlin
  EqualTheme {
      ChatErrorScreen(state = ErrorState.Generation, onRetry = { /* retry */ })
  }
  ```
- `offline-reply` No internet (in a task): `<ChatErrorScreen state="offline-reply" onRetry={retry} />`
  ```kotlin
  EqualTheme {
      ChatErrorScreen(state = ErrorState.OfflineReply, onRetry = { /* retry */ })
  }
  ```
- `voice` Voice input failure: `<ChatErrorScreen state="voice" />`
  ```kotlin
  EqualTheme {
      ChatErrorScreen(state = ErrorState.Voice)
  }
  ```
- `offline-sheet` No internet (sheet): `<ChatErrorScreen state="offline-sheet" onRetry={refresh} />`
  ```kotlin
  EqualTheme {
      ChatErrorScreen(state = ErrorState.OfflineSheet, onRetry = { /* refresh */ })
  }
  ```
- `offline-screen` No internet (full screen): `<ChatErrorScreen state="offline-screen" onRetry={retry} />`
  ```kotlin
  EqualTheme {
      ChatErrorScreen(state = ErrorState.OfflineScreen, onRetry = { /* retry */ })
  }
  ```

### Contact info (`/flows/contact-info`)

The caller’s page: category avatar, name and number, four action tiles and the call history.

Source: Contact Info

1. Header: a 96dp category avatar (or initials for saved contacts), the headline name and a tabular phone number.
2. Actions: Call, Mute (toggles to Unmute), Save and Share as 72dp tiles with the icon in text/action.
3. Call history: phone_callback, phone_missed (red icon, label not red) and phone_forwarded rows inside a card.

States:
- `contact` Contact Info: `<ContactInfoScreen onBack={goBack} />`
  ```kotlin
  EqualTheme {
      ContactInfoScreen(name = "Amit Nanda", phone = "+91 9871746113", onBack = {})
  }
  ```

## Tokens

Alias colours (CSS `var(--eq-<name without component/>)`, TS `color.*`, Compose `EqualTheme.colors.*`):

- `bg/primary`  light #FAFAFA · dark #141414
- `bg/surface`  light {brand.white} · dark #1F1F1F
- `bg/overlay`  light rgba(30,30,30,0.4) · dark rgba(30,30,30,0.4)
- `text/primary`  light {brand.black} @ 80% · dark {brand.white} @ 80%
- `text/placeholder`  light {brand.black} @ 40% · dark {brand.white} @ 40%
- `text/secondary`  light {brand.black} @ 60% · dark {brand.white} @ 60%
- `text/action-disabled`  light {brand.black} @ 20% · dark {brand.white} @ 40%
- `text/action`  light {brand.green} · dark {brand.lime}
- `text/on-action`  light {brand.white} · dark {brand.black}
- `text/on-action-disabled`  light {neutrals.grey08} · dark {neutrals.grey08}
- `button/primary`  light {brand.green} · dark {brand.lime}
- `button/secondary`  light {brand.lime} · dark {brand.lime}
- `text/on-secondary`  light {brand.black} @ 80% · dark {brand.black} · derived
- `button/danger`  light {red.red08} · dark #FF5151
- `button/disabled`  light {neutrals.grey13} · dark {neutrals.grey04}
- `stroke/subtle`  light {brand.black} @ 5% · dark {brand.white} @ 8%
- `stroke/medium`  light {brand.black} @ 8% · dark {brand.white} @ 16%
- `stroke/dark`  light {brand.black} @ 32% · dark {brand.white} @ 32%
- `action/stroke/unread`  light {brand.green} @ 36% · dark {brand.lime} @ 36%
- `action/fill/unread`  light {brand.lime} @ 8% · dark {brand.lime} @ 8%
- `action/bottom-color`  light #EBEBEB · dark #191919
- `component/chat-bubble/user-bg`  light #E8FFED · dark #272C1E
- `component/chat-bubble/user-title`  light #006223 · dark {brand.lime}
- `component/action-card/highlight`  light #D3FEE3 · dark #2F3423 · derived
- `text/danger`  light {red.red08} · dark #FF5151 · derived
- `text/on-danger`  light {brand.white} · dark {brand.black} · derived
- `text/on-dark`  light {brand.white} · dark {brand.white} · derived
- `text/on-dark-secondary`  light {neutrals.grey10} · dark {neutrals.grey10} · derived
- `text/accent-gold`  light #CFA846 · dark #CFA846
- `component/chat-bubble/contact-title`  light #AF6307 · dark #FFB74D · derived
- `component/chat-bubble/other-bg`  light {brand.white} · dark #292929 · derived
- `component/plan-card/bg`  light #2E2E2E · dark #2E2E2E
- `component/plan-card/pill-stroke`  light #FFF2C3 · dark #FFF2C3
- `component/rating/star-filled`  light {brand.green} · dark {brand.lime} · derived
- `component/rating/star-empty`  light #2B2B2B @ 36% · dark {brand.white} @ 32% · derived
- `component/nav/selected-bg`  light rgba(0,177,64,0.04) · dark rgba(186,255,41,0.08) · derived
- `component/playback/pill-bg`  light #5E5E5E · dark #5E5E5E · derived
- `component/waveform/bar`  light #D9D9D9 · dark #D9D9D9 · derived
- `component/waveform/bar-played`  light {brand.green} · dark {brand.lime} · derived
- `component/notice/bg`  light #FAFFF4 · dark rgba(186,255,41,0.08) · derived
- `component/chip/when-bg`  light rgba(0,0,0,0.05) · dark rgba(255,255,255,0.08) · derived
- `component/plan-card/pattern`  light #C9A55A · dark #C9A55A · derived
- `component/invite/bg`  light #F1FFF6 · dark #272C1E · derived
- `component/invite/stroke`  light rgba(0,177,64,0.10) · dark rgba(186,255,41,0.10) · derived
- `component/chip/do-bg`  light #F0FBF4 · dark #272C1E · derived
- `component/chip/selected-bg`  light #313131 · dark #F7F7F7 · derived
- `component/chip/selected-text`  light #F7F7F7 · dark #313131 · derived
- `component/preset/tint-green`  light rgba(72,255,138,0.16) · dark rgba(186,255,41,0.16) · derived
- `component/preset/tint-orange`  light rgba(255,153,8,0.16) · dark rgba(255,153,8,0.16) · derived
- `component/icon-button/bg`  light #F2F2F2 · dark #333333 · derived
- `component/chat/wallpaper-bg`  light #F5F5F6 · dark #141414 · derived
- `component/voice/player-bg`  light {brand.white} · dark #141414 · derived
- `component/voice/player-bg-sent`  light #E1F7E6 · dark #333926 · derived
- `component/chat/wallpaper-pattern`  light rgba(115,115,115,0.08) · dark rgba(115,115,115,0.08)
- `component/status-card/pill-bg`  light #FFFFFF · dark #2E2E2E · derived
- `component/status-card/button`  light #FAAF39 · dark #F2A22C · derived
- `component/status-card/button-text`  light #3D2600 · dark #1A1A1A · derived
- `component/notification/bg`  light #FFFFFF · dark #2A2A2A · derived
- `component/brand/whatsapp`  light {brand.green} · dark {brand.lime} · derived
- `text/gold`  light #9E6A28 · dark #E8BD62 · derived
- `component/paywall/card-bg`  light #FFFDF7 · dark #221F19 · derived
- `component/paywall/card-stroke`  light #F0F0F0 · dark #3D3D3D
- `component/paywall/divider`  light #A37135 @ 50% · dark #E8BD62 @ 35% · derived
- `component/plan-banner/bg`  light #FFEFC8 · dark #33291A · derived
- `component/plan-banner/text`  light #975F19 · dark #F0C878 · derived
- `component/locked/badge-bg`  light #FCFCFC · dark #292929 · derived
- `component/expiry-banner/warning-bg`  light #FFF0D3 · dark #33291A · derived
- `component/expiry-banner/warning-text`  light #763D00 · dark #F0C878 · derived
- `component/expiry-banner/danger-bg`  light #FFE8E8 · dark #3A2224 · derived
- `component/expiry-banner/danger-text`  light #6E0000 · dark #FFA3A3 · derived
- `component/whats-new/bg`  light #E5FFE7 · dark #272C1E · derived
- `component/whats-new/glow`  light rgba(249,255,237,0.6) · dark #4F5E2F · derived
- `component/missed-call/bg`  light #FEFBFA · dark #2A2120 · derived
- `component/missed-call/stroke`  light #F8F8F8 · dark #3A2E2C · derived
- `component/missed-call/icon-bg`  light #FBEBE7 · dark #45302C · derived
- `component/missed-call/icon`  light #DB330B · dark #FF8A6B · derived
- `component/expiry-chip/warning-bg`  light #FFF1D5 · dark #FEBD6B
- `component/expiry-chip/warning-text`  light #6E4900 · dark #2D1900
- `component/expiry-chip/danger-bg`  light #FFD5D5 · dark #5A2328 · derived
- `component/expiry-chip/danger-text`  light #6E0000 · dark #FFB3B3 · derived
- `component/expiry-chip/active-bg`  light #FFF1D5 · dark #3A3020 · derived
- `component/value-card/stroke`  light #F0F0F0 · dark #3D3D3D
- `component/value-card/perks-bg`  light {brand.white} · dark #242424
- `component/value-card/ring`  light rgba(214,165,70,0.22) · dark rgba(232,189,98,0.35) · derived
- `component/plan-card/expired-pill`  light #CD3200 · dark #CD3200
- `component/sunburst/ray`  light {brand.white} @ 5% · dark {brand.white} @ 5% · derived
- `component/premium-icon/start`  light #D1A85C · dark #FEC378
- `component/premium-icon/end`  light #A0621F · dark #FA8C01
- `component/contact-avatar/blue-bg`  light #D6F1FF · dark #233843 · derived
- `component/contact-avatar/blue-text`  light #296D8E · dark #7DC4E8 · derived
- `component/contact-avatar/green-bg`  light #D5FCE2 · dark #394323 · derived
- `component/contact-avatar/green-text`  light #247B41 · dark {brand.lime} · derived
- `component/contact-avatar/purple-bg`  light #E5D5FC · dark #302343 · derived
- `component/contact-avatar/purple-text`  light #5D2E9E · dark #AA7DE8 · derived
- `component/contact-avatar/orange-bg`  light #FCE8D5 · dark #433323 · derived
- `component/contact-avatar/orange-text`  light #8E5C29 · dark #E8B27D · derived
- `component/contact-avatar/pink-bg`  light #FCD5E5 · dark #432330 · derived
- `component/contact-avatar/pink-text`  light #9E2E5D · dark #E87DAA · derived
- `component/contact-avatar/teal-bg`  light #D5FCF8 · dark #234341 · derived
- `component/contact-avatar/teal-text`  light #227770 · dark #7DE8DF · derived
- `component/contact-avatar/badge-bg`  light #FFFFFF · dark #222222 · derived
- `component/contact-avatar/badge-icon`  light #141414 · dark #F2F2F2 · derived
- `component/plan-badge/expired-bg`  light #CD3200 · dark #CD3200
- `component/profile-hero/status-bg`  light {brand.white} · dark #F8E4A2 · derived
- `component/profile-hero/status-text`  light #000000 · dark #000000 · derived
- `component/profile-hero/plain-bg`  light #F2FBF5 · dark #1E2215 · derived
- `component/info-note/bg`  light rgba(35,149,255,0.06) · dark rgba(35,149,255,0.12) · derived
- `component/ongoing-bar/bg`  light {brand.black} @ 80% · dark {brand.white} @ 80% · derived
- `component/ongoing-bar/text`  light {brand.lime} · dark {brand.black} @ 80% · derived
- `component/initials-disc/bg`  light #FFFFFF · dark #262626 · derived
- `component/paywall/hero-top`  light #FDEFC6 · dark #4A3C1C · derived
- `component/takeover/text`  light #009837 · dark #FFFFFF · derived
- `component/takeover/stroke`  light {brand.green} @ 96% · dark #58741C · derived
- `component/glass-button/default`  light {brand.white} @ 30% · dark {brand.white} @ 2% · derived
- `state/chat-pressed`  light {brand.black} @ 3% · dark {brand.white} @ 8% · derived
- `component/voice/player-stroke`  light #F8F8F8 · dark #141414 · derived
- `component/choice/default-bg`  light {brand.white} @ 30% · dark {brand.white} @ 4% · derived
- `component/plan-badge/expired-stroke`  light #8D0000 · dark #8D0000 · derived
- `component/plan-card/pill-bg`  light #272727 · dark #272727 · derived
- `component/locked/badge-stroke`  light #FFEFC8 · dark #4A3C1C · derived
- `component/expiry-banner/warning-icon-bg`  light #763D00 @ 6% · dark #F0C878 @ 12% · derived
- `component/expiry-banner/danger-icon-bg`  light #6E0000 @ 6% · dark #FFA3A3 @ 12% · derived
- `component/assistant-toggle/bg`  light #FAFFEE · dark #2B3120 · derived
- `component/preset/tint-blue`  light rgba(131,224,255,0.16) · dark rgba(131,224,255,0.16) · derived
- `component/preset/tint-lime`  light rgba(186,255,41,0.18) · dark rgba(186,255,41,0.18) · derived
- `component/gender/stroke`  light #F4F4F4 · dark rgba(255,255,255,0.08) · derived

Gradients (CSS `var(--eq-gradient-<name>)`, Compose `EqualTheme.gradients.*`):

- `gradient/fab`  light 180deg: {brand.lime} -28%, {brand.green} 100% · dark 180deg: #C9FF5C 0%, {brand.lime} 100%
- `gradient/send-disabled`  light 180deg: {brand.lime} @ 20% -28%, {brand.green} @ 20% 100% · dark 180deg: {brand.lime} @ 20% 0%, {brand.lime} @ 20% 100%
- `gradient/gold`  light radial 125% 250% at 2% 9%: #A37236 9%, #B58D55 66%, #A97B41 100% · dark radial 125% 250% at 2% 9%: #A37236 9%, #B58D55 66%, #A97B41 100%
- `gradient/chip-large`  light 180deg: #FBFFF4 0%, #F0FFD2 100% · dark 180deg: #212716 0%, #212716 100%
- `gradient/chip-small-unread`  light 180deg: {brand.lime} @ 1% 0%, {brand.lime} @ 18% 100% · dark 180deg: {brand.lime} @ 1% 0%, {brand.lime} @ 18% 100%
- `gradient/chip-small-read`  light 180deg: {brand.white} 0%, #EBEBEB @ 40% 100% · dark 180deg: #1F1F1F 0%, #1F1F1F 100%
- `gradient/takeover`  light 180deg: #E4FFED 0%, #E4FFED 100% · dark 180deg: #212615 0%, #212615 100%
- `gradient/profile-hero`  light 180deg: #F5E4AE 0%, #F7EBC0 25%, #F5EED8 50%, #F4F0EA 75%, #F7F7F7 100% · dark 180deg: #F5E4AE 0%, #F7EBC0 35%, #FBF5E8 100%
- `gradient/ai-summary`  light 45deg: #F3FBF6 0%, #FFFFFF 25%, #F8FFEA 50%, #FFFFFF 75%, #EAF9EF 100% · dark 45deg: #272A1F 0%, #1F1F1F 25%, #2E3520 50%, #1F1F1F 75%, #2B3120 100%
- `gradient/gender-selected`  light 135deg: rgba(186,255,41,0.08) 0%, rgba(186,255,41,0.08) 100% · dark 135deg: rgba(186,255,41,0.08) 0%, rgba(186,255,41,0.08) 100%
- `gradient/suggestion-card`  light 120deg: #FFFFFF 0%, #F2FBEA 60%, #E9F8EC 100% · dark 120deg: #242424 0%, #2F3423 100%
- `gradient/status-card`  light 120deg: #FEEBC8 0%, #FDF2DB 45%, #FBF9F4 100% · dark 120deg: #3A2E1A 0%, #2A2622 60%, #242424 100%
- `gradient/meet-assistant`  light 135deg: #EBF9F0 0%, #EBF9F0 60%, #F2FCEE 100% · dark 120deg: #272C1E 0%, #2F3423 100%
- `gradient/call-me`  light 90deg: {brand.green} 0%, {brand.green} 100% · dark 90deg: {brand.lime} 0%, {brand.lime} 100%
- `gradient/when-chip`  light 90deg: #FFFFFF 0%, #F4F1FF 100% · dark 90deg: rgba(36,36,36,0.2) 0%, rgba(178,160,255,0.2) 100%
- `gradient/do-chip`  light 90deg: #FFFFFF 0%, #EEFFF8 100% · dark 90deg: rgba(36,36,36,0.2) 0%, rgba(186,255,41,0.2) 100%
- `gradient/paywall-hero`  light 180deg: #FDEFC6 0%, #FEF8DD 40%, {brand.white} 70% · dark 180deg: #4A3C1C 0%, #2A241A 38%, #141414 62%
- `gradient/gold-text`  light radial 48% 93% at 46% 14%: #FFB251 0%, #603600 100% · dark radial 48% 93% at 46% 14%: #F6D48A 0%, #D9A44A 100%
- `gradient/cta-gold`  light radial 125% 250% at 2% 9%: #A37236 9%, #C8A774 66%, #AF854C 100% · dark radial 125% 250% at 2% 9%: #A37236 9%, #C8A774 66%, #AF854C 100%
- `gradient/status-neutral`  light 180deg: #E1E1E1 0%, #F4F4F4 50%, {brand.white} 100% · dark 180deg: #434343 0%, #2F2F2F 50%, #1F1F1F 100%
- `gradient/status-success`  light 180deg: #C7FAD7 0%, #E3FDEA 50%, {brand.white} 100% · dark 180deg: #384321 0%, #2A2F20 50%, #1F1F1F 100%
- `gradient/status-warning`  light 180deg: #FFDDC2 0%, #FFF3E8 50%, {brand.white} 100% · dark 180deg: #43372E 0%, #2F2A26 50%, #1F1F1F 100%
- `gradient/status-danger`  light 180deg: #FFD0D0 0%, #FFECEF 50%, {brand.white} 100% · dark 180deg: #432B2B 0%, #2F2424 50%, #1F1F1F 100%
- `gradient/status-gold`  light 180deg: #FDEFC6 0%, #FFFAE3 50%, {brand.white} 100% · dark 180deg: #3F382A 0%, #2D2A24 50%, #1F1F1F 100%
- `gradient/value-card`  light 180deg: #FBE399 0%, #FEF6D5 25%, {brand.white} 60% · dark 180deg: #4A2C00 0%, #180E01 45%, {brand.black} 100%
- `gradient/voice-note`  light 180deg: {brand.lime} -28%, {brand.green} 100% · dark 180deg: #C9FF5C 0%, {brand.lime} 100%
- `gradient/choice-stroke`  light 74deg: {brand.green} 9%, {brand.lime} 55%, rgba(7,170,66,0.94) 100% · dark 74deg: {brand.lime} 0%, {brand.lime} 100%
- `gradient/setup-done`  light 180deg: #E9F8F9 0%, #F2F8EF 50%, #EDF9D4 100% · dark 180deg: #13201F 0%, #161D17 50%, #222814 100%
- `gradient/setup-prompt`  light 180deg: {brand.black} @ 45% 0%, {brand.black} @ 45% 41%, {brand.black} 100% · dark 180deg: {brand.black} @ 45% 0%, {brand.black} @ 45% 41%, {brand.black} 100%
- `gradient/unlimited-text`  light 90deg: #FFF8C7 -28%, #CFA846 55% · dark 90deg: #FFF8C7 -28%, #CFA846 55%
- `gradient/coupon-stroke`  light radial 48% 116% at 46% 14%: #FFB251 @ 24% 0%, #603600 @ 24% 100% · dark radial 48% 116% at 46% 14%: #FFB251 @ 32% 0%, #E8BD62 @ 32% 100%
- `gradient/cta-renew`  light radial 106% 100% at 50% 0%: #D1A85C 0%, #A0621F 100% · dark radial 106% 100% at 50% 0%: #D1A85C 0%, #A0621F 100%
- `gradient/expired-badge`  light 90deg: #BF3D28 0%, #E4918C 50%, #A43129 100% · dark 90deg: #BF3D28 0%, #E4918C 50%, #A43129 100%
- `gradient/gender-selected-stroke`  light 86deg: #00B140 0%, #BAFF29 51%, rgba(7,170,66,0.94) 100% · dark 86deg: #BAFF29 0%, #BAFF29 51%, rgba(186,255,41,0.94) 100%

Typography (DM Sans; `<Text variant>`, `.eq-t-<name>`, `EqualTheme.type.<name>`):

- `headline`  24/32 weight 500
- `title`  20/28 weight 500
- `subheading`  16/24 weight 500
- `bodyLarge`  16/24 weight 400
- `body2`  14/22 weight 500
- `body1`  14/22 weight 400
- `body1Italic`  14/22 weight 400
- `button`  14/20 weight 500
- `buttonSmall`  12/16 weight 500
- `caption`  12/16 weight 500
- `captionWrap`  12/18 weight 400
- `micro`  12/16 weight 500
- `overline`  11/16 weight 500
- `badge`  10/12 weight 500
- `badgeCount`  10/12 weight 500

Spacing: 0 · 2 · 4 · 6 · 8 · 10 · 12 · 16 · 20 · 24 · 32 · 40 · 48

Radius: xs 4 · sm 8 · md 12 · lg 16 · xl 20 · 2xl 24 · 3xl 32 · full 999

Size: touchTarget 48 · statusBar 52 · appBar 64 · icon {"xs":16,"sm":20,"md":24} · avatar {"xs":24,"sm":28,"md":36,"lg":48} · frame {"width":390,"height":800}

## Image assets

Web `<Asset name="…" size={dp} />`, Compose `EqualAssetImage(EqualAssets.<PascalName>, size)`. "needed" means only a placeholder ships today; ask the designer for it.

- `mascot-robot`: Robot mascot — AI Assistant card on Chats (40dp, via <Mascot>)
- `avatar-male`: Profile avatar (male): You tab header + bottom-nav "You"
- `avatar-female`: Profile avatar (female): You tab header + bottom-nav "You"
- `illustration-high-five`: Invite a Friend card: 113 × 112, flush left, 29dp above the card (tilt baked into the file)
- `illustration-trash`: Delete confirm sheet (72dp)
- `logo-orb-light`: Equal orb, light mode (#00B140): AI avatar, FAB
- `logo-orb-dark`: Equal orb, dark mode (lime): AI avatar, FAB
- `illustration-silent-mode`: Silent Mode header (3D bell + phone, 160dp)
- `illustration-whatsapp`: WhatsApp Updates header + turn-off sheet (3D WhatsApp phone, 160 / 120dp)
- `illustration-addresses-empty`: Addresses empty state (robot on a map, 200dp)
- `illustration-instructions-empty`: Active Instructions empty state (robot on a book, 200dp)
- `illustration-suggestions`: "New suggestions coming…" card (robot with call bubbles, 120dp)
- `avatar-male-bust`: Gender card, male (bust without the ring). Falls back to avatar-male
- `avatar-female-bust`: Gender card, female (bust without the ring). Falls back to avatar-female
- `mascot-sleeping`: System status card: sleeping robot with its warm glow (104dp)
- `avatar-assistant`: Meet Your Assistant card: the assistant persona with the orb badge (84 × 94 compact, 96 × 108 banner)
- `crown-gold`: Monetization: 3D gold crown (supplied still; animated in code by AnimatedCrown until the rotating video is exported), paywall hero (64dp), Unlock All Details (56dp), Congratulations (100dp)
- `premium-glow`: Premium glow: the cream-gold radial with soft light rings behind premium cards (value sheet, quota card). Light theme; dark uses the coded black-gold gradient
- `assistant-phone`: Experiment (Component 25): 3D phone with sparkles on the AI Assistant toggle instead of the robot (36dp). The robot stays the default
- `illustration-search`: Search empty state: the robot with a magnifier and sparkles; "Search across your calls" (200dp)
- `illustration-no-internet`: No-internet state: 3D wifi with a red strike; "No internet connection" (140dp). Reusable on any screen that needs the network
- `illustration-no-results`: No-results state: the robot thinking with a question mark; "No results found" (160dp)
- `system-keyboard`: Stand-in for the Android keyboard (Gboard) in docs and previews only; never ship it in the app (390 × 300)
- `call-handling-all`: Call Handling: you with Mom (favourite) and an Unknown caller; "Which calls should I answer?" hero (280dp)
- `call-handling-exclude`: Call Handling: you with Mom and Didi (favourites); "Anyone you want to answer yourself?" hero (280dp). Animated version: lottie call-handling-contacts
- `call-handling-done`: Call Handling: the robot on a call between Mom and Unknown; Perfect! / All Sorted! (300dp)
- `call-setup`: Call Handling: the robot between a ringing call and an unknown call; "Set up your calls" (240dp)
- `permission-contacts`: Permission sheet: 3D orange contact book; "Allow contacts permission" (100dp)
- `permission-call-history`: Permission sheet: the robot with a call-history phone; "Allow call history" (100dp)
- `illustration-no-contacts`: Empty state: 3D address book; "No contacts saved" (140dp)
- `value-card-pattern`: Plan page value card: gold circuit-line pattern across the top (SVG, 329 × 192)
- `feature-call-screening`: Plan page What You Get: 3D gold phone with sparkle, 24/7 Unlimited Call Screening (28dp)
- `feature-recordings`: Plan page What You Get: 3D gold phone with sound bars, Unlimited Recordings (28dp)
- `feature-summaries`: Plan page What You Get: 3D gold summary card with phone, Unlimited Summaries (28dp)
- `crown-lock`: Monetization: Premium Lock (SVG), the gold crown with a padlock on locked rows, bubbles and the audio scrubber (16–20dp)
- `coupon-seal`: 3D gold % seal; Monetization: gold % seal on the coupon ticket (28dp)
- `status-waiting`: Monetization: 3D rupee coin, Waiting for Confirmation (100dp)
- `status-waiting-cash`: Monetization: 3D cash stack, Waiting for Confirmation variant (100dp)
- `status-confirmed`: Monetization: green check seal, Payment Confirmed (100dp)
- `status-pending`: Monetization: orange ! seal, Payment Pending (100dp)
- `status-failed`: Monetization: red ✕ seal, Payment Failed (100dp)
- `emoji-sad`: Monetization: 3D sad face, cancellation feedback / Are you sure (100dp)
- `thumbs-up`: Monetization: 3D thumbs up, Your Request is Submitted (100dp)
- `star-gold`: Monetization: 3D star in the “Rated 4.5/5” pill (20dp)
- `avatar-testimonial-1`: Subscription page: testimonial avatar (36dp)
- `avatar-testimonial-2`: Subscription page: testimonial avatar (36dp)
- `avatar-testimonial-3`: Subscription page: testimonial avatar (36dp)

## Icons (Material Symbols, Outlined 400; `-fill` = filled)

Web `<Icon name="…" />`, Compose `EqualIcon(EqualIcons.<PascalName>)`.

`arrow-back` (arrow_back) · `call` (call) · `call-filled` (call-fill) · `more-vert` (more_vert) · `send` (send-fill) · `check` (check) · `done-all` (done_all) · `close` (close) · `delete` (delete) · `star` (star-fill) · `star-outline` (star) · `share` (share) · `chevron-right` (chevron_right) · `chevron-down` (keyboard_arrow_down) · `checkbox-blank` (check_box_outline_blank) · `checkbox-checked` (check_box-fill) · `play` (play_arrow-fill) · `pause` (pause-fill) · `chat` (chat_bubble-fill) · `chat-outline` (chat_bubble) · `search` (search) · `edit` (edit) · `edit-profile` (border_color) · `add` (add) · `mic` (mic) · `mute` (volume_off) · `person-add` (person_add) · `calendar` (calendar_month) · `place` (location_on) · `call-received` (call_received) · `call-made` (call_made) · `call-missed` (call_missed) · `phone-incoming` (phone_callback) · `phone-missed` (phone_missed) · `phone-outgoing` (phone_forwarded) · `info` (info) · `settings` (settings) · `home` (home) · `work` (work) · `bolt` (bolt) · `instructions` (note_stack) · `health-check` (health_metrics) · `silent-mode` (notifications_off) · `voice-language` (mic) · `address-pin` (pin_drop) · `account-data` (shield) · `help-center` (question_exchange) · `whatsapp` (brand:siWhatsapp) · `menu` (menu) · `arrow-forward` (arrow_forward) · `content-copy` (content_copy) · `light-mode` (light_mode) · `dark-mode` (dark_mode) · `contrast` (contrast) · `touch` (touch_app) · `notify-me` (notifications_active) · `translate` (translate_indic) · `call-sparkle` (custom:call-sparkle) · `help-circle` (help-fill) · `lock` (lock-fill) · `mail` (mail-fill) · `info-fill` (info-fill) · `signal` (signal_cellular_4_bar-fill) · `wifi` (wifi-fill) · `battery` (battery_full-fill) · `timer` (timer-fill) · `person` (person-fill) · `call-log` (call_log-fill) · `call-sparkle-fill` (custom:call-sparkle-fill) · `auto-fix` (wand_stars-fill) · `keyboard` (keyboard) · `mic-fill` (mic-fill) · `navigation` (navigation-fill) · `slide-left` (keyboard_double_arrow_left) · `globe` (public-fill) · `verified` (verified-fill) · `refresh` (refresh) · `graphic-eq` (graphic_eq) · `phone-missed-fill` (phone_missed-fill) · `thumb-up` (thumb_up) · `thumb-down` (thumb_down) · `thumb-up-fill` (thumb_up-fill) · `thumb-down-fill` (thumb_down-fill)
